% Generated from Funcons/alloc#1.csf

sigdec(alloc,computes(variables),[_]).

onestep(alloc(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(alloc(E),F).

onestep(alloc(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(alloc(E),F).

onestep(alloc(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(alloc(E),F).

sigdec(alloc,computes(variables),[_]).

onestep(alloc(A),L,H,run) :-     rewrites(A,E),     rewrites(I,C),     eq_label(L,[store=B|D]),     rewrites(B,C),     eq_label(D,[store+=_|G]),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,K),     rewrites(fresh_var(I),J),     unobs(G),     rewrites(J,H),     rewrites(map_update(I,J,K),M),     eq_label(L,[store+=M|_]).

onestep(alloc(A),D,variables(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

sigdec(alloc_uninitialised,computes(variables),[types]).

onestep(alloc_uninitialised(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(alloc_uninitialised(E),F).

onestep(alloc_uninitialised(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(alloc_uninitialised(E),F).

onestep(alloc_uninitialised(A),I,F,run) :-     rewrites(A,_),     rewrites(G,C),     eq_label(I,[store=B|D]),     rewrites(B,C),     eq_label(D,[store+=_|E]),     rewrites(fresh_var(G),H),     unobs(E),     rewrites(H,F),     rewrites(map_update(G,H,undefined),J),     eq_label(I,[store+=J|_]).

onestep(alloc_uninitialised(A),G,variables(D),inhabit) :-     rewrites(A,B),     pre_comp(G,E),     rewrites(B,C),     inhabit(C,E,types) ->     mid_comp(E,F),     typeval(C,F,D) ->     post_comp(E,F,G). 

