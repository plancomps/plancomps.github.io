% Generated from Funcons/bind#1.csf

sigdec(bind,patts,[ids]).

onestep(bind(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(bind(E),F).

onestep(bind(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(bind(E),F).

onestep(bind(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(bind(E),F).

sigdec(bind,computes(patts),[computes(ids)]).

rewrite(bind(A),H) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,val),     checktag(C,val,D),     rewrites(D,E),     rewrites(given,F),     rewrites(bind_value(E,F),G),     rewrites(abs(G),H).

onestep(bind(B),D,depends(A,map1(C,A)),inhabit) :-     rewrites(B,C),     unobs(D).

