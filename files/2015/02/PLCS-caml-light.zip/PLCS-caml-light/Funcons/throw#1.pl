% Generated from Funcons/throw#1.csf

sigdec(throw,computes(_),[_]).

onestep(throw(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(throw(E),F).

onestep(throw(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(throw(E),F).

onestep(throw(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(throw(E),F).

sigdec(throw,computes(_),[_]).

onestep(throw(A),G,E,run) :-     rewrites(A,B),     eq_label(G,[exception+=_|D]),     rewrites(B,C),     runcheck(C,val),     checktag(C,val,F),     unobs(D),     rewrites(stuck,E),     rewrites(some(F),H),     eq_label(G,[exception+=H|_]).

onestep(throw(A),D,_,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,_).

