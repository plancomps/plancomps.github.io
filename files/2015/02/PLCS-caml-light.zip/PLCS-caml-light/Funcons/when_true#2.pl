% Generated from Funcons/when_true#2.csf

sigdec(when_true,A,[booleans,A]).

onestep(when_true(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(when_true(G,H),I).

onestep(when_true(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(when_true(J,K),L).

onestep(when_true(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(when_true(J,K),L).

sigdec(when_true,A,[computes(booleans),A]).

rewrite(when_true(A,B),H) :-     rewrites(A,C),     rewrites(B,D),     rewrites(C,E),     rewrites(D,F),     rewrites(fail,G),     rewrites(if_true(E,F,G),H).

