% Generated from Funcons/variant_match#3.csf

sigdec(variant_match,decls,[tags,variants,patts]).

onestep(variant_match(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,G),     rewrites(C,D),     runstep(D,E,H) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(variant_match(I,J,K),L).

onestep(variant_match(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,D),     rewrites(C,H),     runstep(D,E,G) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(variant_match(I,J,K),L).

onestep(variant_match(A,B,C),E,L,run) :-     rewrites(A,D),     rewrites(B,G),     rewrites(C,H),     runstep(D,E,F) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(variant_match(I,J,K),L).

onestep(variant_match(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(variant_match(O,P,Q),R).

onestep(variant_match(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(variant_match(O,P,Q),R).

sigdec(variant_match,decls,[computes(tags),computes(variants),computes(patts)]).

rewrite(variant_match(A,B,E),P) :-     rewrites(A,F),     rewrites(B,variant(C,D)),     rewrites(C,G),     rewrites(D,J),     rewrites(E,K),     rewrites(F,H),     rewrites(G,I),     rewrites(equal(H,I),N),     rewrites(J,L),     rewrites(K,M),     rewrites(match(L,M),O),     rewrites(when_true(N,O),P).

onestep(variant_match(A,B,C),N,K,inhabit) :-     rewrites(A,G),     rewrites(B,D),     rewrites(C,H),     pre_comp(N,L),     rewrites(D,E),     inhabit(E,L,variants(F)) ->     mid_comp(L,M),     rewrites(map_select(F,G),J),     rewrites(H,I),     inhabit(I,M,depends(J,K)) ->     post_comp(L,M,N). 

sigdec(variant_patt,patts(variants),[tags,patts]).

onestep(variant_patt(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(variant_patt(G,H),I).

onestep(variant_patt(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(variant_patt(G,H),I).

onestep(variant_patt(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(variant_patt(J,K),L).

onestep(variant_patt(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(variant_patt(J,K),L).

sigdec(variant_patt,patts(variants),[computes(tags),computes(patts)]).

rewrite(variant_patt(A,B),M) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,G),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,H),     rewrites(G,I),     rewrites(given,J),     rewrites(H,K),     rewrites(variant_match(I,J,K),L),     rewrites(abs(L),M).

onestep(variant_patt(A,B),G,depends(variants(C),I),inhabit) :-     rewrites(A,D),     rewrites(B,E),     rewrites(map_select(C,D),H),     rewrites(E,F),     inhabit(F,G,depends(H,I)).

