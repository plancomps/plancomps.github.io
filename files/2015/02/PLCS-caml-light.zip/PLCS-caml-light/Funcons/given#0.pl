% Generated from Funcons/given#0.csf

sigdec(given,depends(A,A),[]).

onestep(given,A,B,resolve) :-     unobs(A),     rewrites(given,B).

onestep(given,A,B,typeval) :-     unobs(A),     rewrites(given,B).

sigdec(given,depends(A,A),[]).

onestep(given,A,F,run) :-     rewrites(E,C),     eq_label(A,[given=B|D]),     rewrites(B,C),     unobs(D),     rewrites(E,F).

onestep(given,B,A,inhabit) :-     rewrites(A,D),     eq_label(B,[given=C|E]),     rewrites(C,D),     unobs(E).

