% Generated from Funcons/fresh_token#0.csf

sigdec(fresh_token,computes(tokens),[]).

onestep(fresh_token,G,E,typeval) :-     rewrites(F,B),     eq_label(G,[token=A|C]),     rewrites(A,B),     eq_label(C,[token+=_|D]),     unobs(D),     rewrites(F,E),     rewrites(int_plus(F,q(1)),H),     eq_label(G,[token+=H|_]).

onestep(fresh_token,G,E,resolve) :-     rewrites(F,B),     eq_label(G,[token=A|C]),     rewrites(A,B),     eq_label(C,[token+=_|D]),     unobs(D),     rewrites(F,E),     rewrites(int_plus(F,q(1)),H),     eq_label(G,[token+=H|_]).

onestep(fresh_token,G,E,run) :-     rewrites(F,B),     eq_label(G,[token=A|C]),     rewrites(A,B),     eq_label(C,[token+=_|D]),     unobs(D),     rewrites(F,E),     rewrites(int_plus(F,q(1)),H),     eq_label(G,[token+=H|_]).

onestep(fresh_token,A,tokens,inhabit) :-     unobs(A).

