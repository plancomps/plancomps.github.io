% Generated from Funcons/catch#2.csf

sigdec(catch,computes(A),[computes(A),abs(_,A)]).

onestep(catch(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(catch(G,H),I).

onestep(catch(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(catch(J,K),L).

onestep(catch(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(catch(J,K),L).

sigdec(catch,computes(A),[computes(A),computes(abs(_,A))]).

onestep(catch(A,B),O,N,run) :-     rewrites(A,F),     rewrites(B,C),     eq_label(O,[exception+=_|E]),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,K),     G=[exception+=_|E],     runstep(F,G,J) ->     rewrites(none,I),     eq_label(G,[exception+=H|_]),     rewrites(H,I),     rewrites(J,L),     rewrites(K,M),     rewrites(catch(L,M),N),     rewrites(none,P),     eq_label(O,[exception+=P|_]).

onestep(catch(A,B),O,N,run) :-     rewrites(A,F),     rewrites(B,C),     eq_label(O,[exception+=_|E]),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,J),     G=[exception+=_|E],     runstep(F,G,_) ->     rewrites(some(K),I),     eq_label(G,[exception+=H|_]),     rewrites(H,I),     rewrites(J,L),     rewrites(K,M),     rewrites(apply(L,M),N),     rewrites(none,P),     eq_label(O,[exception+=P|_]).

onestep(catch(A,B),G,I,run) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,H),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,_),     unobs(G),     rewrites(H,I).

onestep(catch(A,B),J,G,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,G) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,depends(_,G)) ->     post_comp(H,I,J). 

