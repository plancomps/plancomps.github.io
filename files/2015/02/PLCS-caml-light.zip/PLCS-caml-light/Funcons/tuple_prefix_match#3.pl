% Generated from Funcons/tuple_prefix_match#3.csf

sigdec(tuple_prefix_match,decls,[tuples,patts,patts]).

onestep(tuple_prefix_match(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,G),     rewrites(C,D),     runstep(D,E,H) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(tuple_prefix_match(I,J,K),L).

onestep(tuple_prefix_match(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,D),     rewrites(C,H),     runstep(D,E,G) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(tuple_prefix_match(I,J,K),L).

onestep(tuple_prefix_match(A,B,C),E,L,run) :-     rewrites(A,D),     rewrites(B,G),     rewrites(C,H),     runstep(D,E,F) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(tuple_prefix_match(I,J,K),L).

onestep(tuple_prefix_match(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(tuple_prefix_match(O,P,Q),R).

onestep(tuple_prefix_match(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(tuple_prefix_match(O,P,Q),R).

sigdec(tuple_prefix_match,decls,[computes(tuples),computes(patts),computes(patts)]).

rewrite(tuple_prefix_match(A,D,E),P) :-     rewrites(A,tuple_prefix(B,C)),     rewrites(B,F),     rewrites(C,J),     rewrites(D,G),     rewrites(E,K),     rewrites(F,H),     rewrites(G,I),     rewrites(match(H,I),N),     rewrites(J,L),     rewrites(K,M),     rewrites(match(L,M),O),     rewrites(map_union(N,O),P).

onestep(tuple_prefix_match(A,B,C),R,map_union(I,M),inhabit) :-     rewrites(A,D),     rewrites(B,F),     rewrites(C,J),     pre_comp(R,P),     rewrites(D,E),     inhabit(E,P,tuple_type_prefix(H,L)) ->     mid_comp(P,Q),     pre_comp(Q,N),     rewrites(F,G),     inhabit(G,N,depends(H,I)) ->     mid_comp(N,O),     rewrites(J,K),     inhabit(K,O,depends(L,M)) ->     post_comp(N,O,Q),     post_comp(P,Q,R).

sigdec(tuple_prefix_patt,patts,[patts,patts]).

onestep(tuple_prefix_patt(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(tuple_prefix_patt(G,H),I).

onestep(tuple_prefix_patt(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(tuple_prefix_patt(G,H),I).

onestep(tuple_prefix_patt(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(tuple_prefix_patt(J,K),L).

onestep(tuple_prefix_patt(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(tuple_prefix_patt(J,K),L).

sigdec(tuple_prefix_patt,computes(patts),[computes(patts),computes(patts)]).

rewrite(tuple_prefix_patt(A,B),M) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,G),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,H),     rewrites(given,I),     rewrites(G,J),     rewrites(H,K),     rewrites(tuple_prefix_match(I,J,K),L),     rewrites(abs(L),M).

onestep(tuple_prefix_patt(A,B),M,depends(tuple_type_prefix(E,I),map_union(F,J)),inhabit) :-     rewrites(A,C),     rewrites(B,G),     pre_comp(M,K),     rewrites(C,D),     inhabit(D,K,depends(E,F)) ->     mid_comp(K,L),     rewrites(G,H),     inhabit(H,L,depends(I,J)) ->     post_comp(K,L,M). 

