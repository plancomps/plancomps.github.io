% Generated from Funcons/uncurry#1.csf

sigdec(uncurry,abs(tuples,A),[abs(_,abs(_,A))]).

onestep(uncurry(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(uncurry(E),F).

onestep(uncurry(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(uncurry(E),F).

onestep(uncurry(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(uncurry(E),F).

sigdec(uncurry,computes(abs(tuples,A)),[computes(abs(_,abs(_,A)))]).

rewrite(uncurry(A),N) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,val),     checktag(C,val,D),     rewrites(D,G),     rewrites(zero,E),     rewrites(given,F),     rewrites(project(E,F),H),     rewrites(apply(G,H),K),     rewrites(one,I),     rewrites(given,J),     rewrites(project(I,J),L),     rewrites(apply(K,L),M),     rewrites(abs(M),N).

onestep(uncurry(A),D,depends(tuple_type2(E,G),H),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,depends(E,F)) ->     rewrites(F,depends(G,H)). 

