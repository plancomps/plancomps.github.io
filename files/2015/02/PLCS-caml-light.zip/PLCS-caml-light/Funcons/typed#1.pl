% Generated from Funcons/typed#1.csf

sigdec(typed,A,[A,types]).

onestep(typed(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(typed(J,K),L).

onestep(typed(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(typed(J,K),L).

onestep(typed(A,B),L,G,inhabit) :-     rewrites(A,E),     rewrites(B,C),     pre_comp(L,J),     rewrites(C,D),     inhabit(D,J,types) ->     mid_comp(J,K),     pre_comp(K,H),     typeval(D,H,G) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,G) ->     post_comp(H,I,K),     post_comp(J,K,L).

onestep(typed(A,B),C,E,run) :-     rewrites(A,D),     rewrites(B,_),     unobs(C),     rewrites(D,E).

