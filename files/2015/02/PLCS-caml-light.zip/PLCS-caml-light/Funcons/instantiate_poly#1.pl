% Generated from Funcons/instantiate_poly#1.csf

sigdec(instantiate_poly,A,[A]).

onestep(instantiate_poly(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(instantiate_poly(E),F).

onestep(instantiate_poly(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(instantiate_poly(E),F).

onestep(instantiate_poly(A),D,G,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,forall(F,E)) ->     rewrites(subst(E,list_to_map(F)),G). 

onestep(instantiate_poly(A),B,D,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D).

sigdec(instantiate_if_poly,A,[A]).

onestep(instantiate_if_poly(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(instantiate_if_poly(E),F).

onestep(instantiate_if_poly(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(instantiate_if_poly(E),F).

onestep(instantiate_if_poly(A),D,E,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E) ->     different(E,forall(_,_)). 

onestep(instantiate_if_poly(A),D,E,inhabit) :-     rewrites(A,B),     rewrites(instantiate_poly(B),C),     inhabit(C,D,E).

onestep(instantiate_if_poly(A),B,D,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D).

sigdec(instantiate_poly_decl,decls,[decls]).

onestep(instantiate_poly_decl(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(instantiate_poly_decl(E),F).

onestep(instantiate_poly_decl(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(instantiate_poly_decl(E),F).

onestep(instantiate_poly_decl(A),B,D,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D).

onestep(instantiate_poly_decl(A),D,instantiate_poly_map(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

sigdec(instantiate_poly_map,maps(ids,types),[maps(ids,types)]).

onestep(instantiate_poly_map(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(instantiate_poly_map(E),F).

onestep(instantiate_poly_map(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(instantiate_poly_map(E),F).

onestep(instantiate_poly_map(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(instantiate_poly_map(E),F).

sigdec(instantiate_poly_map,computes(maps(ids,types)),[computes(maps(ids,types))]).

rewrite(instantiate_poly_map(A),B) :-     rewrites(A,map_empty),     rewrites(map_empty,B).

rewrite(instantiate_poly_map(A),L) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,E),     rewrites(C,F),     rewrites(D,G),     different(F,forall(_,_)),     rewrites(E,I),     rewrites(F,J),     rewrites(G,H),     rewrites(instantiate_poly_map(H),K),     rewrites(map_prefix(I,J,K),L).

rewrite(instantiate_poly_map(A),P) :-     rewrites(A,map_prefix(B,C,F)),     rewrites(B,J),     rewrites(C,forall(D,E)),     rewrites(D,H),     rewrites(E,G),     rewrites(F,I),     rewrites(subst(G,list_to_map(H)),K),     rewrites(instantiate_poly_map(I),L),     rewrites(J,M),     rewrites(K,N),     rewrites(L,O),     rewrites(map_prefix(M,N,O),P).

sigdec(instantiate_poly_decl_if_true,decls,[booleans,decls]).

onestep(instantiate_poly_decl_if_true(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(instantiate_poly_decl_if_true(G,H),I).

onestep(instantiate_poly_decl_if_true(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(instantiate_poly_decl_if_true(J,K),L).

onestep(instantiate_poly_decl_if_true(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(instantiate_poly_decl_if_true(J,K),L).

sigdec(instantiate_poly_decl_if_true,decls,[computes(booleans),decls]).

onestep(instantiate_poly_decl_if_true(A,B),C,E,run) :-     rewrites(A,_),     rewrites(B,D),     unobs(C),     rewrites(D,E).

onestep(instantiate_poly_decl_if_true(A,B),F,G,inhabit) :-     rewrites(A,C),     rewrites(B,D),     rewrites(C,true),     rewrites(instantiate_poly_decl(D),E),     inhabit(E,F,G).

onestep(instantiate_poly_decl_if_true(A,B),F,G,inhabit) :-     rewrites(A,C),     rewrites(B,D),     rewrites(C,false),     rewrites(D,E),     inhabit(E,F,G).

