% Generated from Funcons/restrict_domain#2.csf

sigdec(restrict_domain,abs(A,B),[abs(A,B),types]).

onestep(restrict_domain(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(restrict_domain(G,H),I).

onestep(restrict_domain(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(restrict_domain(J,K),L).

onestep(restrict_domain(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(restrict_domain(J,K),L).

sigdec(restrict_domain,computes(abs(A,B)),[computes(abs(A,B)),types]).

onestep(restrict_domain(A,B),C,E,run) :-     rewrites(A,D),     rewrites(B,_),     unobs(C),     rewrites(D,E).

onestep(restrict_domain(A,B),M,depends(G,H),inhabit) :-     rewrites(A,E),     rewrites(B,C),     pre_comp(M,K),     rewrites(C,D),     inhabit(D,K,types) ->     mid_comp(K,L),     pre_comp(L,I),     typeval(D,I,G) ->     mid_comp(I,J),     rewrites(E,F),     inhabit(F,J,depends(G,H)) ->     post_comp(I,J,L),     post_comp(K,L,M).

