% Generated from Funcons/patt_abs#2.csf

sigdec(patt_abs,abs(A,B),[patts,depends(A,B)]).

onestep(patt_abs(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(patt_abs(G,H),I).

onestep(patt_abs(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(patt_abs(J,K),L).

onestep(patt_abs(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(patt_abs(J,K),L).

sigdec(patt_abs,computes(abs(A,B)),[computes(patts),depends(A,B)]).

rewrite(patt_abs(A,B),L) :-     rewrites(A,C),     rewrites(B,H),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,E),     rewrites(given,F),     rewrites(E,G),     rewrites(match(F,G),I),     rewrites(H,J),     rewrites(scope(I,J),K),     rewrites(abs(K),L).

onestep(patt_abs(A,B),C,depends(P,Y),inhabit) :-     rewrites(A,M),     rewrites(B,V),     rewrites(I,E),     eq_label(C,[given=D|F]),     rewrites(D,E),     rewrites(S,H),     eq_label(F,[env=G|ZB]),     rewrites(G,H),     pre_comp(ZB,Z),     rewrites(I,J),     O=[given=J|K],     rewrites(S,L),     K=[env=L|Z],     rewrites(M,N),     inhabit(N,O,depends(P,R)) ->     mid_comp(Z,ZA),     rewrites(P,Q),     X=[given=Q|T],     rewrites(map_over(R,S),U),     T=[env=U|ZA],     rewrites(V,W),     inhabit(W,X,Y) ->     post_comp(Z,ZA,ZB). 

