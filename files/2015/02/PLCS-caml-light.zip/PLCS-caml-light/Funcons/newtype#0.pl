% Generated from Funcons/newtype#0.csf

sigdec(newtype,types,[atoms]).

onestep(newtype(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(newtype(E),F).

onestep(newtype(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(newtype(E),F).

sigdec(newtype,types,[computes(atoms)]).

onestep(newtype(A),B,types,inhabit) :-     rewrites(A,_),     unobs(B).

onestep(newtype(A),E,J,typeval) :-     rewrites(A,B),     pre_comp(E,C),     typeval(B,C,F) ->     mid_comp(C,D),     typeval(fresh_token,D,G) ->     post_comp(C,D,E),     rewrites(F,H),     rewrites(G,I),     rewrites(nomtype(H,I),J).

sigdec(newtype_poly,types,[atoms,lists(types)]).

onestep(newtype_poly(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(newtype_poly(G,H),I).

onestep(newtype_poly(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(newtype_poly(G,H),I).

onestep(newtype_poly(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(newtype_poly(J,K),L).

sigdec(newtype_poly,types,[computes(atoms),computes(lists(types))]).

onestep(newtype_poly(A,B),C,types,inhabit) :-     rewrites(A,_),     rewrites(B,_),     unobs(C).

onestep(newtype_poly(A,B),I,P,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(I,G),     typeval(C,G,J) ->     mid_comp(G,H),     pre_comp(H,E),     typeval(D,E,L) ->     mid_comp(E,F),     typeval(fresh_token,F,K) ->     post_comp(E,F,H),     post_comp(G,H,I),     rewrites(J,M),     rewrites(K,N),     rewrites(L,O),     rewrites(nomtype_poly(M,N,O),P).

