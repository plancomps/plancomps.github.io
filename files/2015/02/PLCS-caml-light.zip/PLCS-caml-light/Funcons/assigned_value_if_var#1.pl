% Generated from Funcons/assigned_value_if_var#1.csf

sigdec(assigned_value_if_var,computes(_),[_]).

onestep(assigned_value_if_var(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(assigned_value_if_var(E),F).

onestep(assigned_value_if_var(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(assigned_value_if_var(E),F).

onestep(assigned_value_if_var(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(assigned_value_if_var(E),F).

sigdec(assigned_value_if_var,computes(_),[_]).

rewrite(assigned_value_if_var(A),F) :-     rewrites(A,var(B)),     rewrites(B,C),     rewrites(C,D),     rewrites(var(D),E),     rewrites(assigned_value(E),F).

rewrite(assigned_value_if_var(A),E) :-     rewrites(A,C),     rewrites(C,B),     runcheck(B,val),     checktag(B,val,D),     different(C,var(_)),     rewrites(D,E).

onestep(assigned_value_if_var(A),D,E,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E) ->     different(E,variables(_)). 

onestep(assigned_value_if_var(A),D,E,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,variables(E)).

