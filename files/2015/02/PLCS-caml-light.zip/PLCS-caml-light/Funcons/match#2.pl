% Generated from Funcons/match#2.csf

sigdec(match,decls,[_,patts]).

onestep(match(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(match(G,H),I).

onestep(match(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(match(G,H),I).

onestep(match(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(match(J,K),L).

onestep(match(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(match(J,K),L).

sigdec(match,decls,[_,computes(patts)]).

rewrite(match(A,B),G) :-     rewrites(A,D),     rewrites(B,C),     rewrites(C,E),     rewrites(D,F),     rewrites(apply(E,F),G).

