% Generated from Funcons/scope#2.csf

sigdec(scope,A,[environments,A]).

onestep(scope(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(scope(G,H),I).

onestep(scope(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(scope(J,K),L).

onestep(scope(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(scope(J,K),L).

sigdec(scope,A,[computes(environments),A]).

onestep(scope(A,B),C,Q,run) :-     rewrites(A,F),     rewrites(B,K),     rewrites(H,E),     eq_label(C,[env=D|J]),     rewrites(D,E),     rewrites(F,G),     runcheck(G,val),     checktag(G,val,M),     rewrites(map_over(M,H),I),     L=[env=I|J],     runstep(K,L,N) ->     rewrites(M,O),     rewrites(N,P),     rewrites(scope(O,P),Q).

onestep(scope(A,B),G,I,run) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,_),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,H),     unobs(G),     rewrites(H,I).

onestep(scope(A,B),C,P,inhabit) :-     rewrites(A,G),     rewrites(B,M),     rewrites(K,E),     eq_label(C,[env=D|S]),     rewrites(D,E),     pre_comp(S,Q),     rewrites(K,F),     I=[env=F|Q],     rewrites(G,H),     inhabit(H,I,J) ->     mid_comp(Q,R),     rewrites(map_over(J,K),L),     O=[env=L|R],     rewrites(M,N),     inhabit(N,O,P) ->     post_comp(Q,R,S). 

