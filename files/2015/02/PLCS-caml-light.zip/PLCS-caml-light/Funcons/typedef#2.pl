% Generated from Funcons/typedef#2.csf

sigdec(typedef,environments,[ids,types]).

onestep(typedef(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(typedef(G,H),I).

onestep(typedef(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(typedef(J,K),L).

onestep(typedef(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(typedef(J,K),L).

sigdec(typedef,computes(environments),[computes(ids),types]).

onestep(typedef(A,C),I,map1(B,F),inhabit) :-     rewrites(A,B),     rewrites(C,D),     pre_comp(I,G),     rewrites(D,E),     inhabit(E,G,types) ->     mid_comp(G,H),     typeval(E,H,F) ->     post_comp(G,H,I). 

onestep(typedef(A,B),C,D,run) :-     rewrites(A,_),     rewrites(B,_),     unobs(C),     rewrites(map_empty,D).

