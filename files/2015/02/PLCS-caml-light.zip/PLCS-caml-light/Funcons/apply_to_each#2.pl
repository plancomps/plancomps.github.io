% Generated from Funcons/apply_to_each#2.csf

sigdec(apply_to_each,comms,[procs,lists(_)]).

onestep(apply_to_each(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(apply_to_each(G,H),I).

onestep(apply_to_each(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(apply_to_each(G,H),I).

onestep(apply_to_each(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(apply_to_each(J,K),L).

onestep(apply_to_each(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(apply_to_each(J,K),L).

sigdec(apply_to_each,comms,[computes(procs),computes(lists(_))]).

onestep(apply_to_each(A,B),E,F,run) :-     rewrites(A,C),     rewrites(B,list_empty),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,_),     unobs(E),     rewrites(null,F).

onestep(apply_to_each(A,B),G,Q,run) :-     rewrites(A,E),     rewrites(B,list_prefix(C,D)),     rewrites(C,H),     rewrites(D,L),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,K),     unobs(G),     rewrites(K,I),     rewrites(H,J),     rewrites(apply(I,J),O),     rewrites(K,M),     rewrites(L,N),     rewrites(apply_to_each(M,N),P),     rewrites(seq(O,P),Q).

onestep(apply_to_each(A,B),J,unit,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,depends(G,unit)) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,lists(G)) ->     post_comp(H,I,J). 

