% Generated from Funcons/while_true#2.csf

sigdec(while_true,comms,[computes(booleans),comms]).

onestep(while_true(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(while_true(J,K),L).

onestep(while_true(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(while_true(J,K),L).

onestep(while_true(A,B),C,M,run) :-     rewrites(A,D),     rewrites(B,E),     unobs(C),     rewrites(D,J),     rewrites(E,H),     rewrites(D,F),     rewrites(E,G),     rewrites(while_true(F,G),I),     rewrites(seq(H,I),K),     rewrites(null,L),     rewrites(if_true(J,K,L),M).

onestep(while_true(A,B),I,unit,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,booleans) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,unit) ->     post_comp(G,H,I). 

