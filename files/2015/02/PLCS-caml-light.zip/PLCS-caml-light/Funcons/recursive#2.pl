% Generated from Funcons/recursive#2.csf

sigdec(recursive,decls,[lists(ids),decls]).

onestep(recursive(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(recursive(G,H),I).

onestep(recursive(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(recursive(J,K),L).

onestep(recursive(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(recursive(J,K),L).

sigdec(recursive,decls,[computes(lists(ids)),decls]).

onestep(recursive(A,B),C,I,run) :-     rewrites(A,D),     rewrites(B,F),     unobs(C),     rewrites(D,E),     rewrites(fresh_fwds(E),G),     rewrites(F,H),     rewrites(reclose(G,H),I).

onestep(recursive(A,B),C,N,inhabit) :-     rewrites(A,F),     rewrites(B,J),     rewrites(G,E),     eq_label(C,[env=D|I]),     rewrites(D,E),     rewrites(list_to_map(F),M),     rewrites(map_over(fwds_typenv(M),G),H),     L=[env=H|I],     rewrites(J,K),     inhabit(K,L,N) ->     rewrites(map_subset(M,N),true). 

sigdec(fwds_typenv,maps(ids,types),[maps(id,types)]).

onestep(fwds_typenv(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(fwds_typenv(E),F).

onestep(fwds_typenv(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(fwds_typenv(E),F).

onestep(fwds_typenv(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(fwds_typenv(E),F).

sigdec(fwds_typenv,computes(maps(ids,types)),[computes(maps(id,types))]).

rewrite(fwds_typenv(A),B) :-     rewrites(A,map_empty),     rewrites(map_empty,B).

rewrite(fwds_typenv(A),M) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,E),     rewrites(C,F),     rewrites(D,H),     rewrites(E,J),     rewrites(F,G),     rewrites(fwds(G),K),     rewrites(H,I),     rewrites(fwds_typenv(I),L),     rewrites(map_prefix(J,K,L),M).

sigdec(reclose,decls,[maps(ids,fwds),decls]).

onestep(reclose(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(reclose(G,H),I).

onestep(reclose(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(reclose(J,K),L).

onestep(reclose(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(reclose(J,K),L).

sigdec(reclose,decls,[computes(maps(ids,fwds)),decls]).

rewrite(reclose(A,B),N) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,H),     rewrites(H,F),     rewrites(E,G),     rewrites(scope(F,G),L),     rewrites(H,I),     rewrites(set_forwards(I),J),     rewrites(map_empty,K),     rewrites(seq(J,K),M),     rewrites(accum(L,M),N).

sigdec(fresh_fwds,computes(maps(ids,fwds)),[lists(ids)]).

onestep(fresh_fwds(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(fresh_fwds(E),F).

onestep(fresh_fwds(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(fresh_fwds(E),F).

onestep(fresh_fwds(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(fresh_fwds(E),F).

sigdec(fresh_fwds,computes(maps(ids,fwds)),[computes(lists(ids))]).

rewrite(fresh_fwds(A),B) :-     rewrites(A,list_empty),     rewrites(map_empty,B).

onestep(fresh_fwds(A),S,Q,run) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,I),     rewrites(C,L),     rewrites(G,E),     eq_label(S,[forward=D|F]),     rewrites(D,E),     eq_label(F,[forward+=_|H]),     rewrites(fwd_fresh(G),fwd(J)),     rewrites(map_update(G,fwd(J),undefined),R),     unobs(H),     rewrites(I,N),     rewrites(J,K),     rewrites(fwd(K),O),     rewrites(L,M),     rewrites(fresh_fwds(M),P),     rewrites(map_prefix(N,O,P),Q),     rewrites(R,T),     eq_label(S,[forward+=T|_]).

sigdec(set_forwards,comms,[maps(ids,fwds)]).

onestep(set_forwards(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(set_forwards(E),F).

onestep(set_forwards(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(set_forwards(E),F).

onestep(set_forwards(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(set_forwards(E),F).

sigdec(set_forwards,comms,[computes(maps(ids,fwds))]).

rewrite(set_forwards(A),B) :-     rewrites(A,map_empty),     rewrites(null,B).

onestep(set_forwards(A),U,S,run) :-     rewrites(A,map_prefix(B,C,E)),     rewrites(B,O),     rewrites(C,fwd(D)),     rewrites(D,M),     rewrites(E,Q),     rewrites(N,G),     eq_label(U,[env=F|H]),     rewrites(F,G),     rewrites(L,J),     eq_label(H,[forward=I|K]),     rewrites(I,J),     eq_label(K,[forward+=_|P]),     rewrites(map_update(L,fwd(M),map_select(N,O)),T),     unobs(P),     rewrites(Q,R),     rewrites(set_forwards(R),S),     rewrites(T,V),     eq_label(U,[forward+=V|_]).

