% Generated from Funcons/generalise#1.csf

sigdec(generalise,A,[A]).

onestep(generalise(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(generalise(E),F).

onestep(generalise(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(generalise(E),F).

onestep(generalise(A),B,forall(N,M),inhabit) :-     rewrites(A,I),     rewrites(F,D),     eq_label(B,[env=C|H]),     rewrites(C,D),     rewrites(free_vars(I),E),     rewrites(map_over(map_zip(E,E),F),G),     K=[env=G|H],     rewrites(I,J),     inhabit(J,K,L) ->     rewrites(instantiate_meta(L),M),     rewrites(free_vars(M),N).

onestep(generalise(A),B,D,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D).

sigdec(generalise_if_poly,A,[A]).

onestep(generalise_if_poly(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(generalise_if_poly(E),F).

onestep(generalise_if_poly(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(generalise_if_poly(E),F).

onestep(generalise_if_poly(A),D,E,inhabit) :-     rewrites(A,B),     rewrites(generalise(B),C),     inhabit(C,D,forall(list_empty,E)).

onestep(generalise_if_poly(A),D,E,inhabit) :-     rewrites(A,B),     rewrites(generalise(B),C),     inhabit(C,D,E) ->     rewrites(E,forall(list_prefix(_,_),_)). 

onestep(generalise_if_poly(A),B,D,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D).

sigdec(generalise_decl,decls,[decls]).

onestep(generalise_decl(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(generalise_decl(E),F).

onestep(generalise_decl(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(generalise_decl(E),F).

onestep(generalise_decl(A),B,generalise_map(L),inhabit) :-     rewrites(A,I),     rewrites(F,D),     eq_label(B,[env=C|H]),     rewrites(C,D),     rewrites(free_vars(I),E),     rewrites(map_over(map_zip(E,E),F),G),     K=[env=G|H],     rewrites(I,J),     inhabit(J,K,L).

onestep(generalise_decl(A),B,D,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D).

sigdec(generalise_map,maps(ids,types),[maps(ids,types)]).

onestep(generalise_map(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(generalise_map(E),F).

onestep(generalise_map(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(generalise_map(E),F).

onestep(generalise_map(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(generalise_map(E),F).

sigdec(generalise_map,computes(maps(ids,types)),[computes(maps(ids,types))]).

rewrite(generalise_map(A),B) :-     rewrites(A,map_empty),     rewrites(map_empty,B).

rewrite(generalise_map(A),M) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,F),     rewrites(C,G),     rewrites(D,H),     rewrites(instantiate_meta(G),E),     rewrites(free_vars(E),list_empty),     rewrites(F,J),     rewrites(G,K),     rewrites(H,I),     rewrites(generalise_map(I),L),     rewrites(map_prefix(J,K,L),M).

rewrite(generalise_map(A),P) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,F),     rewrites(C,E),     rewrites(D,K),     rewrites(instantiate_meta(E),H),     rewrites(free_vars(H),G),     \+rewrites(G,list_empty),     rewrites(F,M),     rewrites(G,I),     rewrites(H,J),     rewrites(forall(I,J),N),     rewrites(K,L),     rewrites(generalise_map(L),O),     rewrites(map_prefix(M,N,O),P).

