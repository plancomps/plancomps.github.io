% Generated from Funcons/supply#2.csf

sigdec(supply,B,[A,depends(A,B)]).

onestep(supply(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(supply(G,H),I).

onestep(supply(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(supply(J,K),L).

onestep(supply(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(supply(J,K),L).

sigdec(supply,B,[A,depends(A,B)]).

onestep(supply(A,B),C,P,run) :-     rewrites(A,F),     rewrites(B,J),     rewrites(_,E),     eq_label(C,[given=D|I]),     rewrites(D,E),     rewrites(F,G),     runcheck(G,val),     checktag(G,val,L),     rewrites(L,H),     K=[given=H|I],     runstep(J,K,M) ->     rewrites(L,N),     rewrites(M,O),     rewrites(supply(N,O),P).

onestep(supply(A,B),G,I,run) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,_),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,H),     unobs(G),     rewrites(H,I).

onestep(supply(A,B),C,P,inhabit) :-     rewrites(A,H),     rewrites(B,M),     rewrites(F,E),     eq_label(C,[given=D|S]),     rewrites(D,E),     pre_comp(S,Q),     rewrites(F,G),     J=[given=G|Q],     rewrites(H,I),     inhabit(I,J,K) ->     mid_comp(Q,R),     rewrites(K,L),     O=[given=L|R],     rewrites(M,N),     inhabit(N,O,P) ->     post_comp(Q,R,S). 

