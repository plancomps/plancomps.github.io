% Generated from Funcons/curry#1.csf

sigdec(curry,abs(_,abs(_,A)),[abs(tuples,A)]).

onestep(curry(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(curry(E),F).

onestep(curry(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(curry(E),F).

onestep(curry(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(curry(E),F).

sigdec(curry,computes(abs(_,abs(_,A))),[computes(abs(tuples,A))]).

rewrite(curry(A),H) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,val),     checktag(C,val,D),     rewrites(D,E),     rewrites(given,F),     rewrites(partial_app(E,F),G),     rewrites(abs(G),H).

onestep(curry(A),D,depends(E,F),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,depends(tuple_type2(E,G),H)) ->     rewrites(F,depends(G,H)). 

sigdec(curry_N,_,[peano_nats,abs(tuples,_)]).

onestep(curry_N(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(curry_N(G,H),I).

onestep(curry_N(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(curry_N(G,H),I).

onestep(curry_N(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(curry_N(J,K),L).

onestep(curry_N(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(curry_N(J,K),L).

sigdec(curry_N,_,[computes(peano_nats),computes(abs(tuples,_))]).

rewrite(curry_N(A,B),H) :-     rewrites(A,zero),     rewrites(B,C),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,E),     rewrites(E,F),     rewrites(tuple_empty,G),     rewrites(apply(F,G),H).

rewrite(curry_N(A,C),M) :-     rewrites(A,succ(B)),     rewrites(B,F),     rewrites(C,D),     rewrites(D,E),     runcheck(E,val),     checktag(E,val,G),     rewrites(F,J),     rewrites(G,H),     rewrites(given,I),     rewrites(partial_app_N(H,I),K),     rewrites(curry_N(J,K),L),     rewrites(abs(L),M).

onestep(curry_N(A,B),E,I,inhabit) :-     rewrites(A,F),     rewrites(B,C),     rewrites(C,D),     inhabit(D,E,depends(G,H)) ->     rewrites(curried_type(F,G,H),I). 

sigdec(curried_type,types,[peano_nats,tuple_types,types]).

onestep(curried_type(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,D),     rewrites(C,H),     runstep(D,E,G) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(curried_type(I,J,K),L).

onestep(curried_type(A,B,C),E,L,run) :-     rewrites(A,D),     rewrites(B,G),     rewrites(C,H),     runstep(D,E,F) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(curried_type(I,J,K),L).

onestep(curried_type(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(curried_type(O,P,Q),R).

onestep(curried_type(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(curried_type(O,P,Q),R).

sigdec(curried_type,types,[computes(peano_nats),computes(tuple_types),types]).

rewrite(curried_type(A,B,C),E) :-     rewrites(A,zero),     rewrites(B,tuple_type_empty),     rewrites(C,D),     rewrites(D,E).

rewrite(curried_type(A,C,F),N) :-     rewrites(A,succ(B)),     rewrites(B,G),     rewrites(C,tuple_type_prefix(D,E)),     rewrites(D,J),     rewrites(E,H),     rewrites(F,I),     rewrites(curried_type(G,H,I),K),     rewrites(J,L),     rewrites(K,M),     rewrites(depends(L,M),N).

