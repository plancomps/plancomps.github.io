% Generated from Funcons/assign#2.csf

sigdec(assign,comms,[variables,_]).

onestep(assign(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(assign(G,H),I).

onestep(assign(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(assign(G,H),I).

onestep(assign(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(assign(J,K),L).

onestep(assign(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(assign(J,K),L).

sigdec(assign,comms,[computes(variables),_]).

onestep(assign(A,B),O,K,run) :-     rewrites(A,I),     rewrites(B,G),     rewrites(L,D),     eq_label(O,[store=C|E]),     rewrites(C,D),     eq_label(E,[store+=_|J]),     rewrites(I,F),     runcheck(F,val),     checktag(F,val,M),     rewrites(G,H),     runcheck(H,val),     checktag(H,val,N),     rewrites(contains_key(L,I),true),     unobs(J),     rewrites(null,K),     rewrites(map_update(L,M,N),P),     eq_label(O,[store+=P|_]).

onestep(assign(A,B),M,unit,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(M,K),     rewrites(C,D),     inhabit(D,K,variables(H)) ->     mid_comp(K,L),     pre_comp(L,I),     rewrites(E,F),     inhabit(F,I,G) ->     mid_comp(I,J),     subtype(G,J,H),     post_comp(I,J,L),     post_comp(K,L,M).

