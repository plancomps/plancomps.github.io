% Generated from Funcons/compose#2.csf

sigdec(compose,abs(B,A),[abs(C,A),abs(B,C)]).

onestep(compose(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(compose(G,H),I).

onestep(compose(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(compose(G,H),I).

onestep(compose(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(compose(J,K),L).

onestep(compose(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(compose(J,K),L).

sigdec(compose,computes(abs(B,A)),[computes(abs(C,A)),computes(abs(B,C))]).

rewrite(compose(A,B),N) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,G),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,H),     rewrites(G,K),     rewrites(H,I),     rewrites(given,J),     rewrites(apply(I,J),L),     rewrites(apply(K,L),M),     rewrites(abs(M),N).

onestep(compose(A,B),L,depends(E,I),inhabit) :-     rewrites(A,F),     rewrites(B,C),     pre_comp(L,J),     rewrites(C,D),     inhabit(D,J,depends(E,H)) ->     mid_comp(J,K),     rewrites(F,G),     inhabit(G,K,depends(H,I)) ->     post_comp(J,K,L). 

