% Generated from Funcons/close#1.csf

sigdec(close,computes(abs(A,B)),[abs(A,B)]).

onestep(close(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(close(E),F).

onestep(close(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(close(E),F).

onestep(close(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(close(E),F).

sigdec(close,computes(abs(A,B)),[computes(abs(A,B))]).

onestep(close(A),C,L,run) :-     rewrites(A,abs(B)),     rewrites(B,G),     rewrites(H,E),     eq_label(C,[env=D|F]),     rewrites(D,E),     unobs(F),     rewrites(G,I),     rewrites(H,J),     rewrites(closure(I,J),K),     rewrites(abs(K),L).

onestep(close(A),D,depends(E,F),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,depends(E,F)).

