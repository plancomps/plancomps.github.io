% Generated from Funcons/apply#2.csf

sigdec(apply,computes(A),[abs(B,A),B]).

onestep(apply(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(apply(G,H),I).

onestep(apply(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(apply(G,H),I).

onestep(apply(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(apply(J,K),L).

onestep(apply(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(apply(J,K),L).

sigdec(apply,computes(A),[computes(abs(B,A)),B]).

rewrite(apply(A,C),H) :-     rewrites(A,abs(B)),     rewrites(B,E),     rewrites(C,D),     rewrites(D,F),     rewrites(E,G),     rewrites(supply(F,G),H).

onestep(apply(A,B),K,E,inhabit) :-     rewrites(A,C),     rewrites(B,F),     pre_comp(K,I),     rewrites(C,D),     inhabit(D,I,depends(H,E)) ->     mid_comp(I,J),     rewrites(F,G),     inhabit(G,J,H) ->     post_comp(I,J,K). 

onestep(apply(A,B),N,E,inhabit) :-     rewrites(A,C),     rewrites(B,F),     pre_comp(N,L),     rewrites(C,D),     inhabit(D,L,depends(I,E)) ->     mid_comp(L,M),     pre_comp(M,J),     rewrites(F,G),     inhabit(G,J,H) ->     mid_comp(J,K),     subtype(H,K,I),     post_comp(J,K,M),     post_comp(L,M,N).

