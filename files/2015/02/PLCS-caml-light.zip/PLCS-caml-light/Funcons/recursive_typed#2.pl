% Generated from Funcons/recursive_typed#2.csf

sigdec(recursive_typed,decls,[maps(ids,types),decls]).

onestep(recursive_typed(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(recursive_typed(G,H),I).

onestep(recursive_typed(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(recursive_typed(J,K),L).

onestep(recursive_typed(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(recursive_typed(J,K),L).

sigdec(recursive_typed,decls,[computes(maps(ids,types)),decls]).

onestep(recursive_typed(A,B),C,I,run) :-     rewrites(A,D),     rewrites(B,F),     unobs(C),     rewrites(D,E),     rewrites(map_domain(E),G),     rewrites(F,H),     rewrites(recursive(G,H),I).

onestep(recursive_typed(A,B),C,R,inhabit) :-     rewrites(A,J),     rewrites(B,N),     rewrites(L,E),     eq_label(C,[env=D|W]),     rewrites(D,E),     pre_comp(W,U),     rewrites(L,F),     H=[env=F|U],     rewrites(map_to_list(J),G),     inhabit(G,H,lists(types)) ->     mid_comp(U,V),     pre_comp(V,S),     rewrites(L,I),     K=[env=I|S],     typeval(J,K,Q) ->     mid_comp(S,T),     rewrites(map_over(fwds_typenv(Q),L),M),     P=[env=M|T],     rewrites(N,O),     inhabit(O,P,R) ->     rewrites(map_subset(Q,R),true),     post_comp(S,T,V),     post_comp(U,V,W).

