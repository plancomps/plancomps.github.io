let square x = x *. x;;
(* square : float -> float = <fun> *)

square 2.5;;
(* - : float = 6.25 *)

