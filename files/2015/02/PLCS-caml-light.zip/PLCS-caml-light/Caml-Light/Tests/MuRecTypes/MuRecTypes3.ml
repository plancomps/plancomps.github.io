type ty1 = { x2 : ty2 }
and  ty2 = { x1 : ty1 } ;;
(* Type ty1 defined.
   Type ty2 defined. *)
