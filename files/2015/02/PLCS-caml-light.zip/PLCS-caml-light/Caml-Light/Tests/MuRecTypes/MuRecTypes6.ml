type ty1 == ty2
and  ty2 =  { n : int } ;;
(* Type ty1 defined.
   Type ty2 defined. *)

({ n = 9 } : ty1) ;;
(* - : ty1 = {n = 9} *)
