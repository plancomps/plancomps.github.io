type ty1 == ty2
and  ty2 =  C of int ;;
(* Type ty1 defined.
   Type ty2 defined. *)

(C 9 : ty1) ;;
(* - : ty1 = C 9 *)
