let f = function x -> function y -> x + y
 in f 1 2
;;
(* - : int = 3 *)
