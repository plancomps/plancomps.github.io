true & false ;;
(* - : bool = false *)

false or false ;;
(* - : bool = false *)

if true then 1 else 2 ;;
(* - : int = 1 *)

if false then 3 else 4 ;;
(* - : int = 4 *)
