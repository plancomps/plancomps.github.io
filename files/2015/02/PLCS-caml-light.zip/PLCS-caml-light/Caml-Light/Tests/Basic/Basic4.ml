not not true ;;
(* - : bool = true *)
