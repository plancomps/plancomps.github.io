if (5 < 3) then print_string "bad" ;;
(* - : unit = () *)