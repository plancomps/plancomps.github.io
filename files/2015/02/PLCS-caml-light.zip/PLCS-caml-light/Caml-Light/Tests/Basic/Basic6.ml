5 mod 3;;
(* - : int = 2 *)

1.2 ** 3.4 ;;
(* float = 1.85872969198 *)

"hello" ^ " world" ;;
(* - : string = "hello world" *)
