let double = function x -> x + x ;;
(* double : int -> int = <fun> *)

double 7;;
(* - : int = 14 *)
