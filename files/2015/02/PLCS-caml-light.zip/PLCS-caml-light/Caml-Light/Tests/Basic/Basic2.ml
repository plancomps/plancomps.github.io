not true
;;
(* - : bool = false *)

not false
;;
(* - : bool = true *)

