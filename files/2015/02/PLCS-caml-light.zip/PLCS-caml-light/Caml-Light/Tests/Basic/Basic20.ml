let rec (f : bool -> bool) = function b -> not (f b) ;;
(* f : bool -> bool = <fun> *)
