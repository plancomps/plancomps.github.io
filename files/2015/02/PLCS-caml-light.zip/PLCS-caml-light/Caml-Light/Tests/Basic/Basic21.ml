let v = [| true |] ;;
(* v : bool vect = [|true|] *)

let r = ref v ;;
(* r : (bool vect) ref = ref [|true|] *)

!r.(0) ;;
(* - : bool = true *)
