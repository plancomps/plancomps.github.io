(1+2) :: if true then [] else (1 :: []) ;;
(* - : int list = [3] *)
