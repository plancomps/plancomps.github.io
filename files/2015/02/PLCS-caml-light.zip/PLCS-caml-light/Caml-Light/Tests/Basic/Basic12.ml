type fg = { f : int ; g : int } ;;
(* Type fg defined. *)

{f = 1+2 ; g = 3+4 ; } ;;
(* - : fg = {f = 3; g = 7} *)
