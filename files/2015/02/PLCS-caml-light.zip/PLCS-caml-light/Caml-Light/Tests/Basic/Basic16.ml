let x = 1 + 2 in x + 4 ;;
(* - : int = 7 *)
