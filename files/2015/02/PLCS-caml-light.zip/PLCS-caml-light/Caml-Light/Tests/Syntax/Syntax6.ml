let x = [ 1 ; 2 ; ] ;;
(* x : int list = [1; 2] *)
