let rec (f : (string * int) -> int) = function _ -> 7 ;;
(* f : string * int -> int = <fun> *)