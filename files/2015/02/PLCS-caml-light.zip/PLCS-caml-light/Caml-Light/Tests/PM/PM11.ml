let f = fun | (0,1) (2,3) -> `A` ;;
(* f : int * int -> int * int -> char = <fun> *)

f (0,1) (2,3) ;;
(* - : char = `A` *)

