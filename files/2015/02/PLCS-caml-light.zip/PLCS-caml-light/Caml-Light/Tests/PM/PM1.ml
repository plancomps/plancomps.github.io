match 1 with
    2 -> 2
  | 3 -> 3
;;
(* Uncaught exception: Match_failure *)
