type tyC = C of int ;;
(* Type tyC defined. *)

let (C x) = C 7 ;;
(* x : int = 7 *)

x ;;
(* - : int = 7 *)

type tyA = A ;;
(* Type tyA defined. *)

let A = A ;;
(* *)
