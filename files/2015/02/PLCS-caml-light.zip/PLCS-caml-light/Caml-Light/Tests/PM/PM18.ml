match (3 > 4) with
  | false -> 0
  | true  -> 1 ;;
(* - : int = 0 *)
