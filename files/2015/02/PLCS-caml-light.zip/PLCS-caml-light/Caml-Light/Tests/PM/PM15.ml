match [ 0 ] with
    [] | 0 :: [] -> "good"
  | 1 :: []      -> "bad" ;;
(* - : string = "good" *)
