type ty = A | B ;;
(* Type ty defined. *)

let A = B ;;
(* Match_failure *)
