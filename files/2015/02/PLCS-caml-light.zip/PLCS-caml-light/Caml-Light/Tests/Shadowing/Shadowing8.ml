let f = function x -> function x -> x
 in f 1 2
;;
(* - : int = 2 *)