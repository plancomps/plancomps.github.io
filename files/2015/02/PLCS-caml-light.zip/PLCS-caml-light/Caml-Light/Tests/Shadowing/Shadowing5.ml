let one = 1 :: [] ;;
(* one : int list = [1] *)

(one : int list) ;;
(* - : int list = [1] *)

type list = L ;;
(* Type list defined. *)

(L : list) ;;
(* - : list = L *)

let two = 2 :: [] ;;
(* two : int builtin__list = [2] *)

two ;;
(* - : int builtin__list = [2] *)
