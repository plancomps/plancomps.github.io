(function a -> a) >= (function b -> b) ;;
(* Uncaught exception: Invalid_argument "equal: functional value" *)