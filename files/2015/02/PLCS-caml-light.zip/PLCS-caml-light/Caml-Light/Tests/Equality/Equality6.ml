[] = [] ;;
(* - : bool = true *)

[0] = [0] ;;
(* - : bool = true *)

[] = [1] ;;
(* - : bool = false *)

[2] = [3];;
(* - : bool = false *)
