1 = 2
;;
(* - : bool = false *)

1 = 1
;;
(* - : bool = true *)

true = false
;;
(* - : bool = false *)

false = false
;;
(* - : bool = true *)

true = true
;;
(* - : bool = true *)
