(function x -> 1) = (function x -> 1) ;;
(* Invalid_argument "equal: functional value" *)