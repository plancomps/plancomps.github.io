type r = { x : int ; y : char } ;;
(* Type r defined. *)

{ x = 3 ; y = `P` } < { x = 3 ; y = `Q` } ;;
(* - : bool = true *)