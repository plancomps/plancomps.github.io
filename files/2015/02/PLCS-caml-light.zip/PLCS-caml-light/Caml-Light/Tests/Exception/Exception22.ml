exception E2 ;;
(* Exception E2 defined. *)

while false do raise E2 done ;;
(* - : unit = () *)
