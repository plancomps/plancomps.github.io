exception EEE ;;
(* Exception EEE defined. *)

let f = function _ -> raise EEE ;;
(* f : 'a -> 'b = <fun> *)
