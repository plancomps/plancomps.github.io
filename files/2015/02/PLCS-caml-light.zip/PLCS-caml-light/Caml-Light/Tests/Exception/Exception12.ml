exception E1 and E2 ;;
(* Exception E1 defined.
   Exception E2 defined. *)

raise E1 || raise E2 ;;
(* Uncaught exception: E1 *)
