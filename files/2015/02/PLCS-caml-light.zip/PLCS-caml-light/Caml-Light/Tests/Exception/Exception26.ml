exception E1 of exn ;;
(* Exception E1 defined. *)

exception E ;;
(* Exception E defined. *)

(E1 E : exn) ;;
(* - : exn = E1 E *)
