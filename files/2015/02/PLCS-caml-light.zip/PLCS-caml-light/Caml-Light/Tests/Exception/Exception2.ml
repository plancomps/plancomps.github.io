exception E ;;
(* Exception E defined. *)

(raise E) 1 ;;
(* Uncaught exception: E *)

