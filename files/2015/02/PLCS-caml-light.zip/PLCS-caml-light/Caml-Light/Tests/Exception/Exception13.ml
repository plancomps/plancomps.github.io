exception E2 ;;
(* Exception E2 defined. *)

true && raise E2 ;;
(* Uncaught exception: E2 *)
