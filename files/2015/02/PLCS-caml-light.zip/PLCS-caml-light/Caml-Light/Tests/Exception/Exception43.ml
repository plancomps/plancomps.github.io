exception X ;;
(* Exception X defined. *)

let x = raise X ;;
(* Uncaught exception: X *)
