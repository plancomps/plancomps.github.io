exception E2 ;;
(* Exception E2 defined. *)

false || raise E2 ;;
(* Uncaught exception: E2 *)
