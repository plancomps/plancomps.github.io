exception E ;;
(*
Exception E defined.
*)

let x = 1 in raise E ;;
(* Uncaught exception: E *)
