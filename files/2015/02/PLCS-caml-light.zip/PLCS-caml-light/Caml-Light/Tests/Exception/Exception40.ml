7 / 0 ;;
(* Uncaught exception: Division_by_zero *)