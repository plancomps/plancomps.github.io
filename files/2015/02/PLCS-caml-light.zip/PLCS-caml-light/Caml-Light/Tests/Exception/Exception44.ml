exception E ;;
(* Exception E defined. *)

let e = E ;;
(* e : exn = E *)

raise e ;;
(* Uncaught exception: E *)
