type e == exn ;;
(* Type e defined. *)

exception E1 ;;
(* Exception E1 defined. *)

(E1 : e) ;;
(* - : e = E1 *)
