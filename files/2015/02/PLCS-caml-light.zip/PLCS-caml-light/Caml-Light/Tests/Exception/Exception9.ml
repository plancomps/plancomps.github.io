exception E ;;
(* Exception E defined. *)

raise E :: [] ;;
(* Uncaught exception: E *)
