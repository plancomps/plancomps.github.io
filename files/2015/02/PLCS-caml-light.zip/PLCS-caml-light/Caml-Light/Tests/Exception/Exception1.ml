exception E ;;
(* Exception E defined. *)

1 + raise E ;;
(* Uncaught exception: E *)
