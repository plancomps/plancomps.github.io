exception E3 ;;
(*
Exception E3 defined.
*)

for i = 0 to 0
do
  raise E3
done ;;
(* Uncaught exception: E3 *)
