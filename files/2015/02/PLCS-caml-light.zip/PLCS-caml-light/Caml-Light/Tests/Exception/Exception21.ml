exception E2 ;;
(* Exception E2 defined. *)

while true do raise E2 done ;;
(* Uncaught exception: E2 *)
