exception E ;;
(* Exception E defined. *)

((raise E) : int) ;;
(* Uncaught exception: E *)
