exception E1 ;;
(* Exception E1 defined. *)

exception E2 ;;
(* Exception E2 defined. *)

raise E1 ;;
(* Uncaught exception: E1 *)
