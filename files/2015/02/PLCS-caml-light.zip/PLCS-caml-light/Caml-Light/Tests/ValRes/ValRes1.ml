(* Value restriction test. *)

let e = []
 in (true :: e, 7 :: e) ;;
(* bool list * int list = [true], [7] *)
