type 'a t = C ;;
(* Type t defined. *)

(C : int t) ;;
(* - : int t = C *)
