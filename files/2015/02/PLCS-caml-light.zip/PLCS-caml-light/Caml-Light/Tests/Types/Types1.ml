type ty1 = A ;;
(* Type ty1 defined.*)

A ;;
(* - : ty1 = A *)

let (x : ty1) = A ;;
(* x : ty1 = A *)

x ;;
(* - : ty1 = A *)
