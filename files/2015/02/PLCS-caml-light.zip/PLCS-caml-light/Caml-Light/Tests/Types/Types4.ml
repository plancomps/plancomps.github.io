type integer == int ;;
(* Type integer defined. *)

(3 : integer) ;;
(* - : integer = 3 *)
