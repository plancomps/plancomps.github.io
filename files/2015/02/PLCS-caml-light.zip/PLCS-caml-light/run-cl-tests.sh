#!/bin/bash

function run-test-set {
  testName=$1
  testDir="Caml-Light/Tests/$testName"

  for i in $(seq $2 $3)
  do

    echo -e "\n$testName Test $i:"

    ./run-fct.sh ${testDir}/${testName}$i.fct

  done
}

run-test-set "Basic" 1 21

run-test-set "Advanced" 1 11

run-test-set "Shadowing" 1 8

run-test-set "Types" 1 12

run-test-set "MuRecTypes" 1 6

run-test-set "OL" 1 22
echo "Skipping OL Test 23, it takes too long."
run-test-set "OL" 24 26

run-test-set "PM" 1 20

run-test-set "Exception" 1 44

run-test-set "Equality" 1 12

run-test-set "ValRes" 1 12

run-test-set "Syntax" 1 6
