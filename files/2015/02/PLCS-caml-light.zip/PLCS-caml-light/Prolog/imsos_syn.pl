/* Abstract syntax of IMSOS (informal)

 imsos_file(imsos_item list)
 
 a imsos_item can be:
 * imsos_rule(imsos_form list, form)

 * imsos_typeeq(Type1,Type2) -- sort equality
 * imsos_valsort(Type) -- value sort declaration
 * imsos_sigdec(F,Out,List(Ins)) -- signature declaration
 * imsos_valcons(Functor) - Functor is a value constructor
 * imsos_subsort(Type,Type) - Subsorting

 * imsos_readable(component)
 * imsos_writeable(component)
 * imsos_entity(Name,Default) -- default entity declaration
 
 a imsos_form can be:
 * imsos_termeq(imsos_term,imsos_term) -- term equality (in premise, RHS is normal form)
    * imsos_terms are similar to Prolog terms (translated verbatim, apart from
      unquoting vars)
 * imsos_notermeq(imsos_term,imsos_term) -- term equality (in premise, RHS is normal form)
          except, first var => second must be var
 * imsos_termlt(imsos_term,imsos_term) -- term comparison (lexical, opaque) *premise only*
 * imsos_onestep(imsos_term,label,imsos_term,relation)
    * label is a partial list of equations [Lcomp=Lvalue, Lcomp += Lvalue]
      following MSOS conventions
    * relation is relation type - run | resolve | inhabit | subtype | intype (=inhabit + subtype)
 * imsos_neg(imsos_formula) - negation *premise only*
 * imsos_sigdec(F,Out,List(Ins)) - signature declaration
 * imsos_runcheck(Term,Type) - lightweight runtime membership checking for value types *premise only*
 * imsos_valsort(Type) -- value sort declaration
 * imsos_sigdec(F,Out,List(Ins)) -- signature declaration
 * imsos_subsort(Type,Type) -- subsort declaration

 * note that there's a special "val" value sort that matches any declared value

 for concrete syntax, see DCG below and also examples in funcons.imsos
 
*/

% LEXICALS
% --------

upper(C) --> [C], { char_type(C, upper) }. % A-Z

lower(C) --> [C], { char_type(C, lower) }. % a-z

alpha(C) --> [C], { char_type(C, alpha) }. % A-Z, a-z

digit(C) --> [C], { char_type(C, digit) }. % 0-9

alnum(C) --> [C], { char_type(C, alnum) }. % A-Z, a-z, 0-9

csym(C) --> [C], { char_type(C, csym) }. % A-Z, a-z, 0-9, _
csym(95) --> "\'". % replace prime for underscore

graph(C) --> [C], { char_type(C, graph) }. % visible characters

white --> [C], { char_type(C, white) }. % space, tab

newline --> [C], { char_type(C, end_of_line) }. % newline on Unix-like systems

syms([C|Cs]) --> csym(C), !, syms(Cs). % String of symbols
syms([]) --> "".

syms_low([C|Cs]) --> lower(C), syms(Cs). % Starting lower case
syms_up([C|Cs]) --> upper(C), syms(Cs). % Starting upper case

letter(C) --> upper(C) ; lower(C).

letters([C|Cs]) --> letter(C), !, letters(Cs).
letters([]) --> "".

digits([C|Cs]) --> digit(C), !, digits(Cs).
digits([]) --> "".

notquote([C|Cs],[C|Cs1],Rest) :- C \= 39, !, notquote(Cs,Cs1,Rest).
notquote([],[39|Cs],[39|Cs]).

not2quote([C|Cs],[C|Cs1],Rest) :- C \= 34, !, not2quote(Cs,Cs1,Rest).
not2quote([],[34|Cs],[34|Cs]).

% Layout and Comments

mblanklines --> mwhites, newline, mwhites, newline, moptblanklines.
mblanklines --> mwhites, ".", mwhites, newline, moptblanklines.

moptblanklines --> mwhites, newline, moptblanklines.
moptblanklines --> mwhites.

m --> mwhites, newline, !, mwhites.
m --> mwhites.

mwhites --> mwhite, !, mwhites.
mwhites --> "".

up_to(Cs) --> Cs, !.
up_to(Cs) --> [_], up_to(Cs).

mwhite --> white.
mwhite --> "/*", up_to("*/").
mwhite --> "%", up_to("\n").

% Infer (dashed line) concrete syntax

mline --> "----", moptline.
moptline --> "-", !, moptline.
moptline --> "".

% PARSING
% -------

% Considering the first-order fragment, terms are just Prolog terms,
% represented as Prolog atoms.
% Variable names are placed in single quotes to prevent Prolog alpha conversion.
% Variables can also be placed in the functor position ('F'(a,b)) and are
% universally quantified.

% Second-order arguments are placed between the functor and arguments seperated
% by spaces.
% These may only be variables or nullary functors.
% e.g. seq F(a,b) or seq F skip(a,b).
% these are translated to prolog terms seq_1(F,a,b) and seq_2(F,skip,a,b) with
% the subscript representing the higher-order arguments, only included to avoid
% name clashes.

iterm2(Term) --> syms_low(Cons), {read_from_chars(Cons,Func)},
   {Term =.. [Func]}.   % constructor with no args

% Term1 is a subset of the terms, those that may appear in a 2nd order position
iterm1(_) --> "_".
iterm1(Term) --> syms_low(Cons), {read_from_chars(Cons,Func)},
   {Term =.. [Func]}.   % constructor with no args
iterm1(Atom) --> syms_up(Var), {append([39|Var],[39],QuoteVar)},   
    {read_from_chars(QuoteVar,Atom)}. % variable

iterm(Term1) --> iterm3(Term), more(Term,Term1).

more(Term1,Term) --> "->", iterm3(Term2), { Term = depends(Term1,Term2) }.
more(Term,Term) --> "".

iterm3(Term) --> iterm1(Term).
iterm3(Term) --> "->", iterm(Term1), { Term = computes(Term1) }.
iterm3(Term) --> syms_low(Cons), "(" , m, iterms(Ts) , m, ")",  % constructor with % m added by peter
    {read_from_chars(Cons,Func)}, {Term =.. [Func|Ts]}.     % only FO args
iterm3(Term) --> syms_low(Cons), " ", hoargs(Terms), {length(Terms,Len)},
   {name(Len,LenStr)}, {append([Cons,"_",LenStr],Cons1)},  % constructor with
   {read_from_chars(Cons1,Func)}, {Term =.. [Func|Terms]}. % only SO args
iterm3(Term) --> syms_low(Cons), " ", hoargs(Terms), "(" , m, iterms(Ts) , m, ")", % m added by peter
   {length(Terms,Len)}, {name(Len,LenStr)}, {append([Cons,"_",LenStr],Cons1)},
   {read_from_chars(Cons1,Func)}, {append(Terms,Ts,AllTerms)},
   {Term =.. [Func|AllTerms]}. % constructor with FO and SO args
iterm3(Term) --> syms_up(VarCons), "(" , m, iterms(Ts) , m,  ")", % variable functor, % m added by peter
    {append([39|VarCons],[39],QuoteVar)},                 % applied to arguments
    {read_from_chars(QuoteVar,Atom)},
    {Term =.. [Atom|Ts]}.
% Atoms
iterm3(Term) --> "'", notquote(Cs), "'", { name(Term1,Cs), Term = q(Term1) }.
% Literals
iterm3(Term) --> "\"", not2quote(Cs), "\"", { append(["\"",Cs,"\""],Ds),
                 name(Term1,Ds), Term = str(q(Term1)) }.
iterm3(Term) --> digits([D|Igits]), ".", digits(Digits1),
         { append([[D|Igits],".",Digits1],Digits2), number_codes(Term1,Digits2),
           Term = q(Term1) }.
iterm3(Term) --> digits([D|Igits]), { number_codes(Term1,[D|Igits]), Term = q(Term1) }.
iterm3(Term) --> "-", digits([D|Igits]), { number_codes(Term1,[D|Igits]), Term2 is - Term1, Term = q(Term2) }.
iterm3(Term) --> "{", m, imap(Term), m, "}".
iterm3(Term) --> "[", m, ilist(Term), m, "]".

imap(map_empty) --> "".
imap(map_update(map_empty,Key,Val)) --> iterm(Key), m, "|-->", m, iterm(Val).
imap(map_update(Map,Key,Val)) --> iterm(Key), m, "|-->", m, iterm(Val), m, ",", m, imap(Map).

ilist(list_empty) --> "".
ilist(list_prefix(X,list_empty)) --> iterm(X).
ilist(list_prefix(X,Xs)) --> iterm(X), m, ",", m, ilist(Xs).

hoargs([Term]) --> iterm1(Term).
hoargs([Term|Terms]) --> iterm1(Term), " ", hoargs(Terms).

iterms([Term|Terms]) --> iterm(Term), iterms_more(Terms).

iterms_more(Terms) --> "," , m, !, iterms(Terms).
iterms_more([]) --> "".

% Auxiliary entity names, just prolog atoms

cauxent(Comp) --> syms_low(StrComp) , {read_from_chars(StrComp,Comp)}.

% Transitions, represented as described above.

iform(Formula) --> iterm(Source), m, "=", m, iterm(Target),
     { Formula = imsos_termeq(Source,Target) }.
iform(Formula) --> iterm(Source), m, "!=", m, iterm(Target),
     { Formula = imsos_notermeq(Source,Target) }.
iform(Formula) --> iterm(Source), m, "@<", m, iterm(Target),
     { Formula = imsos_termlt(Source,Target) }.
iform(Formula) --> iterm(Source), m, "@>", m, iterm(Target),
     { Formula = imsos_termlt(Target,Source) }.
iform(Formula) --> ireads(Eqns1), m, irwsource(Eqns2,Source), m,
     iarrwrites(Eqns3), m, irwtarget(Eqns4,Target),
     { append([Eqns1,Eqns2,Eqns3,Eqns4],Eqns),
       Formula = imsos_onestep(Source,Eqns,Target,run)}.
iform(Formula) --> "Funcon", m, iterm(Source), m, ":", m, iterm(Target),
     { Source =.. [F|Args] , Formula = imsos_sigdec(F,Target,Args) } .
iform(Formula) -->
     ireads(Eqns1), m, irwsource(Eqns2,Source), m, iarrwritesbig(Eqns3), m,
     irwtarget(Eqns4,Target),
     { append([Eqns1,Eqns2,Eqns3,Eqns4],Eqns),
       Formula = imsos_onestep(Source,Eqns,Target,resolve) }.
iform(Formula) -->
     ireads(Eqns1), m, irwsource(Eqns2,Source), m, iarrwritestyp(Eqns3), m,
     irwtarget(Eqns4,Target),
     { append([Eqns1,Eqns2,Eqns3,Eqns4],Eqns),
       Formula = imsos_onestep(Source,Eqns,Target,typeval) }.
iform(Formula) -->
     ireads(Eqns1), m, irwsource(Eqns2,Source), m, ":", m,
     irwtarget(Eqns4,Target),
     { append([Eqns1,Eqns2,Eqns4],Eqns),
       Formula = imsos_onestep(Source,Eqns,Target,inhabit) }.
iform(Formula) -->
     ireads(Eqns1), m, irwsource(Eqns2,Source), m, ":<", m,
     irwtarget(Eqns4,Target),
     { append([Eqns1,Eqns2,Eqns4],Eqns),
       Formula = imsos_onestep(Source,Eqns,Target,intype) }.
iform(Formula) -->
     ireads(Eqns1), m, irwsource(Eqns2,Source), m, "<", m,
     irwtarget(Eqns4,Target),
     { append([Eqns1,Eqns2,Eqns4],Eqns) , 
       Formula = imsos_onestep(Source,Eqns,Target,subtype) }.
iform(Formula) -->
     "~", m, iform(Formula1),
     { Formula = imsos_neg(Formula1) }.
iform(Formula) --> iterm2(Type), m, "(", m , iterm(Term) , m, ")",
     { Formula = imsos_runcheck(Term,Type) }.

:- op(700, xfx, (+=)).

ireads(Eqns) --> ireadpairs(Eqns), m, "|-".
ireads([]) --> "".

iarrwrites([]) --> "-->".
iarrwrites(Eqns) --> "--", m, iwritepairs(Eqns), m, "-->".

iarrwritesbig([]) --> "==>".
iarrwritesbig(Eqns) --> "==", m, iwritepairs(Eqns), m, "==>".

iarrwritestyp([]) --> "~~>".
iarrwritestyp(Eqns) --> "~~", m, iwritepairs(Eqns), m, "~~>".

ireadpairs(Labels) --> cauxent(CompName), m, iterm(CompValue),
    { Labels = [CompName = CompValue] }.
ireadpairs(Labels) --> cauxent(CompName), m,
    iterm(CompValue), m, ",", m, ireadpairs(Rest),
    { Labels = [CompName = CompValue|Rest] }.

iwritepairs(Labels) --> cauxent(CompName), m, iterm(CompValue),
    { Labels = [CompName += CompValue] }.
iwritepairs(Labels) --> cauxent(CompName), m,
    iterm(CompValue), m, ",", m, ireadpairs(Rest),
    { Labels = [CompName += CompValue|Rest] }.

irwsource(Eqns,Source) --> "(", m, iterm(Source), m, "," , m,
       ireadpairs(Eqns), m, ")".
irwsource([],Source) --> iterm(Source).

irwtarget(Eqns,Target) --> "(", m, iterm(Target), m, "," , m,
       iwritepairs(Eqns), m, ")".
irwtarget([],Target) --> iterm(Target).

% Items, represented as above.

iconds([Tran|Trans]) --> iform(Tran), m, ",", m, iconds(Trans).
iconds([Tran]) --> iform(Tran).

iitem(Item) --> iconds(Prem), m, mline, m, iform(Conc),
      { Item = imsos_rule(Prem,Conc) }.
iitem(Item) --> iform(Conc),
      { Item = imsos_rule([],Conc) }.
iitem(Item) --> "Entity Default", m, cauxent(Name), m, "=", m, iterm(Default),
      { Item = imsos_entity(Name,Default) }.
iitem(Item) --> "Value Type", m, iterm(Type),
      { Item = imsos_valsort(Type) }.
%iitem(Item) --> "Nominal Type", m, iterm(Type),
%      { Item = imsos_nomtype(Type) }.
iitem(Item) --> iterm(Sort1), m, "==", m, iterm(Sort2),
      { Item = imsos_typeeq(Sort1,Sort2) }.

% Files, lists of rules.

ifile(imsos_file(CSF)) --> moptblanklines, ifile1(CSF), moptblanklines.

ifile1([Rule|Rules]) --> iitem(Rule), mblanklines, ifile1(Rules).
ifile1([Rule]) --> iitem(Rule).
ifile1([]) --> "".

% Reads entire file (stream) to a string [needed for parsers]
read_entire_file(Stream,"") :- at_end_of_stream(Stream), !.
read_entire_file(Stream,String) :- read_line_to_codes(Stream,X),
  read_entire_file(Stream,Xs), append([X,"\n",Xs],String).


