/* IMSOS Library

   To be added to Prolog generated from imsos2pl.pl

*/

% IMSOS - generated predicates
% --------------------------

:- multifile onestep/4, readable/1, writeable/1, default/2, rewrite/2, typedef/2, valsort/1, sigdec/3, valcons/1, subsort/2, decompose/3.
:- discontiguous onestep/4, readable/1, writeable/1, default/2, rewrite/2, typedef/2, valsort/1, sigdec/3, valcons/1, subsort/2, decompose/3.
:- dynamic onestep/4, readable/1, writeable/1, default/2, rewrite/2, typedef/2, valsort/1, sigdec/3, valcons/1, subsort/2, decompose/3.

:- op(700, xfx, (+=)).

:- dynamic tracing/0.

% old

:- dynamic inhabit/3.

% IMSOS MECHANICS
% ---------------

/* Mechanics of MSOS label propogation */

% Records are represented by unordered lists of equations [...,I=A,...]

% unprimed index: I=A  (initial value of label component)
% "primed" index: I+=A (final value of label component)

% Computation sorts out initial label (second arg. may be just a variable)

% readable and writeable is a predicate on label components declaring their
% status generated automatically

changeable(I) :- readable(I), writeable(I).

% default gives default value of label components (for readable components:
% starting value).
% for writeable and not readable, the "identity" arrow

% Composition...

% pre_comp(X, X1) sets readable components of X1

pre_comp([I=C|L], X1) :-
        select(I=C, X1, L1), !, pre_comp(L, L1).
pre_comp([I+=_C|L], X1) :-
        select(I+=_, X1, L1), !, pre_comp(L, L1).
pre_comp([], []).

% mid_comp(X1, X2) sets readable components of X2

mid_comp([I=C1|L1], X2) :-
        ( changeable(I) ->
            select(I+=_, X2, L2) ;
            select(I=C1, X2, L2) ), !,
        mid_comp(L1, L2).

mid_comp([I+=C1|L1], X2) :-
        ( changeable(I) ->
            select(I=C1, X2, L2) ;
            select(I+=_, X2, L2) ), !,
        mid_comp(L1, L2).

mid_comp([], []).

% post_comp(X1, X2, X) sets writeable components of X

post_comp([_=_|L1], X2, X) :-
        post_comp(L1, X2, X).

post_comp([I+=C1|L1], X2, X) :-
        member(I+=C2, X2),
        ( changeable(I) ->
            member(I+=C2, X) ;
            combwrite(I,C1,C2,C),
          member(I+=C, X) ), !,
        post_comp(L1, X2, X).

post_comp([], _X2, _X).

% combwrite deals with composition of writeables.
% component,first,second,output

combwrite(I,D,C,C) :- writeable(I), \+ readable(I), removechecks(D,D1), default(I,D1).
combwrite(I,C,D,C) :- writeable(I), \+ readable(I), removechecks(D,D1), default(I,D1).
combwrite(I,_,D,D) :- changeable(I).
combwrite(I,C,D,E) :- rewrites(monop(I,C,D),E).

/* Label observability: */

unobs([I=C|L]) :-
        \+ writeable(I) -> unobs(L) ;
        select(I+=C, L, L1), unobs(L1).

unobs([I+=C|L]) :-
        \+ readable(I) -> default(I,C), unobs(L) ;
        select(I=C, L, L1), unobs(L1).

unobs([]).

% eq_label(X, [...|R]) holds when X contains ... and R is the rest of X
% used for extracting R from a concrete list

eq_label(X, L) :-
        var(L) -> X = L ;
        L=[H|T],
        select(H, X, R),
        eq_label(R, T).

/* Transitive closure of "run" */

% Manysteps continues running until getting stuck

manysteps(T1,L,T3) :-
        pre_comp(L,L1),
    rewrites(T1,T1a),
    (tracing -> prompting(T1a) ; true),
        onestep(T1a,L1,T2,run), !,
        mid_comp(L1,L2),
        manysteps(T2,L2,T3),
    post_comp(L1,L2,L).
manysteps(T,L,T1) :- rewrites(T,T1), unobs(L).

% Maysteps keeps track of all possible computations

manysteps_all(T1,L,T3) :-
        pre_comp(L,L1),
        rewrites(T1,T1a),
        onestep(T1a,L1,T2,run),
        mid_comp(L1,L2),
        manysteps_all(T2,L2,T3),
        post_comp(L1,L2,L).
manysteps_all(T,L,T1) :- rewrites(T,T1), unobs(L).

% Premises of rules

runstep(Term,Label,Term1) :- (deep_tracing -> prompting(Term) ; true) , onestep(Term,Label,Term1,run).

% Inhabit does type inhabitance, also evaluating types to normal form.
% Diferrent strategies for checking and inference (first, second below)
%
% Checking x : A (given first) uses:
%
% A => B , x : C , C => B
% -----------------------
%      x : A
%
% if this fails, we then try a second strategy
%
%
% A => B , x : B
% --------------
%     x : A
%
% which passes the target type up the proof search
%
%
% Inference x : A (given second) uses:
%
% x : A , A => B
% --------------
%      x : B

typeval(Term,Label,Term1) :- \+ ground(Term), !, Term1 = Term, unobs(Label).
typeval(Term,Label,Type) :- onestep(Term,Label,Type,typeval), !.
typeval(Term,Label,Term) :- unobs(Label).

inhabit(Term,Label,Type) :- nonvar(Type), pre_comp(LabelA,Label),pre_comp(Label,Label1),
							rewrites(Type,TypeA), typeval(TypeA,Label1,Type2), mid_comp(Label1,Label2), rewrites(Type2,Type2a),
							rewrites(Term,Term1),onestep(Term1,Label2,Type4,inhabit),post_comp(Label1,Label2,Label),mid_comp(LabelA,LabelB),rewrites(Type4,Type4a),removechecks(Type4a,Type4b),
							typeval(Type4b,LabelB,Type5),post_comp(LabelA,LabelB,Label),rewrites(Type5,Type5a) ->  removechecks(Type2a,Type3), removechecks(Type5a,Type3).
inhabit(Term,Label,Type) :- removechecks(Type,Type1), nonvar(Type1), %(nonvar(Type1) ; Type1 = depends(Type1Source,_) , nonvar(Type1Source)),
                            pre_comp(Label,Label1), rewrites(Type1,TypeA), typeval(TypeA,Label1,Type2), mid_comp(Label1,Label2), rewrites(Type2,Type2a),
                            removechecks(Type2a,Type3),	rewrites(Term,Term1) -> onestep(Term1,Label2,Type3,inhabit),post_comp(Label1,Label2,Label).
/* inhabit(Term,Label,Type) :- var(Type), rewrites(Term,Term1), onestep(Term1,Label,Type1,inhabit), rewrites(Type1,Type1b), removechecks(Type1b,Type1a),
                            rewrites(Type1a,Type3) -> removechecks(Type,TypeR), removechecks(Type3,TypeR). */
inhabit(Term,Label,Type) :- var(Type), rewrites(Term,Term1), pre_comp(Label,Label1), onestep(Term1,Label1,Type1,inhabit), mid_comp(Label1,Label2), rewrites(Type1,Type1b),
                            removechecks(Type1b,Type1a), typeval(Type1a,Label2,Type2), post_comp(Label1,Label2,Label),rewrites(Type2,Type3) -> removechecks(Type3,Type).

subtype(Term,Label,Type) :- var(Term), !, Type = Term, unobs(Label).
subtype(ischecked(Term,_),Label,Type) :- !, subtype(Term,Label,Type).
subtype(Term,Label,X) :- X == ischecked(Type,_), !, subtype(Term,Label,Type).
subtype(Type,Label,Type) :- unobs(Label).
subtype(Subtype,Label,Type) :- nonvar(Subtype), pre_comp(Label,Label1), onestep(Subtype,Label1,Type1,subtype),
                               mid_comp(Label1,Label2), subtype(Type1,Label2,Type), post_comp(Label1,Label2,Label).
subtype(Subtype,Label,Type) :- nonvar(Type), typedef(Subtype,Subtype2), subtype(Subtype2,Label,Type).
subtype(Subtype,Label,Type) :- typedef(Type,Type1), subtype(Subtype,Label,Type1).

% SORTING HAT
% -----------

% Checking a term is of a particular sort, according to signatures

% This clause will always fail, so I've commented it out.  TODO: investigate why it is here?
% deccheck(Term,Type) :- (X == val ; X == ground) , runcheck(Term,Type).
deccheck(Term,Type) :- Term=q(_), !, sigdec(Term,Type1,[]), subsort_rt(Type1,Type).
deccheck(Term,Type) :- Term=gen(Type1), !, subsort_rt(Type1,Type).
deccheck(Term,Type) :- Term=..[F|Xs], name(F,Fn), append([_,"_",Num1],Fn), name(Num,Num1), integer(Num), !,
      firsts(Num,Xs,Ys1), append(Ys1,Ys2,Ys), sigdec(F,Type1,Ys), lasts(Num,Xs,Xs1), decchecks(Xs1,Ys2),
      subsort_rt(Type1,Type).
deccheck(Term,Type) :- Term=..[F|Xs], sigdec(F,Type1,Ys), decchecks(Xs,Ys), subsort_rt(Type1,Type).
decchecks([],[]).
decchecks([X|Xs],[Y|Ys]) :- deccheck(X,Y), decchecks(Xs,Ys).

firsts(0,_,[]) :- !.
firsts(N,[X|Xs],[X|Ys]) :- M is N - 1, firsts(M,Xs,Ys).

lasts(0,Xs,Xs).
lasts(N,[_|Xs],Ys) :- M is N - 1, lasts(M,Xs,Ys).

% Checking a term is of a particular value sort, according to signatures, optimised for runtime

% For efficiency, at runtime we use ischecked(X,normal) to mean X has been reduced to normal form.
% By replacing normal by a type, we also note that X has been judged to have that value type.

% The following lines make 'ischecked' transparent with regard to steps and signatures:

onestep(X,L,O,resolve) :- var(X), !, O = X, unobs(L).
onestep(ischecked(Term,_),L,O,Relation) :- !, onestep(Term,L,O,Relation).

sigdec(ischecked(F,_),Xs,X) :- !, sigdec(F,Xs,X).

% and this line gives code for adding the 'checked' tag if it's not already there
%(used in generated prolog)

checktag(ischecked(Term,_),Type,ischecked(Term,Type)) :- !.
checktag(Term,Type,ischecked(Term,Type)).

% runtime checking...

runcheck(Term,X) :- X == var, removechecks(Term,Term1), nonvar(Term1), !, fail.
runcheck(Term,X) :- X == var, removechecks(Term,Term1), var(Term1), !.
runcheck(_,Y) :- var(Y), !.
runcheck(ischecked(_,Type),Type1) :- Type == Type1, !.
runcheck(ischecked(E,normal),Type1) :- !, runcheck1(E,Type1).
runcheck(ischecked(_,Type),Type1) :- subsort_rt(Type,Type1), !.
runcheck(ischecked(Term,_),Type1) :- runcheck(Term,Type1), !.
runcheck(Term,Type) :- rewrites(Term,Term1), Term1 = ischecked(Term2,normal), runcheck1(Term2,Type).

runcheck1(_,Type) :- \+ valsort(Type), !.
%runcheck1(Term,X) :- X == constant, Term =.. [F], valcons(F).
%runcheck1(Term,X) :- X == constant, Term = q(_), !.
runcheck1(Term,X) :- X == nullary, Term =.. [_].
runcheck1(Term,X) :- X == nullary, Term = q(_), !.
runcheck1(Term,X) :- X == ground, Term=q(_), !.
runcheck1(Term,X) :- X == ground, !, Term=..[F|Xs], valcons(F), sigdec(F,_,Ys),
                       length(Xs,N), length(Ys,N), maplist(runcheck_ground,Xs).
runcheck1(Term,Type) :- Term=q(_), !, sigdec(Term,Type1,[]), subsort_rt(Type1,Type).
runcheck1(Term,Type) :- Term=..[F|Xs], valcons(F), sigdec(F,Type1,Ys),
                       subsort_rt(Type1,Type), runchecks(Xs,Ys).

runcheck_ground(Term) :- runcheck(Term,ground).

runchecks([],[]).
runchecks([X|Xs],[Y|Ys]) :- runcheck(X,Y), runchecks(Xs,Ys).

% Checking a term is of a particular sort according to signatures, with supsumption enabled

% The cut is present for efficiency. Complete if each functor has one sigdec (apart from liftings)
supcheck(Term,Type) :- Term=q(_), !, sigdec(Term,Type1,[]), subsort_rt(Type1,Type).
supcheck(Term,Type) :- Term=gen(Type1), !, bounded_above(Type,Type1).
supcheck(Term,Type) :- Term=..[F|Xs], name(F,Fn), append([_,"_",Num1],Fn), name(Num,Num1), integer(Num), !,
      firsts(Num,Xs,Ys1), append(Ys1,Ys2,Ys), sigdec(F,Type1,Ys), lasts(Num,Xs,Xs1), supchecks(Xs1,Ys2), !,
      bounded_above(Type1,Type).
supcheck(Term,Type) :- Term=..[F|Xs], sigdec(F,Type1,Ys), supchecks(Xs,Ys), !, bounded_above(Type,Type1).
supchecks([],[]).
supchecks([X|Xs],[Y|Ys]) :- supcheck(X,Y), supchecks(Xs,Ys).

bounded_above(Type,Type1) :- ( var(Type) ; var(Type1) ) , !, Type = Type1.
bounded_above(Type,Type1) :- subsort_rt(Type1,Type), !.
bounded_above(Type,Type1) :-
       setof(Type1sup,subsort_rt(Type1,computes(Type1sup)),Type1sups),
       setof(Typesup,subsort_rt(Type,computes(Typesup)),Typesups),
       share_element(Type1sups,Typesups).
share_element([X|_],[X|_]) :- !.
share_element([X|Xs],[Y|Ys]) :- Y @< X , share_element([X|Xs],Ys).
share_element([X|Xs],[Y|Ys]) :- X @< Y , share_element(Xs,[Y|Ys]).

% Checking a sort is a subsort of another sort

subsort_rt(Subtype,Type) :- Type == val , !, valsort(Subtype).
subsort_rt(Subtype,Type) :- var(Subtype) , var(Type), !, Subtype = Type.
subsort_rt(Type,Type).
subsort_rt(Subtype,Type) :- nonvar(Subtype), subsort(Subtype,Type1), subsort_rt(Type1,Type).
subsort_rt(Subtype,Type) :- nonvar(Type), typedef(Subtype,Subtype2), subsort_rt(Subtype2,Type).
subsort_rt(Subtype,Type) :- typedef(Type,Type1), subsort_rt(Subtype,Type1).

decompose(NewVar,_,Args) :- var(NewVar), var(Args), !.
decompose(NewVar,Func,_) :- var(NewVar), var(Func), !.
decompose(NewVar,Func,NewTs) :- removechecks(Func,Func1), removechecks(NewVar,NewVar1),
        maplist(removechecks,NewTs,NewTs1), NewVar1 =.. [Func1|NewTs1].

% REWRITES AND INEQUALITIES
% -------------------------

% Equational rewrite. rewrite(X,Y) will always succeed, Y is X is normal form
% (may just be equal to X).

% The definition has been mutilated a little so that ischecked is transparent with
% respect to rewrites. As well as adding a normal form tag to the RHS, there is
% a little additional complexity. CSF-generated Prolog uses rewrites(X,Y) to see if
% X and Y are the same when Y is a concrete term. In such cases, we need to ensure
% that the equality testing ignores 'ischecked's

rewrites(E,F) :- var(E), !, E = F.
rewrites(ischecked(Term,Type),F) :- var(F), !, F = ischecked(Term,Type).
rewrites(TermA,X) :- \+ var(X), X = ischecked(Term1,_), !, rewrites(TermA,Term1).
rewrites(ischecked(Term,_),Term1) :- \+ var(Term1), !, rewrites(Term,Term1).
rewrites(E,E2) :- rewrite(E,E1), !, rewrites(E1,E2).
rewrites(E,X) :- var(X), !, X = ischecked(E,normal).
rewrites(TermA,X) :- nonvar(X), removechecks(X,X1), \+ X = X1 , rewrites(TermA,X1).
%rewrites(TermA,X) :- nonvar(X), removechecks(TermA,TermB), \+ TermA == TermB , rewrites(TermB,X).
rewrites(TermA,X) :- nonvar(X), nonvar(TermA), X = TermA.
rewrites(TermA,X) :- nonvar(X), nonvar(TermA), X =.. [F|Xs], TermA =.. [F|Ys], maplist(rewrites,Xs,Ys).
rewrites(E,E).

removechecks(X,Y) :- var(X), !, X = Y.
removechecks(ischecked(Term,_),Term1) :- !, removechecks(Term,Term1).
removechecks(Term1,Term) :- Term1 =.. [F|Xs], maplist(removechecks,Xs,Ys), Term =.. [F|Ys].

lessthan(A,B) :- removechecks(A,A1), removechecks(B,B1), A1 @< B1.

different(A,_) :- removechecks(A,A1), var(A1), !.
different(A,B) :- removechecks(A,A1), removechecks(B,B1), nonvar(A1), \+ rewrites(A1,B1).

% RUNNING COMPUTATIONS
% --------------------

% generation of start label from declared defaults

start_comp(X=Y) :- readable(X), default(X,Y).
start_comp(X+=_) :- writeable(X).

start_label(L1) :- findall(X,start_comp(X),L), sort(L,L1).

% compute("funcon tree",L,O) computes funcon tree, L becomes label trace,
%   O final value.
compute(T,L1,Out1) :- start_label(L), manysteps(T,L,Out), removechecks(Out,Out1), removechecksL(L,L1).

removechecksL([],[]).
removechecksL([X=T|Xs],[X=T1|Xs1]) :- removechecks(T,T1), removechecksL(Xs,Xs1).
removechecksL([X+=T|Xs],[X+=T1|Xs1]) :- removechecks(T,T1), removechecksL(Xs,Xs1).

% compute disregards alternative computation paths by using cut,
%   to keep them use manysteps_all
compute_all(T,L1,Out1) :- start_label(L), manysteps_all(T,L,Out), removechecks(Out,Out1), removechecksL(L,L1).

% compute_type("funcon tree",L,T) runs typechecking on funcon tree
% L becomes label trace, T inferred type.
compute_type(Term,L1,Type1) :- start_label(L), inhabit(Term,L,Type), removechecks(Type,Type1), removechecksL(L,L1).

% check_type("funcon tree",L,"type") checks funcon tree is of given type
% L becomes label trace
check_type(Term,L,Type) :- start_label(L), inhabit(Term,L,Type).

% compute_type("funcon tree",L,T) runs typechecking on funcon tree with subsumption enabled
% L becomes label trace, T inferred type (sort).
%compute_sort(T,L2,Sort) :- start_label(L), eq_label(L,[ inhabit_mode = _ |L1]),
%   L2 = [inhabit_mode = sort|L1],
%   inhabit(T,L2,Type),
%   maxsuptype(Type,L2,Sort1),
%   (typedef(Sort,Sort1) ; Sort1 = Sort).

% check_sort("funcon tree",L,"type") checks funcon tree is of given sort
% L becomes label trace
%check_sort(Term,L,Type) :- start_label(L), eq_label(L,[ inhabit_mode = _ |L1]), L2 = [inhabit_mode = sort|L1], inhabit(Term,L2,Type).

% compute_static("funcon tree",L,T) runs static semantics on funcon tree
% L becomes label trace, T inferred type.
compute_static(Term,L,Term1) :- iterm(Sem,Term,[]), start_label(L), onestep(Sem,L,Term1,resolve).

% Command-line interface versions
% run(T) computes a funcon tree and prints output and label components that are
% not default, other functions do analogous things.

nondefaults([],[]).
nondefaults([X=Y|Eqns],Eqns2) :- default(X,Y), !, nondefaults(Eqns,Eqns2).
nondefaults([X=Y|Eqns],[X=Y|Eqns2]) :- nondefaults(Eqns,Eqns2).
nondefaults([X+=Y|Eqns],Eqns2) :- default(X,Y), !, nondefaults(Eqns,Eqns2).
nondefaults([X+=Y|Eqns],[X+=Y|Eqns2]) :- nondefaults(Eqns,Eqns2).

run(T) :- compute(T,L,Out), nondefaults(L,L1),
   print('-- '), print(L1), print(' --> '), print(Out).

% explores all computation paths, use ; for next
run_all(T) :- compute_all(T,L,Out), nondefaults(L,L1),
   inhabit(Out,[],val),
   print('-- '), print(L1), print(' --> '), print(Out).

% typeinfer(T) runs type inference and prints result
typeinfer(T) :- compute_type(T,L,Type), removechecks(Type,Type1), removechecks(L,L2),
   nondefaults(L2,L1), print(Type1), print(' '), print(L1).

% typecheck(Term,Type) checks term inhabits type
typecheck(Term,Type) :- check_type(Term,L,Type), removechecks(L,L2),
   nondefaults(L2,L1), print('ok with trace '), print(L1).

% sortcheck(Term,Type) checks term inhabits type
sortcheck(Term,Type) :- check_sort(Term,L,Type), nondefaults(L,L1),
   print('ok with trace '), print(L1).

% sortinfer(T) runs sort checking (inference) and prints result
sortinfer(T) :- compute_sort(T,L2,Sort), nondefaults(L2,L3),
   print(':'), print(Sort), print(' '), print(L3).

% static semantics
resolve(T) :- compute_static(T,L,Out), nondefaults(L,L1),
   print('== '), print(L1), print(' ==> '), print(Out).

% Debugging

:- dynamic tracing/0, deep_tracing/0.

prompting(Term) :- removechecks(Term,Term1), print_term(Term1, 0, ''), nl, get_code(_).

%% Pseudo-pretty printing
print_term(Term, Level, Postfix) :-
        ground(Term) ->
        print_subterm(Term, Level, Postfix).

print_subterm(Term, Level, Postfix) :-
        Term =.. [F|As],
        print(F),
        Level_ = Level + 1,
        ( As = [] -> print(Postfix)
        ; As = [_] ->
          ( print('('), print_args(As, Level), print(')'), print(Postfix) )
        ; ( print('('), nl, print_indentation(Level_),
            print_args(As, Level_), print(')'), print(Postfix) ) ).

print_args([], _) :- !.
print_args([Arg], Level) :-
        !, print_subterm(Arg, Level, '').
print_args([Arg|Args], Level) :-
        print_subterm(Arg, Level, ','), nl, print_indentation(Level),
        print_args(Args, Level).


print_indentation(Level) :- Level =< 0,  !.
print_indentation(Level) :- Level >= 50, !, print_indentation(49), print('|.. ').
print_indentation(Level) :-
        Level_ = Level - 1,
        print(' '),
        print_indentation(Level_).

valsort(A) :- var(A), !, fail.

% To see generated Prolog code, type listing(Predicate) where Predicate is :
%     onestep, decl_member, decl_inclusion, default, readable, writeable
% these are the predicates defined by generated code (declared dynamic here)

% to trace, spy on manysteps
