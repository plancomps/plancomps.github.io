:- ensure_loaded('tests_common').

list_prefix_match_test(1) :- Term = list_prefix_match(list1(true),only(true),only(list_empty)),
                             Type = map_empty,
                             Result = map_empty,
                             compute_type(Term,L1,Type), unobs(L1),
                             compute(Term,L2,Result), unobs(L2).

list_prefix_match_test(2) :- Term = list_prefix_match(list2(true,false),only(true),list_prefix_patt(only(false),only(list_empty))),
                             Type = map_empty,
                             Result = map_empty,
                             compute_type(Term,L1,Type), unobs(L1),
                             compute(Term,L2,Result), unobs(L2).

list_prefix_match_test(3) :- Term = list_prefix_match(list1(true),only(false),only(list_empty)),
                             Type = map_empty,
                             compute_type(Term,L1,Type), unobs(L1),
                             compute(Term,L2,_), member(failure += true, L2).

list_prefix_match_test(4) :- Term = list_prefix_match(list_empty,any,any),
                             Type = map_empty,
                             compute_type(Term,L1,Type), unobs(L1),
                             compute(Term,L2,_), member(failure += true, L2).

list_prefix_match_tests :- run_tests(list_prefix_match_test,4).

