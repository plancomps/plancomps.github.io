:- ensure_loaded('tests_common').

scope_test(1) :- Term = scope(map_empty,true),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

scope_test(2) :- Term = scope(map_empty,if_true(false,q(0),q(1))),
                 Type = ints,
                 Result = q(1),
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

scope_test(3) :- Term = scope(map1(id(q(x)),q(3)),q(1)),
                 Type = ints,
                 Result = q(1),
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

scope_test(4) :- Term = scope(map1(id(q(x)),q(3)),if_true(false,q(0),q(1))),
                 Type = ints,
                 Result = q(1),
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

scope_test(5) :- Term = scope(map1(id(q(x)),q(3)),if_true(false,q(0),bound_value(id(q(x))))),
                 Type = ints,
                 Result = q(3),
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

scope_test(6) :- Term = scope(map1(id(q(x)),false),scope(map1(id(q(x)),true),bound_value(id(q(x))))),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

scope_test(7) :- Term = scope(bind_value(id(q(x)),q(0)),bound_value(id(q(x)))),
                 Type = ints,
                 Result = q(0),
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

scope_tests :- run_tests(scope_test,7).
