:- ensure_loaded('tests_common').

effect_test(1) :- Term = effect(q(7)),
                  Type = unit,
                  Result = null,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

effect_test(2) :- Term = effect(seq(print(true),q(8))),
                  Type = unit,
                  Result = null,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), member(output+=list_prefix(true, list_empty), L2).

effect_test(3) :- Term = effect(alloc(true)),
                  Type = unit,
                  Result = null,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), member(store += map_prefix(var(_),true,map_empty), L2).

effect_tests :- run_tests(effect_test,3).

