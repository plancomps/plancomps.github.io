:- ensure_loaded('tests_common').

instantiate_type_test(1)  :- Term = typedef(id(q(ty)),instantiate_type(type_abs(list_empty,ints),list_empty)),
                             Type = map_prefix(id(q(ty)),ints,map_empty),
                             Result = map_empty,
                             compute_type(Term,L1,Type), unobs(L1),
                             compute(Term,L2,Result), unobs(L2).

instantiate_type_test(2)  :- Term = typedef(id(q(ty)),instantiate_type(type_abs(list1(typevar(q(a))),ints),list1(booleans))),
                             Type = map_prefix(id(q(ty)),ints,map_empty),
                             Result = map_empty,
                             compute_type(Term,L1,Type), unobs(L1),
                             compute(Term,L2,Result), unobs(L2).

instantiate_type_test(3)  :- Term = typedef(id(q(ty)),instantiate_type(type_abs(list1(typevar(q(a))),typevar(q(a))),list1(booleans))),
                             Type = map_prefix(id(q(ty)),booleans,map_empty),
                             Result = map_empty,
                             compute_type(Term,L1,Type), unobs(L1),
                             compute(Term,L2,Result), unobs(L2).

instantiate_type_test(4)  :- Term = typedef(id(q(ty)),instantiate_type(type_abs(list2(typevar(q(a)),typevar(q(b))),typevar(q(b))),list2(booleans,ints))),
                             Type = map_prefix(id(q(ty)),ints,map_empty),
                             Result = map_empty,
                             compute_type(Term,L1,Type), unobs(L1),
                             compute(Term,L2,Result), unobs(L2).

instantiate_type_test(5)  :- Term = typedef(id(q(ty)),instantiate_type(type_abs(list1(typevar(q(a))),type_abs(list1(typevar(q(a))),typevar(q(a)))),list1(booleans))),
                             Type = map_prefix(id(q(ty)),type_abs(list_prefix(typevar(q(a)),list_empty),typevar(q(a))),map_empty),
                             Result = map_empty,
                             compute_type(Term,L1,Type), unobs(L1),
                             compute(Term,L2,Result), unobs(L2).

instantiate_type_test(6)  :- Term = typedef(id(q(ty)),instantiate_type(type_abs(list1(typevar(q(a))),forall(list1(typevar(q(a))),typevar(q(a)))),list1(booleans))),
                             Type = map_prefix(id(q(ty)),forall(list_prefix(typevar(q(a)),list_empty),typevar(q(a))),map_empty),
                             Result = map_empty,
                             compute_type(Term,L1,Type), unobs(L1),
                             compute(Term,L2,Result), unobs(L2).

instantiate_type_test(7)  :- Term = typedef(id(q(ty)),instantiate_type(type_abs(list1(typevar(q(a))),type_abs(list1(typevar(q(b))),typevar(q(a)))),list1(booleans))),
                             Type = map_prefix(id(q(ty)),type_abs(list_prefix(typevar(q(b)),list_empty),booleans),map_empty),
                             Result = map_empty,
                             compute_type(Term,L1,Type), unobs(L1),
                             compute(Term,L2,Result), unobs(L2).

instantiate_type_tests :- run_tests(instantiate_type_test,7).

