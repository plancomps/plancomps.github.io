:- ensure_loaded('tests_common').

record_match_test(1) :- Term = record_match(record1(q(b),true),map1(q(b),only(true))),
                        Type = map_empty,
                        Result = map_empty,
                        compute_type(Term,L1,Type), unobs(L1),
                        compute(Term,L2,Result), unobs(L2).

record_match_test(2) :- Term = record_match(record1(q(b),true),map1(q(b),only(false))),
                        Type = map_empty,
                        compute_type(Term,L1,Type), unobs(L1),
                        compute(Term,L2,_), member(failure += true, L2).

record_match_test(3) :- Term = record_match(record1(q(b),true),map1(q(b),bind(id(q(x))))),
                        Type = map_prefix(id(q(x)),booleans,map_empty),
                        Result = map_prefix(id(q(x)),true,map_empty),
                        compute_type(Term,L1,Type), unobs(L1),
                        compute(Term,L2,Result), unobs(L2).

record_match_test(4) :- Term = record_match_loose(record_union(record1(q(b),true),record1(q(n),q(0))),map1(q(n),bind(id(q(x))))),
                        Type = map_prefix(id(q(x)),ints,map_empty),
                        Result = map_prefix(id(q(x)),q(0),map_empty),
                        compute_type(Term,L1,Type), unobs(L1),
                        compute(Term,L2,Result), unobs(L2).

record_match_tests :- run_tests(record_match_test,4).

