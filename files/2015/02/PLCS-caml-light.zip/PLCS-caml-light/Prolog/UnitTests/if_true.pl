:- ensure_loaded('tests_common').

if_true_test(1) :- Term = if_true(true,q(1),q(2)),
                   Type = ints,
                   Result = q(1),
                   compute_type(Term,L1,Type), unobs(L1),
                   compute(Term,L2,Result), unobs(L2).

if_true_test(2) :- Term = if_true(false,q(1),q(2)),
                   Type = ints,
                   Result = q(2),
                   compute_type(Term,L1,Type), unobs(L1),
                   compute(Term,L2,Result), unobs(L2).

if_true_test(3) :- Term = if_true(or(false,true),q(3),q(4)),
                   Type = ints,
                   Result = q(3),
                   compute_type(Term,L1,Type), unobs(L1),
                   compute(Term,L2,Result), unobs(L2).

if_true_test(4) :- Term = if_true(supply(false,given),q(0),q(4)),
                   Type = ints,
                   Result = q(4),
                   compute_type(Term,L1,Type), unobs(L1),
                   compute(Term,L2,Result), unobs(L2).

if_true_tests :- run_tests(if_true_test,4).

