:- ensure_loaded('tests_common').

curry_test(1)  :- Term = apply(apply(curry(Fst),q(0)),true), Fst = abs(project(zero,given)),
                  Type = ints,
                  Result = q(0),
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

curry_test(2)  :- Term = apply(apply(curry(Snd),q(0)),true), Snd = abs(project(one,given)),
                  Type = booleans,
                  Result = true,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

curry_test(3)  :- Term = apply(uncurry(Const),tuple2(q(0),true)), Const = patt_abs(bind(meta(q(x))),close(abs(bound_value(meta(q(x)))))),
                  Type = ints,
                  Result = q(0),
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

curry_test(4)  :- Term = apply(uncurry(curry(Minus)),tuple2(q(7),q(3))), Minus = abs(int_minus(project(zero,given),project(one,given))),
                  Type = ints,
                  Result = q(4),
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

curry_test(5)  :- Term = apply(apply(curry(uncurry(Subtract)),q(7)),q(3)), Subtract = patt_abs(bind(meta(q(x))),close(abs(int_minus(bound_value(meta(q(x))),given)))),
                  Type = ints,
                  Result = q(4),
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

curry_test(6)  :- Term = curry_N(zero,patt_abs(only(tuple_empty),true)),
                  Type = booleans,
                  Result = true,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

curry_test(7)  :- Term = apply(curry_N(one,patt_abs(only(tuple1(q(0))),true)),q(0)),
                  Type = booleans,
                  Result = true,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

curry_test(8)  :- Term = apply(apply(curry_N(two,patt_abs(only(tuple2(q(0),q(1))),true)),q(0)),q(1)),
                  Type = booleans,
                  Result = true,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

curry_test(9)  :- Term = apply(apply(apply(curry_N(three,patt_abs(only(tuple3(q(0),q(1),q(2))),true)),q(0)),q(1)),q(2)),
                  Type = booleans,
                  Result = true,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

curry_test(10) :- Term = apply(partial_app(Minus,q(7)),q(4)), Minus = abs(int_minus(project(zero,given),project(one,given))),
                  Type = ints,
                  Result = q(3),
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

curry_test(11) :- Term = apply(partial_app_N(Fst,true),tuple_empty), Fst = abs(project(zero,given)),
                  Type = booleans,
                  Result = true,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

curry_test(12) :- Term = apply(partial_app_N(Thd,char(q(c))),tuple2(q(7),true)), Thd = abs(project(two,given)),
                  Type = booleans,
                  Result = true,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).


curry_tests :- run_tests(curry_test,12).

