:- ensure_loaded('tests_common').

close_test(1) :- Term = closure(true,map_empty),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

close_test(2) :- Term = closure(true,map1(id(q(x)),true)),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

close_test(3) :- Term = closure(bound_value(id(q(x))),map1(id(q(x)),true)),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

close_test(4) :- Term = scope(bind_value(id(q(x)),false),closure(bound_value(id(q(x))),map1(id(q(x)),true))),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

close_test(5) :- Term = apply(close(abs(true)),char(q(a))),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

close_test(6) :- Term = scope(bind_value(id(q(f)),scope(bind_value(id(q(b)),true),close(patt_abs(only(q(2)),bound_value(id(q(b))))))),apply(bound_value(id(q(f))),q(2))),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

close_test(7) :- Term = scope(bind_value(id(q(f)),scope(bind_value(id(q(b)),true),close(patt_abs(only(q(2)),bound_value(id(q(b))))))),scope(bind_value(id(q(b)),false),apply(bound_value(id(q(f))),q(2)))),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

close_tests :- run_tests(close_test,7).
