:- ensure_loaded('tests_common').

supply_test(1) :- Term = supply(q(1),given),
                  Type = ints,
                  Result = q(1),
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

supply_test(2) :- Term = supply(false,q(2)),
                  Type = ints,
                  Result = q(2),
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

supply_test(3) :- Term = supply(true,supply(q(3),given)),
                  Type = ints,
                  Result = q(3),
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

supply_test(4) :- Term = supply(supply(int_plus(q(0),q(1)),int_plus(given,q(3))),given),
                  Type = ints,
                  Result = q(4),
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2). 

supply_tests :- run_tests(supply_test,4).

