:- ensure_loaded('../imsos_lib').
:- ensure_loaded('../builtin').
:- ensure_loaded('../run_fct').

numbs(0,[]) :- !.
numbs(N,[N|Xs]) :- M is N - 1, numbs(M,Xs).

% P : Nat -> Pred 
% N : Nat (largest test case)
% X : Nat (failing test cases)
test_fails(P,N,X) :- numbs(N,Xs), member(X,Xs),
                     PX =.. [P,X],
                     \+ call(PX).

print_test_results([])     :- print(' all tests succeeded.').
print_test_results([X|Xs]) :- print(' the following tests failed: '), print([X|Xs]).

run_tests(P,N) :- print(P),
                  print('s :'),
                  findall(X,test_fails(P,N,X),Xs),
                  print_test_results(Xs),
                  print('\n').

