:- ensure_loaded('tests_common').

compose_test(1) :- Term = apply(compose(abs(given),abs(true)),q(0)),
                   Type = booleans,
                   Result = true,
                   compute_type(Term,L1,Type), unobs(L1),
                   compute(Term,L2,Result), unobs(L2).

compose_test(2) :- Term = apply(compose(abs(int_minus(q(15),given)),abs(int_plus(given,q(7)))),q(3)),
                   Type = ints,
                   Result = q(5),
                   compute_type(Term,L1,Type), unobs(L1),
                   compute(Term,L2,Result), unobs(L2).

compose_test(3) :- Term = supply(abs(int_plus(given,given)), apply(compose(given,given),q(7))),
                   Type = ints,
                   Result = q(28),
                   compute_type(Term,L1,Type), unobs(L1),
                   compute(Term,L2,Result), unobs(L2).

compose_tests :- run_tests(compose_test,3).

