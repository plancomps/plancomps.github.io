:- ensure_loaded('tests_common').

apply_to_each_test(1) :- Term = apply_to_each(abs(print(given)),list_empty),
                         Type = unit,
                         Result = null,
                         compute_type(Term,L1,Type), unobs(L1),
                         compute(Term,L2,Result), unobs(L2).

apply_to_each_test(2) :- Term = apply_to_each(abs(print(given)),list1(true)),
                         Type = unit,
                         Result = null,
                         compute_type(Term,L1,Type), unobs(L1),
                         compute(Term,L2,Result), member(output+=list_prefix(true, list_empty), L2).

apply_to_each_test(3) :- Term = apply_to_each(abs(print(given)),list2(true,false)),
                         Type = unit,
                         Result = null,
                         compute_type(Term,L1,Type), unobs(L1),
                         compute(Term,L2,Result), member(output+=list_prefix(true, list_prefix(false,list_empty)), L2).

apply_to_each_test(4) :- Term = supply(abs(print(given)),apply_to_each(given,list1(true))),
                         Type = unit,
                         Result = null,
                         compute_type(Term,L1,Type), unobs(L1),
                         compute(Term,L2,Result), member(output+=list_prefix(true, list_empty), L2).

apply_to_each_test(5) :- Term = supply(list1(q(0)),apply_to_each(abs(print(given)),given)),
                         Type = unit,
                         Result = null,
                         compute_type(Term,L1,Type), unobs(L1),
                         compute(Term,L2,Result), member(output+=list_prefix(q(0), list_empty), L2).


apply_to_each_tests :- run_tests(apply_to_each_test,5).

