:- ensure_loaded('tests_common').

typedef_test(1) :- Term = typedef(id(q(ty)),ints),
                   Type = map_prefix(id(q(ty)),ints,map_empty),
                   Result = map_empty,
                   compute_type(Term,L1,Type), unobs(L1),
                   compute(Term,L2,Result), unobs(L2).

typedef_test(2) :- Term = scope(typedef(id(q(ty)),booleans),typed(true,bound_type(id(q(ty))))),
                   Type = booleans,
                   Result = true,
                   compute_type(Term,L1,Type), unobs(L1),
                   compute(Term,L2,Result), unobs(L2).

typedef_test(3) :- Term = scope(typedef(id(q(ty)),booleans),typedef(id(q(b)),bound_type(id(q(ty))))),
                   Type = map_prefix(id(q(b)),booleans,map_empty),
                   Result = map_empty,
                   compute_type(Term,L1,Type), unobs(L1),
                   compute(Term,L2,Result), unobs(L2).

typedef_test(4) :- Term = accum(typedef(id(q(ty)),booleans),typedef(id(q(b)),bound_type(id(q(ty))))),
                   Type = map_prefix(id(q(b)),booleans,map_prefix(id(q(ty)),booleans,map_empty)),
                   Result = map_empty,
                   compute_type(Term,L1,Type), unobs(L1),
                   compute(Term,L2,Result), unobs(L2).

typedef_test(5) :- Term = typedef(id(q(ty)),type_of(true)),
                   Type = map_prefix(id(q(ty)),booleans,map_empty),
                   Result = map_empty,
                   compute_type(Term,L1,Type), unobs(L1),
                   compute(Term,L2,Result), unobs(L2).

typedef_test(6) :- Term = typed(true,unknown_type),
                   Type = booleans,
                   Result = true,
                   compute_type(Term,L1,Type), unobs(L1),
                   compute(Term,L2,Result), unobs(L2).

typedef_test(7) :- Term = scope(typedef(id(q(ty)),unknown_type),typed(true,bound_type(id(q(ty))))),
                   Type = booleans,
                   Result = true,
                   compute_type(Term,L1,Type), unobs(L1),
                   compute(Term,L2,Result), unobs(L2).

typedef_tests :- run_tests(typedef_test,7).

