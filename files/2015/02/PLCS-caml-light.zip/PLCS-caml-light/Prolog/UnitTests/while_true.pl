:- ensure_loaded('tests_common').

while_true_test(1) :- Term = while_true(false,print(q(bad))),
                      Type = unit,
                      Result = null,
                      compute_type(Term,L1,Type), unobs(L1),
                      compute(Term,L2,Result), unobs(L2).

while_true_test(2) :- Term = supply(alloc(q(0)),while_true(int_less(assigned_value(given),q(5)),assign(given,int_plus(assigned_value(given),q(1))))),
                      Type = unit,
                      Result = null,
                      compute_type(Term,L1,Type), unobs(L1),
                      compute(Term,L2,Result), member(store += map_prefix(var(_),q(5),map_empty), L2).

while_true_tests :- run_tests(while_true_test,2).
