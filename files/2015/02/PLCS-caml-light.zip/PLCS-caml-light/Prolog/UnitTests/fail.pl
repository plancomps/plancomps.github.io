:- ensure_loaded('tests_common').

fail_test(1)  :- Term = fail,
                 Result = stuck,
                 compute_type(Term,L1,_), unobs(L1),
                 compute(Term,L2,Result), member(failure += true, L2).

fail_test(2)  :- Term = else(true,false),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

fail_test(3)  :- Term = else(true,fail),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

fail_test(4)  :- Term = else(fail,true),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

fail_test(5)  :- Term = else(fail,else(true,false)),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

fail_test(6)  :- Term = else(fail,fail),
                 Result = stuck,
                 compute_type(Term,L1,_), unobs(L1),
                 compute(Term,L2,Result), member(failure += true, L2).

fail_test(7)  :- Term = else(fail,else(fail,true)),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

fail_test(8)  :- Term = when_true(true,q(1)),
                 Type = ints,
                 Result = q(1),
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

fail_test(9)  :- Term = when_true(false,q(1)),
                 Type = ints,
                 Result = stuck,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), member(failure += true, L2).

fail_test(10) :- Term = else(when_true(false,q(1)),q(2)),
                 Type = ints,
                 Result = q(2),
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

fail_test(11) :- Term = else(when_true(true,q(1)),q(2)),
                 Type = ints,
                 Result = q(1),
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

fail_test(12) :- Term = apply(prefer_over(abs(true),abs(false)),q(0)),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

fail_test(13) :- Term = apply(prefer_over(abs(fail),abs(true)),q(0)),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

fail_test(14) :- Term = apply(prefer_over(abs(fail),abs(fail)),q(0)),
                 compute_type(Term,L1,_), unobs(L1),
                 compute(Term,L2,_), member(failure += true, L2).

fail_tests :- run_tests(fail_test,14).

