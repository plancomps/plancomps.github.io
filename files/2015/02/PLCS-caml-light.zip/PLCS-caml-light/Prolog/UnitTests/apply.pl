:- ensure_loaded('tests_common').

apply_test(1) :- Term = apply(abs(given),true),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

apply_test(2) :- Term = apply(abs(true),false),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

apply_test(3) :- Term = apply(apply(abs(abs(given)),false),true),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

apply_test(4) :- Term = apply(abs(given),apply(abs(true),false)),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

apply_test(5) :- Term = supply(false,apply(abs(given),not(given))),
                 Type = booleans,
                 Result = true,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

apply_tests :- run_tests(apply_test,5).

