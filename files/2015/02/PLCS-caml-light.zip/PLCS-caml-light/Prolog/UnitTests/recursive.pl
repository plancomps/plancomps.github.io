:- ensure_loaded('tests_common').

recursive_test(1)  :- Term = follow_if_fwd(true),
                      Type = booleans,
                      Result = true,
                      compute_type(Term,L1,Type), unobs(L1),
                      compute(Term,L2,Result), unobs(L2).

recursive_test(2)  :- Term = abs(follow_fwd(given)),
                      Type = depends(fwds(T),T),
                      Result = Term,
                      compute_type(Term,L1,Type), unobs(L1),
                      compute(Term,L2,Result), unobs(L2).

recursive_test(3)  :- Term = recursive(list_empty,map_empty),
                      Type = map_empty,
                      Result = map_empty,
                      compute_type(Term,L1,Type), unobs(L1),
                      compute(Term,L2,Result), unobs(L2).

recursive_test(4)  :- Term = recursive(list_empty,bind_value(id(q(n)),q(1))),
                      Type = map_prefix(id(q(n)),ints,map_empty),
                      Result = map_prefix(id(q(n)),q(1),map_empty),
                      compute_type(Term,L1,Type), unobs(L1),
                      compute(Term,L2,Result), unobs(L2).

recursive_test(5)  :- Term = recursive(list1(id(q(n))),bind_value(id(q(n)),q(1))),
                      Type = map_prefix(id(q(n)),ints,map_empty),
                      Result = map_prefix(id(q(n)),q(1),map_empty),
                      compute_type(Term,L1,Type), unobs(L1),
                      compute(Term,L2,Result), member(forward += map_prefix(fwd(_),q(1),map_empty), L2).

recursive_test(6)  :- Term = recursive(list1(id(q(f))),bind_value(id(q(f)),close(abs(BODY)))),
                             BODY = not(apply(follow_fwd(bound_value(id(q(f)))), not(given))),
                      Type = map_prefix(id(q(f)),depends(booleans,booleans),map_empty),
                      Result = map_prefix(id(q(f)),F,map_empty),
                             F = abs(closure(BODY,map_prefix(id(q(f)),fwd(N),map_empty))),
                      compute_type(Term,L1,Type), unobs(L1),
                      compute(Term,L2,Result), member(forward += map_prefix(fwd(N),F,map_empty), L2).

recursive_test(7)  :- Term = recursive(list1(id(q(f))),bind_value(id(q(f)),close(abs(BODY)))),
                             BODY = not(apply(follow_if_fwd(bound_value(id(q(f)))), not(given))),
                      Type = map_prefix(id(q(f)),depends(booleans,booleans),map_empty),
                      Result = map_prefix(id(q(f)),F,map_empty),
                             F = abs(closure(BODY,map_prefix(id(q(f)),fwd(N),map_empty))),
                      compute_type(Term,L1,Type), unobs(L1),
                      compute(Term,L2,Result), member(forward += map_prefix(fwd(N),F,map_empty), L2).

recursive_test(8)  :- Term = supply(scope(DECL,bound_value(id(q(f)))),apply(given,false)),
                             DECL = recursive(list1(id(q(f))),bind_value(id(q(f)),close(abs(BODY)))),
                             BODY = if_true(given,given,apply(follow_fwd(bound_value(id(q(f)))), not(given))),
                      Type = booleans,
                      Result = true,
                      compute_type(Term,L1,Type), unobs(L1),
                      compute(Term,L2,Result), member(forward += map_prefix(fwd(N),abs(closure(BODY,map_prefix(id(q(f)),fwd(N),map_empty))),map_empty), L2).

recursive_test(9)  :- Term = supply(scope(DECL,bound_value(id(q(f)))),apply(given,false)),
                             DECL = recursive(list2(id(q(f)),id(q(g))),map_union(bind_value(id(q(f)),F),bind_value(id(q(g)),G))),
                             F = close(abs(BODY)), BODY = if_true(given,given,apply(follow_fwd(bound_value(id(q(f)))), apply(follow_fwd(bound_value(id(q(g)))),given))),
                             G = abs(not(given)),
                      Type = booleans,
                      Result = true,
                      compute_type(Term,L1,Type), unobs(L1),
                      compute(Term,L2,Result), member(forward += map_prefix(fwd(N1),abs(closure(BODY,map_prefix(id(q(f)),fwd(N1),map_prefix(id(q(g)),fwd(N2),map_empty)))),map_prefix(fwd(N2),G,map_empty)), L2).

recursive_test(10) :- Term = recursive_typed(map1(id(q(n)),ints),bind_value(id(q(n)),q(1))),
                      Type = map_prefix(id(q(n)),ints,map_empty),
                      Result = map_prefix(id(q(n)),q(1),map_empty),
                      compute_type(Term,L1,Type), unobs(L1),
                      compute(Term,L2,Result), member(forward += map_prefix(fwd(_),q(1),map_empty), L2).

recursive_test(11) :- Term = recursive_typed(map1(id(q(f)),depends(booleans,booleans)),bind_value(id(q(f)),close(abs(BODY)))),
                             BODY = apply(follow_if_fwd(bound_value(id(q(f)))), given),
                      Type = map_prefix(id(q(f)),depends(booleans,booleans),map_empty),
                      Result = map_prefix(id(q(f)),F,map_empty),
                             F = abs(closure(BODY,map_prefix(id(q(f)),fwd(N),map_empty))),
                      compute_type(Term,L1,Type), unobs(L1),
                      compute(Term,L2,Result), member(forward += map_prefix(fwd(N),F,map_empty), L2).


recursive_test(12) :- Term = scope(typedef(id(q(b)),booleans),supply(scope(DECL,bound_value(id(q(f)))),apply(given,false))),
                             DECL = recursive_typed(TMAP,bind_value(id(q(f)),F)),
                             TMAP = map1(id(q(f)),depends(bound_type(id(q(b))),booleans)),
                             F = close(abs(BODY)), BODY = if_true(given,given,apply(follow_fwd(bound_value(id(q(f)))), not(given))),
                      Type = booleans,
                      Result = true,
                      compute_type(Term,L1,Type), unobs(L1),
                      compute(Term,L2,Result), member(forward += map_prefix(fwd(N1),abs(closure(BODY,map_prefix(id(q(f)),fwd(N1),map_empty))),map_empty), L2).

recursive_test(13) :- Term = supply(scope(DECL,bound_value(id(q(f)))),apply(given,false)),
                             DECL = recursive_typed(TMAP,map_union(bind_value(id(q(f)),F),bind_value(id(q(g)),G))),
                             TMAP = map_update(map1(id(q(f)),depends(booleans,booleans)),id(q(g)),depends(booleans,booleans)),
                             F = close(abs(BODY)), BODY = if_true(given,given,apply(follow_fwd(bound_value(id(q(f)))), apply(follow_fwd(bound_value(id(q(g)))),given))),
                             G = abs(not(given)),
                      Type = booleans,
                      Result = true,
                      compute_type(Term,L1,Type), unobs(L1),
                      compute(Term,L2,Result), member(forward += map_prefix(fwd(N1),abs(closure(BODY,map_prefix(id(q(f)),fwd(N1),map_prefix(id(q(g)),fwd(N2),map_empty)))),map_prefix(fwd(N2),G,map_empty)), L2).

recursive_test(14) :- Term = scope(typedef(id(q(b)),booleans),supply(scope(DECL,bound_value(id(q(f)))),apply(given,false))),
                             DECL = recursive_typed(TMAP,map_union(bind_value(id(q(f)),F),bind_value(id(q(g)),G))),
                             TMAP = map_update(map1(id(q(f)),depends(bound_type(id(q(b))),booleans)),id(q(g)),depends(booleans,bound_type(id(q(b))))),
                             F = close(abs(BODY)), BODY = if_true(given,given,apply(follow_fwd(bound_value(id(q(f)))), apply(follow_fwd(bound_value(id(q(g)))),given))),
                             G = abs(not(given)),
                      Type = booleans,
                      Result = true,
                      compute_type(Term,L1,Type), unobs(L1),
                      compute(Term,L2,Result), member(forward += map_prefix(fwd(N1),abs(closure(BODY,map_prefix(id(q(f)),fwd(N1),map_prefix(id(q(g)),fwd(N2),map_empty)))),map_prefix(fwd(N2),G,map_empty)), L2).

recursive_tests :- run_tests(recursive_test,14).

