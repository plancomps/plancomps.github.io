:- ensure_loaded('tests_common').

restrict_domain_test(1) :- Term = restrict_domain(abs(true),ints),
                           Type = depends(ints,booleans),
                           Result = abs(true),
                           compute_type(Term,L1,Type), unobs(L1),
                           compute(Term,L2,Result), unobs(L2).

restrict_domain_test(2) :- Term = restrict_codomain(abs(given),ints),
                           Type = depends(ints,ints),
                           Result = abs(given),
                           compute_type(Term,L1,Type), unobs(L1),
                           compute(Term,L2,Result), unobs(L2).

restrict_domain_test(3) :- Term = restrict_codomain(patt_abs(abs(record_match(given,map1(q(x),bind(id(q(i)))))),bound_value(id(q(i)))),ints),
                           Type = depends(records(map_prefix(q(x),ints,map_empty)),ints),
                           compute_type(Term,L1,Type), unobs(L1),
                           compute(Term,L2,_), unobs(L2).

restrict_domain_test(4) :- Term = patt_at_type(any,ints),
                           Type = depends(ints,map_empty),
                           Result = abs(map_empty),
                           compute_type(Term,L1,Type), unobs(L1),
                           compute(Term,L2,Result), unobs(L2).

restrict_domain_test(5) :- Term = patt_non_binding(patt_union(any,only(true))),
                           Type = depends(booleans,map_empty),
                           compute_type(Term,L1,Type), unobs(L1),
                           compute(Term,L2,_), unobs(L2).


restrict_domain_tests :- run_tests(restrict_domain_test,5).

