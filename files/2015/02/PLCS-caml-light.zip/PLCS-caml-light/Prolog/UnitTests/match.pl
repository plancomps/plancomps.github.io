:- ensure_loaded('tests_common').

match_test(1) :- Term = match(true,any),
                 Type = map_empty,
                 Result = map_empty,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

match_test(2) :- Term = match(true,only(true)),
                 Type = map_empty,
                 Result = map_empty,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

match_test(3) :- Term = match(true,only(false)),
                 Type = map_empty,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,_), member(failure += true, L2).

match_test(4) :- Term = match(true,patt_union(only(true),any)),
                 Type = map_empty,
                 Result = map_empty,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

match_test(5) :- Term = match(true,patt_union(only(false),any)),
                 Type = map_empty,
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,_), member(failure += true, L2).

match_test(6) :- Term = match(true,bind(id(q(b)))),
                 Type = map_prefix(id(q(b)),booleans,map_empty),
                 Result = map_prefix(id(q(b)),true,map_empty),
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

match_test(7) :- Term = match(true,patt_union(bind(id(q(b))),only(true))),
                 Type = map_prefix(id(q(b)),booleans,map_empty),
                 Result = map_prefix(id(q(b)),true,map_empty),
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

match_test(8) :- Term = match(true,patt_union(bind(id(q(b))),only(false))),
                 Type = map_prefix(id(q(b)),booleans,map_empty),
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,_), member(failure += true, L2).

match_test(9) :- Term = match(true,patt_union(bind(id(q(b))),bind(id(q(z))))),
                 Type = map_prefix(id(q(b)),booleans,map_prefix(id(q(z)),booleans,map_empty)),
                 Result = map_prefix(id(q(b)),true,map_prefix(id(q(z)),true,map_empty)),
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

match_test(10) :- Term = supply(true,match(given,only(true))),
                  Type = map_empty,
                  Result = map_empty,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

match_test(11) :- Term = supply(any,match(char(q(a)),given)),
                  Type = map_empty,
                  Result = map_empty,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

match_tests :- run_tests(match_test,11).

