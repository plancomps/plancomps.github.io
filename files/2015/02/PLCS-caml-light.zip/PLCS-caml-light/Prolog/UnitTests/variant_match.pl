:- ensure_loaded('tests_common').

variant_match_test(1) :- Term = variant_match(q(k),variant(q(k),true),only(true)),
                         Type = map_empty,
                         Result = map_empty,
                         compute_type(Term,L1,Type), unobs(L1),
                         compute(Term,L2,Result), unobs(L2).

variant_match_test(2) :- Term = variant_match(q(k),variant(q(c),true),only(true)),
                         Type = map_empty,
                         compute_type(Term,L1,Type), unobs(L1),
                         compute(Term,L2,_), member(failure += true, L2).

variant_match_test(3) :- Term = match(variant(q(k),true),variant_patt(q(k),bind(id(q(b))))),
                         Type = map_prefix(id(q(b)),booleans,map_empty),
                         Result = map_prefix(id(q(b)),true,map_empty),
                         compute_type(Term,L1,Type), unobs(L1),
                         compute(Term,L2,Result), unobs(L2).

variant_match_tests :- run_tests(variant_match_test,3).

