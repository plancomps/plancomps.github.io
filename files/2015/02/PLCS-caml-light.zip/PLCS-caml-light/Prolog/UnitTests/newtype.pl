:- ensure_loaded('tests_common').

newtype_test(1)  :- Term = fresh_token,
                    Result = q(K),
                    compute(Term,L2,Result), member(token += q(K1), L2), K \= K1.

newtype_test(2)  :- Term = supply(fresh_token,equal(fresh_token,given)),
                    Type = booleans,
                    Result = false,
                    compute_type(Term,L1,Type), unobs(L1),
                    compute(Term,L2,Result), member(token += q(_), L2).

newtype_test(3)  :- Term = typedef(id(q(ty)),newtype(q(ty))),
                    Type = map_prefix(id(q(ty)),nomtype(q(ty),q(K)),map_empty),
                    Result = map_empty,
                    compute_type(Term,L1,Type), member(token += q(K1), L1), K \= K1,
                    compute(Term,L2,Result), unobs(L2).

newtype_test(4)  :- Term = typedef(id(q(ty)),newtype_poly(q(ty),list2(ints,booleans))),
                    Type = map_prefix(id(q(ty)),nomtype_poly(q(ty),q(K),list_prefix(ints,list_prefix(booleans,list_empty))),map_empty),
                    Result = map_empty,
                    compute_type(Term,L1,Type), member(token += q(K1), L1), K \= K1,
                    compute(Term,L2,Result), unobs(L2).


newtype_tests :- run_tests(newtype_test,4).

