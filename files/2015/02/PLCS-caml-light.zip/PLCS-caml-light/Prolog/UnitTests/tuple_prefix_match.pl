:- ensure_loaded('tests_common').

tuple_prefix_match_test(1) :- Term = tuple_prefix_match(tuple1(true),only(true),only(tuple_empty)),
                              Type = map_empty,
                              Result = map_empty,
                              compute_type(Term,L1,Type), unobs(L1),
                              compute(Term,L2,Result), unobs(L2).

tuple_prefix_match_test(2) :- Term = tuple_prefix_match(tuple2(true,q(0)),only(true),tuple_prefix_patt(only(q(0)),only(tuple_empty))),
                              Type = map_empty,
                              Result = map_empty,
                              compute_type(Term,L1,Type), unobs(L1),
                              compute(Term,L2,Result), unobs(L2).

tuple_prefix_match_test(3) :- Term = tuple_prefix_match(tuple1(true),only(false),only(tuple_empty)),
                              Type = map_empty,
                              compute_type(Term,L1,Type), unobs(L1),
                              compute(Term,L2,_), member(failure += true, L2).

tuple_prefix_match_tests :- run_tests(tuple_prefix_match_test,3).

