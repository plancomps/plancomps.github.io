% Commented out funcons do not have their own test file, but are tested instead in combination with another function, noted in parentheses.
%
:- ensure_loaded('accum').
%                'alloc'                   (assign)
%                'any'                     (match)
:- ensure_loaded('apply').
:- ensure_loaded('apply_to_each').
:- ensure_loaded('assign').
%                'assigned_value'          (assign)
%                'assigned_value_if_var'   (assign)
%                'bind'                    (match)
%                'bind_value'              (scope)
%                'bound_value'             (scope)
%                'bound_type'              (typedef)
:- ensure_loaded('catch').
%                'catch_else_rethrow'      (catch)
:- ensure_loaded('close').
%                'closure'                 (close)
:- ensure_loaded('compose').
:- ensure_loaded('curry').
:- ensure_loaded('effect').
%                'else'                    (fail)
:- ensure_loaded('fail').
%                'follow_fwd'              (recursive)
%                'follow_if_fwd'           (recursive)
%                'fresh_token'             (newtype)
:- ensure_loaded('generalise').
%                'given'                   (supply)
:- ensure_loaded('if_true').
%                'instantiate_poly'        (generalise)
:- ensure_loaded('instantiate_type').
:- ensure_loaded('list_prefix_match').
:- ensure_loaded('match').
:- ensure_loaded('newtype').
%                'only'                    (match)
%                'partial_app'             (curry)
:- ensure_loaded('patt_abs').
%                'patt_at_type'            (restrict_domain)
%                'patt_non_binding'        (restrict_domain)
%                'patt_union'              (match)
%                'prefer_over'             (fail)
%                'print'                   (apply_to_each)
:- ensure_loaded('recursive').
%                'recursive_typed'         (recursive)
:- ensure_loaded('record_match').
%                'restrict_codomain'       (restrict_domain)
:- ensure_loaded('restrict_domain').
:- ensure_loaded('scope').
%                'seq'                     (assign)
%                'stuck'                   (fail)
:- ensure_loaded('supply').
%                'throw'                   (throw)
:- ensure_loaded('tuple_prefix_match').
%                'typed'                   (typedef)
:- ensure_loaded('typedef').
%                'type_of'                 (typedef)
%                'uncurry'                 (curry)
%                'unknown_type'            (typedef)
:- ensure_loaded('variant_match').
:- ensure_loaded('vector_alloc').
%                'when_true'               (fail)
:- ensure_loaded('while_true').

% Tests are (roughly) ordered with most basic first.  Subsequent test files may make use of funcons that have already been tested.
all_unit_tests :- supply_tests,
                  apply_tests,
                  compose_tests,
                  apply_to_each_tests,
                  if_true_tests,
                  scope_tests,
                  accum_tests,
                  typedef_tests,
                  assign_tests,
                  vector_alloc_tests,
                  effect_tests,
                  while_true_tests,
                  fail_tests,
                  match_tests,
                  patt_abs_tests,
                  tuple_prefix_match_tests,
                  list_prefix_match_tests,
                  variant_match_tests,
                  record_match_tests,
                  restrict_domain_tests,
                  catch_tests,
                  close_tests,
                  curry_tests,
                  recursive_tests,
                  instantiate_type_tests,
                  generalise_tests,
                  newtype_tests.

