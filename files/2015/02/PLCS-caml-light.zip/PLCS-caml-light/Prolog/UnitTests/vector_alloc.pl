:- ensure_loaded('tests_common').

vector_alloc_test(1) :- Term = vector_alloc(q(0),char(q(a))),
                        Type = vectors(characters),
                        Result = vector(list_empty),
                        compute_type(Term,L1,Type), unobs(L1),
                        compute(Term,L2,Result), unobs(L2).

vector_alloc_test(2) :- Term = vector_alloc(q(1),true),
                        Type = vectors(booleans),
                        Result = vector(list_prefix(var(V),list_empty)),
                        compute_type(Term,L1,Type), unobs(L1),
                        compute(Term,L2,Result), member(store += map_prefix(var(V),true,map_empty), L2).

vector_alloc_test(3) :- Term = vector_length(vector_alloc(q(2),true)),
                        Type = ints,
                        Result = q(2),
                        compute_type(Term,L1,Type), unobs(L1),
                        compute(Term,L2,Result), member(store += map_prefix(var(_),true,map_prefix(var(_),true,map_empty)), L2).

vector_alloc_test(4) :- Term = supply(vector_alloc(q(1),q(77)),assign(vector_select(given,q(0)),vector_length(given))),
                        Type = unit,
                        Result = null,
                        compute_type(Term,L1,Type), unobs(L1),
                        compute(Term,L2,Result), member(store += map_prefix(var(_),q(1),map_empty), L2).

vector_alloc_test(5) :- Term = vector_length(vector_append(vector_append(vector_alloc(q(2),true),vector_alloc(q(1),false)),vector_empty)),
                        Type = ints,
                        Result = q(3),
                        compute_type(Term,L1,Type), unobs(L1),
                        compute(Term,L2,Result), member(store += map_prefix(var(_),_,map_prefix(var(_),_,map_prefix(var(_),_,map_empty))), L2).


vector_alloc_tests :- run_tests(vector_alloc_test,5).

