:- ensure_loaded('tests_common').

catch_test(1)  :- Term = throw(char(q(e))),
                  Result = stuck,
                  compute_type(Term,L1,_), unobs(L1),
                  compute(Term,L2,Result), member(exception += some(char(q(e))), L2).

catch_test(2)  :- Term = catch(true,abs(given)),
                  Type = booleans,
                  Result = true,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

catch_test(3)  :- Term = catch(throw(q(1)),abs(int_plus(given,q(2)))),
                  Type = ints,
                  Result = q(3),
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

catch_test(4)  :- Term = catch(throw(false),abs(throw(given))),
                  compute_type(Term,L1,_), unobs(L1),
                  compute(Term,L2,_), member(exception += some(false), L2).

catch_test(5)  :- Term = catch(catch(throw(false),abs(throw(given))),abs(not(given))),
                  Type = booleans,
                  Result = true,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

catch_test(6)  :- Term = catch_else_rethrow(throw(false),patt_abs(only(true),q(7))),
                  Type = ints,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,_), member(exception += some(false), L2).

catch_test(7)  :- Term = catch_else_rethrow(throw(false),patt_abs(only(false),q(7))),
                  Type = ints,
                  Result = q(7),
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

catch_test(8)  :- Term = catch_else_rethrow(q(5),patt_abs(only(true),q(7))),
                  Type = ints,
                  Result = q(5),
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

catch_test(9)  :- Term = catch(catch_else_rethrow(throw(false),patt_abs(only(true),q(7))),abs(q(4))),
                  Type = ints,
                  Result = q(4),
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

catch_test(10) :- Term = catch(catch_else_rethrow(throw(false),patt_abs(only(true),q(7))),abs(throw(char(q(e))))),
                  Type = ints,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,_), member(exception += some(char(q(e))), L2).

catch_test(11) :- Term = catch(catch_else_rethrow(q(0),abs(throw(char(q(e))))),abs(catch(throw(true),abs(q(2))))),
                  Type = ints,
                  Result = q(0),
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

catch_test(12) :- Term = throw(throw(false)),
                  compute_type(Term,L1,_), unobs(L1),
                  compute(Term,L2,_), member(exception += some(false), L2).

catch_test(13) :- Term = throw(catch(throw(false),abs(q(0)))),
                  compute_type(Term,L1,_), unobs(L1),
                  compute(Term,L2,_), member(exception += some(q(0)), L2).

catch_test(14) :- Term = catch(throw(throw(false)),abs(given)),
                  Type = booleans,
                  Result = false,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

catch_test(15) :- Term = if_true(false,throw(true),throw(false)),
                  compute_type(Term,L1,_), unobs(L1),
                  compute(Term,L2,_), member(exception += some(false), L2).

catch_test(16) :- Term = apply(catch(abs(not(throw(given))),abs(abs(true))),q(0)),
                  Type = booleans,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,_), member(exception += some(q(0)), L2).

catch_tests :- run_tests(catch_test,16).

