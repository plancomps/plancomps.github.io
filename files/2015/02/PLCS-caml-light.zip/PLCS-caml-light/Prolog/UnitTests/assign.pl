:- ensure_loaded('tests_common').

assign_test(1) :- Term = alloc(true),
                  Type = variables(booleans),
                  Result = var(V),
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), member(store += map_prefix(var(V),true,map_empty), L2).

assign_test(2) :- Term = assign(alloc(false),true),
                  Type = unit,
                  Result = null,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), member(store += map_prefix(var(_),true,map_empty), L2).

assign_test(3) :- Term = supply(alloc(false),seq(assign(given,true),assigned_value(given))),
                  Type = booleans,
                  Result = true,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), member(store += map_prefix(var(_),true,map_empty), L2).

assign_test(4) :- Term = supply(alloc(q(0)),seq(assign(given,q(1)),seq(assign(given,q(2)),assigned_value(given)))),
                  Type = ints,
                  Result = q(2),
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), member(store += map_prefix(var(_),q(2),map_empty), L2).

assign_test(5) :- Term = seq(assign(alloc(q(0)),q(1)),assign(alloc(q(2)),q(3))),
                  Type = unit,
                  Result = null,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), (member(store += map_prefix(var(_),q(1),map_prefix(var(_),q(3),map_empty)), L2) ;
                                            member(store += map_prefix(var(_),q(3),map_prefix(var(_),q(1),map_empty)), L2) ).

assign_test(6) :- Term = supply(alloc(true),seq(assign(alloc(q(0)),q(1)),assigned_value(given))),
                  Type = booleans,
                  Result = true,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), (member(store += map_prefix(var(_),q(1),map_prefix(var(_),q(true),map_empty)), L2) ;
                                            member(store += map_prefix(var(_),true,map_prefix(var(_),q(1),map_empty)),    L2) ).

assign_test(7) :- Term = assigned_value_if_var(true),
                  Type = booleans,
                  Result = true,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), unobs(L2).

assign_test(8) :- Term = assigned_value_if_var(alloc(true)),
                  Type = booleans,
                  Result = true,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), member(store += map_prefix(var(_),true,map_empty), L2).

assign_test(9) :- Term = supply(alloc(false),seq(assign(given,true),assigned_value_if_var(given))),
                  Type = booleans,
                  Result = true,
                  compute_type(Term,L1,Type), unobs(L1),
                  compute(Term,L2,Result), member(store += map_prefix(var(_),true,map_empty), L2).

assign_tests :- run_tests(assign_test,9).

