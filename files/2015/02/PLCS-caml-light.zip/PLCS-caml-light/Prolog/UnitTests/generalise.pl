:- ensure_loaded('tests_common').

generalise_test(1)  :- Term = generalise(abs(given)),
                       Type = forall(list_prefix(typevar(q(V)),list_empty),depends(typevar(q(V)),typevar(q(V)))),
                       Result = abs(given),
                       compute_type(Term,L1,Type), unobs(L1),
                       compute(Term,L2,Result), unobs(L2).

generalise_test(2)  :- Term = instantiate_poly(generalise(abs(given))),
                       Type = depends(T,T),
                       Result = abs(given),
                       compute_type(Term,L1,Type), unobs(L1),
                       compute(Term,L2,Result), unobs(L2).

generalise_test(3)  :- Term = supply(generalise(abs(given)),tuple2(apply(instantiate_poly(given),true),apply(instantiate_poly(given),char(q(c))))),
                       Type = tuple_type_prefix(booleans,tuple_type_prefix(characters,tuple_type_empty)),
                       Result = tuple_prefix(true,tuple_prefix(char(q(c)),tuple_empty)),
                       compute_type(Term,L1,Type), unobs(L1),
                       compute(Term,L2,Result), unobs(L2).

generalise_test(4)  :- Term = generalise(restrict_domain(abs(given),typevar(q(x)))),
                       Type = forall(list_prefix(typevar(q(x)),list_empty),depends(typevar(q(x)),typevar(q(x)))),
                       Result = abs(given),
                       compute_type(Term,L1,Type), unobs(L1),
                       compute(Term,L2,Result), unobs(L2).

generalise_test(5)  :- Term = generalise(patt_abs(tuple_prefix_patt(bind(id(q(e1))),tuple_prefix_patt(patt_at_type(bind(id(q(e2))),typevar(q(t))),only(tuple_empty))),bound_value(id(q(e1))))),
                       Type = forall(list_prefix(typevar(q(t)),list_prefix(typevar(q(V)),list_empty)),depends(tuple_type_prefix(typevar(q(V)),tuple_type_prefix(typevar(q(t)),tuple_type_empty)),typevar(q(V)))),
                       compute_type(Term,L1,Type), unobs(L1),
                       compute(Term,L2,_), unobs(L2).

generalise_test(6)  :- Term = generalise_if_poly(abs(given)),
                       Type = forall(list_prefix(typevar(q(V)),list_empty),depends(typevar(q(V)),typevar(q(V)))),
                       Result = abs(given),
                       compute_type(Term,L1,Type), unobs(L1),
                       compute(Term,L2,Result), unobs(L2).

generalise_test(7)  :- Term = generalise_if_poly(abs(not(given))),
                       Type = depends(booleans,booleans),
                       Result = abs(not(given)),
                       compute_type(Term,L1,Type), unobs(L1),
                       compute(Term,L2,Result), unobs(L2).

generalise_test(8)  :- Term = generalise_decl(map_union(bind_value(id(q(i)),abs(given)),bind_value(id(q(n)),abs(not(given))))),
                       Type = map_prefix(id(q(i)),forall(list_prefix(typevar(q(a)),list_empty),depends(typevar(q(a)),typevar(q(a)))),map_prefix(id(q(n)),depends(booleans,booleans),map_empty)),
                       Result = map_prefix(id(q(i)),abs(given),map_prefix(id(q(n)),abs(not(given)),map_empty)),
                       compute_type(Term,L1,Type), unobs(L1),
                       compute(Term,L2,Result), unobs(L2).

generalise_test(9)  :- Term = instantiate_if_poly(generalise(abs(given))),
                       Type = depends(T,T),
                       Result = abs(given),
                       compute_type(Term,L1,Type), unobs(L1),
                       compute(Term,L2,Result), unobs(L2).

generalise_test(10) :- Term = instantiate_if_poly(generalise(abs(not(given)))),
                       Type = depends(booleans,booleans),
                       Result = abs(not(given)),
                       compute_type(Term,L1,Type), unobs(L1),
                       compute(Term,L2,Result), unobs(L2).

generalise_test(11) :- Term = instantiate_poly_decl(generalise_decl(map_union(bind_value(id(q(i)),abs(given)),bind_value(id(q(n)),abs(not(given)))))),
                       Type = map_prefix(id(q(i)),depends(T,T),map_prefix(id(q(n)),depends(booleans,booleans),map_empty)),
                       Result = map_prefix(id(q(i)),abs(given),map_prefix(id(q(n)),abs(not(given)),map_empty)),
                       compute_type(Term,L1,Type), unobs(L1),
                       compute(Term,L2,Result), unobs(L2).

generalise_test(12) :- Term = instantiate_poly_decl_if_true(true,generalise_decl(bind_value(id(q(i)),abs(given)))),
                       Type = map_prefix(id(q(i)),depends(T,T),map_empty),
                       Result = map_prefix(id(q(i)),abs(given),map_empty),
                       compute_type(Term,L1,Type), unobs(L1),
                       compute(Term,L2,Result), unobs(L2).

generalise_test(13) :- Term = instantiate_poly_decl_if_true(false,generalise_decl(bind_value(id(q(i)),abs(given)))),
                       Type = map_prefix(id(q(i)),forall(list_prefix(typevar(q(V)),list_empty),depends(typevar(q(V)),typevar(q(V)))),map_empty),
                       Result = map_prefix(id(q(i)),abs(given),map_empty),
                       compute_type(Term,L1,Type), unobs(L1),
                       compute(Term,L2,Result), unobs(L2).


generalise_tests :- run_tests(generalise_test,13).
