:- ensure_loaded('tests_common').

accum_test(1) :- Term = accum(bind_value(id(q(b)),true),bind_value(id(q(n)),q(7))),
                 Type = map_prefix(id(q(b)),booleans,map_prefix(id(q(n)),ints,map_empty)),
                 Result = map_prefix(id(q(b)),true,map_prefix(id(q(n)),q(7),map_empty)),
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

accum_test(2) :- Term = accum(bind_value(id(q(b)),true),bind_value(id(q(c)),bound_value(id(q(b))))),
                 Type = map_prefix(id(q(b)),booleans,map_prefix(id(q(c)),booleans,map_empty)),
                 Result = map_prefix(id(q(b)),true,map_prefix(id(q(c)),true,map_empty)),
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

accum_test(3) :- Term = accum(bind_value(id(q(b)),true),bind_value(id(q(b)),false)),
                 Type = map_prefix(id(q(b)),booleans,map_empty),
                 Result = map_prefix(id(q(b)),false,map_empty),
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

accum_test(4) :- Term = accum(bind_value(id(q(b)),true),accum(bind_value(id(q(c)),bound_value(id(q(b)))),map_empty)),
                 Type = map_prefix(id(q(b)),booleans,map_prefix(id(q(c)),booleans,map_empty)),
                 Result = map_prefix(id(q(b)),true,map_prefix(id(q(c)),true,map_empty)),
                 compute_type(Term,L1,Type), unobs(L1),
                 compute(Term,L2,Result), unobs(L2).

accum_tests :- run_tests(accum_test,4).

