:- ensure_loaded('tests_common').

patt_abs_test(1)  :- Term = apply(patt_abs(any,q(0)),q(1)),
                     Type = ints,
                     Result = q(0),
                     compute_type(Term,L1,Type), unobs(L1),
                     compute(Term,L2,Result), unobs(L2).

patt_abs_test(2)  :- Term = apply(patt_abs(only(true),q(0)),true),
                     Type = ints,
                     Result = q(0),
                     compute_type(Term,L1,Type), unobs(L1),
                     compute(Term,L2,Result), unobs(L2).

patt_abs_test(3)  :- Term = apply(patt_abs(only(true),q(0)),false),
                     Type = ints,
                     compute_type(Term,L1,Type), unobs(L1),
                     compute(Term,L2,_), member(failure += true, L2).

patt_abs_test(4)  :- Term = apply(patt_abs(bind(id(q(b))),bound_value(id(q(b)))),true),
                     Type = booleans,
                     Result = true,
                     compute_type(Term,L1,Type), unobs(L1),
                     compute(Term,L2,Result), unobs(L2).

patt_abs_test(5)  :- Term = apply(patt_abs(bind(id(q(b))),given),true),
                     Type = booleans,
                     Result = true,
                     compute_type(Term,L1,Type), unobs(L1),
                     compute(Term,L2,Result), unobs(L2).

patt_abs_test(6)  :- Term = supply(false,apply(patt_abs(bind(id(q(b))),given),true)),
                     Type = booleans,
                     Result = true,
                     compute_type(Term,L1,Type), unobs(L1),
                     compute(Term,L2,Result), unobs(L2).

patt_abs_tests :- run_tests(patt_abs_test,6).

