SpooDir="Caml-Light/Spoofax-1.3"
TestDir="Caml-Light/Tests"

echo "Generating funcons for all files in ${TestDir}"
java -jar ${SpooDir}/spoofax-sunshine.jar --auto-lang ${SpooDir}/include --project ${TestDir} --builder "Generate Funcons" --build-on-all ./ --non-incremental
