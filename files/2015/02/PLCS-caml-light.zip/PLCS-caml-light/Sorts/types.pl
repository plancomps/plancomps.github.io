% Generated from Sorts/types.csf

sigdec(types,types,[]).

onestep(types,A,B,resolve) :-     unobs(A),     rewrites(types,B).

onestep(types,A,B,typeval) :-     unobs(A),     rewrites(types,B).

