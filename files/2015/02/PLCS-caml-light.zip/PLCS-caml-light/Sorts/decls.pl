% Generated from Sorts/decls.csf

sigdec(decls,types,[]).

onestep(decls,A,B,resolve) :-     unobs(A),     rewrites(decls,B).

onestep(decls,A,B,typeval) :-     unobs(A),     rewrites(decls,B).

typedef(decls,computes(environments)).

