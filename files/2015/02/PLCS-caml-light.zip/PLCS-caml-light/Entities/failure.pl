% Generated from Entities/failure.csf

writeable(failure).

default(failure,false).

rewrite(monop(A,B,C),H) :-     rewrites(A,failure),     rewrites(B,D),     rewrites(C,E),     rewrites(D,F),     rewrites(E,G),     rewrites(or(F,G),H).

