#!/bin/bash

swipl -s Prolog/UnitTests/tests_all.pl -q -g "all_unit_tests,halt."
