% Generated from Values/unit.csf

sigdec(null,unit,[]).

onestep(null,A,unit,inhabit) :-     unobs(A).

onestep(null,A,B,resolve) :-     unobs(A),     rewrites(null,B).

onestep(null,A,B,typeval) :-     unobs(A),     rewrites(null,B).

valcons(null).

sigdec(unit,types,[]).

onestep(unit,A,B,resolve) :-     unobs(A),     rewrites(unit,B).

onestep(unit,A,B,typeval) :-     unobs(A),     rewrites(unit,B).

valsort(unit).

onestep(unit,A,types,inhabit) :-     unobs(A).

