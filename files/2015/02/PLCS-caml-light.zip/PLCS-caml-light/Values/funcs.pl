% Generated from Values/funcs.csf

sigdec(funcs,types,[]).

onestep(funcs,A,B,resolve) :-     unobs(A),     rewrites(funcs,B).

onestep(funcs,A,B,typeval) :-     unobs(A),     rewrites(funcs,B).

typedef(funcs,abs(val,val)).

valsort(funcs).

