% Generated from Values/booleans.csf

sigdec(true,booleans,[]).

onestep(true,A,booleans,inhabit) :-     unobs(A).

onestep(true,A,B,resolve) :-     unobs(A),     rewrites(true,B).

onestep(true,A,B,typeval) :-     unobs(A),     rewrites(true,B).

valcons(true).

sigdec(false,booleans,[]).

onestep(false,A,booleans,inhabit) :-     unobs(A).

onestep(false,A,B,resolve) :-     unobs(A),     rewrites(false,B).

onestep(false,A,B,typeval) :-     unobs(A),     rewrites(false,B).

valcons(false).

sigdec(booleans,types,[]).

onestep(booleans,A,B,resolve) :-     unobs(A),     rewrites(booleans,B).

onestep(booleans,A,B,typeval) :-     unobs(A),     rewrites(booleans,B).

valsort(booleans).

onestep(booleans,A,types,inhabit) :-     unobs(A).

sigdec(not,booleans,[booleans]).

onestep(not(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(not(E),F).

onestep(not(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(not(E),F).

onestep(not(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(not(E),F).

sigdec(not,computes(booleans),[computes(booleans)]).

rewrite(not(A),B) :-     rewrites(A,false),     rewrites(true,B).

rewrite(not(A),B) :-     rewrites(A,true),     rewrites(false,B).

onestep(not(A),D,booleans,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,booleans).

sigdec(and,booleans,[booleans,booleans]).

onestep(and(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(and(G,H),I).

onestep(and(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(and(G,H),I).

onestep(and(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(and(J,K),L).

onestep(and(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(and(J,K),L).

sigdec(and,computes(booleans),[computes(booleans),computes(booleans)]).

rewrite(and(A,B),C) :-     rewrites(A,true),     rewrites(B,true),     rewrites(true,C).

rewrite(and(A,B),C) :-     rewrites(A,true),     rewrites(B,false),     rewrites(false,C).

rewrite(and(A,B),C) :-     rewrites(A,false),     rewrites(B,true),     rewrites(false,C).

rewrite(and(A,B),C) :-     rewrites(A,false),     rewrites(B,false),     rewrites(false,C).

onestep(and(A,B),I,booleans,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,booleans) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,booleans) ->     post_comp(G,H,I). 

sigdec(or,booleans,[booleans,booleans]).

onestep(or(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(or(G,H),I).

onestep(or(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(or(G,H),I).

onestep(or(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(or(J,K),L).

onestep(or(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(or(J,K),L).

sigdec(or,computes(booleans),[computes(booleans),computes(booleans)]).

rewrite(or(A,B),C) :-     rewrites(A,true),     rewrites(B,true),     rewrites(true,C).

rewrite(or(A,B),C) :-     rewrites(A,true),     rewrites(B,false),     rewrites(true,C).

rewrite(or(A,B),C) :-     rewrites(A,false),     rewrites(B,false),     rewrites(false,C).

rewrite(or(A,B),C) :-     rewrites(A,false),     rewrites(B,true),     rewrites(true,C).

onestep(or(A,B),I,booleans,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,booleans) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,booleans) ->     post_comp(G,H,I). 

sigdec(equal,booleans,[A,A]).

onestep(equal(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(equal(G,H),I).

onestep(equal(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(equal(G,H),I).

onestep(equal(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(equal(J,K),L).

onestep(equal(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(equal(J,K),L).

sigdec(equal,computes(booleans),[A,A]).

rewrite(equal(A,B),E) :-     rewrites(A,C),     rewrites(B,C),     rewrites(C,D),     runcheck(D,ground),     checktag(D,ground,_),     rewrites(true,E).

rewrite(equal(A,B),G) :-     rewrites(A,E),     rewrites(B,F),     rewrites(E,C),     runcheck(C,ground),     checktag(C,ground,_),     rewrites(F,D),     runcheck(D,ground),     checktag(D,ground,_),     \+rewrites(E,F),     rewrites(false,G).

onestep(equal(A,B),J,booleans,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,G) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,G) ->     post_comp(H,I,J). 

sigdec(less,booleans,[A,A]).

onestep(less(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(less(G,H),I).

onestep(less(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(less(G,H),I).

onestep(less(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(less(J,K),L).

onestep(less(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(less(J,K),L).

sigdec(less,computes(booleans),[A,A]).

rewrite(less(A,B),G) :-     rewrites(A,E),     rewrites(B,F),     rewrites(E,C),     runcheck(C,ground),     checktag(C,ground,_),     rewrites(F,D),     runcheck(D,ground),     checktag(D,ground,_),     lessthan(E,F),     rewrites(true,G).

rewrite(less(A,B),G) :-     rewrites(A,E),     rewrites(B,F),     rewrites(E,C),     runcheck(C,ground),     checktag(C,ground,_),     rewrites(F,D),     runcheck(D,ground),     checktag(D,ground,_),     \+lessthan(E,F),     rewrites(false,G).

onestep(less(A,B),J,booleans,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,G) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,G) ->     post_comp(H,I,J). 

sigdec(greater,booleans,[A,A]).

onestep(greater(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(greater(G,H),I).

onestep(greater(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(greater(G,H),I).

onestep(greater(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(greater(J,K),L).

onestep(greater(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(greater(J,K),L).

sigdec(greater,computes(booleans),[A,A]).

rewrite(greater(A,B),G) :-     rewrites(A,D),     rewrites(B,C),     rewrites(C,E),     rewrites(D,F),     rewrites(less(E,F),G).

sigdec(less_equal,booleans,[A,A]).

onestep(less_equal(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(less_equal(G,H),I).

onestep(less_equal(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(less_equal(G,H),I).

onestep(less_equal(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(less_equal(J,K),L).

onestep(less_equal(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(less_equal(J,K),L).

sigdec(less_equal,computes(booleans),[A,A]).

rewrite(less_equal(A,B),H) :-     rewrites(A,C),     rewrites(B,D),     rewrites(C,E),     rewrites(D,F),     rewrites(greater(E,F),G),     rewrites(not(G),H).

sigdec(greater_equal,booleans,[A,A]).

onestep(greater_equal(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(greater_equal(G,H),I).

onestep(greater_equal(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(greater_equal(G,H),I).

onestep(greater_equal(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(greater_equal(J,K),L).

onestep(greater_equal(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(greater_equal(J,K),L).

sigdec(greater_equal,computes(booleans),[A,A]).

rewrite(greater_equal(A,B),H) :-     rewrites(A,C),     rewrites(B,D),     rewrites(C,E),     rewrites(D,F),     rewrites(less(E,F),G),     rewrites(not(G),H).

sigdec(min,A,[A,A]).

onestep(min(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(min(G,H),I).

onestep(min(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(min(G,H),I).

onestep(min(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(min(J,K),L).

onestep(min(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(min(J,K),L).

sigdec(min,A,[A,A]).

rewrite(min(A,B),E) :-     rewrites(A,D),     rewrites(B,C),     rewrites(less(D,C),true),     rewrites(D,E).

rewrite(min(A,B),E) :-     rewrites(A,C),     rewrites(B,D),     rewrites(less(C,D),false),     rewrites(D,E).

onestep(min(A,B),J,G,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,G) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,G) ->     post_comp(H,I,J). 

sigdec(max,A,[A,A]).

onestep(max(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(max(G,H),I).

onestep(max(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(max(G,H),I).

onestep(max(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(max(J,K),L).

onestep(max(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(max(J,K),L).

sigdec(max,A,[A,A]).

rewrite(max(A,B),E) :-     rewrites(A,D),     rewrites(B,C),     rewrites(greater(D,C),true),     rewrites(D,E).

rewrite(max(A,B),E) :-     rewrites(A,C),     rewrites(B,D),     rewrites(greater(C,D),false),     rewrites(D,E).

onestep(max(A,B),J,G,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,G) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,G) ->     post_comp(H,I,J). 

