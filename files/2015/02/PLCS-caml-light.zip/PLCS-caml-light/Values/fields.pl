% Generated from Values/fields.csf

sigdec(fields,types,[]).

onestep(fields,A,B,resolve) :-     unobs(A),     rewrites(fields,B).

onestep(fields,A,B,typeval) :-     unobs(A),     rewrites(fields,B).

typedef(fields,atoms).

valsort(fields).

