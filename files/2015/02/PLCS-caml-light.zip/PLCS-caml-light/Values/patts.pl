% Generated from Values/patts.csf

sigdec(patts,types,[]).

onestep(patts,A,B,resolve) :-     unobs(A),     rewrites(patts,B).

onestep(patts,A,B,typeval) :-     unobs(A),     rewrites(patts,B).

typedef(patts,abs(val,environments)).

valsort(patts).

