% Generated from Values/abs.csf

sigdec(abs,abs(A,B),[depends(A,B)]).

onestep(abs(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(abs(E),F).

onestep(abs(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(abs(E),F).

sigdec(abs,computes(abs(A,B)),[depends(A,B)]).

valcons(abs).

sigdec(abs(_,_),types,[]).

onestep(abs(A,B),C,H,resolve) :-     rewrites(A,D),     rewrites(B,E),     unobs(C),     rewrites(D,F),     rewrites(E,G),     rewrites(abs(F,G),H).

onestep(abs(A,B),C,H,typeval) :-     rewrites(A,D),     rewrites(B,E),     unobs(C),     rewrites(D,F),     rewrites(E,G),     rewrites(abs(F,G),H).

valsort(abs(_,_)).

onestep(depends(A,B),I,types,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,types) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,types) ->     post_comp(G,H,I). 

onestep(abs(A),B,depends(E,K),inhabit) :-     rewrites(A,H),     rewrites(_,D),     eq_label(B,[given=C|G]),     rewrites(C,D),     rewrites(E,F),     J=[given=F|G],     rewrites(H,I),     inhabit(I,J,K).

