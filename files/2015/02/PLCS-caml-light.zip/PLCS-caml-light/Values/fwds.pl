% Generated from Values/fwds.csf

sigdec(fwd,fwds,[ints]).

onestep(fwd(A),D,fwds(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

onestep(fwd(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(fwd(E),F).

onestep(fwd(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(fwd(E),F).

onestep(fwd(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(fwd(E),F).

sigdec(fwd,computes(fwds),[computes(ints)]).

valcons(fwd).

sigdec(fwds,types,[]).

onestep(fwds,A,B,resolve) :-     unobs(A),     rewrites(fwds,B).

onestep(fwds,A,B,typeval) :-     unobs(A),     rewrites(fwds,B).

valsort(fwds).

sigdec(fwds,types,[types]).

onestep(fwds(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(fwds(E),F).

onestep(fwds(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(fwds(E),F).

onestep(fwds(A),D,types,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,types).

