% Generated from Values/tuples.csf

sigdec(tuple_empty,tuples,[]).

onestep(tuple_empty,A,B,resolve) :-     unobs(A),     rewrites(tuple_empty,B).

onestep(tuple_empty,A,B,typeval) :-     unobs(A),     rewrites(tuple_empty,B).

valcons(tuple_empty).

sigdec(tuple_prefix,tuples,[val,tuples]).

onestep(tuple_prefix(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(tuple_prefix(G,H),I).

onestep(tuple_prefix(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(tuple_prefix(G,H),I).

onestep(tuple_prefix(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(tuple_prefix(J,K),L).

onestep(tuple_prefix(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(tuple_prefix(J,K),L).

sigdec(tuple_prefix,computes(tuples),[computes(val),computes(tuples)]).

valcons(tuple_prefix).

sigdec(tuples,types,[]).

onestep(tuples,A,B,resolve) :-     unobs(A),     rewrites(tuples,B).

onestep(tuples,A,B,typeval) :-     unobs(A),     rewrites(tuples,B).

valsort(tuples).

sigdec(tuple_type_empty,tuple_types,[]).

onestep(tuple_type_empty,A,B,resolve) :-     unobs(A),     rewrites(tuple_type_empty,B).

onestep(tuple_type_empty,A,B,typeval) :-     unobs(A),     rewrites(tuple_type_empty,B).

valcons(tuple_type_empty).

sigdec(tuple_type_prefix,tuple_types,[types,tuple_types]).

onestep(tuple_type_prefix(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(tuple_type_prefix(G,H),I).

onestep(tuple_type_prefix(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(tuple_type_prefix(J,K),L).

onestep(tuple_type_prefix(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(tuple_type_prefix(J,K),L).

sigdec(tuple_type_prefix,computes(tuple_types),[types,computes(tuple_types)]).

valcons(tuple_type_prefix).

sigdec(tuple_types,types,[]).

onestep(tuple_types,A,B,resolve) :-     unobs(A),     rewrites(tuple_types,B).

onestep(tuple_types,A,B,typeval) :-     unobs(A),     rewrites(tuple_types,B).

valsort(tuple_types).

subsort(tuple_types,types).

onestep(tuple_type_empty,A,types,inhabit) :-     unobs(A).

onestep(tuple_type_prefix(A,B),I,types,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,types) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,types) ->     post_comp(G,H,I). 

onestep(tuple_empty,A,tuple_type_empty,inhabit) :-     unobs(A).

onestep(tuple_prefix(A,B),K,tuple_type_prefix(E,H),inhabit) :-     rewrites(A,C),     rewrites(B,F),     pre_comp(K,I),     rewrites(C,D),     inhabit(D,I,E) ->     mid_comp(I,J),     rewrites(F,G),     inhabit(G,J,H) ->     post_comp(I,J,K). 

sigdec(tuple1,tuples,[val]).

onestep(tuple1(A),D,tuples,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,val).

onestep(tuple1(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(tuple1(E),F).

onestep(tuple1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(tuple1(E),F).

onestep(tuple1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(tuple1(E),F).

sigdec(tuple1,computes(tuples),[computes(val)]).

sigdec(tuple2,tuples,[val,val]).

onestep(tuple2(A,B),I,tuples,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,val) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,val) ->     post_comp(G,H,I). 

onestep(tuple2(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(tuple2(G,H),I).

onestep(tuple2(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(tuple2(G,H),I).

onestep(tuple2(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(tuple2(J,K),L).

onestep(tuple2(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(tuple2(J,K),L).

sigdec(tuple2,computes(tuples),[computes(val),computes(val)]).

sigdec(tuple3,tuples,[val,val,val]).

onestep(tuple3(A,B,C),N,tuples,inhabit) :-     rewrites(A,D),     rewrites(B,F),     rewrites(C,H),     pre_comp(N,L),     rewrites(D,E),     inhabit(E,L,val) ->     mid_comp(L,M),     pre_comp(M,J),     rewrites(F,G),     inhabit(G,J,val) ->     mid_comp(J,K),     rewrites(H,I),     inhabit(I,K,val) ->     post_comp(J,K,M),     post_comp(L,M,N).

onestep(tuple3(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,G),     rewrites(C,D),     runstep(D,E,H) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(tuple3(I,J,K),L).

onestep(tuple3(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,D),     rewrites(C,H),     runstep(D,E,G) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(tuple3(I,J,K),L).

onestep(tuple3(A,B,C),E,L,run) :-     rewrites(A,D),     rewrites(B,G),     rewrites(C,H),     runstep(D,E,F) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(tuple3(I,J,K),L).

onestep(tuple3(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(tuple3(O,P,Q),R).

onestep(tuple3(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(tuple3(O,P,Q),R).

sigdec(tuple3,computes(tuples),[computes(val),computes(val),computes(val)]).

sigdec(tuple_type1,tuple_types,[types]).

onestep(tuple_type1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(tuple_type1(E),F).

onestep(tuple_type1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(tuple_type1(E),F).

sigdec(tuple_type2,tuple_types,[types,types]).

onestep(tuple_type2(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(tuple_type2(J,K),L).

onestep(tuple_type2(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(tuple_type2(J,K),L).

sigdec(tuple_type3,tuple_types,[types,types,types]).

onestep(tuple_type3(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(tuple_type3(O,P,Q),R).

onestep(tuple_type3(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(tuple_type3(O,P,Q),R).

rewrite(tuple1(A),E) :-     rewrites(A,B),     rewrites(B,C),     rewrites(tuple_empty,D),     rewrites(tuple_prefix(C,D),E).

rewrite(tuple2(A,B),H) :-     rewrites(A,C),     rewrites(B,D),     rewrites(C,F),     rewrites(D,E),     rewrites(tuple1(E),G),     rewrites(tuple_prefix(F,G),H).

rewrite(tuple3(A,B,C),K) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     rewrites(D,I),     rewrites(E,G),     rewrites(F,H),     rewrites(tuple2(G,H),J),     rewrites(tuple_prefix(I,J),K).

rewrite(tuple_type1(A),E) :-     rewrites(A,B),     rewrites(B,C),     rewrites(tuple_type_empty,D),     rewrites(tuple_type_prefix(C,D),E).

rewrite(tuple_type2(A,B),H) :-     rewrites(A,C),     rewrites(B,D),     rewrites(C,F),     rewrites(D,E),     rewrites(tuple_type1(E),G),     rewrites(tuple_type_prefix(F,G),H).

rewrite(tuple_type3(A,B,C),K) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     rewrites(D,I),     rewrites(E,G),     rewrites(F,H),     rewrites(tuple_type2(G,H),J),     rewrites(tuple_type_prefix(I,J),K).

sigdec(project,val,[peano_nats,tuples]).

onestep(project(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(project(G,H),I).

onestep(project(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(project(G,H),I).

onestep(project(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(project(J,K),L).

onestep(project(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(project(J,K),L).

sigdec(project,computes(val),[computes(peano_nats),computes(tuples)]).

rewrite(project(A,B),F) :-     rewrites(A,zero),     rewrites(B,tuple_prefix(C,D)),     rewrites(C,E),     rewrites(D,_),     rewrites(E,F).

rewrite(project(A,C),J) :-     rewrites(A,succ(B)),     rewrites(B,F),     rewrites(C,tuple_prefix(D,E)),     rewrites(D,_),     rewrites(E,G),     rewrites(F,H),     rewrites(G,I),     rewrites(project(H,I),J).

onestep(project(A,B),E,H,inhabit) :-     rewrites(A,F),     rewrites(B,C),     rewrites(C,D),     inhabit(D,E,G) ->     rewrites(project_type(F,G),H). 

sigdec(project_type,types,[peano_nats,tuple_types]).

onestep(project_type(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(project_type(G,H),I).

onestep(project_type(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(project_type(G,H),I).

onestep(project_type(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(project_type(J,K),L).

onestep(project_type(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(project_type(J,K),L).

sigdec(project_type,types,[computes(peano_nats),computes(tuple_types)]).

rewrite(project_type(A,B),F) :-     rewrites(A,zero),     rewrites(B,tuple_type_prefix(C,D)),     rewrites(C,E),     rewrites(D,_),     rewrites(E,F).

rewrite(project_type(A,C),J) :-     rewrites(A,succ(B)),     rewrites(B,F),     rewrites(C,tuple_type_prefix(D,E)),     rewrites(D,_),     rewrites(E,G),     rewrites(F,H),     rewrites(G,I),     rewrites(project_type(H,I),J).

