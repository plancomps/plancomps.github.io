% Generated from Values/procs.csf

sigdec(procs,types,[]).

onestep(procs,A,B,resolve) :-     unobs(A),     rewrites(procs,B).

onestep(procs,A,B,typeval) :-     unobs(A),     rewrites(procs,B).

typedef(procs,abs(val,unit)).

valsort(procs).

