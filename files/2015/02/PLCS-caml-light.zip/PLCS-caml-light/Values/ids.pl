% Generated from Values/ids.csf

sigdec(id,ids,[atoms]).

onestep(id(A),D,ids(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

onestep(id(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(id(E),F).

onestep(id(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(id(E),F).

onestep(id(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(id(E),F).

sigdec(id,computes(ids),[computes(atoms)]).

valcons(id).

sigdec(ids,types,[]).

onestep(ids,A,B,resolve) :-     unobs(A),     rewrites(ids,B).

onestep(ids,A,B,typeval) :-     unobs(A),     rewrites(ids,B).

valsort(ids).

