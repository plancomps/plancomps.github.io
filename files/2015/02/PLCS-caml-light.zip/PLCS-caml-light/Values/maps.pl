% Generated from Values/maps.csf

sigdec(map_empty,maps(_,_),[]).

onestep(map_empty,A,B,resolve) :-     unobs(A),     rewrites(map_empty,B).

onestep(map_empty,A,B,typeval) :-     unobs(A),     rewrites(map_empty,B).

sigdec(map_empty,computes(maps(_,_)),[]).

valcons(map_empty).

sigdec(map_prefix,maps(A,B),[A,B,maps(A,B)]).

onestep(map_prefix(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,G),     rewrites(C,D),     runstep(D,E,H) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(map_prefix(I,J,K),L).

onestep(map_prefix(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,D),     rewrites(C,H),     runstep(D,E,G) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(map_prefix(I,J,K),L).

onestep(map_prefix(A,B,C),E,L,run) :-     rewrites(A,D),     rewrites(B,G),     rewrites(C,H),     runstep(D,E,F) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(map_prefix(I,J,K),L).

onestep(map_prefix(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(map_prefix(O,P,Q),R).

onestep(map_prefix(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(map_prefix(O,P,Q),R).

sigdec(map_prefix,computes(maps(A,B)),[A,B,computes(maps(A,B))]).

valcons(map_prefix).

sigdec(maps(_,_),types,[]).

onestep(maps(A,B),C,H,resolve) :-     rewrites(A,D),     rewrites(B,E),     unobs(C),     rewrites(D,F),     rewrites(E,G),     rewrites(maps(F,G),H).

onestep(maps(A,B),C,H,typeval) :-     rewrites(A,D),     rewrites(B,E),     unobs(C),     rewrites(D,F),     rewrites(E,G),     rewrites(maps(F,G),H).

valsort(maps(_,_)).

onestep(map_empty,A,map_empty,inhabit) :-     unobs(A).

onestep(map_prefix(A,C,D),M,map_prefix(B,G,J),inhabit) :-     rewrites(A,B),     rewrites(C,E),     rewrites(D,H),     pre_comp(M,K),     rewrites(E,F),     inhabit(F,K,G) ->     mid_comp(K,L),     rewrites(H,I),     inhabit(I,L,J) ->     post_comp(K,L,M). 

sigdec(map_update,maps(A,B),[maps(A,B),A,B]).

onestep(map_update(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,G),     rewrites(C,D),     runstep(D,E,H) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(map_update(I,J,K),L).

onestep(map_update(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,D),     rewrites(C,H),     runstep(D,E,G) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(map_update(I,J,K),L).

onestep(map_update(A,B,C),E,L,run) :-     rewrites(A,D),     rewrites(B,G),     rewrites(C,H),     runstep(D,E,F) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(map_update(I,J,K),L).

onestep(map_update(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(map_update(O,P,Q),R).

onestep(map_update(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(map_update(O,P,Q),R).

sigdec(map_update,computes(maps(A,B)),[computes(maps(A,B)),A,B]).

rewrite(map_update(A,B,C),I) :-     rewrites(A,map_empty),     rewrites(B,D),     rewrites(C,E),     rewrites(D,F),     rewrites(E,G),     rewrites(map_empty,H),     rewrites(map_prefix(F,G,H),I).

rewrite(map_update(A,E,F),O) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,G),     rewrites(C,_),     rewrites(D,K),     rewrites(E,G),     rewrites(F,J),     rewrites(G,H),     runcheck(H,ground),     checktag(H,ground,I),     rewrites(I,L),     rewrites(J,M),     rewrites(K,N),     rewrites(map_prefix(L,M,N),O).

rewrite(map_update(A,E,F),T) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,K),     rewrites(C,L),     rewrites(D,M),     rewrites(E,H),     rewrites(F,J),     rewrites(H,G),     runcheck(G,ground),     checktag(G,ground,I),     lessthan(H,K),     rewrites(I,Q),     rewrites(J,R),     rewrites(K,N),     rewrites(L,O),     rewrites(M,P),     rewrites(map_prefix(N,O,P),S),     rewrites(map_prefix(Q,R,S),T).

rewrite(map_update(A,E,F),T) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,I),     rewrites(C,J),     rewrites(D,K),     rewrites(E,H),     rewrites(F,M),     rewrites(H,G),     runcheck(G,ground),     checktag(G,ground,L),     lessthan(I,H),     rewrites(I,Q),     rewrites(J,R),     rewrites(K,N),     rewrites(L,O),     rewrites(M,P),     rewrites(map_update(N,O,P),S),     rewrites(map_prefix(Q,R,S),T).

onestep(map_update(A,B,D),M,map_update(G,C,J),inhabit) :-     rewrites(A,E),     rewrites(B,C),     rewrites(D,H),     pre_comp(M,K),     rewrites(E,F),     inhabit(F,K,G) ->     mid_comp(K,L),     rewrites(H,I),     inhabit(I,L,J) ->     post_comp(K,L,M). 

sigdec(map_select,A,[maps(B,A),B]).

onestep(map_select(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_select(G,H),I).

onestep(map_select(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_select(G,H),I).

onestep(map_select(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_select(J,K),L).

onestep(map_select(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_select(J,K),L).

sigdec(map_select,A,[computes(maps(B,A)),B]).

rewrite(map_select(A,E),I) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,F),     rewrites(C,H),     rewrites(D,_),     rewrites(E,F),     rewrites(F,G),     runcheck(G,ground),     checktag(G,ground,_),     rewrites(H,I).

rewrite(map_select(A,E),M) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,H),     rewrites(C,_),     rewrites(D,I),     rewrites(E,G),     rewrites(G,F),     runcheck(F,ground),     checktag(F,ground,J),     \+rewrites(G,H),     rewrites(I,K),     rewrites(J,L),     rewrites(map_select(K,L),M).

onestep(map_select(A,B),E,map_select(F,G),inhabit) :-     rewrites(A,C),     rewrites(B,G),     rewrites(C,D),     inhabit(D,E,F) ->     rewrites(contains_key(_,G),true). 

sigdec(map_over,maps(A,B),[maps(A,B),maps(A,B)]).

onestep(map_over(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_over(G,H),I).

onestep(map_over(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_over(G,H),I).

onestep(map_over(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_over(J,K),L).

onestep(map_over(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_over(J,K),L).

sigdec(map_over,computes(maps(A,B)),[computes(maps(A,B)),computes(maps(A,B))]).

rewrite(map_over(A,B),D) :-     rewrites(A,map_empty),     rewrites(B,C),     rewrites(C,D).

rewrite(map_over(A,E),N) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,I),     rewrites(C,J),     rewrites(D,F),     rewrites(E,G),     rewrites(map_over(F,G),H),     rewrites(H,K),     rewrites(I,L),     rewrites(J,M),     rewrites(map_update(K,L,M),N).

onestep(map_over(A,B),K,map_over(E,H),inhabit) :-     rewrites(A,C),     rewrites(B,F),     pre_comp(K,I),     rewrites(C,D),     inhabit(D,I,E) ->     mid_comp(I,J),     rewrites(F,G),     inhabit(G,J,H) ->     post_comp(I,J,K). 

sigdec(map_union,maps(A,B),[maps(A,B),maps(A,B)]).

onestep(map_union(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_union(G,H),I).

onestep(map_union(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_union(G,H),I).

onestep(map_union(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_union(J,K),L).

onestep(map_union(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_union(J,K),L).

sigdec(map_union,computes(maps(A,B)),[computes(maps(A,B)),computes(maps(A,B))]).

rewrite(map_union(A,B),D) :-     rewrites(A,map_empty),     rewrites(B,C),     rewrites(C,D).

rewrite(map_union(A,E),N) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,I),     rewrites(C,J),     rewrites(D,F),     rewrites(E,G),     rewrites(contains_key(G,I),false),     rewrites(map_union(F,G),H),     rewrites(H,K),     rewrites(I,L),     rewrites(J,M),     rewrites(map_update(K,L,M),N).

onestep(map_union(A,B),K,map_union(E,H),inhabit) :-     rewrites(A,C),     rewrites(B,F),     pre_comp(K,I),     rewrites(C,D),     inhabit(D,I,E) ->     mid_comp(I,J),     rewrites(F,G),     inhabit(G,J,H) ->     post_comp(I,J,K). 

sigdec(contains_key,booleans,[maps(A,_),A]).

onestep(contains_key(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(contains_key(G,H),I).

onestep(contains_key(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(contains_key(G,H),I).

onestep(contains_key(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(contains_key(J,K),L).

onestep(contains_key(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(contains_key(J,K),L).

sigdec(contains_key,computes(booleans),[computes(maps(A,_)),A]).

rewrite(contains_key(A,B),E) :-     rewrites(A,map_empty),     rewrites(B,C),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,_),     rewrites(false,E).

rewrite(contains_key(A,E),H) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,F),     rewrites(C,_),     rewrites(D,_),     rewrites(E,F),     rewrites(F,G),     runcheck(G,ground),     checktag(G,ground,_),     rewrites(true,H).

rewrite(contains_key(A,E),I) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,H),     rewrites(C,_),     rewrites(D,_),     rewrites(E,G),     rewrites(G,F),     runcheck(F,ground),     checktag(F,ground,_),     lessthan(G,H),     rewrites(false,I).

rewrite(contains_key(A,E),M) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,G),     rewrites(C,_),     rewrites(D,I),     rewrites(E,H),     rewrites(H,F),     runcheck(F,ground),     checktag(F,ground,J),     lessthan(G,H),     rewrites(I,K),     rewrites(J,L),     rewrites(contains_key(K,L),M).

sigdec(map1,maps(A,B),[A,B]).

onestep(map1(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map1(G,H),I).

onestep(map1(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map1(G,H),I).

onestep(map1(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map1(J,K),L).

onestep(map1(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map1(J,K),L).

sigdec(map1,computes(maps(A,B)),[A,B]).

rewrite(map1(A,B),H) :-     rewrites(A,C),     rewrites(B,D),     rewrites(C,E),     rewrites(D,F),     rewrites(map_empty,G),     rewrites(map_prefix(E,F,G),H).

sigdec(map_domain,lists(A),[maps(A,_)]).

onestep(map_domain(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(map_domain(E),F).

onestep(map_domain(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(map_domain(E),F).

onestep(map_domain(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(map_domain(E),F).

sigdec(map_domain,computes(lists(A)),[computes(maps(A,_))]).

rewrite(map_domain(A),B) :-     rewrites(A,map_empty),     rewrites(list_empty,B).

rewrite(map_domain(A),J) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,E),     rewrites(C,_),     rewrites(D,F),     rewrites(E,H),     rewrites(F,G),     rewrites(map_domain(G),I),     rewrites(list_prefix(H,I),J).

sigdec(largest_key,A,[maps(A,_)]).

onestep(largest_key(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(largest_key(E),F).

onestep(largest_key(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(largest_key(E),F).

onestep(largest_key(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(largest_key(E),F).

sigdec(largest_key,A,[computes(maps(A,_))]).

rewrite(largest_key(A),E) :-     rewrites(A,B),     rewrites(B,C),     rewrites(map_domain(C),D),     rewrites(list_last(D),E).

sigdec(map_subset,booleans,[maps(A,B),maps(A,B)]).

onestep(map_subset(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_subset(G,H),I).

onestep(map_subset(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_subset(G,H),I).

onestep(map_subset(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_subset(J,K),L).

onestep(map_subset(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_subset(J,K),L).

sigdec(map_subset,computes(booleans),[computes(maps(A,B)),computes(maps(A,B))]).

rewrite(map_subset(A,B),E) :-     rewrites(A,map_empty),     rewrites(B,C),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,_),     rewrites(true,E).

rewrite(map_subset(A,E),L) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,F),     rewrites(C,G),     rewrites(D,H),     rewrites(E,I),     rewrites(map_contains(I,F,G),true),     rewrites(H,J),     rewrites(I,K),     rewrites(map_subset(J,K),L).

rewrite(map_subset(A,E),I) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,G),     rewrites(C,H),     rewrites(D,_),     rewrites(E,F),     rewrites(map_contains(F,G,H),false),     rewrites(false,I).

sigdec(map_contains,booleans,[maps(A,B),A,B]).

onestep(map_contains(A,B,C),E,L,run) :-     rewrites(A,D),     rewrites(B,G),     rewrites(C,H),     runstep(D,E,F) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(map_contains(I,J,K),L).

onestep(map_contains(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(map_contains(O,P,Q),R).

onestep(map_contains(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(map_contains(O,P,Q),R).

sigdec(map_contains,computes(booleans),[computes(maps(A,B)),A,B]).

rewrite(map_contains(A,B,C),D) :-     rewrites(A,map_empty),     rewrites(B,_),     rewrites(C,_),     rewrites(false,D).

rewrite(map_contains(A,E,G),I) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,F),     rewrites(C,H),     rewrites(D,_),     rewrites(E,F),     rewrites(G,H),     rewrites(true,I).

rewrite(map_contains(A,E,G),J) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,F),     rewrites(C,H),     rewrites(D,_),     rewrites(E,F),     rewrites(G,I),     \+rewrites(H,I),     rewrites(false,J).

rewrite(map_contains(A,E,F),N) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,G),     rewrites(C,_),     rewrites(D,H),     rewrites(E,I),     rewrites(F,J),     lessthan(G,I),     rewrites(H,K),     rewrites(I,L),     rewrites(J,M),     rewrites(map_contains(K,L,M),N).

rewrite(map_contains(A,E,F),I) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,H),     rewrites(C,_),     rewrites(D,_),     rewrites(E,G),     rewrites(F,_),     lessthan(G,H),     rewrites(false,I).

sigdec(map_zip,maps(A,B),[lists(A),lists(B)]).

onestep(map_zip(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_zip(G,H),I).

onestep(map_zip(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_zip(G,H),I).

onestep(map_zip(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_zip(J,K),L).

onestep(map_zip(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_zip(J,K),L).

sigdec(map_zip,computes(maps(A,B)),[computes(lists(A)),computes(lists(B))]).

rewrite(map_zip(A,B),C) :-     rewrites(A,list_empty),     rewrites(B,list_empty),     rewrites(map_empty,C).

rewrite(map_zip(A,D),P) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,K),     rewrites(C,G),     rewrites(D,list_prefix(E,F)),     rewrites(E,L),     rewrites(F,H),     rewrites(G,I),     rewrites(H,J),     rewrites(map_zip(I,J),M),     rewrites(K,N),     rewrites(L,O),     rewrites(map_update(M,N,O),P).

sigdec(map_to_list,lists(A),[maps(_,A)]).

onestep(map_to_list(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(map_to_list(E),F).

onestep(map_to_list(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(map_to_list(E),F).

onestep(map_to_list(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(map_to_list(E),F).

sigdec(map_to_list,computes(lists(A)),[computes(maps(_,A))]).

rewrite(map_to_list(A),B) :-     rewrites(A,map_empty),     rewrites(list_empty,B).

rewrite(map_to_list(A),J) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,_),     rewrites(C,E),     rewrites(D,F),     rewrites(E,H),     rewrites(F,G),     rewrites(map_to_list(G),I),     rewrites(list_prefix(H,I),J).

sigdec(list_to_map,map(A,_),[list(A)]).

onestep(list_to_map(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(list_to_map(E),F).

onestep(list_to_map(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(list_to_map(E),F).

sigdec(list_to_map,map(A,_),[list(A)]).

rewrite(list_to_map(A),B) :-     rewrites(A,list_empty),     rewrites(map_empty,B).

rewrite(list_to_map(A),J) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,F),     rewrites(C,D),     rewrites(D,E),     rewrites(list_to_map(E),G),     rewrites(F,H),     rewrites(_,I),     rewrites(map_update(G,H,I),J).

