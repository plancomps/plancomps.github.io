% Generated from Values/records.csf

sigdec(record,records,[maps(fields,val)]).

onestep(record(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(record(E),F).

onestep(record(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(record(E),F).

onestep(record(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(record(E),F).

sigdec(record,computes(records),[computes(maps(fields,val))]).

valcons(record).

sigdec(records,types,[]).

onestep(records,A,B,resolve) :-     unobs(A),     rewrites(records,B).

onestep(records,A,B,typeval) :-     unobs(A),     rewrites(records,B).

valsort(records).

sigdec(records,types,[maps(fields,types)]).

onestep(records(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(records(E),F).

onestep(records(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(records(E),F).

onestep(records(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(records(E),F).

sigdec(records,types,[computes(maps(fields,types))]).

onestep(records(A),D,types,inhabit) :-     rewrites(A,B),     rewrites(map_to_list(B),C),     inhabit(C,D,lists(types)).

onestep(record(A),D,records(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

sigdec(record1,records,[fields,_]).

onestep(record1(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record1(G,H),I).

onestep(record1(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record1(G,H),I).

onestep(record1(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record1(J,K),L).

onestep(record1(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record1(J,K),L).

sigdec(record1,computes(records),[computes(fields),_]).

rewrite(record1(A,B),L) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,G),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,H),     rewrites(G,I),     rewrites(H,J),     rewrites(map1(I,J),K),     rewrites(record(K),L).

onestep(record1(A,B),E,records(H),inhabit) :-     rewrites(A,F),     rewrites(B,C),     rewrites(C,D),     inhabit(D,E,G) ->     rewrites(map1(F,G),H). 

sigdec(record_select,_,[records,fields]).

onestep(record_select(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_select(G,H),I).

onestep(record_select(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_select(G,H),I).

onestep(record_select(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_select(J,K),L).

onestep(record_select(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_select(J,K),L).

sigdec(record_select,_,[computes(records),computes(fields)]).

rewrite(record_select(A,C),H) :-     rewrites(A,record(B)),     rewrites(B,D),     rewrites(C,E),     rewrites(D,F),     rewrites(E,G),     rewrites(map_select(F,G),H).

onestep(record_select(A,B),E,map_select(F,G),inhabit) :-     rewrites(A,C),     rewrites(B,G),     rewrites(C,D),     inhabit(D,E,records(F)) ->     rewrites(contains_key(F,G),true). 

sigdec(record_over,records,[records,records]).

onestep(record_over(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_over(G,H),I).

onestep(record_over(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_over(G,H),I).

onestep(record_over(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_over(J,K),L).

onestep(record_over(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_over(J,K),L).

sigdec(record_over,computes(records),[computes(records),computes(records)]).

rewrite(record_over(A,C),J) :-     rewrites(A,record(B)),     rewrites(B,E),     rewrites(C,record(D)),     rewrites(D,F),     rewrites(E,G),     rewrites(F,H),     rewrites(map_over(G,H),I),     rewrites(record(I),J).

onestep(record_over(A,B),L,records(I),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(L,J),     rewrites(C,D),     inhabit(D,J,records(G)) ->     mid_comp(J,K),     rewrites(E,F),     inhabit(F,K,records(H)) ->     rewrites(map_over(G,H),I),     post_comp(J,K,L).

sigdec(record_union,records,[records,records]).

onestep(record_union(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_union(G,H),I).

onestep(record_union(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_union(G,H),I).

onestep(record_union(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_union(J,K),L).

onestep(record_union(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_union(J,K),L).

sigdec(record_union,computes(records),[computes(records),computes(records)]).

rewrite(record_union(A,C),J) :-     rewrites(A,record(B)),     rewrites(B,E),     rewrites(C,record(D)),     rewrites(D,F),     rewrites(E,G),     rewrites(F,H),     rewrites(map_union(G,H),I),     rewrites(record(I),J).

onestep(record_union(A,B),L,records(I),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(L,J),     rewrites(C,D),     inhabit(D,J,records(G)) ->     mid_comp(J,K),     rewrites(E,F),     inhabit(F,K,records(H)) ->     rewrites(map_union(G,H),I),     post_comp(J,K,L).

sigdec(records_union,types,[types,types]).

onestep(records_union(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(records_union(J,K),L).

onestep(records_union(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(records_union(J,K),L).

rewrite(records_union(A,C),J) :-     rewrites(A,records(B)),     rewrites(B,E),     rewrites(C,records(D)),     rewrites(D,F),     rewrites(E,G),     rewrites(F,H),     rewrites(map_union(G,H),I),     rewrites(records(I),J).

onestep(records_union(A,B),I,types,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,types) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,types) ->     post_comp(G,H,I). 

