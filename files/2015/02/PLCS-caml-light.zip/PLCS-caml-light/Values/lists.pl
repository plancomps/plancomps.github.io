% Generated from Values/lists.csf

sigdec(list_empty,lists(_),[]).

onestep(list_empty,A,B,resolve) :-     unobs(A),     rewrites(list_empty,B).

onestep(list_empty,A,B,typeval) :-     unobs(A),     rewrites(list_empty,B).

sigdec(list_empty,computes(lists(_)),[]).

valcons(list_empty).

sigdec(list_prefix,lists(A),[A,lists(A)]).

onestep(list_prefix(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_prefix(G,H),I).

onestep(list_prefix(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_prefix(G,H),I).

onestep(list_prefix(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_prefix(J,K),L).

onestep(list_prefix(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_prefix(J,K),L).

sigdec(list_prefix,computes(lists(A)),[A,computes(lists(A))]).

valcons(list_prefix).

sigdec(lists(_),types,[]).

onestep(lists(A),B,E,resolve) :-     rewrites(A,C),     unobs(B),     rewrites(C,D),     rewrites(lists(D),E).

onestep(lists(A),B,E,typeval) :-     rewrites(A,C),     unobs(B),     rewrites(C,D),     rewrites(lists(D),E).

valsort(lists(_)).

onestep(lists(A),D,types,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,types).

onestep(list_empty,A,lists(_),inhabit) :-     unobs(A).

onestep(list_prefix(A,B),J,lists(G),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,G) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,lists(G)) ->     post_comp(H,I,J). 

sigdec(list1,lists(A),[A]).

onestep(list1(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(list1(E),F).

onestep(list1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(list1(E),F).

onestep(list1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(list1(E),F).

sigdec(list1,computes(lists(A)),[A]).

rewrite(list1(A),E) :-     rewrites(A,B),     rewrites(B,C),     rewrites(list_empty,D),     rewrites(list_prefix(C,D),E).

sigdec(list2,lists(A),[A,A]).

onestep(list2(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list2(G,H),I).

onestep(list2(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list2(G,H),I).

onestep(list2(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list2(J,K),L).

onestep(list2(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list2(J,K),L).

sigdec(list2,computes(lists(A)),[A,A]).

rewrite(list2(A,B),I) :-     rewrites(A,C),     rewrites(B,D),     rewrites(C,G),     rewrites(D,E),     rewrites(list_empty,F),     rewrites(list_prefix(E,F),H),     rewrites(list_prefix(G,H),I).

sigdec(list_reverse,lists(A),[lists(A)]).

onestep(list_reverse(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(list_reverse(E),F).

onestep(list_reverse(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(list_reverse(E),F).

onestep(list_reverse(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(list_reverse(E),F).

sigdec(list_reverse,computes(lists(A)),[computes(lists(A))]).

rewrite(list_reverse(A),B) :-     rewrites(A,list_empty),     rewrites(list_empty,B).

rewrite(list_reverse(A),J) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,F),     rewrites(C,D),     rewrites(D,E),     rewrites(list_reverse(E),H),     rewrites(F,G),     rewrites(list1(G),I),     rewrites(list_append(H,I),J).

onestep(list_reverse(A),D,lists(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,lists(E)).

sigdec(list_append,lists(A),[lists(A),lists(A)]).

onestep(list_append(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_append(G,H),I).

onestep(list_append(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_append(G,H),I).

onestep(list_append(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_append(J,K),L).

onestep(list_append(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_append(J,K),L).

sigdec(list_append,computes(lists(A)),[computes(lists(A)),computes(lists(A))]).

rewrite(list_append(A,B),D) :-     rewrites(A,list_empty),     rewrites(B,C),     rewrites(C,D).

rewrite(list_append(A,D),L) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,F),     rewrites(D,G),     rewrites(E,J),     rewrites(F,H),     rewrites(G,I),     rewrites(list_append(H,I),K),     rewrites(list_prefix(J,K),L).

onestep(list_append(A,B),J,lists(G),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,lists(G)) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,lists(G)) ->     post_comp(H,I,J). 

sigdec(list_head,A,[lists(A)]).

onestep(list_head(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(list_head(E),F).

onestep(list_head(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(list_head(E),F).

onestep(list_head(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(list_head(E),F).

sigdec(list_head,A,[computes(lists(A))]).

rewrite(list_head(A),E) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,D),     rewrites(C,_),     rewrites(D,E).

onestep(list_head(A),D,E,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,lists(E)).

sigdec(list_tail,lists(A),[lists(A)]).

onestep(list_tail(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(list_tail(E),F).

onestep(list_tail(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(list_tail(E),F).

onestep(list_tail(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(list_tail(E),F).

sigdec(list_tail,computes(lists(A)),[computes(lists(A))]).

rewrite(list_tail(A),E) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,_),     rewrites(C,D),     rewrites(D,E).

onestep(list_tail(A),D,lists(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,lists(E)).

sigdec(list_last,A,[lists(A)]).

onestep(list_last(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(list_last(E),F).

onestep(list_last(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(list_last(E),F).

onestep(list_last(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(list_last(E),F).

sigdec(list_last,A,[computes(lists(A))]).

rewrite(list_last(A),E) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,D),     rewrites(C,list_empty),     rewrites(D,E).

rewrite(list_last(A),K) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,_),     rewrites(C,list_prefix(D,E)),     rewrites(D,F),     rewrites(E,G),     rewrites(F,H),     rewrites(G,I),     rewrites(list_prefix(H,I),J),     rewrites(list_last(J),K).

sigdec(list_select,A,[lists(A),ints]).

onestep(list_select(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_select(G,H),I).

onestep(list_select(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_select(G,H),I).

onestep(list_select(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_select(J,K),L).

onestep(list_select(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_select(J,K),L).

sigdec(list_select,A,[computes(lists(A)),computes(ints)]).

rewrite(list_select(A,D),F) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,_),     rewrites(D,q(0)),     rewrites(E,F).

rewrite(list_select(A,D),K) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,_),     rewrites(C,E),     rewrites(D,F),     rewrites(int_greater(F,q(0)),true),     rewrites(E,I),     rewrites(F,G),     rewrites(q(1),H),     rewrites(int_minus(G,H),J),     rewrites(list_select(I,J),K).

onestep(list_select(A,B),J,E,inhabit) :-     rewrites(A,C),     rewrites(B,F),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,lists(E)) ->     mid_comp(H,I),     rewrites(F,G),     inhabit(G,I,ints) ->     post_comp(H,I,J). 

sigdec(list_length,ints,[lists(_)]).

onestep(list_length(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(list_length(E),F).

onestep(list_length(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(list_length(E),F).

onestep(list_length(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(list_length(E),F).

sigdec(list_length,computes(ints),[computes(lists(_))]).

rewrite(list_length(A),q(0)) :-     rewrites(A,list_empty).

rewrite(list_length(A),H) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,_),     rewrites(C,D),     rewrites(D,E),     rewrites(list_length(E),F),     rewrites(q(1),G),     rewrites(int_plus(F,G),H).

onestep(list_length(A),D,ints,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,lists(_)).

sigdec(list_union,lists(A),[lists(A),lists(A)]).

onestep(list_union(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_union(G,H),I).

onestep(list_union(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_union(G,H),I).

onestep(list_union(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_union(J,K),L).

onestep(list_union(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_union(J,K),L).

sigdec(list_union,computes(lists(A)),[computes(lists(A)),computes(lists(A))]).

rewrite(list_union(A,B),D) :-     rewrites(A,list_empty),     rewrites(B,C),     rewrites(C,D).

rewrite(list_union(A,D),L) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,F),     rewrites(D,G),     rewrites(list_contains(G,E),false),     rewrites(E,J),     rewrites(F,H),     rewrites(G,I),     rewrites(list_union(H,I),K),     rewrites(list_prefix(J,K),L).

rewrite(list_union(A,D),J) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,F),     rewrites(D,G),     rewrites(list_contains(G,E),true),     rewrites(F,H),     rewrites(G,I),     rewrites(list_union(H,I),J).

onestep(list_union(A,B),J,lists(G),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,lists(G)) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,lists(G)) ->     post_comp(H,I,J). 

sigdec(list_intersect,lists(A),[lists(A),lists(A)]).

onestep(list_intersect(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_intersect(G,H),I).

onestep(list_intersect(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_intersect(G,H),I).

onestep(list_intersect(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_intersect(J,K),L).

onestep(list_intersect(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_intersect(J,K),L).

sigdec(list_intersect,computes(lists(A)),[computes(lists(A)),computes(lists(A))]).

rewrite(list_intersect(A,B),E) :-     rewrites(A,list_empty),     rewrites(B,C),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,_),     rewrites(list_empty,E).

rewrite(list_intersect(A,D),J) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,F),     rewrites(D,G),     rewrites(list_contains(G,E),false),     rewrites(F,H),     rewrites(G,I),     rewrites(list_intersect(H,I),J).

rewrite(list_intersect(A,D),L) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,F),     rewrites(D,G),     rewrites(list_contains(G,E),true),     rewrites(E,J),     rewrites(F,H),     rewrites(G,I),     rewrites(list_intersect(H,I),K),     rewrites(list_prefix(J,K),L).

onestep(list_intersect(A,B),J,lists(G),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,lists(G)) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,lists(G)) ->     post_comp(H,I,J). 

sigdec(list_contains,booleans,[lists(A),A]).

onestep(list_contains(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_contains(G,H),I).

onestep(list_contains(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_contains(G,H),I).

onestep(list_contains(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_contains(J,K),L).

onestep(list_contains(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_contains(J,K),L).

sigdec(list_contains,computes(booleans),[computes(lists(A)),A]).

rewrite(list_contains(A,B),E) :-     rewrites(A,list_empty),     rewrites(B,C),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,_),     rewrites(false,E).

rewrite(list_contains(A,D),F) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,_),     rewrites(D,E),     rewrites(true,F).

rewrite(list_contains(A,D),L) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,F),     rewrites(C,H),     rewrites(D,G),     rewrites(G,E),     runcheck(E,val),     checktag(E,val,I),     \+rewrites(F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_contains(J,K),L).

onestep(list_contains(A,B),J,booleans,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,lists(G)) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,G) ->     post_comp(H,I,J). 

sigdec(list_subset,booleans,[lists(A),lists(A)]).

onestep(list_subset(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_subset(G,H),I).

onestep(list_subset(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_subset(G,H),I).

onestep(list_subset(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_subset(J,K),L).

onestep(list_subset(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_subset(J,K),L).

sigdec(list_subset,computes(booleans),[computes(lists(A)),computes(lists(A))]).

rewrite(list_subset(A,B),E) :-     rewrites(A,list_empty),     rewrites(B,C),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,_),     rewrites(true,E).

rewrite(list_subset(A,D),N) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,H),     rewrites(D,I),     rewrites(I,F),     rewrites(E,G),     rewrites(list_contains(F,G),L),     rewrites(H,J),     rewrites(I,K),     rewrites(list_subset(J,K),M),     rewrites(and(L,M),N).

onestep(list_subset(A,B),J,booleans,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,lists(G)) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,lists(G)) ->     post_comp(H,I,J). 

sigdec(list_remove,lists(A),[lists(A),A]).

onestep(list_remove(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_remove(G,H),I).

onestep(list_remove(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_remove(G,H),I).

onestep(list_remove(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_remove(J,K),L).

onestep(list_remove(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_remove(J,K),L).

sigdec(list_remove,computes(lists(A)),[computes(lists(A)),A]).

rewrite(list_remove(A,B),E) :-     rewrites(A,list_empty),     rewrites(B,C),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,_),     rewrites(list_empty,E).

rewrite(list_remove(A,D),I) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,F),     rewrites(C,E),     rewrites(D,F),     rewrites(E,G),     rewrites(F,H),     rewrites(list_remove(G,H),I).

rewrite(list_remove(A,D),N) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,G),     rewrites(C,H),     rewrites(D,F),     rewrites(F,E),     runcheck(E,val),     checktag(E,val,I),     \+rewrites(G,F),     rewrites(G,L),     rewrites(H,J),     rewrites(I,K),     rewrites(list_remove(J,K),M),     rewrites(list_prefix(L,M),N).

onestep(list_remove(A,B),J,lists(G),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,lists(G)) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,G) ->     post_comp(H,I,J). 

sigdec(list_removes,lists(A),[lists(A),lists(A)]).

onestep(list_removes(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_removes(G,H),I).

onestep(list_removes(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_removes(G,H),I).

onestep(list_removes(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_removes(J,K),L).

onestep(list_removes(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_removes(J,K),L).

sigdec(list_removes,computes(lists(A)),[computes(lists(A)),computes(lists(A))]).

rewrite(list_removes(A,B),F) :-     rewrites(A,C),     rewrites(B,list_empty),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,E),     rewrites(E,F).

rewrite(list_removes(A,B),N) :-     rewrites(A,E),     rewrites(B,list_prefix(C,D)),     rewrites(C,K),     rewrites(D,H),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,G),     rewrites(G,I),     rewrites(H,J),     rewrites(list_removes(I,J),L),     rewrites(K,M),     rewrites(list_remove(L,M),N).

onestep(list_remove(A,B),J,lists(G),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,lists(G)) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,lists(G)) ->     post_comp(H,I,J). 

sigdec(list_replicate,lists(A),[ints,A]).

onestep(list_replicate(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_replicate(G,H),I).

onestep(list_replicate(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_replicate(G,H),I).

onestep(list_replicate(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_replicate(J,K),L).

onestep(list_replicate(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_replicate(J,K),L).

sigdec(list_replicate,computes(lists(A)),[computes(ints),A]).

rewrite(list_replicate(A,B),E) :-     rewrites(A,q(0)),     rewrites(B,C),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,_),     rewrites(list_empty,E).

rewrite(list_replicate(A,B),M) :-     rewrites(A,E),     rewrites(B,C),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,H),     rewrites(int_greater(E,q(0)),true),     rewrites(H,K),     rewrites(E,F),     rewrites(q(1),G),     rewrites(int_minus(F,G),I),     rewrites(H,J),     rewrites(list_replicate(I,J),L),     rewrites(list_prefix(K,L),M).

onestep(list_replicate(A,B),J,lists(G),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,ints) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,G) ->     post_comp(H,I,J). 

sigdec(list_sort,lists(A),[lists(A)]).

onestep(list_sort(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(list_sort(E),F).

onestep(list_sort(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(list_sort(E),F).

onestep(list_sort(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(list_sort(E),F).

sigdec(list_sort,computes(lists(A)),[computes(lists(A))]).

rewrite(list_sort(A),B) :-     rewrites(A,list_empty),     rewrites(list_empty,B).

rewrite(list_sort(A),I) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,D),     rewrites(C,E),     rewrites(D,G),     rewrites(E,F),     rewrites(list_sort(F),H),     rewrites(list_insert(G,H),I).

sigdec(list_insert,lists(A),[A,lists(A)]).

onestep(list_insert(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_insert(G,H),I).

onestep(list_insert(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_insert(G,H),I).

onestep(list_insert(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_insert(J,K),L).

onestep(list_insert(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_insert(J,K),L).

sigdec(list_insert,computes(lists(A)),[A,computes(lists(A))]).

rewrite(list_insert(A,B),E) :-     rewrites(A,C),     rewrites(B,list_empty),     rewrites(C,D),     rewrites(list1(D),E).

rewrite(list_insert(A,B),L) :-     rewrites(A,E),     rewrites(B,list_prefix(C,D)),     rewrites(C,F),     rewrites(D,G),     rewrites(less(E,F),true),     rewrites(E,J),     rewrites(F,H),     rewrites(G,I),     rewrites(list_prefix(H,I),K),     rewrites(list_prefix(J,K),L).

rewrite(list_insert(A,B),L) :-     rewrites(A,F),     rewrites(B,list_prefix(C,D)),     rewrites(C,E),     rewrites(D,G),     rewrites(less(F,E),false),     rewrites(E,J),     rewrites(F,H),     rewrites(G,I),     rewrites(list_insert(H,I),K),     rewrites(list_prefix(J,K),L).

