#!/bin/bash

# Example usage
# > ./run-fct Languages/Caml-Light/Tests/Advanced/Advanced1.fct

swipl -s Prolog/run_fct.pl -q -g "startf('"$1"'),halt."
