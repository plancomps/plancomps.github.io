% Generated from Higher/subst#2.csf

sigdec(subst,types,[types,typevars,types]).

onestep(subst(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,D),     rewrites(C,H),     runstep(D,E,G) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(subst(I,J,K),L).

onestep(subst(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(subst(O,P,Q),R).

onestep(subst(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(subst(O,P,Q),R).

sigdec(subst,types,[types,computes(typevars),types]).

rewrite(subst(A,B,C),G) :-     rewrites(A,D),     rewrites(B,_),     rewrites(C,_),     rewrites(D,E),     runcheck(E,nullary),     checktag(E,nullary,F),     rewrites(F,G).

rewrite(subst(A,C,F),H) :-     rewrites(A,typevar(B)),     rewrites(B,E),     rewrites(C,typevar(D)),     rewrites(D,E),     rewrites(F,G),     rewrites(G,H).

rewrite(subst(A,D,F),O) :-     decompose(B,Q,[C]),     rewrites(A,B),     decompose(B,Q,[C]),     rewrites(C,H),     rewrites(D,typevar(E)),     rewrites(E,I),     rewrites(F,K),     decompose(G,Q,[H]),     \+rewrites(G,typevar(I)),     decompose(G,Q,[H]),     rewrites(H,L),     rewrites(I,J),     rewrites(typevar(J),M),     rewrites(K,N),     rewrites(subst(L,M,N),R),     decompose(P,Q,[R]),     rewrites(P,O),     decompose(P,Q,[R]).

rewrite(subst(A,D,F),L) :-     rewrites(A,type_abs(B,C)),     rewrites(B,H),     rewrites(C,I),     rewrites(D,typevar(E)),     rewrites(E,G),     rewrites(F,_),     rewrites(list_contains(H,typevar(G)),true),     rewrites(H,J),     rewrites(I,K),     rewrites(type_abs(J,K),L).

rewrite(subst(A,D,F),L) :-     rewrites(A,forall(B,C)),     rewrites(B,H),     rewrites(C,I),     rewrites(D,typevar(E)),     rewrites(E,G),     rewrites(F,_),     rewrites(list_contains(H,typevar(G)),true),     rewrites(H,J),     rewrites(I,K),     rewrites(forall(J,K),L).

rewrite(subst(A,D,F),Q) :-     rewrites(A,type_abs(B,C)),     rewrites(B,G),     rewrites(C,H),     rewrites(D,typevar(E)),     rewrites(E,I),     rewrites(F,K),     rewrites(list_contains(G,typevar(I)),false),     rewrites(list_intersect(free_vars(K),G),list_empty),     rewrites(G,O),     rewrites(H,L),     rewrites(I,J),     rewrites(typevar(J),M),     rewrites(K,N),     rewrites(subst(L,M,N),P),     rewrites(type_abs(O,P),Q).

rewrite(subst(A,D,F),Q) :-     rewrites(A,forall(B,C)),     rewrites(B,G),     rewrites(C,H),     rewrites(D,typevar(E)),     rewrites(E,I),     rewrites(F,K),     rewrites(list_contains(G,typevar(I)),false),     rewrites(list_intersect(free_vars(K),G),list_empty),     rewrites(G,O),     rewrites(H,L),     rewrites(I,J),     rewrites(typevar(J),M),     rewrites(K,N),     rewrites(subst(L,M,N),P),     rewrites(forall(O,P),Q).

rewrite(subst(A,E,G),V) :-     decompose(B,X,[C,D]),     rewrites(A,B),     decompose(B,X,[C,D]),     rewrites(C,J),     rewrites(D,O),     rewrites(E,typevar(F)),     rewrites(F,P),     rewrites(G,R),     decompose(H,X,[J,O]),     \+rewrites(H,type_abs(_,_)),     decompose(H,X,[J,O]),     decompose(I,X,[J,O]),     \+rewrites(I,forall(_,_)),     decompose(I,X,[J,O]),     rewrites(J,L),     rewrites(P,K),     rewrites(typevar(K),M),     rewrites(R,N),     rewrites(subst(L,M,N),Y),     rewrites(O,S),     rewrites(P,Q),     rewrites(typevar(Q),T),     rewrites(R,U),     rewrites(subst(S,T,U),Z),     decompose(W,X,[Y,Z]),     rewrites(W,V),     decompose(W,X,[Y,Z]).

rewrite(subst(A,F,H),Z) :-     decompose(B,ZB,[C,D,E]),     rewrites(A,B),     decompose(B,ZB,[C,D,E]),     rewrites(C,I),     rewrites(D,N),     rewrites(E,S),     rewrites(F,typevar(G)),     rewrites(G,T),     rewrites(H,V),     rewrites(I,K),     rewrites(T,J),     rewrites(typevar(J),L),     rewrites(V,M),     rewrites(subst(K,L,M),ZC),     rewrites(N,P),     rewrites(T,O),     rewrites(typevar(O),Q),     rewrites(V,R),     rewrites(subst(P,Q,R),ZD),     rewrites(S,W),     rewrites(T,U),     rewrites(typevar(U),X),     rewrites(V,Y),     rewrites(subst(W,X,Y),ZE),     decompose(ZA,ZB,[ZC,ZD,ZE]),     rewrites(ZA,Z),     decompose(ZA,ZB,[ZC,ZD,ZE]).

sigdec(subst,types,[types,maps(typevars,types)]).

onestep(subst(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(subst(G,H),I).

onestep(subst(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(subst(J,K),L).

onestep(subst(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(subst(J,K),L).

sigdec(subst,types,[types,computes(maps(typevars,types))]).

rewrite(subst(A,B),D) :-     rewrites(A,C),     rewrites(B,map_empty),     rewrites(C,D).

rewrite(subst(A,B),O) :-     rewrites(A,F),     rewrites(B,map_prefix(C,D,E)),     rewrites(C,J),     rewrites(D,K),     rewrites(E,G),     rewrites(F,H),     rewrites(G,I),     rewrites(subst(H,I),L),     rewrites(J,M),     rewrites(K,N),     rewrites(subst(L,M,N),O).

