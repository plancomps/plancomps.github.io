% Generated from Higher/instantiate_meta#1.csf

sigdec(instantiate_meta,types,[types]).

onestep(instantiate_meta(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(instantiate_meta(E),F).

onestep(instantiate_meta(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(instantiate_meta(E),F).

