% Generated from Higher/abs.csf

sigdec(abs1_1,abs(val,val),[_]).

onestep(abs1_1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(abs1_1(E),F).

onestep(abs1_1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(abs1_1(E),F).

rewrite(abs1_1(A),F) :-     rewrites(A,C),     rewrites(given,D),     decompose(B,C,[D]),     rewrites(B,E),     decompose(B,C,[D]),     rewrites(abs(E),F).

sigdec(abs2_1,abs(tuples,val),[_]).

onestep(abs2_1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(abs2_1(E),F).

onestep(abs2_1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(abs2_1(E),F).

rewrite(abs2_1(A),K) :-     rewrites(A,G),     rewrites(zero,B),     rewrites(given,C),     rewrites(project(B,C),H),     rewrites(one,D),     rewrites(given,E),     rewrites(project(D,E),I),     decompose(F,G,[H,I]),     rewrites(F,J),     decompose(F,G,[H,I]),     rewrites(abs(J),K).

