
module Main where

import System.Environment (getArgs)

import Funcons.EDSL 
import Funcons.Parser
import Funcons.Printer
import Funcons.Core.Library

main :: IO ()
main = do   args <- getArgs
            case args of
                []          -> go0
                fp:args'    -> go2 fp args'
 where  go0 = putStrLn "Please provide me with an .fct file"
        go2 fp args = do    str <- readFile fp
                            let f0 :: Funcons
                                f0 = parse fp str 
                            emulate library args f0


