
module Funcons.EDSL (
    -- * Making steps
    MSOS(..), StepRes, StepFunction(..),
        -- ** Entity-types
        Output, writeOUT,
        Mutable, getMUT, putMUT, modifyMUT,
        Inherited, getINH, withINH,
        Control, raiseSignal, receiveSignal,
        -- ** IMSOS helpers
        afterStep, afterRewrite, premiseStep, norule, exception, sortErr,
        -- *** Congruence rules
        congruence1_1, congruence1_2, congruence2_2
                     , congruence1_3, congruence2_3, congruence3_3,
        -- *** Boolean premise conditions
        isVal, isMap, isBool, hasStep,
    -- * Values
        -- ** Helpers
        funconValue,
    -- * Running funcons
    emulate,
    -- * Funcon libraries
    FunconLibrary, libUnions, libEmpty, libUnion, libFromList,
    
    module Funcons.Types,
    module Funcons.RunOptions,
    )where

import Prelude
import qualified Prelude as P
import Control.Applicative
import Control.Arrow ((***))
import Control.Monad (liftM, forM_, ap, unless, when)
import Data.Char (isDigit)
import Data.List (intercalate, intersperse, foldl')
import Data.Fixed (mod')
import Data.Maybe (isJust,catMaybes)
import Data.Monoid hiding (Any)
import Data.Ratio
import Numeric

import qualified Data.Map as M
import qualified Data.Set as S
import qualified Data.Vector as V
import qualified Data.BitVector as BV

import Funcons.Types
import Funcons.RunOptions
import Funcons.Printer
import Funcons.Parser

---------------------------------------------------------------------
type FunconLibrary = M.Map Key StepFunction

data StepFunction   = LazyFuncon    ([Funcons] -> StepRes)
                    | StrictFuncon  (Values -> StepRes)
                    | NullaryFuncon (StepRes)
                    | ValueOp       (Values -> StepRes)

getLib :: Name -> MSOS StepFunction
getLib nm = do  lib <- giveLib
                case M.lookup key lib of
                    Nothing -> error ("unknown funcon: " ++ nm)
                    Just s  -> return s
 where key = name2key nm

libEmpty :: FunconLibrary
libEmpty = M.empty 

libUnion :: FunconLibrary -> FunconLibrary -> FunconLibrary
libUnion = M.unionWithKey op
 where op k x _ = error ("duplicate funcon name: " ++ key2name k)

libUnions :: [FunconLibrary] -> FunconLibrary
libUnions = foldl' libUnion libEmpty
 where op _ _ = error ("duplicate funcon name")

libFromList :: [(Name, StepFunction)] -> FunconLibrary
libFromList = M.fromList . map (name2key *** id)

---------------------------------------------------------------------------
newtype MSOS a = MSOS { runMSOS :: (FunconLibrary -> RunOptions -> Inherited -> Mutable
                        -> (Either IE a, Mutable, Control, Output, Counters)) }

instance Applicative MSOS where
  pure = return
  (<*>) = ap

instance Functor MSOS where
  fmap = liftM

instance Monad MSOS  where
  return a = MSOS (\_ _ _ rw -> (Right a,rw,emptyCTRL,emptyOUT,emptyCounters))

  (MSOS f) >>= k = MSOS (\lib opts ro rw ->
                    let res1@(e_a1,rw1,ctrl1,wo1,cs1) = f lib opts ro rw 
                     in case e_a1 of 
                          Left err  -> (Left err, rw1, ctrl1, wo1, cs1)
                          Right a1  -> let (MSOS h) = k a1
                                           (a2,rw2,ctrl2,wo2,cs2) = h lib opts ro rw1 
                                        in (a2,rw2,ctrl1 `unionCTRL` ctrl2
                                                  ,wo1 `unionOUT` wo2
                                                  ,cs1 `unionCS` cs2))

-- handling exception from the interpreter
data IE = SortErr Funcons Funcons String
        | NoRule Funcons Funcons
        | Err Funcons Funcons String

errFmap :: (Funcons -> Funcons) -> IE -> IE
errFmap f2q (SortErr f f0 str)  = SortErr (f2q f) f0 str
errFmap f2q (NoRule f f0)       = NoRule (f2q f) f0
errFmap f2q (Err f  f0 str)     = Err (f2q f) f0 str

errF :: IE -> Funcons
errF (SortErr f _ _) = f 
errF (NoRule f _)    = f 
errF (Err f _ _)     = f

errReport :: IE -> StepRes
errReport ie = MSOS $ \ opts lib ro rw -> (Left ie, rw, emptyCTRL, emptyOUT, emptyCounters)

instance Show IE where
    show (SortErr _ f err) = "dynamic sort check (" ++ err ++ ") on " ++ show f
    show (NoRule _ f)      = "no rule to execute on " ++ show f
    show (Err _ f err)     = "exception (" ++ err ++ ") on " ++ show f

---
giveLib :: MSOS FunconLibrary
giveLib = MSOS (\lib opts ro rw -> (Right lib, rw, emptyCTRL, emptyOUT, emptyCounters))

giveOpts :: MSOS RunOptions 
giveOpts = MSOS $ \lib opts ro rw -> (Right opts, rw, emptyCTRL, emptyOUT, emptyCounters)

giveINH :: MSOS Inherited
giveINH = MSOS $ \lib opts ro rw -> (Right ro, rw, emptyCTRL, emptyOUT, emptyCounters)

giveMUT :: MSOS Mutable
giveMUT = MSOS $ \lib opts ro rw -> (Right rw, rw, emptyCTRL, emptyOUT, emptyCounters)

newMUT :: Mutable -> MSOS ()
newMUT rw = MSOS $ \lib opts ro _ -> (Right (), rw, emptyCTRL, emptyOUT, emptyCounters)

myLookup :: (Ord k) => M.Map k v -> k -> String -> v
myLookup m k str = maybe (error str) id $ M.lookup k m

----------------------------------------------------

type Mutable      = M.Map Key Values

emptyMUT :: Mutable
emptyMUT = M.empty

getMUT :: Name -> Values -> MSOS Values
getMUT nm b = do  rw <- giveMUT
                  case M.lookup key rw of
                      Nothing -> return b --error ("unknown read-write entity: " ++ nm)
                      Just v  -> return v
 where key = name2key nm

modifyMUT :: Name -> Values -> (Values -> Values) -> MSOS ()
modifyMUT nm def f = do rw <- giveMUT
                        newMUT (M.alter up key rw)
 where  key = name2key nm
        up Nothing  = Just def
        up (Just x) = Just (f x)

putMUT :: Name -> Values -> MSOS ()
putMUT nm v = do rw <- giveMUT
                 newMUT (M.insert key v rw)
 where key = name2key nm 

-----------------
type Inherited       = M.Map Key Values 

emptyINH :: Inherited
emptyINH = M.empty 

getINH :: Name -> Values -> MSOS Values
getINH nm b = do   ro <- giveINH
                   case M.lookup key ro of
                      Nothing -> return b --error ("unknown read-only entity: " ++ nm)
                      Just v  -> return v
 where key = name2key nm

withINH :: Name -> Values -> MSOS a -> MSOS a
withINH nm v (MSOS f) = MSOS (\lib opts ro rw  -> let ro' = M.insert key v ro
                                                 in f lib opts ro' rw)
 where key = name2key nm 
       
----------
type Control = M.Map Key Values 

emptyCTRL :: Control
emptyCTRL = M.empty

singleCTRL :: Key -> Values -> Control
singleCTRL = M.singleton

unionCTRL = M.unionWithKey (error . err)
 where err key = "Two " ++ key2name key ++ " signals converging!"

raiseSignal :: Name -> Values -> MSOS ()
raiseSignal nm v = MSOS (\lib opts ro rw -> 
                        (Right (), rw, singleCTRL (name2key nm) v, emptyOUT, emptyCounters))

receiveSignal :: Name -> StepRes -> MSOS (Funcons, Maybe Values)
receiveSignal nm (MSOS f) = MSOS (\lib opts ro rw -> 
    let (e_a, rw1, ctrl1, wo1, cs1) = f lib opts ro rw
    in case e_a of 
        Left err -> (Left err, rw1, ctrl1, wo1, cs1)
        Right a  -> (Right (a,M.lookup key ctrl1), rw1, M.delete key ctrl1, wo1, cs1))
 where key = name2key nm

-----------
type Output      = M.Map Key [Values]

unionOUT :: Output -> Output -> Output
unionOUT = M.unionWith (++)

emptyOUT :: Output 
emptyOUT = M.fromList    [(name2key "output", [])]

writeOUT :: Name -> Values -> MSOS ()
writeOUT nm v = MSOS $ \lib opts ro rw -> 
                        (Right (), rw, emptyCTRL, M.singleton key [v], emptyCounters)
 where key = name2key nm
-----------
type Counters   = M.Map Key Int
type Steps      = Int

unionCS :: Counters -> Counters -> Counters
unionCS = M.unionWith (+)

emptyCounters = M.fromList  [(name2key "step", 0)
                            ,(name2key "restart", 0)
                            ,(name2key"rewrite", 0)]

count_step :: MSOS ()
count_step = MSOS $ \lib opts ro rw-> 
                        (Right (), rw, emptyCTRL, emptyOUT, M.singleton (name2key "step") 1)

count_restart :: MSOS ()
count_restart = MSOS $ \lib opts ro rw -> 
                        (Right (), rw, emptyCTRL, emptyOUT, M.singleton (name2key "restart") 1)

count_rewrite :: MSOS ()
count_rewrite = MSOS $ \lib opts ro rw -> 
                        (Right (), rw, emptyCTRL, emptyOUT, M.singleton (name2key "rewrite") 1)

---- StepRes
type StepRes = MSOS Funcons

norule :: Funcons -> StepRes
norule f = errReport (NoRule f f)

sortErr :: Funcons -> String -> StepRes
sortErr f str = errReport (SortErr f f str)

exception :: Funcons -> String -> StepRes
exception f str = errReport (Err f f str)

afterStep :: Funcons -> StepRes 
afterStep f = count_step >> return f

afterRewrite :: Funcons -> StepRes
afterRewrite f | hasStep f   = 
                    do    count_rewrite
                          if_abruptly_terminates f stepFuncons return afterRewrite 
               | otherwise   = count_rewrite >> return f

subStep :: Funcons -> StepRes
subStep f = MSOS $ \lib opts ->
    let step'   | do_refocus opts   = refocus
                | otherwise         = stepFuncons
        MSOS m = step' f
    in m lib opts

refocus :: Funcons -> StepRes
refocus f | hasStep f   = if_abruptly_terminates f stepFuncons return refocus
          | otherwise   = return f
          
if_abruptly_terminates :: Funcons -> 
    (Funcons -> StepRes) -> (Funcons -> StepRes)
                         -> (Funcons -> StepRes) -> StepRes
if_abruptly_terminates f0 eval abr no_abr = MSOS $ \lib opts ro rw ->
    let MSOS fstep = eval f0 in
    case fstep lib opts ro rw of
        (Right f', rw', ctrl', wo', cs') ->
            let failed     = abruptly_terminated opts ctrl'
                MSOS fstep | failed      = abr f'
                           | otherwise   = no_abr f'
            in case fstep lib opts ro rw' of
                (Right f'', rw'', ctrl'', wo'', cs'') -> 
                    (Right f'', rw'', ctrl' `unionCTRL` ctrl'', wo' `unionOUT` wo'', cs' `unionCS` cs'')
                (Left err, rw'', ctrl'', wo'', cs'')  -> 
                    (Left err, rw'', ctrl' `unionCTRL` ctrl'', wo' `unionOUT` wo'', cs' `unionCS` cs'')
        norule_res -> norule_res

abruptly_terminated :: RunOptions -> Control -> Bool
abruptly_terminated opts ctrl =
    let failed  = isJust $ M.lookup (name2key "failed") ctrl
        failed' = isJust $ M.lookup (name2key "thrown") ctrl
    in do_abrupt_terminate opts && (failed || failed')

rewriteWith :: (Funcons -> StepRes) -> (Funcons -> Funcons) -> Funcons -> StepRes
rewriteWith step' f x = f <<$>> step' x

premiseStep :: (Funcons -> Funcons) -> Funcons -> StepRes
premiseStep l_map = stepResMap id l_map  . subStep

congruence1_1 :: (Funcons -> Funcons) -> Funcons -> StepRes
congruence1_1 x2f x = x2f <<$>> subStep x

congruence1_2 :: (Funcons -> Funcons -> Funcons) -> Funcons -> Funcons -> StepRes
congruence1_2 cons arg1 arg2 = (\arg1' -> (cons arg1' arg2)) <<$>> subStep arg1

congruence2_2 :: (Funcons -> Funcons -> Funcons) -> Funcons -> Funcons -> StepRes
congruence2_2 cons arg1 arg2 = (\arg2' -> (cons arg1 arg2')) <<$>> subStep arg2

congruence1_3 :: (Funcons -> Funcons -> Funcons -> Funcons) ->
                    Funcons -> Funcons -> Funcons -> StepRes
congruence1_3 cons arg1 arg2 arg3  = (\arg1' -> (cons arg1' arg2 arg3)) <<$>> subStep arg1

congruence2_3 :: (Funcons -> Funcons -> Funcons -> Funcons) ->
                    Funcons -> Funcons -> Funcons -> StepRes
congruence2_3 cons arg1 arg2 arg3 = (\arg2' -> (cons arg1 arg2' arg3)) <<$>> subStep arg2 

congruence3_3 :: (Funcons -> Funcons -> Funcons -> Funcons) ->
                    Funcons -> Funcons -> Funcons -> StepRes
congruence3_3 cons arg1 arg2 arg3  = cons arg1 arg2 <<$>> subStep arg3

infixl 1 <<$>> 
f2q <<$>> r = stepResMap f2q f2q r
stepResMap :: (Funcons -> Funcons) -> (Funcons -> Funcons) -> StepRes -> StepRes
stepResMap l_map r_map (MSOS p) = MSOS $ \opts lib ro rw -> 
    let (e_a1, rw1, ctrl1, out1, cs1) = p opts lib ro rw
    in case e_a1 of
        Left err -> (Left (errFmap l_map err), rw1, ctrl1, out1, cs1)
        Right f  -> (Right (r_map f), rw1, ctrl1, out1, cs1)

hasStep,noStep :: Funcons -> Bool
hasStep (Value _)           = False
hasStep _                   = True
noStep                      = Prelude.not . hasStep

----- main `step` function
stepFuncons :: Funcons -> StepRes 
stepFuncons (FunconName nm)     = 
    do  mystepf <- getLib nm 
        case mystepf of 
            NullaryFuncon mystep -> mystep
            _ -> error ("funcon " ++ nm ++ " not applied to any arguments")
stepFuncons (FunconApp nm arg)    = 
    do  mystepf <- getLib nm
        case mystepf of 
            NullaryFuncon _     -> exception (FunconApp nm arg) ("nullary funcon applied to arguments")
            ValueOp mystep      -> if isVal arg then mystep (funconValue arg)
                                                else FunconApp nm <<$>> stepFuncons arg
            StrictFuncon mystep -> if isVal arg then mystep (funconValue arg)
                                                else FunconApp nm <<$>> stepFuncons arg 
            LazyFuncon mystep   -> case arg of
                                    TupleNotation fs -> mystep fs
                                    _ -> exception (FunconApp nm arg) ("lazy funcon not applied to a tuple of arguments")
stepFuncons (Value v)           = exception (Value v) "cannot step a value"
stepFuncons (TupleNotation fs)  = stepSequence fs tup TupleNotation
stepFuncons (ListNotation fs)   = stepSequence fs listval ListNotation
stepFuncons (SetNotation fs)    = stepSequence fs setval SetNotation
stepFuncons (MapNotation fs)    = stepSequence fs mapval MapNotation

stepSequence :: [Funcons] -> ([Values] -> Funcons) -> ([Funcons] -> Funcons) -> StepRes
stepSequence args withVals withFunc = 
    let (vals,fs) = span isVal args
      in case fs of
           []   -> afterRewrite (withVals (map funconValue vals))
           x:xs -> (\x' -> (withFunc (vals ++ x':xs))) <<$>> stepFuncons x 

--- transitive closure over steps
stepsAux :: RunOptions -> Int -> Funcons -> StepRes
stepsAux opts i f
    | isVal f || maybe False ((<= i)) (max_steps opts) = return f
    | otherwise = if_abruptly_terminates f stepFuncons
                          return (\f -> count_restart >> stepsAux opts (i+1) f)

--- running programs 

emulate :: FunconLibrary -> [String] -> Funcons -> IO ()
emulate lib args f0 = do 
    forM_ unknown_opts $ \arg -> do
        putStrLn ("unknown option: " ++ arg)
    case e_exc_f of 
        Left ie -> print ie
        Right f -> do   printResult f
                        printCounts 
                        printMutable
                        printControl
                        printOutput
 where  (e_exc_f, mut, ctrl, out, cs) = runMSOS (stepsAux opts 0 f0) lib opts emptyINH emptyMUT
        (opts, unknown_opts) = run_options args

        printResult f = when (show_result opts) (putStrLn (ppFuncons opts f))

        printCounts = when (show_counts opts) (putStrLn $ toTuple)
         where  toTuple = "number of (" ++ intercalate "," keys ++ "): " ++ 
                            "(" ++ intercalate "," vals ++ ")"
                keys = map key2name (M.keys cs)
                vals = map show (M.elems cs)

        printMutable = mapM_ (putStrLn . displayValue) (catMaybes $ map select $ show_mutable opts)
         where select name = M.lookup (name2key name) mut 

        printControl = mapM_ (putStrLn . displayValue) (catMaybes $ map select $ show_control opts)
         where select name = M.lookup (name2key name) ctrl 
        printOutput = mapM_ (putStrLn . displayValue) (catMaybes $ map select $ show_output opts)
         where select name = fmap List $ M.lookup (name2key name) out 

        displayValue (Map m) =  unlines [ displayValue key ++ " |-> " ++ displayValue val 
                                        | (key, val) <- M.assocs m ]
        displayValue (ADT "variable" (Tuple [Atom a, Type t])) = 
            "variable(" ++ displayValue (Atom a) ++ ", " ++ ppTypes opts t ++ ")"
        displayValue (Atom a) = "@" ++ a
        displayValue val = ppValues opts val

--- Value specific

funconValue :: Funcons -> Values
funconValue (Value v) = v
funconValue _ = error "funconValue: not a value"

(===) :: Values -> Values -> Bool
v1 === v2 = isGround v1 && isGround v2 && (v1 == v2)

(=/=) :: Values -> Values -> Bool
v1 =/= v2 = isGround v1 && isGround v2 && (v1 /= v2)

isGround :: Values -> Bool
isGround (ADT _ v)      = isGround v
isGround (Ascii _)      = True
isGround (Atom _)       = True
isGround (Bool _)       = True
isGround (Bits _)       = True
isGround (Char _)       = True
isGround (Float _)      = True
isGround (ID _)         = True
isGround (List vs)      = all isGround vs
isGround (Map m)        = all isGround (M.elems m)
isGround (Nameid _ _)   = True
isGround (Set s)        = all isGround (S.toList s)
isGround (String _)     = True
isGround (Thunk _)      = False
isGround (Tuple vs)     = all isGround vs
isGround (Type v)       = True
isGround (Vector v)     = all isGround (V.toList v)
-- rationals
isGround (IEEE_Float_32 f) = True
isGround (IEEE_Float_64 d) = True
isGround (Rational _)   = True
isGround (Int _)        = True
isGround (Nat n)        = True

-- functions that check simple properties of funcons
isBool (Value (Bool _))         = True
isBool _                        = False
isChar (Value (Char _))         = True
isChar _                        = False
isId (Value (ID _))             = True
isId _                          = False
isInt (Value (Int _))           = True
isInt _                         = False
isLink (Value (ADT "link" _))   = True
isLink _                        = False
isList (Value (List _))         = True
isList _                        = False
isMap (Value (Map _))           = True
isMap _                         = False
isSet (Value (Set _))           = True
isSet _                         = False
isString (Value v)              = isString_ v
isString _                      = False
isString_ (String _)            = True
isString_ _                     = False
isThunk (Value (Thunk _))       = True
isThunk _                       = False
isTup (Value (Tuple _))         = True
isTup _                         = False
isType (Value (Type _))         = True
isType _                        = False
isType_Abs (Value (Type (Type_Abs _ _))) = True
isType_Abs _                    = False
isVal (Value _)                 = True
isVal _                         = False
isVar (Value (ADT "variable" _))= True
isVar _                         = False
isVec (Value (Vector _))        = True
isVec _                         = False

integers,booleans,chars,strings,unknown_type,values :: Funcons
integers = Value $ Type Integers
chars    = Value $ Type Chars
booleans = Value $ Type Booleans
strings = Value $ Type Strings
unknown_type = Value $ Type Unknown
values = Value $ Type Values

