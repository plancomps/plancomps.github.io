
module Funcons.Parser (Funcons.Parser.parse) where

import Text.ParserCombinators.Parsec
import Text.ParserCombinators.Parsec.Language (haskellDef)
import qualified Text.ParserCombinators.Parsec.Token as P

import Control.Applicative hiding ((<|>))
import qualified Data.Map as M
import qualified Data.Set as S
import qualified Data.Vector as V
import qualified Data.BitVector as BV
import Data.Char (isAlpha, isDigit)
import Data.List (intercalate)
import Data.Ratio
import Numeric

import Funcons.Lexer
import Funcons.Types

pFuncons :: Parser Funcons
pFuncons = 
        ListNotation    <$> brackets    (commaSep pFuncons)
    <|> try (MapNotation<$> braces      (commaSep pKeyValue))
    <|> SetNotation     <$> braces      (commaSep pFuncons)
    <|> TupleNotation   <$> parens      (commaSep pFuncons)
    <|> Value           <$> pValues
    <|> maybe_apply     <$> identifier <*> optionMaybe pFuncons
 where  maybe_apply :: Name -> Maybe Funcons -> Funcons
        maybe_apply nm mf = case mf of 
                            Nothing     -> FunconName nm
                            Just arg    -> FunconApp nm arg

        pKeyValue :: Parser Funcons
        pKeyValue = (\x y -> TupleNotation [x,y]) <$> pFuncons <* reservedOp "|->" <*> pFuncons

pValues :: Parser Values 
pValues =
        Atom <$ reserved "atom" <*> parens (many1 alphaNum)
    <|> Char <$ char '\'' <*> anyChar <* char '\'' 
    <|> String <$> stringLiteral 
    <|> ID . ID' <$ (reserved "id" <|> reserved "meta") <*> parens pValues
    <|> Tuple [] <$ reserved "void" 
    <|> Vector . V.fromList <$ reserved "vector" <*> parens (sepBy pValues comma)
    <|> List [] <$ reserved "nil"
    <|> String "\n" <$ reserved "newline" 
    <|> int_ . (0-) . readInt <$ char '-' <*> (many1 digit) 
    <|> nat_ . readInt <$> (many1 digit) 
    <|> mk_rationals . readRational
            <$> ((\m l -> m ++ "." ++ l) <$> many1 (satisfy isDigit) <* period <*>
                                             many1 (satisfy isDigit))
    <|> Type <$> pTypes
  where readInt :: String -> Int
        readInt = read 

pTypes :: Parser Types
pTypes =
        Chars    <$ reserved "chars"
    <|> Integers <$ reserved "integers"
    <|> Booleans <$ reserved "booleans" 
    <|> Strings <$ reserved "strings"
    <|> reserved "depends" *> parens (Depends <$> pFuncons <* char ',' <*> pFuncons)
    <|> reserved "forall" *> parens (ForallType <$> pValues <* char ',' <*> pFuncons)
    <|> Typevar <$ reserved "typevar" <*> parens pValues
    <|> reserved "type_abs" *> parens (Type_Abs <$> pFuncons <* char ',' <*> pFuncons) 
    <|> Values <$ reserved "values" 
    <|> Unknown <$ reserved "unknown"

readRational :: String -> Rational
readRational = fst . head . readFloat

--------
parse :: FilePath -> String -> Funcons
parse = parser pFuncons

parser :: Parser a -> FilePath -> String -> a 
parser p fp str = case Text.ParserCombinators.Parsec.parse p fp str of
                    Left err -> error (show err)
                    Right a  -> a

reader :: Parser a -> FilePath -> String -> [(a, String)]
reader p fp str = [(parser p fp str, "")]

instance Read Funcons where
    readsPrec d str = reader pFuncons "" str

instance Read Values where
    readsPrec d str = reader pValues "" str
