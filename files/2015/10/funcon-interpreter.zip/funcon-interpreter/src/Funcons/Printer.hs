
module Funcons.Printer where

import Data.List (intercalate)
import qualified Data.Map as M
import qualified Data.Set as S
import qualified Data.Vector as V
import qualified Data.BitVector as BV

import Funcons.Types
import Funcons.RunOptions

instance Show Funcons where
    show f = ppFuncons defaultRunOptions f

instance Show Values where
    show v = ppValues defaultRunOptions v 

ppFuncons :: RunOptions -> Funcons -> String
ppFuncons opts (ListNotation fs)    = "[" ++ showArgs opts False fs ++ "]"
ppFuncons opts (TupleNotation fs)   = "(" ++ showArgs opts False fs ++ ")"
ppFuncons opts (SetNotation fs)     = "{" ++ showArgs opts False fs ++ "}"
ppFuncons opts (MapNotation fs)     = "{" ++ intercalate "," (map toKeyValue fs) ++ "}"
 where  toKeyValue (TupleNotation [k,v]) = ppFuncons opts k ++ " |-> " ++ ppFuncons opts v
        toKeyValue _ = error "pretty-print map"
ppFuncons opts (Value v)            = ppValues opts v
ppFuncons opts (FunconName nm)      = nm
ppFuncons opts (FunconApp nm f)     = nm ++ ppFuncons opts f 

ppValues :: RunOptions -> Values -> String
ppValues opts (ADT c (Tuple [])) = c
ppValues opts (ADT c args)       = c ++ ppValues opts args
ppValues _ (Atom c)       = "atom("++ c ++")"
ppValues _ (Ascii c)      = "`" ++ [toEnum c] ++ "`"
ppValues _ (Bool True)    = "true"
ppValues _ (Bool False)   = "false"
ppValues _ (Bits i)       = "bits(" ++ show (BV.size i)
                                        ++ ", " ++ show (BV.int i) ++ ")"
ppValues _ (Char c)       = show c
ppValues _ (Float f)      = show f
ppValues _ (ID (ID' (String s)))= "id(\"" ++ s ++ "\")"
ppValues _ (ID (ID' (Bool True)))  = "id(true)"
ppValues _ (ID (ID' (Bool False))) = "id(false)"
ppValues _ (ID (ID' (Int i)))   = "id(" ++ show i ++ ")"
ppValues _ (ID (ID' (Char c)))  = "id(char(" ++ show c ++ "))"
ppValues args (ID (ID' v)) = "id(" ++ ppValues args v ++ ")"
-- rationals
ppValues _ (IEEE_Float_32 f) = show f
ppValues _ (IEEE_Float_64 d) = show d
ppValues _ (Rational r)   = show r
ppValues _ (Int f)        = show f
ppValues _ (Nat f)        = show f
ppValues opts (List vs)      =   if Prelude.null vs
                                then "[]"
                                else "[" ++ showArgs opts False (map Value vs) ++ "]"
ppValues opts (Map m)        = if M.null m then "map-empty"
                               else "{" ++ key_values ++ "}"
 where key_values = intercalate ", " (map (\(k,v) -> ppValues opts k++" |-> "++ ppValues opts v)$ M.toList m)
ppValues opts (Nameid v i)   = "nameid(" ++ ppFuncons opts (Value v) ++ "," ++ ppFuncons opts (Value $ ID i) ++ ")"
ppValues opts (Set s)        = if S.size s == 0
                                then "{}"
                                else "{" ++ showArgs opts False (map Value (S.toList s)) ++ "}"
ppValues _ (String s)        = show s
ppValues opts (Thunk f)      = "thunk(" ++ ppFuncons opts f ++ ")"
ppValues opts (Tuple vals)   = showArgs opts True (map Value vals)
ppValues opts (Vector v) = showFn opts "vector" (map Value (V.toList v))
ppValues opts (Type t)   = ppTypes opts t

ppTypes :: RunOptions -> Types -> String
ppTypes _ (Booleans)      = "booleans"
ppTypes _ (Chars)      = "chars"
ppTypes opts (Depends t1 t2) = "depends(" ++ ppFuncons opts t1 ++ "," ++ ppFuncons opts t2 ++ ")"
ppTypes opts (ForallType v t) = "forall(" ++ ppFuncons opts (Value v) ++ "," ++ ppFuncons opts t ++ ")"
ppTypes _ (Integers)          = "integers"
ppTypes _ (Strings)       = "strings"
ppTypes opts (Typevar t)     = "typevar(" ++ ppValues opts t ++ ")"
ppTypes opts (Type_Abs x y)     = "type_abs(" ++ ppFuncons opts x ++ ","++ ppFuncons opts y++ ")"
ppTypes _ (Unknown)       = "unknown"
ppTypes _ (Values)        = "values"

-- helpers

showFn :: RunOptions -> String -> [Funcons] -> String
showFn opts n xs = n ++ showArgs opts True xs

showArgs :: RunOptions -> Bool -> [Funcons] -> String
showArgs opts b args | b         = "(" ++ seq ++ ")"
                     | otherwise = seq
 where seq = intercalate "," (map (ppFuncons opts) args)

