
module Funcons.Core.Computations.DataFlow.Binding.Scope where

import qualified Data.Map as M

import Funcons.EDSL
import Funcons.Core.Computations.DataFlow.Binding.Environment

library = libFromList [
        ("scope", LazyFuncon stepScope)
    ]

scope :: Funcons -> Funcons -> Funcons
scope x y = FunconApp "scope" $ TupleNotation [x,y]

stepScope :: [Funcons] -> StepRes 
stepScope [fm, fx] 
    | isMap fm && isVal fx = afterStep fx
    | isMap fm && hasStep fx =
        let Value (Map m) = fm
        in do   Map e  <- get_environment
                with_environment (Map $ M.union m e) $ do
                    premiseStep (scope fm) fx  
    | isVal fm = exception (scope fm fx)  "first argument of scope is not of sort envs"
    | hasStep fm = congruence1_2 scope fm fx
    | otherwise = norule (scope fm fx)

