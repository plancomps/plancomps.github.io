module Funcons.Core.Library (library) where
import Funcons.EDSL
import qualified Funcons.Core.Computations.ControlFlow.Normal.Sequencing.LeftToRight
import qualified Funcons.Core.Computations.ControlFlow.Normal.Sequencing.Sequential
import qualified Funcons.Core.Computations.ControlFlow.Normal.Iterating.Indefinite.While
import qualified Funcons.Core.Computations.ControlFlow.Normal.Choosing.IfThenElse
import qualified Funcons.Core.Computations.ControlFlow.Abnormal.Stuck
import qualified Funcons.Core.Computations.ControlFlow.Abnormal.Throwing.Thrown
import qualified Funcons.Core.Computations.ControlFlow.Abnormal.Throwing.HandleThrown
import qualified Funcons.Core.Computations.ControlFlow.Abnormal.Throwing.Throw
import qualified Funcons.Core.Computations.ControlFlow.Abnormal.Failing.Fail
import qualified Funcons.Core.Computations.ControlFlow.Abnormal.Failing.Signals
import qualified Funcons.Core.Computations.ControlFlow.Abnormal.Failing.Failed
import qualified Funcons.Core.Computations.DataFlow.Interacting.Print
import qualified Funcons.Core.Computations.DataFlow.Interacting.StandardOut
import qualified Funcons.Core.Computations.DataFlow.Storing.Stores
import qualified Funcons.Core.Computations.DataFlow.Storing.SimpleVariables.StoredValue
import qualified Funcons.Core.Computations.DataFlow.Storing.SimpleVariables.StoreValue
import qualified Funcons.Core.Computations.DataFlow.Storing.SimpleVariables.AllocateInitialisedVariable
import qualified Funcons.Core.Computations.DataFlow.Storing.SimpleVariables.AllocateVariable
import qualified Funcons.Core.Computations.DataFlow.Storing.Variables
import qualified Funcons.Core.Computations.DataFlow.Giving.Given
import qualified Funcons.Core.Computations.DataFlow.Giving.Give
import qualified Funcons.Core.Computations.DataFlow.Giving.GivenValue
import qualified Funcons.Core.Computations.DataFlow.Generating.AtomGenerator
import qualified Funcons.Core.Computations.DataFlow.Generating.FreshAtom
import qualified Funcons.Core.Computations.DataFlow.Binding.Bound
import qualified Funcons.Core.Computations.DataFlow.Binding.Scope
import qualified Funcons.Core.Computations.DataFlow.Binding.Bind
import qualified Funcons.Core.Computations.DataFlow.Binding.Environment
import qualified Funcons.Core.Values.Composite.Collections.Maps
import qualified Funcons.Core.Values.Composite.Collections.Tuples
import qualified Funcons.Core.Values.Primitive.Strings
import qualified Funcons.Core.Values.Primitive.Numbers.Integers
import qualified Funcons.Core.Values.Primitive.Numbers.Rationals
import qualified Funcons.Core.Values.Primitive.Bool
library = libUnions
    [
     Funcons.Core.Computations.ControlFlow.Normal.Sequencing.LeftToRight.library
    , Funcons.Core.Computations.ControlFlow.Normal.Sequencing.Sequential.library
    , Funcons.Core.Computations.ControlFlow.Normal.Iterating.Indefinite.While.library
    , Funcons.Core.Computations.ControlFlow.Normal.Choosing.IfThenElse.library
    , Funcons.Core.Computations.ControlFlow.Abnormal.Stuck.library
    , Funcons.Core.Computations.ControlFlow.Abnormal.Throwing.Thrown.library
    , Funcons.Core.Computations.ControlFlow.Abnormal.Throwing.HandleThrown.library
    , Funcons.Core.Computations.ControlFlow.Abnormal.Throwing.Throw.library
    , Funcons.Core.Computations.ControlFlow.Abnormal.Failing.Fail.library
    , Funcons.Core.Computations.ControlFlow.Abnormal.Failing.Signals.library
    , Funcons.Core.Computations.ControlFlow.Abnormal.Failing.Failed.library
    , Funcons.Core.Computations.DataFlow.Interacting.Print.library
    , Funcons.Core.Computations.DataFlow.Interacting.StandardOut.library
    , Funcons.Core.Computations.DataFlow.Storing.Stores.library
    , Funcons.Core.Computations.DataFlow.Storing.SimpleVariables.StoredValue.library
    , Funcons.Core.Computations.DataFlow.Storing.SimpleVariables.StoreValue.library
    , Funcons.Core.Computations.DataFlow.Storing.SimpleVariables.AllocateInitialisedVariable.library
    , Funcons.Core.Computations.DataFlow.Storing.SimpleVariables.AllocateVariable.library
    , Funcons.Core.Computations.DataFlow.Storing.Variables.library
    , Funcons.Core.Computations.DataFlow.Giving.Given.library
    , Funcons.Core.Computations.DataFlow.Giving.Give.library
    , Funcons.Core.Computations.DataFlow.Giving.GivenValue.library
    , Funcons.Core.Computations.DataFlow.Generating.AtomGenerator.library
    , Funcons.Core.Computations.DataFlow.Generating.FreshAtom.library
    , Funcons.Core.Computations.DataFlow.Binding.Bound.library
    , Funcons.Core.Computations.DataFlow.Binding.Scope.library
    , Funcons.Core.Computations.DataFlow.Binding.Bind.library
    , Funcons.Core.Computations.DataFlow.Binding.Environment.library
    , Funcons.Core.Values.Composite.Collections.Maps.library
    , Funcons.Core.Values.Composite.Collections.Tuples.library
    , Funcons.Core.Values.Primitive.Strings.library
    , Funcons.Core.Values.Primitive.Numbers.Integers.library
    , Funcons.Core.Values.Primitive.Numbers.Rationals.library
    , Funcons.Core.Values.Primitive.Bool.library
    ]
