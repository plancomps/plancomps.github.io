
module Funcons.Core.Values.Composite.Collections.Maps where

import Funcons.EDSL
import qualified Data.Set as S
import qualified Data.Map as M

library = libFromList [
        ("map-unite", ValueOp map_unite_op)
    ]

map_unite_ = FunconApp "map-unite" . TupleNotation
map_unite_op :: Values -> StepRes
map_unite_op (Tuple vs) = unite_maps vs
map_unite_op (Map m) = afterRewrite $ Value $ Map m
map_unite_op vx = exception (map_unite_ [Value vx]) "map-unite not applied to a sequence of maps"

unite_maps vs 
  | not (all isMap vs) = exception (map_unite_ [tup vs]) "map-unite not applied to a sequence of maps"
  | otherwise = let maps = map toMap vs
                    domains = map (M.keysSet) maps
                in if S.null (foldr S.intersection S.empty domains)
                        then afterRewrite $ Value $ Map $ M.unions maps
                        else exception (map_unite_ [tup vs]) "map-unite not applied to maps with disjoint domains"
 where  toMap (Map m) = m 
        isMap (Map m) = True
        isMap _       = False

