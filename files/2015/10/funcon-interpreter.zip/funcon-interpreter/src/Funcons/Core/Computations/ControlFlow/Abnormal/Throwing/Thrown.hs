
module Funcons.Core.Computations.ControlFlow.Abnormal.Throwing.Thrown where

import Funcons.EDSL

library = libEmpty

raiseThrown = raiseSignal "thrown"
receiveThrown = receiveSignal "thrown"
