
module Funcons.Core.Computations.DataFlow.Binding.Bind where

import qualified Data.Map as M

import Funcons.EDSL

library = libFromList [ 
        ("bind", StrictFuncon stepBind)
    ]

bind_ = FunconApp "bind" . TupleNotation
stepBind :: Values -> StepRes
stepBind (Tuple [i, x])      = afterRewrite $ Value $ Map $ M.singleton i x
stepBind vx                  = exception (bind_ [Value vx]) "sort check: bind(I, v)"

