
module Funcons.Core.Values.Primitive.Bool where

import Funcons.EDSL

library = libFromList [
        ("true", NullaryFuncon (afterRewrite $ Value $ Bool True))
    ,   ("false", NullaryFuncon (afterRewrite $ Value $ Bool False))
    ,   ("not",  ValueOp stepNot)
    ]

not_ = FunconApp "not" . TupleNotation

stepNot :: Values -> StepRes
stepNot (Bool b) = afterRewrite $ Value $ Bool $ not b
stepNot v        = exception (not_ [Value v]) "not applied to a non-Boolean"


