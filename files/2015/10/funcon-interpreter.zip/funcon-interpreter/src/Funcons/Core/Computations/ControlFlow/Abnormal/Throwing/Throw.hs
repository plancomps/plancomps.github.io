
module Funcons.Core.Computations.ControlFlow.Abnormal.Throwing.Throw where

import Funcons.EDSL
import Funcons.Core.Computations.ControlFlow.Abnormal.Throwing.Thrown
import Funcons.Core.Computations.ControlFlow.Abnormal.Stuck

library = libFromList [
    ("throw", StrictFuncon stepThrow)
    ]

stepThrow :: Values -> StepRes
stepThrow x = raiseThrown x >> afterStep stuck 

throw x = throw' [x]
throw' xs = FunconApp "throw" $ TupleNotation xs
