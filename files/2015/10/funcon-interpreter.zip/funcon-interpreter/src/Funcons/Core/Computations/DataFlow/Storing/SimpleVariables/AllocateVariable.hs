
module Funcons.Core.Computations.DataFlow.Storing.SimpleVariables.AllocateVariable where

import Funcons.EDSL
import Funcons.Core.Computations.DataFlow.Generating.FreshAtom
import Funcons.Core.Computations.DataFlow.Storing.Stores
import Funcons.Core.Computations.DataFlow.Storing.Variables
import Funcons.Core.Computations.DataFlow.Generating.AtomGenerator

import qualified Data.Map as M

library = libFromList [
        ("allocate-variable", StrictFuncon stepAllocate_Variable) 
    ]

allocate_variable t = allocate_variable_ [t]
allocate_variable_ = FunconApp "allocate-variable" . TupleNotation
stepAllocate_Variable :: Values -> StepRes
stepAllocate_Variable t@(Type _) =
    do  Value k <- premiseStep id fresh_atom 
        Map sigma <- get_store
        let var = variable k t
        put_store (Map $ M.insert var uninitialised sigma)
        afterStep $ Value var
stepAllocate_Variable v = exception (allocate_variable_ [Value v]) "allocate-variable not applied to type"


