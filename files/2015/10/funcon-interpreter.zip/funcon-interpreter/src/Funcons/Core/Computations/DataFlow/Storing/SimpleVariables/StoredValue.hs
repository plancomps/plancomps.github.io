
module Funcons.Core.Computations.DataFlow.Storing.SimpleVariables.StoredValue where

import Prelude hiding (fail)

import Funcons.EDSL
import Funcons.Core.Computations.DataFlow.Storing.Stores
import Funcons.Core.Computations.ControlFlow.Abnormal.Failing.Fail

import qualified Data.Map as M
import qualified Data.Set as S

library = libFromList [
        ("stored-value", StrictFuncon stepStored_Value)
    ]

stored_value = FunconApp "stored-value" . TupleNotation
stepStored_Value :: Values -> StepRes
stepStored_Value var@(ADT "variable" t) =
    do  Map sigma <- get_store
        if var `S.member` M.keysSet sigma
            then -- TODO type-checking val : t
                 let val = sigma M.! var
                 in if val == uninitialised
                        then afterStep fail
                        else afterStep $ Value val
            else afterStep fail
stepStored_Value v = exception (stored_value [Value v]) "stored-value not applied to variable"

