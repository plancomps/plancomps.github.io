
module Funcons.Core.Computations.DataFlow.Generating.AtomGenerator where

import Funcons.EDSL

library = libEmpty

get_atom_generator = getMUT "atom-generator" (Atom "0")
put_atom_generator = putMUT "atom-generator"
