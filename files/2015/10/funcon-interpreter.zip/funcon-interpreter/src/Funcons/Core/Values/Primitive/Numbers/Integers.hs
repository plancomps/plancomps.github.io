
module Funcons.Core.Values.Primitive.Numbers.Integers where

import Funcons.EDSL

library = libFromList [
        ("integer-add", ValueOp integer_add_op)
    ,   ("integer-multiply", ValueOp integer_multiply_op)
    ,   ("integer-divide", ValueOp integer_divide_op)
    ,   ("integer-negate", ValueOp integer_negate_op)
    ]

integer_op :: String -> ([Funcons] -> Funcons)
                     -> (Integer -> Integer -> Integer) -> Integer -> [Values] -> StepRes
integer_op str cons f b vs | all isInt vs = afterRewrite $ q_ $ foldr f b $ map toInt vs
                           | otherwise = exception (cons (map Value vs)) err
    where   isInt v | Int _ <- upcastIntegers v = True
                    | otherwise = False
            toInt v | Int i <- upcastIntegers v = i
                    | otherwise = error err
            err     = str ++ " not applied to integers"

integer_add_ = FunconApp "integer-add" . TupleNotation
integer_add_op :: Values -> StepRes
integer_add_op (Tuple vs) = integer_op "integer-add" integer_add_ (+) 0 vs
integer_add_op v = integer_add_op $ Tuple [v]

integer_multiply_ = FunconApp "integer-multiple" . TupleNotation
integer_multiply_op (Tuple vs) = integer_op "integer-multiply" integer_multiply_ (*) 1 vs
integer_multiply_op v = integer_multiply_op $ Tuple [v]

integer_divide_ = FunconApp "integer-divide" . TupleNotation
integer_divide_op (Tuple [vx,vy]) 
    | (Int x,Int y) <- (upcastIntegers vx, upcastIntegers vy) = afterRewrite $ q_ (x `div` y)
    | True = exception (integer_divide_ [Value vx, Value vy]) "integer-divide not applied to ints" 
integer_divide_op vx = exception (integer_divide_ [Value vx]) "integer-divide not applied to two arguments" 

integer_negate_ = FunconApp "integer-negate" . TupleNotation
integer_negate_op vx
    | (Int x) <- upcastIntegers vx = afterRewrite $ q_ (-x)
    | otherwise = exception (integer_negate_ [Value vx]) "integer-negate not applied to integer"


