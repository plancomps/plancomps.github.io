
module Funcons.Core.Computations.ControlFlow.Abnormal.Failing.Signals where

import Funcons.EDSL

library = libFromList [ ("signal", NullaryFuncon (afterRewrite $ Value signal)) ]

signal = ADT "signal" (Tuple [])
