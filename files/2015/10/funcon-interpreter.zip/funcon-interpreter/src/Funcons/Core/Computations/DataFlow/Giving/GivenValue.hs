
module Funcons.Core.Computations.DataFlow.Giving.GivenValue where

import Funcons.EDSL

getGiven_Value = getINH "given-value" empty_tuple 
withGiven_Value = withINH "given-value"

library = libEmpty 
