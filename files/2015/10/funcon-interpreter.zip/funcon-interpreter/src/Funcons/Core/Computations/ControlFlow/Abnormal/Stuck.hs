
module Funcons.Core.Computations.ControlFlow.Abnormal.Stuck where

import Funcons.EDSL
 
stuck = FunconName "stuck"
library = libFromList [("stuck", NullaryFuncon (norule stuck))]
