
module Funcons.Core.Computations.DataFlow.Giving.Given where

import Funcons.EDSL
import Funcons.Core.Computations.DataFlow.Giving.GivenValue

library = libFromList [
    ("given", NullaryFuncon stepGiven)
    ]

given{-,given1,given2.given3-} :: Funcons
given = FunconName "given"

{-
given1 = FunconName "given1"
given2 = FunconName "given2"
given3 = FunconName "given3"
-}
stepGiven :: StepRes 
stepGiven  = do   ge <- getGiven_Value
                  afterStep (Value ge)

{-
stepGiven1 :: [Funcons] -> Funcons
stepGiven1 [] = afterRewrite $ nth given (q 1)
stepGiven1 _ = sortErr given "given1 applied to arguments"
 -}
