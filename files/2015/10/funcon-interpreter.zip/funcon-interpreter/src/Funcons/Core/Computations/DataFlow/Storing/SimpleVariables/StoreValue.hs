
module Funcons.Core.Computations.DataFlow.Storing.SimpleVariables.StoreValue where

import Prelude hiding (fail)

import Funcons.EDSL
import Funcons.Core.Computations.DataFlow.Storing.Stores
import Funcons.Core.Computations.ControlFlow.Abnormal.Failing.Fail

import qualified Data.Map as M
import qualified Data.Set as S

library = libFromList [
        ("store-value", StrictFuncon stepStore_Value)
    ]

store_value var val = FunconApp "store-value" $ TupleNotation [var,val]
store_value_ = FunconApp "store-value" . TupleNotation
stepStore_Value :: Values -> StepRes
stepStore_Value (Tuple [var@(ADT "variable" t), val]) =
    do  Map sigma <- get_store
        if var `S.member` M.keysSet sigma
            then -- TODO type-checking val : t
                 do put_store (Map $ M.insert var val sigma)
                    afterStep (Value empty_tuple)
            else afterStep fail
stepStore_Value v = exception (store_value_ [Value v]) "store-value not applied to variable and a value"

