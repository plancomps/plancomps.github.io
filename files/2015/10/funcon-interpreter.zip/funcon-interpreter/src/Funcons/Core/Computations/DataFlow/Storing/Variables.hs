
module Funcons.Core.Computations.DataFlow.Storing.Variables where

import Funcons.EDSL

library = libFromList [ ("variable", StrictFuncon stepVariable) ]

variable :: Values -> Values -> Values
variable a t = ADT "variable" $ Tuple [a, t]

variable_ = FunconApp "variable" . TupleNotation
stepVariable :: Values -> StepRes
stepVariable (Tuple [a,t]) = afterRewrite $ Value (variable a t)
stepVariable v = exception (variable_ [Value v]) "variable not applied to an atom and a type"
