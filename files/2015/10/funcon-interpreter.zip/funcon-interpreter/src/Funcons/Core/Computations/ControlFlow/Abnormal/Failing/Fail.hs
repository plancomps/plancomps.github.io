
module Funcons.Core.Computations.ControlFlow.Abnormal.Failing.Fail where

import Funcons.EDSL
import Funcons.Core.Computations.ControlFlow.Abnormal.Failing.Failed
import Funcons.Core.Computations.ControlFlow.Abnormal.Failing.Signals
import Funcons.Core.Computations.ControlFlow.Abnormal.Stuck

library = libFromList [
        ("fail", NullaryFuncon stepFail) 
    ]

fail = FunconName "fail" 
stepFail = raise_failed signal >> afterStep stuck
