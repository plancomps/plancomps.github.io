
module Funcons.Core.Computations.ControlFlow.Abnormal.Failing.Failed where

import Funcons.EDSL

library = libEmpty

raise_failed f = raiseSignal "failed" f
receive_failed = receiveSignal "failed"
