
module Funcons.Core.Computations.ControlFlow.Normal.Iterating.Indefinite.While where

import Funcons.EDSL
import Funcons.Core.Computations.ControlFlow.Normal.Choosing.IfThenElse
import Funcons.Core.Computations.ControlFlow.Normal.Sequencing.Sequential

library = libFromList [
        ("while", LazyFuncon stepWhile) 
    ]

while x y = FunconApp "while" (TupleNotation [x,y])
stepWhile [b, c] = afterRewrite $ if_then_else b (sequential_ [c, while b c]) (Value empty_tuple)

