
module Funcons.Core.Computations.DataFlow.Giving.Give where

import Funcons.EDSL
import Funcons.Core.Computations.DataFlow.Giving.GivenValue

library = libFromList [
    ("give", LazyFuncon stepGive)
    ]

stepGive :: [Funcons] -> StepRes 
stepGive [fx,fy]| isVal fx && hasStep fy =
                    let Value x = fx
                    in withGiven_Value x (premiseStep (give fx) fy)
                | isVal fx && isVal fy = afterRewrite fy
                | hasStep fx = congruence1_2 give fx fy
                | otherwise = norule (give fx fy)
stepGive vs = sortErr (give_ vs) "give applied to incorrect number of arguments"

give :: Funcons -> Funcons -> Funcons
give x y = give_ [x,y]

give_ :: [Funcons] -> Funcons
give_ = FunconApp "give" . TupleNotation
