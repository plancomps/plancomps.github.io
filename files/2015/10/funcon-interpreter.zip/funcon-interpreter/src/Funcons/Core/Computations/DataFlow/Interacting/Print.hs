
module Funcons.Core.Computations.DataFlow.Interacting.Print where

import Funcons.EDSL
import Funcons.Core.Computations.DataFlow.Interacting.StandardOut

library :: FunconLibrary
library = libFromList [
    ("print", StrictFuncon stepPrint) 
    ]  

stepPrint :: Values -> StepRes
stepPrint v = standard_out v >> afterStep (Value empty_tuple)     

print :: Funcons -> Funcons
print = FunconApp "print"
