
module Funcons.Core.Computations.DataFlow.Storing.SimpleVariables.AllocateInitialisedVariable where

import Funcons.EDSL
import Funcons.Core.Computations.DataFlow.Giving.Give
import Funcons.Core.Computations.DataFlow.Giving.Given
import Funcons.Core.Computations.DataFlow.Storing.SimpleVariables.StoreValue
import Funcons.Core.Computations.DataFlow.Storing.SimpleVariables.AllocateVariable
import Funcons.Core.Computations.ControlFlow.Normal.Sequencing.Sequential

library = libFromList [
        ("allocate-initialised-variable", StrictFuncon stepAllocate_Initialised_Variable)
    ]

allocate_initialised_variable_ = FunconApp "allocate-initalised-variable" . TupleNotation
stepAllocate_Initialised_Variable :: Values -> StepRes 
stepAllocate_Initialised_Variable (Tuple [t, v]) =
    afterRewrite $ give  (allocate_variable (Value t))
                    (sequential_ [store_value given (Value v), given])
stepAllocate_Initialised_Variable v = exception (allocate_initialised_variable_ [Value v]) "sort check: allocate-initalised-variable(T:types,V:T)"

