
module Funcons.Core.Computations.ControlFlow.Abnormal.Throwing.HandleThrown where

import Funcons.EDSL
import Funcons.Core.Computations.DataFlow.Giving.Give
import Funcons.Core.Computations.ControlFlow.Abnormal.Throwing.Thrown

library :: FunconLibrary
library = libFromList [
    ("handle-thrown", LazyFuncon (\[e, h] -> stepHandleThrown e h) )
    ]  

stepHandleThrown :: Funcons -> Funcons -> StepRes
stepHandleThrown x y 
    | isVal x   = afterStep x
    | hasStep x = do    (x',t) <- receiveThrown (premiseStep cons x)
                        case t of
                          Nothing -> afterStep (cons x')
                          Just e  -> afterStep (give (Value e) y)
    | otherwise = norule (cons x)
 where cons x' = handle_thrown x' y

handle_thrown :: Funcons -> Funcons -> Funcons
handle_thrown e h = handle_thrown_ [e,h]

handle_thrown_ :: [Funcons] -> Funcons
handle_thrown_ fs = FunconApp "handle-thrown" (TupleNotation fs)
