
module Funcons.Core.Values.Primitive.Numbers.Rationals where

import Funcons.EDSL

library = libFromList [
        ("is-less", ValueOp is_less_op)
    ,   ("is-less-or-equal", ValueOp is_less_or_equal_op)
    ,   ("is-greater", ValueOp is_greater_op)
    ,   ("is-greater-or-equal", ValueOp is_greater_or_equal_op)
    ]

is_less_ = FunconApp "is-less" . TupleNotation
is_less_op (Tuple [vx, vy])
    | (Rational x, Rational y) <- (upcastRationals vx, upcastRationals vy)
        = afterStep $ Value $ Bool (x < y)
    | otherwise = exception (is_less_ [Value vx,Value vy]) "is-less not applied to rationals"
is_less_op vx = exception (is_less_ [Value vx]) "is-less not applied to two arguments"

is_less_or_equal_ = FunconApp "is-less-or-equal" . TupleNotation
is_less_or_equal_op (Tuple [vx, vy])
    | (Rational x, Rational y) <- (upcastRationals vx, upcastRationals vy)
        = afterStep $ bool (x <= y)
    | otherwise = exception (is_less_or_equal_ [Value vx, Value vy]) "is-less-or-equal not applied to rationals"
is_less_or_equal_op vx = exception (is_less_or_equal_ [Value vx]) "is_less_or_equal not applied to two arguments"

is_greater_ = FunconApp "is-greater" . TupleNotation
is_greater_op (Tuple [vx, vy])
    | (Rational x, Rational y) <- (upcastRationals vx, upcastRationals vy)
        = afterStep $ bool (x > y)
    | otherwise = exception (is_greater_ [Value vx, Value vy]) "is-greater not applied to rationals"
is_greater_op vx = exception (is_greater_ [Value vx]) "is-greater not applied to two arguments"

is_greater_or_equal_ = FunconApp "is-greater-or-equal" . TupleNotation
is_greater_or_equal_op (Tuple [vx, vy])
    | (Rational x, Rational y) <- (upcastRationals vx, upcastRationals vy)
        = afterStep $ bool (x >= y)
    | otherwise = exception (is_greater_or_equal_ [Value vx, Value vy]) "is-greater-or-equal not applied to rationals"
is_greater_or_equal_op vx = exception (is_greater_or_equal_ [Value vx]) "is-greater-or-equal not applied to two arguments"


