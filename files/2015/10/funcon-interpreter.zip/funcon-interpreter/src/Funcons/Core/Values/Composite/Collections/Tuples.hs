
module Funcons.Core.Values.Composite.Collections.Tuples where

import Funcons.EDSL

library = libFromList [
        ("discard-empty-tuples", ValueOp discard_empty_tuples_op)
    ]

discard_empty_tuples_ = FunconApp "discard-empty-tuples" . TupleNotation
discard_empty_tuples_op (Tuple vs) = afterRewrite $ Value $ tuple_val (filter (/= Tuple []) vs)
discard_empty_tuples_op v          = afterRewrite $ Value v

