
module Funcons.Core.Computations.DataFlow.Storing.Stores where

import Funcons.EDSL

import qualified Data.Map as M

library = libFromList [("uninitialised", NullaryFuncon (afterRewrite $ Value uninitialised))]

get_store = getMUT "store" (Map M.empty)
put_store s = putMUT "store" s

uninitialised = ADT "uninitialised" (Tuple []) 
