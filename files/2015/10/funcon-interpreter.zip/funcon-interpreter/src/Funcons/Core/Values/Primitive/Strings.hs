
module Funcons.Core.Values.Primitive.Strings where

import Funcons.EDSL

library = libFromList [
        ("decimal-natural", ValueOp decimal_natural_op) 
    ]

decimal_natural_ = FunconApp "decimal-natural" . TupleNotation
decimal_natural_op (String s) = afterRewrite $ Value $ nat_ (read s)
decimal_natural_op vx = exception (decimal_natural_ [Value vx]) "decimal-natural not applied to strings"
