
module Funcons.Core.Computations.DataFlow.Interacting.StandardOut where

import Funcons.EDSL

library = libEmpty

standard_out :: Values -> MSOS ()
standard_out = writeOUT "standard-in" 
