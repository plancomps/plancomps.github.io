
module Funcons.Core.Computations.DataFlow.Binding.Bound where

import Prelude hiding (fail)
import qualified Data.Map as M

import Funcons.EDSL
import Funcons.Core.Computations.ControlFlow.Abnormal.Failing.Fail
import Funcons.Core.Computations.DataFlow.Binding.Environment

library = libFromList [
        ("bound", StrictFuncon stepBound) 
    ]

stepBound :: Values -> StepRes
stepBound i = do    Map rho <- get_environment
                    case M.lookup i rho of
                        Nothing -> afterStep fail
                        Just v  -> afterStep $ Value v

