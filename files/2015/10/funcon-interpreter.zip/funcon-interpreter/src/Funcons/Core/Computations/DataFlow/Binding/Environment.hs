
module Funcons.Core.Computations.DataFlow.Binding.Environment where

import qualified Data.Map as M

import Funcons.EDSL

library = libEmpty

get_environment = getINH "environment" (Map M.empty)
with_environment = withINH "environment" 

