
module Funcons.Core.Computations.ControlFlow.Normal.Sequencing.Sequential where

import Funcons.EDSL
import Funcons.Core.Computations.ControlFlow.Normal.Sequencing.LeftToRight
import Funcons.Core.Values.Composite.Collections.Tuples

library = libFromList [
        ("sequential", LazyFuncon stepSequential) 
    ]

sequential_ = FunconApp "sequential" . TupleNotation
stepSequential v = afterRewrite $ discard_empty_tuples_ [left_to_right_ v]
