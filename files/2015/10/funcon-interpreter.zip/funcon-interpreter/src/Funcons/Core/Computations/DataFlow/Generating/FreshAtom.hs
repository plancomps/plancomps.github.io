
module Funcons.Core.Computations.DataFlow.Generating.FreshAtom 
        (library, fresh_atom) where

import Funcons.EDSL
import Funcons.Core.Computations.DataFlow.Generating.AtomGenerator hiding (library)

library = libFromList [
        ("fresh-atom", NullaryFuncon stepFreshAtom)
    ]

fresh_atom = FunconName "fresh-atom"
stepFreshAtom :: StepRes
stepFreshAtom = do  k <- get_atom_generator
                    put_atom_generator (next_atom k)
                    afterStep (Value k)
                    
next_atom (Atom k) = Atom (show (k'+1))
 where  k' :: Int
        k' = read k
