
module Funcons.Core.Computations.ControlFlow.Normal.Sequencing.LeftToRight where

import Funcons.EDSL

library = libFromList [
        ("left-to-right", LazyFuncon stepLeft_To_Right)
    ]   


left_to_right_ = FunconApp "left-to-right" . TupleNotation

stepLeft_To_Right :: [Funcons] -> StepRes
stepLeft_To_Right fs =
    let (vals,comps) = span isVal fs
     in case comps of
          []   -> afterStep (Value (tuple_val (map funconValue vals)))
          x:xs -> premiseStep (\x' -> (left_to_right_ (vals ++ x':xs))) x

