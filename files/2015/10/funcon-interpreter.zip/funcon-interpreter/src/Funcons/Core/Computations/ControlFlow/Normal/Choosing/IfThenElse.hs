
module Funcons.Core.Computations.ControlFlow.Normal.Choosing.IfThenElse where

import Funcons.EDSL

library = libFromList [
        ("if-then-else", LazyFuncon stepIf_Then_Else)
    ]

if_then_else x y z = FunconApp "if-then-else" (TupleNotation [x,y,z])

stepIf_Then_Else [fx, fy, fz] 
    | isBool fx = let Value (Bool x) = fx
                   in case x of
                      True -> afterRewrite fy
                      False -> afterRewrite fz
    | isVal fx  = exception (if_then_else fx fy fz)
                                        "first arg of if_true is not boolean"
    | hasStep fx = congruence1_3 if_then_else fx fy fz
    | otherwise  = norule (if_then_else fx fy fz)


