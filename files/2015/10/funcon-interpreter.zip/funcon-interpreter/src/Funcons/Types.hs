
module Funcons.Types where

import qualified Data.Map as M
import qualified Data.Set as S
import qualified Data.Vector as V
import qualified Data.BitVector as BV
import Data.Text (Text, pack, unpack)
import Data.Ratio

----
type Key    = Text 
type Name   = String

name2key = pack
key2name = unpack

----
data Funcons    = FunconName Name
                | FunconApp Name Funcons
                | Value Values
                | TupleNotation [Funcons]
                | ListNotation [Funcons]
                | SetNotation [Funcons]
                | MapNotation [Funcons]
                deriving (Eq, Ord) 

data Values     = ADT String Values 
                | Ascii Int
                | Atom String
                | Bits BV.BitVector
                | Bool Bool
                | Char Char
                | Float Float
                | ID ID
                | List [Values]
                | Map Map
                | Nameid Values ID
                | Set Set
                | String String
                | Thunk Funcons
                | Tuple [Values]
                | Type Types
                | Vector Vectors
                -- rationals
                | IEEE_Float_32 Float
                | IEEE_Float_64 Double
                | Rational Rational
                | Int Prelude.Integer
                | Nat Prelude.Integer
        deriving (Eq,Ord)

type Map        = M.Map Values Values
type Set        = S.Set Values
type Vectors    = V.Vector Values

--- types
data Types      = Booleans
                | Chars
                | Depends Funcons Funcons
                | ForallType Values Funcons -- lists(typevars) x types
                | Integers
                | Strings
                | Values
                | Typevar Values
                | Type_Abs Funcons Funcons
                | Unknown
        deriving (Ord,Eq)

-- Ids
newtype ID = ID' Values
    deriving (Eq)

instance Ord ID where
    (ID' v1) `compare` (ID' v2) = idCompare v1 v2

idCompare :: Values -> Values -> Ordering
(Int i1)    `idCompare` (Int i2)     = compare i1 i2
(Int i1)    `idCompare` _            = LT
_           `idCompare` (Int i2)    = GT
(Bool b)    `idCompare` (Bool b2)   = compare b b2
(Bool b)    `idCompare` _           = LT
_           `idCompare` (Bool _)    = GT
(String s)  `idCompare` (String s2) = compare s s2
_           `idCompare` _           = error "comparing non-atomic ids"

-- Values should be atoms: Ints,Booleans,Strings,Tuples? etc
id_ :: Funcons -> Funcons
id_ (Value v@(Int _))    = Value (ID (ID' v))
id_ (Value v@(Bool _))   = Value (ID (ID' v))
id_ (Value v@(String _)) = Value (ID (ID' v))
id_ v = error $ "id supplied with non-atomic value"

--- smart constructors for values
int_ :: Int -> Values
int_ = mk_integers . toInteger

nat_ :: Int -> Values
nat_ = mk_naturals . toInteger

atom :: String -> Funcons
atom = Value . Atom

empty_tuple :: Values
empty_tuple = Tuple []

q :: Int -> Funcons
q = Value . int_
q_ = Value . mk_integers

r :: Rational -> Funcons
r = Value . mk_rationals

s :: String -> Funcons
s = Value . String

false,true :: Funcons
false = Value (Bool False)
true = Value (Bool True)

nil :: Values
nil = List []

void ::  Funcons
void = Value empty_tuple

tup :: [Values] -> Funcons
tup = Value . tuple_val 

type_ :: Types -> Funcons
type_ = Value . Type

vec :: V.Vector (Values) -> Funcons
vec = Value . Vector

bool :: Bool -> Funcons
bool = Value . Bool

idval :: Values -> Values
idval = ID . ID'

tuple_val :: [Values] -> Values
tuple_val [v] = v
tuple_val vs  = Tuple vs

tuple_unval :: Values -> [Funcons]
tuple_unval (Tuple vs) = map Value vs
tuple_unval v = [Value v]

listval :: [Values] -> Funcons
listval = Value . List

setval :: [Values] -> Funcons
setval = Value . Set . S.fromList

mapval :: [Values] -> Funcons
mapval = Value . Map . M.fromList . map toKeyValue
 where  toKeyValue (Tuple [k,v]) = (k,v)
        toKeyValue _ = error "mapval"

-- subtyping rationals
mk_rationals :: Rational -> Values
mk_rationals r  | denominator r == 1 = mk_integers (numerator r)
                | otherwise             = Rational r

mk_integers :: Integer -> Values
mk_integers i   | i >= 0    = mk_naturals i
                | otherwise = Int i

mk_naturals :: Integer -> Values
mk_naturals = Nat

upcastRationals :: Values -> Values
upcastRationals (Nat n) = Rational (toRational n)
upcastRationals (Int i) = Rational (toRational i)
upcastRationals v       = v

upcastIntegers :: Values -> Values
upcastIntegers (Nat n)  = Int n
upcastIntegers v        = v

upcastNaturals :: Values -> Values
upcastNaturals v = v


