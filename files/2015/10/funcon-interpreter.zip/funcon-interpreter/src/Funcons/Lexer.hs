module Funcons.Lexer where

import Text.ParserCombinators.Parsec
import Text.ParserCombinators.Parsec.Language (emptyDef)
import qualified Text.ParserCombinators.Parsec.Token as P

lexer = P.makeTokenParser emptyDef  { P.identStart  = letter
                                    , P.identLetter = alphaNum <|> (char '-')
                                    , P.reservedNames = [ "chars", "strings", "booleans", "integers", "atom", "meta", "id", "void", "newline", "depends", "forall", "type_abs", "values", "unknown", "typevar", "vector"]
                                    , P.reservedOpNames = ["|->"]
                                    }

parens          = P.parens lexer 
brackets        = P.brackets lexer
braces          = P.braces lexer
identifier      = P.identifier lexer
natural         = P.natural lexer
reserved        = P.reserved lexer
reservedOp      = P.reservedOp lexer
comma           = P.comma lexer
stringLiteral   = P.stringLiteral lexer
period          = P.dot lexer
commaSep        = P.commaSep lexer
