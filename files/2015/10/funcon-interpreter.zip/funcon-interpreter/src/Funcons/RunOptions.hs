
module Funcons.RunOptions where

data RunOptions = RunOptions{do_refocus :: Bool
                            ,max_steps :: Maybe Int
                            ,do_abrupt_terminate :: Bool
                            ,pp_full_environments :: Bool
                            ,show_result :: Bool
                            ,show_mutable :: [String]
                            ,show_control :: [String]
                            ,show_output  :: [String]
                            ,show_counts  :: Bool
                            }
defaultRunOptions = RunOptions{  do_refocus = False
                                ,max_steps =  Nothing
                                ,do_abrupt_terminate = True
                                ,pp_full_environments = False
                                ,show_result = True
                                ,show_mutable = []
                                ,show_control = []
                                ,show_output = []
                                ,show_counts = False
                                }

run_options :: [String] -> (RunOptions, [String])
run_options = fold (defaultRunOptions, [])
 where  fold (opts,rest) ("--refocus":args) = 
            fold (opts{do_refocus = True}, rest) args
        fold (opts,rest) ("--full-environments":args) = 
            fold (opts{pp_full_environments = True}, rest) args
        fold (opts,rest) ("--hide-result":args) = 
            fold (opts{show_result = False}, rest) args
        fold (opts,rest) ("--display-steps":args) = 
            fold (opts{show_counts = True},rest) args

        -- options with argument
        fold (opts,rest) ("--display-mutable-entity":(entity:args)) = 
            fold (opts{show_mutable = entity : show_mutable opts},rest) args
        fold (opts,rest) ("--display-control-entity":(entity:args)) = 
            fold (opts{show_control = entity : show_control opts},rest) args
        fold (opts,rest) ("--display-output-entity":(entity:args)) = 
            fold (opts{show_output = entity : show_output opts},rest) args

        fold (opts,rest) (arg:args) = fold (opts,arg:rest) args
        fold (opts,rest) [] = (opts,rest)


