Component-based Semantics (CBS)
===============================

CBS is a unified meta-notation for expressing:
 - abstract syntax grammars;
 - translation equations from abstract syntax to funcon terms;
 - funcon and semantic entity specifications.

This directory contains:
 - CBS-Editor: A spoofax editor project for viewing CBS specifications.
 - FCT-Editor: A spoofax editor project for viewing funcon terms.
 - IMP-Editor: A specification for an object language (IMP).  This includes:
    * CBS specifications of the IMP syntax, and its translation to funcons (cbs/IMP/);
    * CBS specifications of the funcon library (cbs/Funcons/).

CBS specifications can be viewed in any text editor.  However, we strongly recommend
using the CBS-Editor Spoofax project within Eclipse.


Setup Instructions
------------------

(1) Install Eclipse 4.4 (Luna), and the Spoofax 1.4.1 plugin.

  (a) Spoofax can be installed from within Eclipse by using

      http://download.spoofax.org/update/stable

      as the download location.

  OR

  (b) You will probably find it easier to download a version of Eclipse with Spoofax
      pre-installed.  This is available at:

      http://buildfarm.metaborg.org/job/spoofax-master/lastSuccessfulBuild/artifact/dist/eclipse/

      (Select a "-jre" version).  Note that you should deselect "Build Automatically"
      from the Project menu before building any projects.

(2) Import and build the "CBS-Editor" project.

(3) Import and build the "FCT-Editor" project.


Viewing CBS Specifications
--------------------------

(4) Import the "IMP-Editor" project.
      - The IMP specification can be found in "cbs/IMP/"
      - The funcon specifications can be found in "cbs/Funcons/"

(5) If CBS-Editor has built successfully, opening a .cbs file within Eclipse should
    cause the file to be parsed and displayed with coloured syntax.


Translating Test programs
-------------------------

(7) Build the IMP-Editor project.

(8) The IMP test files can be found inside "test/".  If IMP-Editor has built
    successfully, opening a .imp test file within Eclipse should cause it to be
    parsed and displayed with coloured syntax.

(9) Clicking "Generate Funcons" from the "Generation" menu while viewing a
    test program will execute (the Stratego code generated from the) CBS
    translation equations, generating a funcon term.  If FCT-Editor has built
    successfully, the funcon program should be parsed and displayed with coloured
    syntax.


Executing Funcon Terms
----------------------

(10) Funcons can be executed from within Eclipse or from the command line using
     our Haskell interpreter, which is available separately from:

     http://www.plancomps.org/nwpt2015-tsc/
