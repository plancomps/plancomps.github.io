package FCTEditor;

public class FCTParseController extends FCTParseControllerGenerated 
{ }