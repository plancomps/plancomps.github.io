package IMPEditor;

public class IMPParseController extends IMPParseControllerGenerated 
{ }