IMP programs 
============

Copied from a [K tutorial](https://fmse.info.uaic.ro/imgs/releases/k/tutorial/2_imp/lesson_1/README) written by Grigore Rosu

* [sum.imp](sum.imp) sums in `sum` all numbers up to `n`.

* [collatz.imp](collatz.imp) tests the Collatz conjecture for all numbers up to
`m` and accumulates the total number of steps in `s`.

* [primes.imp](primes.imp) counts in `s` all the prime numbers up to `m`.
