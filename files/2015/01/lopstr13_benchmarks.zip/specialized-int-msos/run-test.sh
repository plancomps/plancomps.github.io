#!/bin/bash
swipl -s test.pl -g "consult_ex(naive),write('\nNAIVE EVALUATION BEGIN\n===\n\n'),test,write('\n===\nNAIVE EVALUATION END\n\n'),consult_ex(refocused),write('\nREFOCUSED EVALUATION BEGIN\n===\n\n'),test,write('\n===\nREFOCUSED EVALUATION END\n\n'),consult_ex(striding),write('\nSTRIDING EVALUATION BEGIN\n===\n\n'),test,write('\n===\nSTRIDING EVALUATION END\n\n')" -t halt
