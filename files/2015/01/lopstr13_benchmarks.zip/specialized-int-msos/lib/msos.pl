:- op(700, xfx, (+=)).

:- multifile msos_step/3,msos_steps/3.
:- discontiguous msos_step/3,msos_steps/3.

:- discontiguous comp_write/3,unobs_default/1.
:- dynamic ro/1,wo/1,rw/1.

%% DEFAULT LABEL
rw(epsilon).

%% EVALUATION HELPERS
msos_eq(X,Y) :- X = Y.

msos_neq(X,Y) :- X \= Y.

msos_int_add(A,B,C) :- C is A + B.
msos_int_sub(A,B,C) :- C is A - B.
msos_int_mul(A,B,C) :- C is A * B.
msos_int_mod(A,B,C) :- C is A mod B.

msos_copy(X1,X2) :- copy_term(X1,X2).

msos_stuck_term(_).             % Assuming the rule with stuck premise
                                % is called when no other rules match,
                                % this predicate is a fact.

msos_steps_acc(X,L,Y) :-
        msos_steps(t__(acc,X),L,t__(acc,Y)).

msos_emit([]).
msos_emit([I+=W|E]) :-
        wo(I) -> print(W), nl,
        msos_emit(E).
msos_emit([_|E]) :- msos_emit(E).

%% LABEL HELPERS %%
ro_component(I=_) :- ro(I).
wo_component(I+=_) :- wo(I).
rw_component(I=_) :- rw(I).
rw_component(I+=_) :- rw(I).

%% MAP HELPERS %%
map_member(map_prefix(X,Y,_),X,Y).
map_member(map_prefix(X,_,Map),X1,R) :-
        X \= X1,
        nonvar(Map),
        map_member(Map,X1,R).

map_select(map_prefix(X,Y,M),X,Y,M).
map_select(map_prefix(X,Y,Map),X1,R,map_prefix(X,Y,M)) :-
        X \= X1,
        map_member(Map,X1,R,M).

map_update(map_prefix(X,_,Map),X,Y1,map_prefix(X,Y1,Map)) :- !.
map_update(Tail,X,Y,map_prefix(X,Y,Tail)) :- var(Tail), !.
map_update(map_empty,X,Y,map_prefix(X,Y,map_empty)) :- !.
map_update(map_prefix(X,Y,Map),X1,Y1,map_prefix(X,Y,Map1)) :-
        X @< X1,
        map_update(Map,X1,Y1,Map1), !.
map_update(map_prefix(X,Y,Map),X1,Y1,map_prefix(X1,Y1,map_prefix(X,Y,Map))) :-
        X1 @< X, !.

map_over(map_empty,Map,Map).
map_over(map_prefix(X,Y,Map1),Map2,R) :-
        map_over(Map1,Map2,Map3),
        map_update(Map3,X,Y,R).

map_union(map_empty,Map,Map).
map_union(map_prefix(X,Y,Map1),Map2,R) :-
        contains_key(Map2,X,false),
        map_union(Map1,Map2,Map3),
        map_update(Map3,X,Y,R).

contains_key(map_empty,_,false).
contains_key(map_prefix(X,_,_),X,true).
contains_key(map_prefix(X,_,Map),X1,R) :-
        X \= X1,
        contains_key(Map,X1,R).

map_append(map_empty,Map,Map).
map_append(map_prefix(K,V,Map1),Map2,map_prefix(K,V,Map)) :-
        map_append(Map1,Map2,Map).

%% LABEL HELPERS
msos_final_label([]).
msos_final_label([I=C,I+=C|L]) :-
        rw(I),
        msos_final_label(L).
msos_final_label([LC|L]) :-
        \+ rw_component(LC),
        msos_final_label(L).

msos_label_instance(LblVar,LblInst) :-
        var(LblVar),
        ( var(LblInst) ->
          is_label(LblVar),
          LblVar = LblInst
        ; is_label(LblVar), is_label(LblInst), LblVar = LblInst
        ; is_label(LblVar),
          msos_label_instance(LblVar,LblInst) ), !.
msos_label_instance(Lbl,LblInst) :-
        nonvar(Lbl),
        var(LblInst),
        Lbl = LblInst, !.
msos_label_instance(Lbl,LblInst) :-
        nonvar(Lbl),
        nonvar(LblInst),
        ( LblInst = [LC|LCs] ->
          selectchk(LC,Lbl,Lbl__),
          msos_label_instance(Lbl__,LCs)
        ; LblInst = [] ->
          true ), !.


msos_comp_label(L1,L2) :-
        msos_label_instance(L1__,L1),
        msos_label_instance(L2__,L2) ->
        msos_comp_label_(L1__,L2__).
msos_comp_label_([],[]).
msos_comp_label_([I=C0|X1],
                 [I=C0|X2]) :-
        ro(I),
        msos_comp_label_(X1,X2).
msos_comp_label_([I=_,I+=C11|X1],
                 [I=C11,I+=_|X2]) :-
        rw(I),
        msos_comp_label_(X1,X2).
msos_comp_label_([I+=_|X1],
                 [I+=_|X2]) :-
        wo(I),
        msos_comp_label_(X1,X2).


msos_is_comp(L2__L1,L1,L2) :-
        msos_label_instance(L2__L1__,L2__L1),
        msos_label_instance(L1__,L1),
        msos_label_instance(L2__,L2) ->
        msos_is_comp_(L2__L1__,L1__,L2__).
msos_is_comp_init(L2__L1,L1,L2) :-
        is_label(L2__L1),
        is_label(L1),
        is_label(L2),
        msos_is_comp_(L2__L1,L1,L2).
msos_is_comp_([],[],[]).
msos_is_comp_([I=C|M2__M1],
              [I=C|M1],
              [I=C|M2]) :-
        ro(I),
        msos_is_comp_(M2__M1,M1,M2).
msos_is_comp_([I=C11,I+=C2|M2__M1],
              [I=C11,I+=C12|M1],
              [I=C12,I+=C2|M2]) :-
        rw(I),
        msos_is_comp_(M2__M1,M1,M2).
msos_is_comp_([I+=_|M2__M1],
              [I+=_|M1],
              [I+=_|M2]) :-
        wo(I),
        msos_is_comp_(M2__M1,M1,M2).

msos_is_comp_w(L2__L1,L1,L2) :-
        msos_label_instance(L2__L1__,L2__L1),
        msos_label_instance(L1__,L1),
        msos_label_instance(L2__,L2) ->
        msos_is_comp_w_(L2__L1__,L1__,L2__).
msos_is_comp_w_init(L2__L1,L1,L2) :-
        msos_is_comp_w_(L2__L1,L1,L2).
msos_is_comp_w_([],[],[]).
msos_is_comp_w_([I+=C2__C1|M2__M1],
                [I+=C1|M1],
                [I+=C2|M2]) :-
        wo(I),
        comp_write(I+=C2__C1,I+=C1,I+=C2),
        msos_is_comp_w_(M2__M1,M1,M2).
msos_is_comp_w_([LC2__LC1|M2__M1],
                [_LC1|M1],
                [_LC2|M2]) :-
        \+ wo_component(LC2__LC1),
        msos_is_comp_w_(M2__M1,M1,M2).


msos_unobs_label(V) :-
        msos_label_instance(V__,V) ->
        msos_unobs_label_(V__).
msos_unobs_label_([]).
msos_unobs_label_([I=_|M]) :-
        ro(I),
        msos_unobs_label_(M).
msos_unobs_label_([I=C,I+=C|M]) :-
        rw(I),
        msos_unobs_label_(M).
msos_unobs_label_([I+=Default|M]) :-
        wo(I),
        unobs_default(I+=Default),
        msos_unobs_label_(M).


msos_unobs_label_w(V) :-
        msos_label_instance(V__,V) ->
        msos_unobs_label_w_(V__).
msos_unobs_label_w_([]).
msos_unobs_label_w_([I=_|M]) :-
        ro(I),
        msos_unobs_label_w_(M).
msos_unobs_label_w_([I=_,I+=_|M]) :-
        rw(I),
        msos_unobs_label_w_(M).
msos_unobs_label_w_([I+=C|M]) :-
        wo(I),
        ( var(C) -> C = v(nil)
        ; true ),
        msos_unobs_label_w_(M).
