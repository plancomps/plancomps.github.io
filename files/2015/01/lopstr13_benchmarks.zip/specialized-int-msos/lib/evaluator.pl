%% [eval(1,refl_v)]
msos_steps(v(_G2833),_G2941,v(_G2833)) :-
        msos_label_instance(_G2941,[epsilon=0|_G2823]),
        msos_unobs_label(_G2941),
        msos_stuck_term(v(_G2833)).

%% [eval(2,trans_steps)]
msos_steps(_G87,_G74,_G102) :-
        msos_is_comp(_G74,_G906,_G76),
        msos_label_instance(_G906,[epsilon=0|_G79]),
        msos_step(_G87,_G906,_G89),
        msos_steps(_G89,_G76,_G102),
        msos_is_comp_w(_G74,_G906,_G76).

%% [eval(3,refl_except)]
msos_steps(_G42,_G2039,_G42) :-
        msos_label_instance(_G2039,[epsilon=1,epsilon+=1|_G53]).

%% [eval(4,untag)]
msos_step(t__(refocus,_G15),_G16,t__(refocus,_G17)) :-
        msos_step(_G15,_G16,_G17).

%% [mod_step,eval(5,refl_v)]
msos_steps(t__(mod_step,v(_G68)),_G533,t__(mod_step,v(_G68))) :-
        msos_label_instance(_G533,[epsilon=0|_G144]),
        msos_unobs_label(_G533).

%% [mod_step,eval(6,refl_except)]
msos_steps(t__(mod_step,_G17),_G1337,t__(mod_step,_G17)) :-
        msos_label_instance(_G1337,[epsilon=1,epsilon+=1|_G26]).
