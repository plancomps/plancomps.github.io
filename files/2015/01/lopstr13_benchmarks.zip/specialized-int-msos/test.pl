consult_ex(S) :-
        retractall(msos_step(_,_,_)),
        retractall(msos_steps(_,_,_)),
        consult('lib/msos.pl'),
        consult('lib/evaluator.pl'),
        consult('semantics/label_sem.pl'),
        ( S = naive ->
          consult('semantics/naive.pl')
        ; S = refocused ->
          consult('semantics/refocused.pl')
        ; S = striding ->
          consult('semantics/stridden.pl') ).


%% UNIT TESTS
%% ----------
test :-
        ( nest_left_assoc_seq(100,R0),init_label(L0),time(msos_steps(R0,L0,X0)),print(X0),nl,!
        , nest_left_assoc_let(50,R1),init_label(L1),time(msos_steps(R1,L1,X1)),print(X1),nl,!
        , imp_fib(100,R2),init_label(L2),time(msos_steps(R2,L2,X2)),print(X2),nl,!
        , app_fib(10,R3),init_label(L3),time(msos_steps(R3,L3,X3)),print(X3),nl,!
        , imp_fac(100,R4),init_label(L4),time(msos_steps(R4,L4,X4)),print(X4),nl,!
        , app_fac(100,R5),init_label(L5),time(msos_steps(R5,L5,X5)),print(X5),nl,!
        , nest_left_assoc_catch(100,R6),init_label(L6),time(msos_steps(R6,L6,X6)),print(X6),nl,!
        , nest_left_assoc_catch_exc(100,R7),init_label(L7),time(msos_steps(R7,L7,X7)),print(X7),nl,!
        , nest_left_assoc_lambda(100,R8),init_label(L8),time(msos_steps(R8,L8,X8)),print(X8),nl,!
        , nest_left_assoc_add(100,R9),init_label(L9),time(msos_steps(R9,L9,X9)),print(X9),nl,!
        , is_prime_app(111,R10),init_label(L10),time(msos_steps(R10,L10,X10)),print(X10),nl,!
        , is_prime_exc(111,R11),init_label(L11),time(msos_steps(R11,L11,X11)),print(X11),nl,!
        , is_prime_catch(111,R12),init_label(L12),time(msos_steps(R12,L12,X12)),print(X12),nl,!
        , euclid_app(7883,7703,R13),init_label(L13),time(msos_steps(R13,L13,X13)),print(X13),nl,!
        , euclid_imp(7883,7703,R14),init_label(L14),time(msos_steps(R14,L14,X14)),print(X14),nl,!
        , nest_left_assoc_assign(200,R15),init_label(L15),time(msos_steps(R15,L15,X15)),print(X15),nl,! ).



%% BENCHMARK HOOKS
%% ---------------
test_ex_imp_fac_n(N) :-
        imp_fac1(N,P),
        init_label(L1),
        print('% ImpFac('),print(N),print('):'),nl,
        time(msos_steps(P,L1,X)),
        print('% Result: '),print(X),nl,nl,print('==========='),nl,nl.

test_ex_app_fac_n(N) :-
        app_fac(N,P),
        init_label(L1),
        print('% AppFac('),print(N),print('):'),nl,
        time(msos_steps(P,L1,X)),
        print('% Result: '),print(X),nl,nl,print('==========='),nl,nl.

test_ex_imp_fib_n(N) :-
        imp_fib1(N,P),
        init_label(L1),
        print('% ImpFib('),print(N),print('):'),nl,
        time(msos_steps(P,L1,X)),
        print('% Result: '),print(X),nl,nl,print('==========='),nl,nl.

test_ex_app_fib_n(N) :-
        app_fib(N,P),
        init_label(L1),
        print('% AppFib('),print(N),print('):'),nl,
        time(msos_steps(P,L1,X)),
        print('% Result: '),print(X),nl,nl,print('==========='),nl,nl.

test_ex_imp_prime_p(N) :-
        prime_number(N,S),
        is_prime_imp(S,P),
        init_label(L1),
        print('% ImpIsPrime('),print(S),print('):'),nl,
        time(msos_steps(P,L1,X)),
        print('% Result: '),print(X),nl,nl,print('==========='),nl,nl.

test_ex_app_prime_p(N) :-
        prime_number(N,S),
        is_prime_app(S,P),
        init_label(L1),
        print('% AppIsPrime('),print(S),print('):'),nl,
        time(msos_steps(P,L1,X)),
        print('% Result: '),print(X),nl,nl,print('==========='),nl,nl.

test_ex_imp_euclid_f(N1) :-
        N2 is N1 + 1,
        fib(N1,S1),
        fib(N2,S2),
        euclid_imp(S1,S2,P),
        init_label(L1),
        print('% ImpEuclid('),print(S1),print(','),print(S2),print('):'),nl,
        time(msos_steps(P,L1,X)),
        print('% Result: '),print(X),nl,nl,print('==========='),nl,nl.

test_ex_app_euclid_f(N1) :-
        N2 is N1 + 1,
        fib(N1,S1),
        fib(N2,S2),
        euclid_app(S1,S2,P),
        init_label(L1),
        print('% AppEuclid('),print(S1),print(','),print(S2),print('):'),nl,
        time(msos_steps(P,L1,X)),
        print('% Result: '),print(X),nl,nl,print('==========='),nl,nl.



%% FIB NUMBER GENERATOR
%% --------------------
fib(0,1).
fib(1,1).
fib(N,F) :-
        N1 is N - 1,
        N2 is N - 2,
        fib(N1,F1),
        fib(N2,F2),
        F is F1 + F2.



%% PRIME NUMBER GENERATOR
%% ----------------------
has_divisor(X,Y) :-
        N is Y*Y,
        N =< X,
        ( X mod Y =:= 0
        ; Y < X,
          Y1 is Y + 1,
          has_divisor(X,Y1) ).

is_prime([X|_],X) :-
        Y is 2,
        X > 1,
        \+ has_divisor(X,Y).
is_prime([_|T],Z) :-
        is_prime(T,Z).

list_of_primes(0,[]).
list_of_primes(N,[X|Xs]) :-
        N > 0,
        X is N + 1,
        N1 is N - 1,
        list_of_primes(N1,Xs).

get_prime(N,C) :-
        list_of_primes(N,X),
        is_prime(X,C).

prime_number(N,C) :-
        findall(P,
                get_prime(5000,P),
                Ps),
        reverse(Ps,Ps1),
        nth1(N,Ps1,C).


%% TEST PREDICATES
%% ---------------
nest_left_assoc_catch_exc(N, R) :-
        nest_left_assoc_catch_exc_inner(N, throw(v(42)), R).
nest_left_assoc_catch_exc_inner(0,R,R).
nest_left_assoc_catch_exc_inner(N,Acc,R) :-
        N > 0,
        N_1 is N - 1,
        nest_left_assoc_catch_exc_inner(N_1,catch(Acc,lambda(x,throw(v(0)))),R).

nest_left_assoc_catch(N, R) :-
        nest_left_assoc_catch_inner(N, v(skip), R).
nest_left_assoc_catch_inner(0,R,R).
nest_left_assoc_catch_inner(N,Acc,R) :-
        N > 0,
        N_1 is N - 1,
        nest_left_assoc_catch_inner(N_1,catch(Acc,lambda(x,bound(x))),R).

nest_left_assoc_seq(N, R) :-
        nest_left_assoc_seq_inner(N, v(skip), R).
nest_left_assoc_seq_inner(0,R,R).
nest_left_assoc_seq_inner(N,Acc,R) :-
        N > 0,
        N_1 is N - 1,
        nest_left_assoc_seq_inner(N_1,seq(Acc,v(skip)),R).

nest_left_assoc_assign(N, R) :-
        nest_left_assoc_assign_inner(N, v(skip), R).
nest_left_assoc_assign_inner(0,R,R).
nest_left_assoc_assign_inner(N,Acc,R) :-
        N > 0,
        N_1 is N - 1,
        nest_left_assoc_assign_inner(N_1,assign(x,Acc),R).

nest_left_assoc_let(N, R) :-
        nest_left_assoc_let_inner(N, v(42), R).
nest_left_assoc_let_inner(0,R,R).
nest_left_assoc_let_inner(N,Acc,R) :-
        N > 0,
        N_1 is N - 1,
        nest_left_assoc_let_inner(N_1,let(id,Acc,bound(id)),R).

nest_left_assoc_lambda(N, R) :-
        nest_left_assoc_lambda_inner(N, bound(x), R).
nest_left_assoc_lambda_inner(0, R, apply(v(abs(x,R,map_empty)),v(1))).
nest_left_assoc_lambda_inner(N, Acc, R) :-
        N > 0,
        N_1 is N - 1,
        nest_left_assoc_lambda_inner(N_1, apply(v(abs(x,Acc,map_empty)),int_add(bound(x),v(1))), R).

nest_left_assoc_add(N, R) :-
        nest_left_assoc_add_inner(N, v(1), R).
nest_left_assoc_add_inner(0, R, R).
nest_left_assoc_add_inner(N, Acc, R) :-
        N > 0,
        N_1 is N - 1,
        nest_left_assoc_add_inner(N_1, int_add(Acc,v(1)), R).

imp_fib(N,F) :-
        F = seq(assign(f1,v(1)),
                seq(assign(f2,v(1)),
                    seq(assign(tmp,v(0)),
                        seq(assign(fib,
                                   lambda(n,
                                          if(eq(bound(n),v(1)),
                                             deref(f1),
                                             seq(assign(tmp,deref(f1)),
                                                 seq(assign(f1,int_add(deref(f1),deref(f2))),
                                                     seq(assign(f2,deref(tmp)),
                                                         apply(deref(fib),
                                                               int_sub(bound(n),v(1))))))))),
                            apply(deref(fib),v(N)))))).

imp_fib1(N,F) :-
        F = seq(assign(f1,v(0)),
                seq(assign(f2,v(1)),
                    seq(assign(i,v(0)),
                        seq(while(eq(eq(deref(i),v(N)),v(false)),
                                  seq(assign(next,
                                             int_add(deref(f1),deref(f2))),
                                      seq(assign(f1,deref(f2)),
                                          seq(assign(f2,deref(next)),
                                              assign(i,int_add(deref(i),v(1))))))),
                            deref(next))))).


app_fib(N,F) :-
        F = seq(assign(fib,
                       lambda(n,
                              if(eq(bound(n),v(0)),
                                 v(1),
                                 if(eq(bound(n),v(1)),
                                    v(1),
                                    int_add(apply(deref(fib),
                                                  int_sub(bound(n),v(1))),
                                            apply(deref(fib),
                                                  int_sub(bound(n),v(2)))))))),
                apply(deref(fib),v(N))).

imp_fac(N,F) :-
        F = seq(assign(f,v(1)),
                seq(assign(fac,
                           lambda(n,
                                  if(eq(bound(n),v(1)),
                                     deref(f),
                                     seq(assign(f,int_mul(deref(f),bound(n))),
                                         apply(deref(fac),int_sub(bound(n),v(1))))))),
                    apply(deref(fac),v(N)))).

imp_fac1(N,F) :-
        F = seq(assign(f,v(1)),
                seq(assign(i,v(N)),
                    seq(while(eq(eq(deref(i),v(1)),v(false)),
                              seq(assign(f,int_mul(deref(f),deref(i))),
                                  assign(i,int_sub(deref(i),v(1))))),
                        deref(f)))).

app_fac(N,F) :-
        F = seq(assign(fac,
                       lambda(n,
                              if(eq(bound(n),v(1)),
                                 v(1),
                                 int_mul(bound(n),
                                         apply(deref(fac),int_sub(bound(n),v(1))))))),
                apply(deref(fac),v(N))).

is_prime_app(N,F) :-
        F = let(p,v(N),
                seq(assign(test,
                           lambda(n,
                                  if(eq(bound(n),bound(p)),
                                     v(true),
                                     if(eq(int_mod(bound(p),bound(n)),v(0)),
                                        v(false),
                                        apply(deref(test),int_add(bound(n),v(1))))))),
                    apply(deref(test),v(2)))).

is_prime_imp(N,F) :-
        F = seq(assign(n,v(2)),
                seq(assign(result,v(true)),
                    seq(while(eq(eq(deref(n),v(N)),v(false)),
                              if(eq(int_mod(v(N),deref(n)),v(0)),
                                 seq(assign(result,v(false)),
                                     assign(n,v(N))),
                                 assign(n,int_add(deref(n),v(1))))),
                        deref(result)))).

is_prime_exc(N,F) :-
        F = let(p,v(N),
                seq(assign(test,
                           lambda(n,
                                  if(eq(bound(n),bound(p)),
                                     v(true),
                                     if(eq(int_mod(bound(p),bound(n)),v(0)),
                                        throw(v(false)),
                                        apply(deref(test),int_add(bound(n),v(1))))))),
                    apply(deref(test),v(2)))).

is_prime_catch(N,F) :-
        F = catch(let(p,v(N),
                      seq(assign(test,
                                 lambda(n,
                                        if(eq(bound(n),bound(p)),
                                           v(true),
                                           if(eq(int_mod(bound(p),bound(n)),v(0)),
                                              throw(v(false)),
                                              apply(deref(test),int_add(bound(n),v(1))))))),
                          apply(deref(test),v(2)))),
                  lambda(v,bound(v))).

is_prime_catch_imp(N,F) :-
        F = catch(seq(assign(n,v(2)),
                      seq(while(eq(eq(deref(n),v(N)),v(false)),
                                if(eq(int_mod(v(N),deref(n)),v(0)),
                                   throw(v(false)),
                                   assign(n,int_add(deref(n),v(1))))),
                          v(true))),
                  lambda(v,bound(v))).

euclid_app(N,M,F) :-
        F = seq(assign(euclid,
                       lambda(a,
                              lambda(b,
                                     if(eq(bound(b),v(0)),
                                        bound(a),
                                        apply(apply(deref(euclid),
                                                    bound(b)),
                                              int_mod(bound(a),bound(b))))))),
                apply(apply(deref(euclid),
                            v(N)),
                      v(M))).

euclid_imp(N,M,F) :-
        F = seq(assign(b,v(M)),
                seq(assign(t,v(M)),
                    seq(assign(euclid,
                               lambda(a,
                                      if(eq(deref(b),v(0)),
                                         bound(a),
                                         seq(assign(t,deref(b)),
                                             seq(assign(b,int_mod(bound(a),deref(b))),
                                                 apply(deref(euclid),deref(t))))))),
                        apply(deref(euclid),v(N))))).

euclid_imp1(N,M,F) :-
        F = seq(assign(a,v(N)),
                seq(assign(b,v(M)),
                    seq(assign(t,v(M)),
                        seq(while(eq(eq(deref(b),v(0)),v(false)),
                                  seq(assign(t,deref(b)),
                                      seq(assign(b,int_mod(deref(a),deref(b))),
                                          assign(a,deref(t))))),
                            deref(a))))).
