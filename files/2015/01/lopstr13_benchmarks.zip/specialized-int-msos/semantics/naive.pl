%% [funcon(apply,4)]
msos_step(apply(v(abs(_G1267,v(_G1271),_G1269)),v(_G1273)),_G8759,v(_G1271)) :-
        msos_unobs_label(_G8759).

%% [funcon(apply,3)]
msos_step(apply(v(abs(_G1294,_G1303,_G1293)),v(_G1298)),_G17597,apply(v(abs(_G1294,_G1305,_G1293)),v(_G1298))) :-
        msos_label_instance(_G17597,[env=_G1332|_G1308]),
        map_update(_G1293,_G1294,v(_G1298),_G1296),
        msos_label_instance(_G17618,[env=_G1296|_G1308]),
        msos_step(t__(refocus,_G1303),_G17618,t__(refocus,_G1305)).

%% [funcon(apply,2)]
msos_step(apply(v(_G1372),_G1361),_G1362,apply(v(_G1372),_G1363)) :-
        msos_step(t__(refocus,_G1361),_G1362,t__(refocus,_G1363)).

%% [funcon(apply,1)]
msos_step(apply(_G1395,_G1404),_G1396,apply(_G1397,_G1404)) :-
        msos_step(t__(refocus,_G1395),_G1396,t__(refocus,_G1397)).

%% [funcon(assign,2)]
msos_step(assign(_G1504,_G1496),_G1497,assign(_G1504,_G1498)) :-
        msos_step(t__(refocus,_G1496),_G1497,t__(refocus,_G1498)).

%% [funcon(assign,1)]
msos_step(assign(_G1532,v(_G1536)),_G20891,v(skip)) :-
        msos_label_instance(_G20891,[store=_G1531,store+=_G1534|_G9816]),
        msos_unobs_label(_G9816),
        map_update(_G1531,_G1532,v(_G1536),_G1534).

%% [funcon(atomic,2)]
msos_step(atomic(v(_G1153)),_G10073,v(_G1153)) :-
        msos_unobs_label(_G10073).

%% [funcon(atomic,1)]
msos_step(atomic(_G1180),_G1173,v(_G1193)) :-
        msos_label_instance(_G22359,_G1174),
        msos_label_instance(_G22365,_G1175),
        msos_is_comp(_G1173,_G22359,_G22365),
        msos_step(t__(refocus,_G1180),_G1174,t__(refocus,_G1182)),
        msos_step(t__(refocus,atomic(_G1182)),_G1175,t__(refocus,v(_G1193))),
        msos_is_comp_w(_G1173,_G1174,_G1175).

%% [funcon(bound,1)]
msos_step(bound(_G1944),_G23812,lookup(_G1938,_G1944)) :-
        msos_label_instance(_G23812,[env=_G1938|_G10469]),
        msos_unobs_label([env=_G1938|_G10469]).

%% [funcon(catch,3)]
msos_step(catch(v(_G1586),_G1584),_G24569,v(_G1586)) :-
        msos_label_instance(_G24569,[exc+=v(nil)|_G10653]),
        msos_unobs_label(_G10653).

%% [funcon(catch,2)]
msos_step(catch(_G1614,_G1656),_G25287,apply(_G1656,_G1626)) :-
        msos_label_instance(_G25287,[exc+=v(nil),epsilon=0,epsilon+=0|_G1638]),
        msos_label_instance(_G25305,[exc+=v(cons(_G1626,v(nil))),epsilon=0,epsilon+=1|_G1638]),
        msos_step(t__(refocus,_G1614),_G25305,t__(refocus,_G1616)),
        msos_neq(_G1626,v(nil)).

%% [funcon(catch,1)]
msos_step(catch(_G1697,_G1726),_G26613,catch(_G1699,_G1726)) :-
        msos_label_instance(_G26613,[exc+=v(nil),epsilon=0,epsilon+=0|_G1716]),
        msos_label_instance(_G26631,[exc+=v(nil),epsilon=0,epsilon+=0|_G1716]),
        msos_step(t__(refocus,_G1697),_G26631,t__(refocus,_G1699)).

%% [funcon(deref,1)]
msos_step(deref(_G1469),_G27780,lookup(_G1463,_G1469)) :-
        msos_label_instance(_G27780,[store=_G1463|_G11739]),
        msos_unobs_label([store=_G1463|_G11739]).

%% [funcon(eq,4)]
msos_step(eq(_G361,_G353),_G354,eq(_G361,_G355)) :-
        msos_step(t__(refocus,_G353),_G354,t__(refocus,_G355)).

%% [funcon(eq,3)]
msos_step(eq(_G383,_G392),_G384,eq(_G385,_G392)) :-
        msos_step(t__(refocus,_G383),_G384,t__(refocus,_G385)).

%% [funcon(eq,2)]
msos_step(eq(v(_G418),v(_G419)),_G12221,v(false)) :-
        msos_unobs_label(_G12221),
        msos_neq(_G418,_G419).

%% [funcon(eq,1)]
msos_step(eq(v(_G455),v(_G456)),_G12416,v(true)) :-
        msos_unobs_label(_G12416),
        msos_eq(_G455,_G456).

%% [funcon(if,3)]
msos_step(if(_G487,_G496,_G497),_G488,if(_G489,_G496,_G497)) :-
        msos_step(t__(refocus,_G487),_G488,t__(refocus,_G489)).

%% [funcon(if,2)]
msos_step(if(v(false),_G526,_G523),_G12756,_G523) :-
        msos_unobs_label(_G12756).

%% [funcon(if,1)]
msos_step(if(v(true),_G551,_G555),_G12885,_G551) :-
        msos_unobs_label(_G12885).

%% [funcon(int_add,3)]
msos_step(int_add(v(_G593),v(_G594)),_G2919,v(_G595)) :-
        msos_unobs_label(_G2919),
        msos_int_add(_G593,_G594,_G595).

%% [funcon(int_add,2)]
msos_step(int_add(_G634,_G626),_G627,int_add(_G634,_G628)) :-
        msos_step(t__(refocus,_G626),_G627,t__(refocus,_G628)).

%% [funcon(int_add,1)]
msos_step(int_add(_G656,_G665),_G657,int_add(_G658,_G665)) :-
        msos_step(t__(refocus,_G656),_G657,t__(refocus,_G658)).

%% [funcon(int_mod,3)]
msos_step(int_mod(v(_G299),v(_G300)),_G3023,v(_G301)) :-
        msos_unobs_label(_G3023),
        msos_int_mod(_G299,_G300,_G301).

%% [funcon(int_mod,2)]
msos_step(int_mod(_G340,_G332),_G333,int_mod(_G340,_G334)) :-
        msos_step(t__(refocus,_G332),_G333,t__(refocus,_G334)).

%% [funcon(int_mod,1)]
msos_step(int_mod(_G362,_G371),_G363,int_mod(_G364,_G371)) :-
        msos_step(t__(refocus,_G362),_G363,t__(refocus,_G364)).

%% [funcon(int_mul,3)]
msos_step(int_mul(v(_G397),v(_G398)),_G3127,v(_G399)) :-
        msos_unobs_label(_G3127),
        msos_int_mul(_G397,_G398,_G399).

%% [funcon(int_mul,2)]
msos_step(int_mul(_G438,_G430),_G431,int_mul(_G438,_G432)) :-
        msos_step(t__(refocus,_G430),_G431,t__(refocus,_G432)).

%% [funcon(int_mul,1)]
msos_step(int_mul(_G460,_G469),_G461,int_mul(_G462,_G469)) :-
        msos_step(t__(refocus,_G460),_G461,t__(refocus,_G462)).

%% [funcon(int_sub,3)]
msos_step(int_sub(v(_G495),v(_G496)),_G3231,v(_G497)) :-
        msos_unobs_label(_G3231),
        msos_int_sub(_G495,_G496,_G497).

%% [funcon(int_sub,2)]
msos_step(int_sub(_G536,_G528),_G529,int_sub(_G536,_G530)) :-
        msos_step(t__(refocus,_G528),_G529,t__(refocus,_G530)).

%% [funcon(int_sub,1)]
msos_step(int_sub(_G558,_G567),_G559,int_sub(_G560,_G567)) :-
        msos_step(t__(refocus,_G558),_G559,t__(refocus,_G560)).

%% [funcon(lambda,1)]
msos_step(lambda(_G887,_G888),_G23487,v(abs(_G887,_G888,_G894))) :-
        msos_label_instance(_G23487,[env=_G894|_G3325]),
        msos_unobs_label(_G3325).

%% [funcon(let,3)]
msos_step(let(_G1480,_G1481,v(_G1484)),_G3370,v(_G1484)) :-
        msos_unobs_label(_G3370).

%% [funcon(let,2)]
msos_step(let(_G1505,v(_G1509),_G1514),_G24737,let(_G1505,v(_G1509),_G1516)) :-
        msos_label_instance(_G24737,[env=_G1504|_G1519]),
        map_update(_G1504,_G1505,v(_G1509),_G1507),
        msos_label_instance(_G24758,[env=_G1507|_G1519]),
        msos_step(t__(refocus,_G1514),_G24758,t__(refocus,_G1516)).

%% [funcon(let,1)]
msos_step(let(_G1570,_G1562,_G1572),_G1563,let(_G1570,_G1564,_G1572)) :-
        msos_step(t__(refocus,_G1562),_G1563,t__(refocus,_G1564)).

%% [funcon(lookup,2)]
msos_step(lookup(map_prefix(_G693,v(_G699),_G697),_G693),_G3486,v(_G699)) :-
        msos_unobs_label(_G3486).

%% [funcon(lookup,1)]
msos_step(lookup(map_prefix(_G736,v(_G750),_G728),_G729),_G3551,v(_G731)) :-
        msos_unobs_label(_G3551),
        msos_step(t__(refocus,lookup(_G728,_G729)),_G3551,t__(refocus,v(_G731))),
        msos_neq(_G736,_G729).

%% [funcon(print,1)]
msos_step(print(_G1093),_G28150,v(skip)) :-
        msos_label_instance(_G28150,[output+=_G1093|_G3610]),
        msos_unobs_label(_G3610).

%% [funcon(seq,2)]
msos_step(seq(v(skip),_G241),_G3650,_G241) :-
        msos_unobs_label(_G3650).

%% [funcon(seq,1)]
msos_step(seq(_G264,_G273),_G265,seq(_G266,_G273)) :-
        msos_step(t__(refocus,_G264),_G265,t__(refocus,_G266)).

%% [funcon(throw,1)]
msos_step(throw(_G1435),_G29870,s_(stuck)) :-
        msos_label_instance(_G29870,[exc+=v(cons(_G1435,v(nil))),epsilon+=1|_G3709]),
        msos_unobs_label(_G3709).

%% [funcon(while,1)]
msos_step(while(_G776,_G777),_G3762,if(_G776,seq(_G777,while(_G776,_G777)),v(skip))) :-
        msos_unobs_label(_G3762).


