%% [funcon(apply,4)]
msos_step(apply(v(abs(_G1372,v(_G1376),_G1374)),v(_G1378)),_G29165,v(_G1376)) :-
        msos_unobs_label(_G29165).

%% [eval(3,trans_step),funcon(apply,3)]
msos_step(apply(v(abs(_G3516,_G3517,_G3518)),v(_G3520)),_G3488,_G3544) :-
        msos_is_comp_init(_G3488,_G12378,_G3490),
        map_update(_G3518,_G3516,v(_G3520),_G3566),
        msos_label_instance(_G12378,[epsilon=0,env=_G3502|_G3499]),
        msos_label_instance(_G12722,[env=_G3566|_G3499]),
        msos_step(_G3517,_G12722,_G3534),
        msos_steps(apply(v(abs(_G3516,_G3534,_G3518)),v(_G3520)),_G3490,_G3544),
        msos_is_comp_w_init(_G3488,_G12378,_G3490).

%% [eval(3,trans_step),funcon(apply,2)]
msos_step(apply(v(_G3631),_G3629),_G3611,_G3649) :-
        msos_is_comp_init(_G3611,_G12794,_G3613),
        msos_label_instance(_G12794,[epsilon=0|_G3616]),
        msos_label_instance(_G13014,[epsilon=0|_G3616]),
        msos_step(_G3629,_G13014,_G3640),
        msos_steps(apply(v(_G3631),_G3640),_G3613,_G3649),
        msos_is_comp_w_init(_G3611,_G12794,_G3613).

%% [eval(3,trans_step),funcon(apply,1)]
msos_step(apply(_G3714,_G3715),_G3697,_G3731) :-
        msos_is_comp_init(_G3697,_G13086,_G3699),
        msos_label_instance(_G13086,[epsilon=0|_G3702]),
        msos_label_instance(_G13292,[epsilon=0|_G3702]),
        msos_step(_G3714,_G13292,_G3723),
        msos_steps(apply(_G3723,_G3715),_G3699,_G3731),
        msos_is_comp_w_init(_G3697,_G13086,_G3699).

%% [eval(3,trans_step),funcon(assign,2)]
msos_step(assign(_G3796,_G3797),_G3779,_G3813) :-
        msos_is_comp_init(_G3779,_G13364,_G3781),
        msos_label_instance(_G13364,[epsilon=0|_G3784]),
        msos_label_instance(_G13570,[epsilon=0|_G3784]),
        msos_step(_G3797,_G13570,_G3806),
        msos_steps(assign(_G3796,_G3806),_G3781,_G3813),
        msos_is_comp_w_init(_G3779,_G13364,_G3781).

%% [funcon(assign,1)]
msos_step(assign(_G1637,v(_G1641)),_G13620,v(skip)) :-
        msos_label_instance(_G13620,[store=_G1636,store+=_G1639|_G31502]),
        msos_unobs_label(_G31502),
        map_update(_G1636,_G1637,v(_G1641),_G1639).

%% [funcon(atomic,2)]
msos_step(atomic(v(_G1258)),_G31807,v(_G1258)) :-
        msos_unobs_label(_G31807).

%% [eval(3,trans_step),funcon(atomic,1)]
msos_step(atomic(_G3407),_G32443,v(_G3415)) :-
        msos_label_instance(_G32443,[epsilon=0|_G3395]),
        msos_is_comp_init([epsilon=0|_G3395],_G3442,_G3443),
        msos_step(_G3407,_G3442,_G3450),
        msos_step(atomic(_G3450),_G3443,v(_G3415)),
        msos_unobs_label(_G32443),
        msos_is_comp_w_init([epsilon=0|_G3395],_G3442,_G3443).

%% [funcon(bound,1)]
msos_step(bound(_G2049),_G14160,lookup(_G2043,_G2049)) :-
        msos_label_instance(_G14160,[env=_G2043|_G2040]),
        msos_unobs_label(_G32870),
        msos_label_instance(_G32870,[env=_G2043|_G2040]).

%% [eval(3,trans_step),funcon(catch,2),conj,eval(3,trans_step),funcon(catch,1)]
msos_step(catch(_G3892,_G3893),_G3861,_G3909) :-
        msos_is_comp_init(_G3861,_G14370,_G3863),
        msos_label_instance(_G14370,[epsilon=0,exc+=_G14671,epsilon+=_G14683|_G3880]),
        msos_label_instance(_G14801,[exc+=_G14812,epsilon=0,epsilon+=_G14830|_G3880]),
        msos_step(_G3892,_G14801,_G3930),
        ( msos_eq(_G14812,v(cons(_G3902,v(nil)))),
        msos_eq(_G14830,1),
        msos_eq(_G14671,v(nil)),
        msos_eq(_G14683,0),
        msos_neq(_G3902,v(nil)),
        msos_steps(apply(_G3893,_G3902),_G3863,_G3909)
        ; msos_eq(_G14812,v(nil)),
        msos_eq(_G14830,0),
        msos_eq(_G14671,v(nil)),
        msos_eq(_G14683,0),
        msos_steps(catch(_G3930,_G3893),_G3863,_G3909) ),
        msos_is_comp_w_init(_G3861,_G14370,_G3863).

%% [funcon(catch,3)]
msos_step(catch(v(_G1691),_G1689),_G14298,v(_G1691)) :-
        msos_label_instance(_G14298,[exc+=v(nil)|_G34541]),
        msos_unobs_label(_G34541).

%% [funcon(deref,1)]
msos_step(deref(_G1574),_G15350,lookup(_G1568,_G1574)) :-
        msos_label_instance(_G15350,[store=_G1568|_G1565]),
        msos_unobs_label(_G34802),
        msos_label_instance(_G34802,[store=_G1568|_G1565]).

%% [eval(3,trans_step),funcon(eq,4),conj,eval(3,trans_step),funcon(eq,3)]
msos_step(eq(_G2318,_G2319),_G2301,_G2335) :-
        msos_is_comp_init(_G2301,_G15510,_G2303),
        msos_label_instance(_G15510,[epsilon=0|_G2306]),
        msos_label_instance(_G15716,[epsilon=0|_G2306]),
        ( msos_step(_G2319,_G15716,_G2328),
        msos_steps(eq(_G2318,_G2328),_G2303,_G2335)
        ; msos_step(_G2318,_G15716,_G2409),
        msos_steps(eq(_G2409,_G2319),_G2303,_G2335) ),
        msos_is_comp_w_init(_G2301,_G15510,_G2303).

%% [funcon(eq,2),conj,funcon(eq,1)]
msos_step(eq(v(_G523),v(_G524)),_G35792,_G16045) :-
        msos_unobs_label(_G35792),
        ( msos_neq(_G523,_G524),
        msos_eq(_G16045,v(false))
        ; msos_eq(_G523,_G524),
        msos_eq(_G16045,v(true)) ).

%% [eval(3,trans_step),funcon(if,3)]
msos_step(if(_G2482,_G2483,_G2484),_G2465,_G2501) :-
        msos_is_comp_init(_G2465,_G16142,_G2467),
        msos_label_instance(_G16142,[epsilon=0|_G2470]),
        msos_label_instance(_G16358,[epsilon=0|_G2470]),
        msos_step(_G2482,_G16358,_G2492),
        msos_steps(if(_G2492,_G2483,_G2484),_G2467,_G2501),
        msos_is_comp_w_init(_G2465,_G16142,_G2467).

%% [funcon(if,2)]
msos_step(if(v(false),_G232,_G229),_G14705,_G229) :-
        msos_unobs_label(_G14705).

%% [funcon(if,1)]
msos_step(if(v(true),_G254,_G258),_G14741,_G254) :-
        msos_unobs_label(_G14741).

%% [eval(3,trans_step),funcon(int_add,2),conj,eval(3,trans_step),funcon(int_add,1)]
msos_step(int_add(_G2550,_G2551),_G2533,_G2567) :-
        msos_is_comp_init(_G2533,_G6301,_G2535),
        msos_label_instance(_G6301,[epsilon=0|_G2538]),
        msos_label_instance(_G6342,[epsilon=0|_G2538]),
        ( msos_step(_G2551,_G6342,_G2560),
        msos_steps(int_add(_G2550,_G2560),_G2535,_G2567)
        ; msos_step(_G2550,_G6342,_G2641),
        msos_steps(int_add(_G2641,_G2551),_G2535,_G2567) ),
        msos_is_comp_w_init(_G2533,_G6301,_G2535).

%% [funcon(int_add,3)]
msos_step(int_add(v(_G598),v(_G599)),_G15082,v(_G600)) :-
        msos_unobs_label(_G15082),
        msos_int_add(_G598,_G599,_G600).

%% [eval(3,trans_step),funcon(int_mod,2),conj,eval(3,trans_step),funcon(int_mod,1)]
msos_step(int_mod(_G2058,_G2059),_G2041,_G2075) :-
        msos_is_comp_init(_G2041,_G6529,_G2043),
        msos_label_instance(_G6529,[epsilon=0|_G2046]),
        msos_label_instance(_G6570,[epsilon=0|_G2046]),
        ( msos_step(_G2059,_G6570,_G2068),
        msos_steps(int_mod(_G2058,_G2068),_G2043,_G2075)
        ; msos_step(_G2058,_G6570,_G2149),
        msos_steps(int_mod(_G2149,_G2059),_G2043,_G2075) ),
        msos_is_comp_w_init(_G2041,_G6529,_G2043).

%% [funcon(int_mod,3)]
msos_step(int_mod(v(_G331),v(_G332)),_G15433,v(_G333)) :-
        msos_unobs_label(_G15433),
        msos_int_mod(_G331,_G332,_G333).

%% [eval(3,trans_step),funcon(int_mul,2),conj,eval(3,trans_step),funcon(int_mul,1)]
msos_step(int_mul(_G2222,_G2223),_G2205,_G2239) :-
        msos_is_comp_init(_G2205,_G6757,_G2207),
        msos_label_instance(_G6757,[epsilon=0|_G2210]),
        msos_label_instance(_G6798,[epsilon=0|_G2210]),
        ( msos_step(_G2223,_G6798,_G2232),
        msos_steps(int_mul(_G2222,_G2232),_G2207,_G2239)
        ; msos_step(_G2222,_G6798,_G2313),
        msos_steps(int_mul(_G2313,_G2223),_G2207,_G2239) ),
        msos_is_comp_w_init(_G2205,_G6757,_G2207).

%% [funcon(int_mul,3)]
msos_step(int_mul(v(_G420),v(_G421)),_G15784,v(_G422)) :-
        msos_unobs_label(_G15784),
        msos_int_mul(_G420,_G421,_G422).

%% [eval(3,trans_step),funcon(int_sub,2),conj,eval(3,trans_step),funcon(int_sub,1)]
msos_step(int_sub(_G2386,_G2387),_G2369,_G2403) :-
        msos_is_comp_init(_G2369,_G6985,_G2371),
        msos_label_instance(_G6985,[epsilon=0|_G2374]),
        msos_label_instance(_G7026,[epsilon=0|_G2374]),
        ( msos_step(_G2387,_G7026,_G2396),
        msos_steps(int_sub(_G2386,_G2396),_G2371,_G2403)
        ; msos_step(_G2386,_G7026,_G2477),
        msos_steps(int_sub(_G2477,_G2387),_G2371,_G2403) ),
        msos_is_comp_w_init(_G2369,_G6985,_G2371).

%% [funcon(int_sub,3)]
msos_step(int_sub(v(_G509),v(_G510)),_G16135,v(_G511)) :-
        msos_unobs_label(_G16135),
        msos_int_sub(_G509,_G510,_G511).

%% [funcon(lambda,1)]
msos_step(lambda(_G868,_G869),_G7161,v(abs(_G868,_G869,_G875))) :-
        msos_label_instance(_G7161,[env=_G875|_G16199]),
        msos_unobs_label(_G16199).

%% [funcon(let,3)]
msos_step(let(_G1422,_G1423,v(_G1426)),_G16265,v(_G1426)) :-
        msos_unobs_label(_G16265).

%% [eval(3,trans_step),funcon(let,2)]
msos_step(let(_G3545,v(_G3549),_G3547),_G3522,_G3568) :-
        msos_is_comp_init(_G3522,_G7246,_G3524),
        msos_label_instance(_G7246,[epsilon=0,env=_G3536|_G3533]),
        map_update(_G3536,_G3545,v(_G3549),_G3590),
        msos_label_instance(_G7306,[env=_G3590|_G3533]),
        msos_step(_G3547,_G7306,_G3559),
        msos_steps(let(_G3545,v(_G3549),_G3559),_G3524,_G3568),
        msos_is_comp_w_init(_G3522,_G7246,_G3524).

%% [eval(3,trans_step),funcon(let,1)]
msos_step(let(_G3643,_G3644,_G3645),_G3626,_G3662) :-
        msos_is_comp_init(_G3626,_G7361,_G3628),
        msos_label_instance(_G7361,[epsilon=0|_G3631]),
        msos_label_instance(_G7403,[epsilon=0|_G3631]),
        msos_step(_G3644,_G7403,_G3654),
        msos_steps(let(_G3643,_G3654,_G3645),_G3628,_G3662),
        msos_is_comp_w_init(_G3626,_G7361,_G3628).

%% [funcon(lookup,2)]
msos_step(lookup(map_prefix(_G689,v(_G695),_G693),_G689),_G16642,v(_G695)) :-
        msos_unobs_label(_G16642).

%% [eval(3,trans_step),funcon(lookup,1)]
msos_step(lookup(map_prefix(_G2717,v(_G2721),_G2719),_G2715),_G16943,v(_G2729)) :-
        msos_unobs_label(_G16943),
        msos_label_instance(_G16943,[epsilon=0|_G2702]),
        msos_label_instance(_G7568,[epsilon=0|_G2702]),
        msos_step(lookup(_G2719,_G2715),_G7568,v(_G2729)),
        msos_neq(_G2717,_G2715),
        msos_unobs_label(_G16943).

%% [funcon(print,1)]
msos_step(print(_G1059),_G7613,v(skip)) :-
        msos_label_instance(_G7613,[output+=_G1059|_G17097]),
        msos_unobs_label(_G17097).

%% [funcon(seq,2)]
msos_step(seq(v(skip),_G279),_G17158,_G279) :-
        msos_unobs_label(_G17158).

%% [eval(3,trans_step),funcon(seq,1)]
msos_step(seq(_G1976,_G1977),_G1959,_G1993) :-
        msos_is_comp_init(_G1959,_G7695,_G1961),
        msos_label_instance(_G7695,[epsilon=0|_G1964]),
        msos_label_instance(_G7736,[epsilon=0|_G1964]),
        msos_step(_G1976,_G7736,_G1985),
        msos_steps(seq(_G1985,_G1977),_G1961,_G1993),
        msos_is_comp_w_init(_G1959,_G7695,_G1961).

%% [funcon(throw,1)]
msos_step(throw(_G1380),_G7775,s_(stuck)) :-
        msos_label_instance(_G7775,[exc+=v(cons(_G1380,v(nil))),epsilon+=1|_G17362]),
        msos_unobs_label(_G17362).

%% [funcon(while,1)]
msos_step(while(_G766,_G767),_G17436,if(_G766,seq(_G767,while(_G766,_G767)),v(skip))) :-
        msos_unobs_label(_G17436).


