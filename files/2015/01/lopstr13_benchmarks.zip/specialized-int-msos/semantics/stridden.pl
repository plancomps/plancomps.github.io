%% [eval(3,trans_step),funcon(apply,1),eval(3,trans_step),funcon(apply,2),eval(3,trans_step),funcon(apply,3),funcon(apply,4),conj,eval(3,trans_step),funcon(apply,1),eval(3,trans_step),funcon(apply,2),eval(3,trans_step),funcon(apply,3),conj,eval(3,trans_step),funcon(apply,1),eval(3,trans_step),funcon(apply,2),conj,eval(3,trans_step),funcon(apply,1)]
msos_step(apply(_G1121,_G1139),_G1108,_G1136) :-
        msos_is_comp_init(_G1108,_G5519,_G1110),
        msos_label_instance(_G5519,[epsilon=0|_G1113]),
        msos_label_instance(_G5536,[epsilon=0|_G1113]),
        ( msos_step(_G1121,_G5536,_G1123),
        ( ( msos_eq(_G1123,v(abs(_G1299,_G1300,_G1301))),
        msos_is_comp_init(_G1110,_G5547,_G1308),
        msos_label_instance(_G5547,[epsilon=0|_G1311]),
        msos_label_instance(_G5560,[epsilon=0|_G1311]),
        msos_steps(_G1139,_G5560,v(_G1329)),
        msos_is_comp_init(_G1308,_G5567,_G1336),
        map_update(_G1301,_G1299,v(_G1329),_G1356),
        msos_label_instance(_G5567,[epsilon=0,env=_G1348|_G1345]),
        msos_label_instance(_G5598,[env=_G1356|_G1345]),
        ( msos_step(_G1300,_G5598,_G1365),
        ( msos_eq(_G1365,v(_G1543)),
        msos_unobs_label(_G1336),
        msos_eq(_G1136,v(_G1543))
        ; msos_steps(apply(v(abs(_G1299,_G1365,_G1301)),v(_G1329)),_G1336,_G1136),
        msos_is_comp_w_init(_G1308,_G5567,_G1336) )
        ; msos_steps(t__(mod_step,_G1300),_G5598,t__(mod_step,v(_G1543))),
        msos_unobs_label(_G1336),
        msos_eq(_G1136,v(_G1543)) ),
        msos_is_comp_w_init(_G1110,_G5547,_G1308)
        ; msos_eq(_G1123,v(_G1193)),
        msos_is_comp_init(_G1110,_G5635,_G1200),
        msos_label_instance(_G5635,[epsilon=0|_G1203]),
        msos_label_instance(_G5652,[epsilon=0|_G1203]),
        msos_step(_G1139,_G5652,_G1213),
        msos_steps(apply(v(_G1193),_G1213),_G1200,_G1136),
        msos_is_comp_w_init(_G1110,_G5635,_G1200) )
        ; msos_steps(apply(_G1123,_G1139),_G1110,_G1136) )
        ; msos_steps(t__(mod_step,_G1121),_G5536,t__(mod_step,_G1123)),
        ( msos_eq(_G1123,v(abs(_G1299,_G1300,_G1301))),
        msos_is_comp_init(_G1110,_G5547,_G1308),
        msos_label_instance(_G5547,[epsilon=0|_G1311]),
        msos_label_instance(_G5560,[epsilon=0|_G1311]),
        msos_steps(_G1139,_G5560,v(_G1329)),
        msos_is_comp_init(_G1308,_G5567,_G1336),
        map_update(_G1301,_G1299,v(_G1329),_G1356),
        msos_label_instance(_G5567,[epsilon=0,env=_G1348|_G1345]),
        msos_label_instance(_G5598,[env=_G1356|_G1345]),
        ( msos_step(_G1300,_G5598,_G1365),
        ( msos_eq(_G1365,v(_G1543)),
        msos_unobs_label(_G1336),
        msos_eq(_G1136,v(_G1543))
        ; msos_steps(apply(v(abs(_G1299,_G1365,_G1301)),v(_G1329)),_G1336,_G1136),
        msos_is_comp_w_init(_G1308,_G5567,_G1336) )
        ; msos_steps(t__(mod_step,_G1300),_G5598,t__(mod_step,v(_G1543))),
        msos_unobs_label(_G1336),
        msos_eq(_G1136,v(_G1543)) ),
        msos_is_comp_w_init(_G1110,_G5547,_G1308)
        ; msos_eq(_G1123,v(_G1193)),
        msos_is_comp_init(_G1110,_G5635,_G1200),
        msos_label_instance(_G5635,[epsilon=0|_G1203]),
        msos_label_instance(_G5652,[epsilon=0|_G1203]),
        msos_step(_G1139,_G5652,_G1213),
        msos_steps(apply(v(_G1193),_G1213),_G1200,_G1136),
        msos_is_comp_w_init(_G1110,_G5635,_G1200) ) ),
        msos_is_comp_w_init(_G1108,_G5519,_G1110).

%% [eval(3,trans_step),funcon(assign,2),funcon(assign,1),conj,eval(3,trans_step),funcon(assign,2)]
msos_step(assign(_G987,_G970),_G957,_G985) :-
        msos_is_comp_init(_G957,_G5688,_G959),
        msos_label_instance(_G5688,[epsilon=0|_G962]),
        msos_label_instance(_G5731,[epsilon=0|_G962]),
        ( msos_step(_G970,_G5731,_G972),
        ( msos_eq(_G972,v(_G1054)),
        msos_label_instance(_G959,[store=_G1033,store+=_G5723|_G1036]),
        msos_unobs_label(_G1036),
        msos_eq(_G5723,_G1039),
        map_update(_G1033,_G987,v(_G1054),_G1039),
        msos_eq(_G985,v(skip))
        ; msos_steps(assign(_G987,_G972),_G959,_G985) )
        ; msos_steps(t__(mod_step,_G970),_G5731,t__(mod_step,v(_G1054))),
        msos_label_instance(_G959,[store=_G1033,store+=_G5723|_G1036]),
        msos_unobs_label(_G1036),
        msos_eq(_G5723,_G1039),
        map_update(_G1033,_G987,v(_G1054),_G1039),
        msos_eq(_G985,v(skip)) ),
        msos_is_comp_w_init(_G957,_G5688,_G959).

%% [funcon(atomic,2)]
msos_step(atomic(v(_G1695)),_G13648,v(_G1695)) :-
        msos_unobs_label(_G13648).

%% [eval(3,trans_step),funcon(atomic,1)]
msos_step(atomic(_G1637),_G13912,v(_G1650)) :-
        msos_label_instance(_G13912,[epsilon=0|_G1616]),
        msos_is_comp_init([epsilon=0|_G1616],_G1625,_G1626),
        msos_step(_G1637,_G1625,_G1639),
        msos_step(atomic(_G1639),_G1626,v(_G1650)),
        msos_unobs_label(_G13912),
        msos_is_comp_w_init([epsilon=0|_G1616],_G1625,_G1626).

%% [eval(3,trans_step),funcon(bound,1),funcon(lookup,2),conj,eval(3,trans_step),funcon(bound,1),eval(3,trans_step),funcon(lookup,1)]
msos_step(bound(_G5372),_G14608,_G5811) :-
        msos_unobs_label(_G14608),
        ( msos_unobs_label(_G14608),
        msos_label_instance(_G14608,[epsilon=0,env=map_prefix(_G5372,v(_G5455),_G5453)|_G5446]),
        msos_eq(_G5811,v(_G5455))
        ; msos_is_comp_init(_G14608,_G5847,_G5345),
        msos_unobs_label(_G5847),
        msos_label_instance(_G14608,[epsilon=0,env=map_prefix(_G5311,v(_G5315),_G5313)|_G5306]),
        msos_label_instance(_G5847,[epsilon=0|_G5348]),
        msos_label_instance(_G5895,[epsilon=0|_G5348]),
        msos_step(lookup(_G5313,_G5372),_G5895,v(_G5380)),
        msos_neq(_G5311,_G5372),
        msos_unobs_label(_G5345),
        msos_eq(_G5811,v(_G5380)),
        msos_is_comp_w_init(_G14608,_G5847,_G5345) ).

%% [eval(3,trans_step),funcon(catch,1),funcon(catch,3),conj,eval(3,trans_step),funcon(catch,2),conj,eval(3,trans_step),funcon(catch,1)]
msos_step(catch(_G696,_G732),_G649,_G833) :-
        msos_is_comp_init(_G649,_G5913,_G766),
        msos_label_instance(_G5913,[epsilon=0,epsilon+=_G5914,exc+=_G5915|_G666]),
        msos_label_instance(_G5976,[epsilon=0,epsilon+=_G5989,exc+=_G5995|_G666]),
        ( msos_step(_G696,_G5976,_G793),
        ( msos_eq(_G5989,0),
        msos_eq(_G5995,v(nil)),
        msos_eq(_G5914,0),
        msos_eq(_G5915,v(nil)),
        ( msos_eq(_G793,v(_G720)),
        msos_label_instance(_G766,[epsilon=0,epsilon+=_G5959,exc+=_G5968|_G686]),
        msos_unobs_label(_G686),
        msos_eq(_G5959,0),
        msos_eq(_G5968,v(nil)),
        msos_eq(_G833,v(_G720))
        ; msos_steps(catch(_G793,_G732),_G766,_G833) )
        ; msos_eq(_G5989,1),
        msos_eq(_G5995,v(cons(_G815,v(nil)))),
        msos_eq(_G5914,0),
        msos_eq(_G5915,v(nil)),
        msos_neq(_G815,v(nil)),
        msos_steps(apply(_G732,_G815),_G766,_G833) )
        ; msos_steps(t__(mod_step,_G696),_G5976,t__(mod_step,_G793)),
        msos_eq(_G5989,0),
        msos_eq(_G5995,v(nil)),
        msos_eq(_G5914,0),
        msos_eq(_G5915,v(nil)),
        msos_eq(_G793,v(_G720)),
        msos_label_instance(_G766,[epsilon=0,epsilon+=_G5959,exc+=_G5968|_G686]),
        msos_unobs_label(_G686),
        msos_eq(_G5959,0),
        msos_eq(_G5968,v(nil)),
        msos_eq(_G833,v(_G720)) ),
        msos_is_comp_w_init(_G649,_G5913,_G766).

%% [funcon(deref,1)]
msos_step(deref(_G5199),_G6059,lookup(_G5193,_G5199)) :-
        msos_label_instance(_G6059,[store=_G5193|_G5190]),
        msos_unobs_label(_G16116),
        msos_label_instance(_G16116,[store=_G5193|_G5190]).

%% [eval(3,trans_step),funcon(eq,4),eval(3,trans_step),funcon(eq,3),funcon(eq,2),conj,eval(3,trans_step),funcon(eq,4),eval(3,trans_step),funcon(eq,3),funcon(eq,1),conj,eval(3,trans_step),funcon(eq,3),eval(3,trans_step),funcon(eq,4),funcon(eq,2),conj,eval(3,trans_step),funcon(eq,3),eval(3,trans_step),funcon(eq,4),funcon(eq,1),conj,eval(3,trans_step),funcon(eq,4),eval(3,trans_step),funcon(eq,3),conj,eval(3,trans_step),funcon(eq,3),eval(3,trans_step),funcon(eq,4),conj,eval(3,trans_step),funcon(eq,4),conj,eval(3,trans_step),funcon(eq,3)]
msos_step(eq(_G4379,_G4397),_G4366,_G4394) :-
        msos_is_comp_init(_G4366,_G6088,_G4368),
        msos_label_instance(_G6088,[epsilon=0|_G4371]),
        msos_label_instance(_G6101,[epsilon=0|_G4371]),
        ( ( ( msos_steps(_G4397,_G6101,_G4831),
        ( msos_eq(_G4831,v(_G4939)),
        msos_is_comp_init(_G4368,_G6116,_G4946),
        msos_label_instance(_G6116,[epsilon=0|_G4949]),
        msos_label_instance(_G6137,[epsilon=0|_G4949]),
        msos_steps(_G4379,_G6137,v(_G4967)),
        msos_unobs_label(_G4946),
        ( msos_neq(_G4967,_G4939),
        msos_eq(_G4394,v(false))
        ; msos_eq(_G4967,_G4939),
        msos_eq(_G4394,v(true)) ),
        msos_is_comp_w_init(_G4368,_G6116,_G4946)
        ; msos_is_comp_init(_G4368,_G6207,_G4844),
        msos_label_instance(_G6207,[epsilon=0|_G4847]),
        msos_label_instance(_G6222,[epsilon=0|_G4847]),
        msos_step(_G4379,_G6222,_G4857),
        msos_steps(eq(_G4857,_G4831),_G4844,_G4394),
        msos_is_comp_w_init(_G4368,_G6207,_G4844) )
        ; msos_steps(_G4379,_G6101,_G4443),
        ( msos_eq(_G4443,v(_G4551)),
        msos_is_comp_init(_G4368,_G6167,_G4558),
        msos_label_instance(_G6167,[epsilon=0|_G4561]),
        msos_label_instance(_G6188,[epsilon=0|_G4561]),
        msos_steps(_G4397,_G6188,v(_G4579)),
        msos_unobs_label(_G4558),
        ( msos_neq(_G4551,_G4579),
        msos_eq(_G4394,v(false))
        ; msos_eq(_G4551,_G4579),
        msos_eq(_G4394,v(true)) ),
        msos_is_comp_w_init(_G4368,_G6167,_G4558)
        ; msos_is_comp_init(_G4368,_G6244,_G4456),
        msos_label_instance(_G6244,[epsilon=0|_G4459]),
        msos_label_instance(_G6259,[epsilon=0|_G4459]),
        msos_step(_G4397,_G6259,_G4469),
        msos_steps(eq(_G4443,_G4469),_G4456,_G4394),
        msos_is_comp_w_init(_G4368,_G6244,_G4456) ) )
        ; msos_step(_G4397,_G6101,_G4769),
        msos_steps(eq(_G4379,_G4769),_G4368,_G4394) )
        ; msos_step(_G4379,_G6101,_G4381),
        msos_steps(eq(_G4381,_G4397),_G4368,_G4394) ),
        msos_is_comp_w_init(_G4366,_G6088,_G4368).

%% [eval(3,trans_step),funcon(if,3),funcon(if,2),conj,eval(3,trans_step),funcon(if,3),funcon(if,1),conj,eval(3,trans_step),funcon(if,3)]
msos_step(if(_G4183,_G4201,_G4202),_G4170,_G4198) :-
        msos_is_comp_init(_G4170,_G6316,_G4172),
        msos_label_instance(_G6316,[epsilon=0|_G4175]),
        msos_label_instance(_G6332,[epsilon=0|_G4175]),
        ( msos_step(_G4183,_G6332,_G4185),
        ( ( msos_eq(_G4185,v(false)),
        msos_unobs_label(_G4172),
        msos_eq(_G4198,_G4202)
        ; msos_eq(_G4185,v(true)),
        msos_unobs_label(_G4172),
        msos_eq(_G4198,_G4201) )
        ; msos_steps(if(_G4185,_G4201,_G4202),_G4172,_G4198) )
        ; msos_steps(t__(mod_step,_G4183),_G6332,t__(mod_step,_G4185)),
        ( msos_eq(_G4185,v(false)),
        msos_unobs_label(_G4172),
        msos_eq(_G4198,_G4202)
        ; msos_eq(_G4185,v(true)),
        msos_unobs_label(_G4172),
        msos_eq(_G4198,_G4201) ) ),
        msos_is_comp_w_init(_G4170,_G6316,_G4172).

%% [eval(3,trans_step),funcon(int_add,2),eval(3,trans_step),funcon(int_add,1),funcon(int_add,3),conj,eval(3,trans_step),funcon(int_add,1),eval(3,trans_step),funcon(int_add,2),funcon(int_add,3),conj,eval(3,trans_step),funcon(int_add,2),eval(3,trans_step),funcon(int_add,1),conj,eval(3,trans_step),funcon(int_add,1),eval(3,trans_step),funcon(int_add,2),conj,eval(3,trans_step),funcon(int_add,2),conj,eval(3,trans_step),funcon(int_add,1)]
msos_step(int_add(_G2952,_G2970),_G2939,_G2967) :-
        msos_is_comp_init(_G2939,_G6373,_G2941),
        msos_label_instance(_G6373,[epsilon=0|_G2944]),
        msos_label_instance(_G6386,[epsilon=0|_G2944]),
        ( ( ( msos_steps(_G2970,_G6386,_G3178),
        ( msos_eq(_G3178,v(_G3400)),
        msos_is_comp_init(_G2941,_G6402,_G3407),
        msos_label_instance(_G6402,[epsilon=0|_G3410]),
        msos_label_instance(_G6425,[epsilon=0|_G3410]),
        msos_steps(_G2952,_G6425,v(_G3428)),
        msos_unobs_label(_G3407),
        msos_int_add(_G3428,_G3400,_G3440),
        msos_eq(_G2967,v(_G3440)),
        msos_is_comp_w_init(_G2941,_G6402,_G3407)
        ; msos_is_comp_init(_G2941,_G6486,_G3191),
        msos_label_instance(_G6486,[epsilon=0|_G3194]),
        msos_label_instance(_G6501,[epsilon=0|_G3194]),
        msos_step(_G2952,_G6501,_G3204),
        msos_steps(int_add(_G3204,_G3178),_G3191,_G2967),
        msos_is_comp_w_init(_G2941,_G6486,_G3191) )
        ; msos_steps(_G2952,_G6386,_G3078),
        ( msos_eq(_G3078,v(_G3286)),
        msos_is_comp_init(_G2941,_G6450,_G3293),
        msos_label_instance(_G6450,[epsilon=0|_G3296]),
        msos_label_instance(_G6473,[epsilon=0|_G3296]),
        msos_steps(_G2970,_G6473,v(_G3314)),
        msos_unobs_label(_G3293),
        msos_int_add(_G3286,_G3314,_G3326),
        msos_eq(_G2967,v(_G3326)),
        msos_is_comp_w_init(_G2941,_G6450,_G3293)
        ; msos_is_comp_init(_G2941,_G6523,_G3091),
        msos_label_instance(_G6523,[epsilon=0|_G3094]),
        msos_label_instance(_G6538,[epsilon=0|_G3094]),
        msos_step(_G2970,_G6538,_G3104),
        msos_steps(int_add(_G3078,_G3104),_G3091,_G2967),
        msos_is_comp_w_init(_G2941,_G6523,_G3091) ) )
        ; msos_step(_G2970,_G6386,_G3016),
        msos_steps(int_add(_G2952,_G3016),_G2941,_G2967) )
        ; msos_step(_G2952,_G6386,_G2954),
        msos_steps(int_add(_G2954,_G2970),_G2941,_G2967) ),
        msos_is_comp_w_init(_G2939,_G6373,_G2941).

%% [eval(3,trans_step),funcon(int_mod,2),eval(3,trans_step),funcon(int_mod,1),funcon(int_mod,3),conj,eval(3,trans_step),funcon(int_mod,1),eval(3,trans_step),funcon(int_mod,2),funcon(int_mod,3),conj,eval(3,trans_step),funcon(int_mod,2),eval(3,trans_step),funcon(int_mod,1),conj,eval(3,trans_step),funcon(int_mod,1),eval(3,trans_step),funcon(int_mod,2),conj,eval(3,trans_step),funcon(int_mod,2),conj,eval(3,trans_step),funcon(int_mod,1)]
msos_step(int_mod(_G2400,_G2418),_G2387,_G2415) :-
        msos_is_comp_init(_G2387,_G6595,_G2389),
        msos_label_instance(_G6595,[epsilon=0|_G2392]),
        msos_label_instance(_G6608,[epsilon=0|_G2392]),
        ( ( ( msos_steps(_G2418,_G6608,_G2740),
        ( msos_eq(_G2740,v(_G2848)),
        msos_is_comp_init(_G2389,_G6624,_G2855),
        msos_label_instance(_G6624,[epsilon=0|_G2858]),
        msos_label_instance(_G6647,[epsilon=0|_G2858]),
        msos_steps(_G2400,_G6647,v(_G2876)),
        msos_unobs_label(_G2855),
        msos_int_mod(_G2876,_G2848,_G2888),
        msos_eq(_G2415,v(_G2888)),
        msos_is_comp_w_init(_G2389,_G6624,_G2855)
        ; msos_is_comp_init(_G2389,_G6708,_G2753),
        msos_label_instance(_G6708,[epsilon=0|_G2756]),
        msos_label_instance(_G6723,[epsilon=0|_G2756]),
        msos_step(_G2400,_G6723,_G2766),
        msos_steps(int_mod(_G2766,_G2740),_G2753,_G2415),
        msos_is_comp_w_init(_G2389,_G6708,_G2753) )
        ; msos_steps(_G2400,_G6608,_G2464),
        ( msos_eq(_G2464,v(_G2572)),
        msos_is_comp_init(_G2389,_G6672,_G2579),
        msos_label_instance(_G6672,[epsilon=0|_G2582]),
        msos_label_instance(_G6695,[epsilon=0|_G2582]),
        msos_steps(_G2418,_G6695,v(_G2600)),
        msos_unobs_label(_G2579),
        msos_int_mod(_G2572,_G2600,_G2612),
        msos_eq(_G2415,v(_G2612)),
        msos_is_comp_w_init(_G2389,_G6672,_G2579)
        ; msos_is_comp_init(_G2389,_G6745,_G2477),
        msos_label_instance(_G6745,[epsilon=0|_G2480]),
        msos_label_instance(_G6760,[epsilon=0|_G2480]),
        msos_step(_G2418,_G6760,_G2490),
        msos_steps(int_mod(_G2464,_G2490),_G2477,_G2415),
        msos_is_comp_w_init(_G2389,_G6745,_G2477) ) )
        ; msos_step(_G2418,_G6608,_G2678),
        msos_steps(int_mod(_G2400,_G2678),_G2389,_G2415) )
        ; msos_step(_G2400,_G6608,_G2402),
        msos_steps(int_mod(_G2402,_G2418),_G2389,_G2415) ),
        msos_is_comp_w_init(_G2387,_G6595,_G2389).

%% [eval(3,trans_step),funcon(int_mul,2),eval(3,trans_step),funcon(int_mul,1),funcon(int_mul,3),conj,eval(3,trans_step),funcon(int_mul,1),eval(3,trans_step),funcon(int_mul,2),funcon(int_mul,3),conj,eval(3,trans_step),funcon(int_mul,2),eval(3,trans_step),funcon(int_mul,1),conj,eval(3,trans_step),funcon(int_mul,1),eval(3,trans_step),funcon(int_mul,2),conj,eval(3,trans_step),funcon(int_mul,2),conj,eval(3,trans_step),funcon(int_mul,1)]
msos_step(int_mul(_G1848,_G1866),_G1835,_G1863) :-
        msos_is_comp_init(_G1835,_G6817,_G1837),
        msos_label_instance(_G6817,[epsilon=0|_G1840]),
        msos_label_instance(_G6830,[epsilon=0|_G1840]),
        ( ( ( msos_steps(_G1866,_G6830,_G2188),
        ( msos_eq(_G2188,v(_G2296)),
        msos_is_comp_init(_G1837,_G6846,_G2303),
        msos_label_instance(_G6846,[epsilon=0|_G2306]),
        msos_label_instance(_G6869,[epsilon=0|_G2306]),
        msos_steps(_G1848,_G6869,v(_G2324)),
        msos_unobs_label(_G2303),
        msos_int_mul(_G2324,_G2296,_G2336),
        msos_eq(_G1863,v(_G2336)),
        msos_is_comp_w_init(_G1837,_G6846,_G2303)
        ; msos_is_comp_init(_G1837,_G6930,_G2201),
        msos_label_instance(_G6930,[epsilon=0|_G2204]),
        msos_label_instance(_G6945,[epsilon=0|_G2204]),
        msos_step(_G1848,_G6945,_G2214),
        msos_steps(int_mul(_G2214,_G2188),_G2201,_G1863),
        msos_is_comp_w_init(_G1837,_G6930,_G2201) )
        ; msos_steps(_G1848,_G6830,_G1912),
        ( msos_eq(_G1912,v(_G2020)),
        msos_is_comp_init(_G1837,_G6894,_G2027),
        msos_label_instance(_G6894,[epsilon=0|_G2030]),
        msos_label_instance(_G6917,[epsilon=0|_G2030]),
        msos_steps(_G1866,_G6917,v(_G2048)),
        msos_unobs_label(_G2027),
        msos_int_mul(_G2020,_G2048,_G2060),
        msos_eq(_G1863,v(_G2060)),
        msos_is_comp_w_init(_G1837,_G6894,_G2027)
        ; msos_is_comp_init(_G1837,_G6967,_G1925),
        msos_label_instance(_G6967,[epsilon=0|_G1928]),
        msos_label_instance(_G6982,[epsilon=0|_G1928]),
        msos_step(_G1866,_G6982,_G1938),
        msos_steps(int_mul(_G1912,_G1938),_G1925,_G1863),
        msos_is_comp_w_init(_G1837,_G6967,_G1925) ) )
        ; msos_step(_G1866,_G6830,_G2126),
        msos_steps(int_mul(_G1848,_G2126),_G1837,_G1863) )
        ; msos_step(_G1848,_G6830,_G1850),
        msos_steps(int_mul(_G1850,_G1866),_G1837,_G1863) ),
        msos_is_comp_w_init(_G1835,_G6817,_G1837).

%% [eval(3,trans_step),funcon(int_sub,2),eval(3,trans_step),funcon(int_sub,1),funcon(int_sub,3),conj,eval(3,trans_step),funcon(int_sub,1),eval(3,trans_step),funcon(int_sub,2),funcon(int_sub,3),conj,eval(3,trans_step),funcon(int_sub,2),eval(3,trans_step),funcon(int_sub,1),conj,eval(3,trans_step),funcon(int_sub,1),eval(3,trans_step),funcon(int_sub,2),conj,eval(3,trans_step),funcon(int_sub,2),conj,eval(3,trans_step),funcon(int_sub,1)]
msos_step(int_sub(_G3504,_G3522),_G3491,_G3519) :-
        msos_is_comp_init(_G3491,_G7039,_G3493),
        msos_label_instance(_G7039,[epsilon=0|_G3496]),
        msos_label_instance(_G7052,[epsilon=0|_G3496]),
        ( ( ( msos_steps(_G3522,_G7052,_G3730),
        ( msos_eq(_G3730,v(_G3952)),
        msos_is_comp_init(_G3493,_G7068,_G3959),
        msos_label_instance(_G7068,[epsilon=0|_G3962]),
        msos_label_instance(_G7091,[epsilon=0|_G3962]),
        msos_steps(_G3504,_G7091,v(_G3980)),
        msos_unobs_label(_G3959),
        msos_int_sub(_G3980,_G3952,_G3992),
        msos_eq(_G3519,v(_G3992)),
        msos_is_comp_w_init(_G3493,_G7068,_G3959)
        ; msos_is_comp_init(_G3493,_G7152,_G3743),
        msos_label_instance(_G7152,[epsilon=0|_G3746]),
        msos_label_instance(_G7167,[epsilon=0|_G3746]),
        msos_step(_G3504,_G7167,_G3756),
        msos_steps(int_sub(_G3756,_G3730),_G3743,_G3519),
        msos_is_comp_w_init(_G3493,_G7152,_G3743) )
        ; msos_steps(_G3504,_G7052,_G3630),
        ( msos_eq(_G3630,v(_G3838)),
        msos_is_comp_init(_G3493,_G7116,_G3845),
        msos_label_instance(_G7116,[epsilon=0|_G3848]),
        msos_label_instance(_G7139,[epsilon=0|_G3848]),
        msos_steps(_G3522,_G7139,v(_G3866)),
        msos_unobs_label(_G3845),
        msos_int_sub(_G3838,_G3866,_G3878),
        msos_eq(_G3519,v(_G3878)),
        msos_is_comp_w_init(_G3493,_G7116,_G3845)
        ; msos_is_comp_init(_G3493,_G7189,_G3643),
        msos_label_instance(_G7189,[epsilon=0|_G3646]),
        msos_label_instance(_G7204,[epsilon=0|_G3646]),
        msos_step(_G3522,_G7204,_G3656),
        msos_steps(int_sub(_G3630,_G3656),_G3643,_G3519),
        msos_is_comp_w_init(_G3493,_G7189,_G3643) ) )
        ; msos_step(_G3522,_G7052,_G3568),
        msos_steps(int_sub(_G3504,_G3568),_G3493,_G3519) )
        ; msos_step(_G3504,_G7052,_G3506),
        msos_steps(int_sub(_G3506,_G3522),_G3493,_G3519) ),
        msos_is_comp_w_init(_G3491,_G7039,_G3493).

%% [funcon(lambda,1)]
msos_step(lambda(_G5264,_G5265),_G7255,v(abs(_G5264,_G5265,_G5271))) :-
        msos_label_instance(_G7255,[env=_G5271|_G24895]),
        msos_unobs_label(_G24895).

%% [eval(3,trans_step),funcon(let,1),eval(3,trans_step),funcon(let,2),funcon(let,3),conj,eval(3,trans_step),funcon(let,1),eval(3,trans_step),funcon(let,2),conj,eval(3,trans_step),funcon(let,1)]
msos_step(let(_G369,_G352,_G371),_G339,_G367) :-
        msos_is_comp_init(_G339,_G7272,_G341),
        msos_label_instance(_G7272,[epsilon=0|_G344]),
        msos_label_instance(_G7285,[epsilon=0|_G344]),
        ( msos_step(_G352,_G7285,_G354),
        ( msos_eq(_G354,v(_G426)),
        msos_is_comp_init(_G341,_G7296,_G433),
        msos_label_instance(_G7296,[epsilon=0,env=_G445|_G442]),
        map_update(_G445,_G369,v(_G426),_G453),
        msos_label_instance(_G7327,[env=_G453|_G442]),
        ( msos_step(_G371,_G7327,_G462),
        ( msos_eq(_G462,v(_G592)),
        msos_unobs_label(_G433),
        msos_eq(_G367,v(_G592))
        ; msos_steps(let(_G369,v(_G426),_G462),_G433,_G367),
        msos_is_comp_w_init(_G341,_G7296,_G433) )
        ; msos_steps(t__(mod_step,_G371),_G7327,t__(mod_step,v(_G592))),
        msos_unobs_label(_G433),
        msos_eq(_G367,v(_G592)) )
        ; msos_steps(let(_G369,_G354,_G371),_G341,_G367) )
        ; msos_steps(t__(mod_step,_G352),_G7285,t__(mod_step,v(_G426))),
        msos_is_comp_init(_G341,_G7296,_G433),
        msos_label_instance(_G7296,[epsilon=0,env=_G445|_G442]),
        map_update(_G445,_G369,v(_G426),_G453),
        msos_label_instance(_G7327,[env=_G453|_G442]),
        ( msos_step(_G371,_G7327,_G462),
        ( msos_eq(_G462,v(_G592)),
        msos_unobs_label(_G433),
        msos_eq(_G367,v(_G592))
        ; msos_steps(let(_G369,v(_G426),_G462),_G433,_G367),
        msos_is_comp_w_init(_G341,_G7296,_G433) )
        ; msos_steps(t__(mod_step,_G371),_G7327,t__(mod_step,v(_G592))),
        msos_unobs_label(_G433),
        msos_eq(_G367,v(_G592)) ) ),
        msos_is_comp_w_init(_G339,_G7272,_G341).

%% [funcon(lookup,2)]
msos_step(lookup(map_prefix(_G1809,v(_G1815),_G1813),_G1809),_G26554,v(_G1815)) :-
        msos_unobs_label(_G26554).

%% [eval(3,trans_step),funcon(lookup,1)]
msos_step(lookup(map_prefix(_G1757,v(_G1776),_G1743),_G1744),_G26855,v(_G1752)) :-
        msos_unobs_label(_G26855),
        msos_label_instance(_G26855,[epsilon=0|_G1720]),
        msos_label_instance(_G7401,[epsilon=0|_G1720]),
        msos_step(lookup(_G1743,_G1744),_G7401,v(_G1752)),
        msos_neq(_G1757,_G1744),
        msos_unobs_label(_G26855).

%% [funcon(print,1)]
msos_step(print(_G5232),_G7418,v(skip)) :-
        msos_label_instance(_G7418,[output+=_G5232|_G27009]),
        msos_unobs_label(_G27009).

%% [eval(3,trans_step),funcon(seq,1),funcon(seq,2),conj,eval(3,trans_step),funcon(seq,1)]
msos_step(seq(_G4056,_G4074),_G4043,_G4071) :-
        msos_is_comp_init(_G4043,_G7435,_G4045),
        msos_label_instance(_G7435,[epsilon=0|_G4048]),
        msos_label_instance(_G7451,[epsilon=0|_G4048]),
        ( msos_step(_G4056,_G7451,_G4058),
        ( msos_eq(_G4058,v(skip)),
        msos_unobs_label(_G4045),
        msos_eq(_G4071,_G4074)
        ; msos_steps(seq(_G4058,_G4074),_G4045,_G4071),
        msos_is_comp_w_init(_G4043,_G7435,_G4045) )
        ; msos_steps(t__(mod_step,_G4056),_G7451,t__(mod_step,v(skip))),
        msos_unobs_label(_G4045),
        msos_eq(_G4071,_G4074) ).

%% [funcon(throw,1)]
msos_step(throw(_G5148),_G7473,s_(stuck)) :-
        msos_label_instance(_G7473,[exc+=v(cons(_G5148,v(nil))),epsilon+=1|_G27549]),
        msos_unobs_label(_G27549).

%% [eval(3,trans_step),funcon(while,1),eval(3,trans_step),funcon(if,3),funcon(if,2),conj,eval(3,trans_step),funcon(while,1),eval(3,trans_step),funcon(if,3),funcon(if,1),conj,eval(3,trans_step),funcon(while,1),eval(3,trans_step),funcon(if,3)]
msos_step(while(_G59,_G80),_G28802,_G74) :-
        msos_label_instance(_G28802,[epsilon=0|_G27]),
        msos_unobs_label(_G28802),
        msos_is_comp_init(_G28802,_G7503,_G48),
        msos_label_instance(_G7503,[epsilon=0|_G51]),
        msos_label_instance(_G7521,[epsilon=0|_G51]),
        ( msos_step(_G59,_G7521,_G61),
        ( ( msos_eq(_G61,v(false)),
        msos_unobs_label(_G48),
        msos_eq(_G74,v(skip))
        ; msos_eq(_G61,v(true)),
        msos_unobs_label(_G48),
        msos_eq(_G74,seq(_G80,while(_G59,_G80))) )
        ; msos_steps(if(_G61,seq(_G80,while(_G59,_G80)),v(skip)),_G48,_G74) )
        ; msos_steps(t__(mod_step,_G59),_G7521,t__(mod_step,_G61)),
        ( msos_eq(_G61,v(false)),
        msos_unobs_label(_G48),
        msos_eq(_G74,v(skip))
        ; msos_eq(_G61,v(true)),
        msos_unobs_label(_G48),
        msos_eq(_G74,seq(_G80,while(_G59,_G80))) ) ),
        msos_is_comp_w_init(_G28802,_G7503,_G48).
