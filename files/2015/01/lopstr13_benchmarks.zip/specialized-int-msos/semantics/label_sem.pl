%% LABEL SEMANTICS %%
rw(epsilon).
ro(env).
wo(exc).
wo(out).
rw(store).

is_label([epsilon=_,
          epsilon+=_,
          env=_,
          exc+=_,
          out+=_,
          store=_,
          store+=_]).
init_label([epsilon=0,
            epsilon+=_,
            env=map_empty,
            exc+=_,
            out+=_,
            store=map_empty,
            store+=_]).

unobs_default(exc+=v(nil)).
comp_write(exc+=v(nil),exc+=v(nil),exc+=v(nil)).
comp_write(exc+=v(cons(v(X),v(nil))),exc+=v(nil),exc+=v(cons(v(X),v(nil)))).
comp_write(exc+=v(cons(v(X),v(nil))),exc+=v(cons(v(X),v(nil))),exc+=v(cons(v(X),v(nil)))).

unobs_default(out+=v(nil)).
comp_write(out+=v(nil),out+=v(nil),out+=v(nil)) :- !.
comp_write(out+=v(cons(v(X),v(Y))),out+=v(nil),out+=v(cons(v(X),v(Y)))).
comp_write(out+=v(cons(v(X),v(Y))),out+=v(cons(v(X),v(Y))),out+=v(nil)).
comp_write(out+=v(cons(v(X),v(Z))),out+=v(cons(v(X),v(X1))),out+=v(cons(v(Y),v(nil)))) :-
        comp_write(out+=v(Z),out+=v(X1),out+=v(cons(v(Y),v(nil)))).
