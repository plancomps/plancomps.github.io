%% %%%%%%% %%
%% TESTING %%
%% %%%%%%% %%

%% Positive tests:
%% ===============

%% Identity function:
%%
%% \ x . x
test_id(P) :-
        P = abs(var(x), var(x)).

%% Closure test:
%%
%% \z . let id = \x . (if true
%%                     then z
%%                     else \y . (x ; y)); x
%%      in id id
test_clo(P) :-
        P = abs(var(z), let(var(id), abs(var(x),
                                         seq(if(b(true),
                                                var(z),
                                                abs(var(y), seq(var(x), var(y)))),
                                             var(x))),
                            app(var(id), var(id)))).

%% Effect test:
%%
%% \z . let id = \x . (if true
%%                     then z
%%                     else \y . (ref x; y)); x
%%      in (id 1; id true)
test_eff(P) :-
        P = abs(var(z), let(var(id), abs(var(x),
                                         seq(if(b(true),
                                                var(z),
                                                abs(var(y),
                                                    seq(ref(var(x)),
                                                        var(y)))),
                                             var(x))),
                            seq(app(var(id), i(1)),
                                app(var(id), b(true))))).

%% Application of polymorphic id function:
%%
%% let r = \x . x in r r
test_app(P) :-
        P = let(var(r), abs(var(x), var(x)),
                app(var(r), var(r))).

%% Reference in let:
%%
%% let r = ref \x . x in (r := 1; 1)
test_absupdint(P) :-
        P = let(var(r), ref(abs(var(x), var(x))),
                seq(assign(var(r), i(1)),
                    i(1))).

%% Dereferencing function argument:
%%
%% \x . !x
test_absderef(P) :-
        P = abs(var(r), deref(var(r))).

%% Program that produces a cyclic store, from TAPL:
%%
%% let r1 = ref \x . 0
%%     r2 = ref \x . !r1 x
%% in ((r1 := \x . !r2 x); r2)
test_cyclicpierce(P) :-
        P = let(var(r1), ref(abs(var(x), i(0))),
                let(var(r2), ref(abs(var(x), app(deref(var(r1)), var(x)))),
                    seq(assign(var(r1), abs(var(x), app(deref(var(r2)), var(x)))),
                        var(r2)))).

%% Eta-expanded version of previous test:
%%
%% let r1 = \_ . ref \x . 0
%%     r2 = \_ . ref \x . !r1 x
%% in (((r1 true) := \x . !(r2 true) x); r2)
test_cyclicpierceeta(P) :-
        P = let(var(r1), abs(var(u), ref(abs(var(x), i(0)))),
                let(var(r2),abs(var(u), ref(abs(var(x),
                                                app(deref(app(var(r1), b(true))),
                                                    var(x))))),
                    seq(assign(app(var(r1),b(true)),
                               abs(var(x),
                                   app(deref(app(var(r2), b(true))), var(x)))),
                        var(r2)))).


%% Function with derefencing inside let:
%%
%% let a = \r . if !r
%%              then 0
%%              else 1
%% in a (ref true)
test_okstoif(P) :-
        P = let(var(a),abs(var(r),if(deref(var(r)),
                                     i(0), i(1))),
                app(var(a),ref(b(true)))).

%% Infinite allocations:
%%
%% let r = ref (\x . (ref 0; !r x))
%% in !r 0
test_infalloc(P) :-
        P = let(var(r), ref(abs(var(x), i(0))),
                seq(assign(var(r), abs(var(x),
                                       seq(ref(i(0)),
                                           app(deref(var(r)), var(x))))),
                    app(deref(var(r)), i(0)))).

%% Factorial:
%%
%% let fac = ref (\x . 0)
%% in (fac := \n . if (n = 0) then 1 else (!fac (n - 1)) * n); !fac 3
test_facknot(P) :-
        P = let(var(fac), ref(abs(var(x), i(0))),
                seq(assign(var(fac), abs(var(n),
                                         if(bop(<=,var(n),i(0)),
                                            i(1),
                                            iop(*, app(deref(var(fac)),
                                                       iop(-, var(n), i(1))),
                                                   var(n))))),
                    app(deref(var(fac)), i(3)))).

%% Tofte's fast_rev:
%%
%% let left = ref [1, 2, 3]
%%     right = ref []
%% in while !left <> []
%%    do (right := hd(!left) :: !right; left := tl(!left)); !right
%%    end
%%
%% Recursion-based version:
%%
%% let left = ref [1, 2, 3]
%%     right = ref []
%%     visit = ref \x . x
%% in (visit := (\ x . if (!left <> [])
%%                     then ((right := hd(!left) :: !right; left := tl(!left)); !visit [])
%%                     else !right)); !visit []
test_fastrevrec(P) :-
        P = let(var(left), ref(cons(i(1), cons(i(2), cons(i(3), nil)))),
                let(var(right), ref(nil),
                    let(var(visit), ref(abs(var(x), var(x))),
                        seq(assign(var(visit),
                                   abs(var(x),
                                       if(blop(<>,deref(var(left)),nil),
                                          seq(seq(assign(var(right),
                                                         cons(hd(deref(var(left))),
                                                              deref(var(right)))),
                                                  assign(var(left),
                                                         tl(deref(var(left))))),
                                              app(deref(var(visit)), nil)),
                                          deref(var(right))))),
                            app(deref(var(visit)), nil))))).

%% Tofte's fast_rev as fold, recursion-based version:
%%
%% \f . \i . \l .
%%   let data = ref l
%%       result = ref i
%%       visit = ref \x . x
%%   in (visit := (\ x . if (!data <> [])
%%                       then ((result := f (hd(!data)) (!result); data := tl(!data)); !visit [])
%%                       else !result)); !visit []
test_fastrevfoldrec(P) :-
        P = abs(var(f),abs(var(i),abs(var(l),
            let(var(data), ref(var(l)),
                let(var(result), ref(var(i)),
                    let(var(visit), ref(abs(var(x), var(x))),
                        seq(assign(var(visit),
                                   abs(var(x),
                                       if(blop(<>,deref(var(data)),nil),
                                          seq(seq(assign(var(result),
                                                         app(app(var(f),
                                                                 hd(deref(var(data)))),
                                                             deref(var(result)))),
                                                  assign(var(data),
                                                         tl(deref(var(data))))),
                                              app(deref(var(visit)), nil)),
                                          deref(var(result))))),
                            app(deref(var(visit)), nil)))))))).

%% Using the recursive fastrevfold polymorphically
test_foldfast(P) :-
        test_fastrevfoldrec(P1),
        P = let(var(fold), P1,
                let(var(fcons),abs(var(h),abs(var(t),cons(var(h),var(t)))),
                    let(var(fast_reverse), app(app(var(fold), var(fcons)), nil),
                        seq(app(var(fast_reverse),cons(i(1),cons(i(2),nil))),
                            app(var(fast_reverse),cons(b(true),cons(b(false),nil))))))).

%% Garrigue's polymorphic list example:
%%
%% let l = (let r = ref [] in !r) in l
test_garriguepolylist(P) :-
        P = let(var(l), let(var(r), ref(nil), deref(var(r))), var(l)).

test_garriguepolylist1(P) :-
        P = let(var(l), let(var(r), ref(nil), deref(var(r))),
                seq(if(hd(var(l)),b(true),b(true)),
                    iop(+,hd(var(l)),hd(var(l))))).

%% Garrigue's polymorphic function example:
%%
%% let l = (let r = ref [] in \u . !r) in l
test_garriguepolyfun(P) :-
        P = let(var(f), let(var(r), ref(nil), abs(var(u), deref(var(r)))), var(f)).

%% Map function:
%%
%% \f . \li .
%%   let visit = ref \x . x
%%   in (visit := (\ l . if (l <> [])
%%                       then (f (hd l)) :: (!visit (tl l))
%%                       else [])); !visit li
test_maprec(P) :-
        P = abs(var(f),abs(var(li),
              let(var(visit), ref(abs(var(x), var(x))),
                  seq(assign(var(visit),
                             abs(var(l),
                                 if(blop(<>,var(l),nil),
                                    cons(app(var(f),hd(var(l))),
                                         app(deref(var(visit)),
                                             tl(var(l)))),
                                    nil))),
                      app(deref(var(visit)), var(li)))))).

%% Using partial application of map to id polymorphically:
test_letmapid(P) :-
        test_maprec(PMap),
        P = let(var(map_id), app(PMap, abs(var(x), var(x))),
                seq(app(var(map_id), cons(i(0),nil)),
                    app(var(map_id), cons(b(true),nil)))).

test_letpaapp(P) :-
        P = let(var(fun), abs(var(f), abs(var(x), app(var(f), deref(var(x))))),
                let(var(deref), app(var(fun), abs(var(x), var(x))),
                    seq(app(var(deref), ref(i(0))),
                        app(var(deref), ref(b(true)))))).

test_pairlistref1(P) :-
        P = let(var(r), pair(nil, ref(nil)),
                seq(if(hd(fst(var(r))),b(true),b(true)),
                    iop(+,hd(fst(var(r))),hd(fst(var(r)))))).

%% Leroy and Weis' functional_make_ref
test_lwmakeref2(P) :-
        P = let(var(functional_ref),
                abs(var(x),
                    let(var(r), ref(var(x)),
                        pair(abs(var(u), deref(var(r))),
                             abs(var(z), assign(var(r), var(z)))))),
                let(var(p),app(var(functional_ref), nil),
                    seq(if(app(snd(var(p)), b(true)),b(true),b(true)),
                        iop(+,app(snd(var(p)), i(0)), app(snd(var(p)), i(1)))))).

test_rid(P) :-
        P = let(var(id), abs(var(x), deref(ref(var(x)))),
                seq(app(var(id), b(true)),
                    app(var(id), i(0)))).

%% let f =
%%   let r = ref [] in (fun s = s :: !r)
%% in (f true; f 1)
test_mklist(P) :-
        P = let(var(f),
                let(var(r), ref(nil), abs(var(s), cons(var(s), deref(var(r))))),
                seq(app(var(f), b(true)),
                    app(var(f), i(1)))).

%% let f =
%%   let r = ref [] in (fun s = r := (s :: !r))
%% in (f true; f 1)
test_mkupdlist(P) :-
        P = let(var(f),
                let(var(r), ref(nil), abs(var(s),
                                          assign(var(r),
                                                 cons(var(s), deref(var(r)))))),
                seq(app(var(f), b(true)),
                    app(var(f), i(1)))).


test_loclist(P) :-
        P = cons(ref(i(0)), cons(ref(i(1)), nil)).

%% Negative tests:
%% ===============

%% Application of non-function using store location:
%%
%% let r = ref (\x . x)
%% in (r := (\x . 1); !r !r)
test_destrapp(P) :-
        P = let(var(r), ref(abs(var(x), var(x))),
                seq(assign(var(r), abs(var(x), i(1))),
                    app(deref(var(r)), deref(var(r))))).

%% Self-referential non-polymorphic identity function:
%%
%% let r = ref (\x . x)
%% in !r !r
test_refapp(P) :-
        P = let(var(r), ref(abs(var(x), var(x))),
                app(deref(var(r)), deref(var(r)))).

%% Type error with location containing integer where boolean is
%% expected:
%%
%% let a = \r . if !r then 0 else 1
%% in a (ref 0)
test_badstoif(P) :-
        P = let(var(a),abs(var(r), if(deref(var(r)),
                                      i(0), i(1))),
                app(var(a), ref(i(0)))).

%% Locations are not polymorphic:
%%
%% let a = ref (\x . x)
%% in (!a 0; !a true)
test_seqpolyrestrict(P) :-
        P = let(var(a), ref(abs(var(x), var(x))),
                seq(app(deref(var(a)), i(0)),
                    app(deref(var(a)), b(true)))).

%% If-statement generates two incompatible stores:
%%
%% let r = ref 1
%% in if true then r := true else r := 0
test_incompatif(P) :-
        P = let(var(r), ref(i(1)),
                if(b(true),
                   assign(var(r), b(false)),
                   assign(var(r), i(0)))).

test_pairlistref2(P) :-
        P = let(var(r), pair(nil, ref(nil)),
                seq(if(hd(snd(var(r))),b(true),b(true)),
                    iop(+,hd(snd(var(r))),hd(snd(var(r)))))).

test_makerefbad(P) :-
        P = let(var(make_ref), abs(var(x), ref(var(x))),
                let(var(l), app(var(make_ref), nil),
                    seq(if(hd(fst(var(r))),b(true),b(true)),
                        iop(+,hd(snd(var(r))),hd(snd(var(r))))))).

%% Leroy and Weis' functional_make_ref
test_lwmakeref1(P) :-
        P = let(var(functional_ref),
                abs(var(x),
                    let(var(r), ref(var(x)),
                        pair(abs(var(u), deref(var(r))),
                             abs(var(z), assign(var(r), var(z)))))),
                let(var(p),app(var(functional_ref), nil),
                    let(var(e), app(fst(var(p)), nil),
                        seq(if(hd(var(e)),b(true),b(true)),
                            iop(+,hd(var(e)),hd(var(e))))))).

%% the store location, while limited to be used inside the let, cannot
%% be generalised, as it "escapes" and is added to the global store.
test_garriguepolyfun1(P) :-
        P = let(var(f), let(var(r), ref(nil), abs(var(u), deref(var(r)))),
                seq(if(hd(app(var(f),nil)),b(true),b(true)),
                    iop(+,hd(app(var(f),nil)),hd(app(var(f),nil))))).

%% let r = ref []
%% in let f = (fun s = r := (s :: !r))
%%    in (f true; f 1)
test_mkupdlistbad(P) :-
        P = let(var(r), ref(nil),
                let(var(f), abs(var(s), assign(var(r), cons(var(s), deref(var(r))))),
                    seq(app(var(f), b(true)),
                        app(var(f), i(1))))).
