:- ensure_loaded(ml_based).
:- ensure_loaded(tests).

negative :-
	do_ntest(test_destrapp),
	do_ntest(test_refapp),
	do_ntest(test_badstoif),
	do_ntest(test_seqpolyrestrict),
	do_ntest(test_absupdint),
	do_ntest(test_incompatif),
	do_ntest(test_foldfast),
	do_ntest(test_letmapid),
	do_ntest(test_pairlistref1),
	do_ntest(test_pairlistref2),
	do_ntest(test_makerefbad),
	do_ntest(test_lwmakeref1),
	do_ntest(test_lwmakeref2),
	do_ntest(test_garriguepolyfun1),
	do_ntest(test_mklist),
	do_ntest(test_mkupdlist),
	do_ntest(test_mkupdlistbad).

positive :-
	do_test(test_id, fun(A, A)),
	do_test(test_clo, fun(fun(Z, Z), fun(X, X))),
	do_test(test_eff, fun(fun(Z, Z), bool)),
	do_test(test_app, fun(A, A)),
	do_test(test_absderef, fun(tref(X), X)),
	do_test(test_cyclicpierce, tref(fun(B, int))),
	do_test(test_cyclicpierceeta, fun(A, tref(fun(B, int)))),
	do_test(test_okstoif, int),
	do_test(test_infalloc, int),
	do_test(test_facknot, int),
	do_test(test_fastrevrec, list(int)),
	%% unification to only produce lists presumably due to use of
	%% identity function as means of making recursive knot:
	do_test(test_fastrevfoldrec,
		fun(fun(A, fun(list(B), list(B))),
		    fun(list(B), fun(list(A), list(B))))),
	do_test(test_garriguepolylist, list(T)),
	do_test(test_garriguepolyfun, fun(A, list(T))),
	do_test(test_maprec, fun(fun(A, B),
				 fun(list(A), list(B)))),
	do_test(test_rid, int).


do_test(T, Tau) :-
	print(T), print(' ... '),
	call(T, P),
	( infer([], P, Tau_), Tau = Tau_ ->
	  print('Pass')
	; print('Fail!') ),
	nl.
do_ntest(T) :-
	print(T), print(' ... '),
	call(T, P),
	( infer([], P, _) ->
	  print('Fail!')
	; print('Pass') ),
	nl.

test :-
	print('POSITIVE TESTS'), nl,
	print('**************'), nl,
	positive,
	nl,
	print('NEGATIVE TESTS'), nl,
	print('**************'), nl,
	negative.
