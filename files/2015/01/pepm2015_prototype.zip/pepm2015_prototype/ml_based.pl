%%% ML-STYLE DAMAS-MILNER TYPE INFERENCE %%%

:- set_prolog_flag(occurs_check,true).

%% %%%%%%%%%%%% %%
%% TYPING RULES %%
%% %%%%%%%%%%%% %%

val(b(_)).
val(i(_)).
val(abs(_, _)).

infer(_, b(_), bool).
infer(_, i(_), int).
infer(A, var(X), Tau) :-
        memberchk((var(X), Sigma), A),
        inst(Sigma, Tau), !.
infer(A, abs(var(X), E), fun(Tau_, Tau)) :-
        infer([(var(X), Tau_)|A], E, Tau), !.
infer(A, app(E, E_), Tau) :-
        infer(A, E, fun(Tau_, Tau)),
        infer(A, E_, Tau_), !.
infer(A, let(var(X), E_, E), Tau) :-
        val(E_),
        infer(A, E_, Tau_),
        gen(A, Tau_, Sigma),
        infer([(var(X), Sigma)|A], E, Tau), !.
infer(A, let(var(X), E_, E), Tau) :-
        \+ val(E_),
        infer(A, E_, Tau_),
        infer([(var(X), Tau_)|A], E, Tau), !.
infer(A, ref(E), tref(Tau)) :-
        infer(A, E, Tau), !.
infer(A, deref(E), Tau) :-
        infer(A, E, tref(Tau)), !.
infer(A, assign(E1, E2), Tau) :-
        infer(A, E1, tref(Tau)),
        infer(A, E2, Tau), !.
infer(A, pair(E1, E2), pair(Tau1, Tau2)) :-
        infer(A, E1, Tau1),
        infer(A, E2, Tau2), !.
infer(A, seq(E1, E2), Tau2) :-
        infer(A, E1, _),
        infer(A, E2, Tau2), !.
infer(A, if(E, E1, E2), Tau2) :-
        infer(A, E, bool),
        infer(A, E1, Tau1),
        infer(A, E2, Tau2),
        Tau1 = Tau2, !.
infer(A, iop(_, E1, E2), int) :-
        infer(A, E1, int),
        infer(A, E2, int).
infer(A, bop(_, E1, E2), bool) :-
        infer(A, E1, int),
        infer(A, E2, int).
infer(A, blop(_, E1, E2), bool) :-
        infer(A, E1, list(Tau)),
        infer(A, E2, list(Tau)), !.
%% List handling:
infer(A, cons(E1, E2), list(Tau)) :-
        infer(A, E1, Tau),
        infer(A, E2, list(Tau)), !.
infer(_, nil, list(_)).
infer(A, hd(E), Tau) :-
        infer(A, E, list(Tau)), !.
infer(A, tl(E), list(Tau)) :-
        infer(A, E, list(Tau)), !.

infergen(E, T) :-
        infer([], E, T_),
        gen([], T_, T).

%% %%%%%%%%% %%
%% UTILITIES %%
%% %%%%%%%%% %%

inst(Tau, Tau_) :-
        ( var(Tau) ->
          Tau = Tau_
        ; Tau = forall(Alphas, Tau0) -> % instantiate all free term variables to fresh Prolog variables
          copy_term(Tau0, Tau_),
          reconstruct_dependencies(Alphas, Tau0, Tau_)
        ; Tau = Tau_ ).
gen(A, Tau, Sigma) :-
        free_vars(A, Vs),
        free_vars(Tau, Vs_Tau),
        strict_diff(Vs_Tau, Vs, Alphas),
        ( length(Alphas, 0) ->
          Sigma = Tau
        ; Sigma = forall(Alphas, Tau) ).


%% [free_vars] is a safe approximation of the free variables, under
%% the invariant that all variables are constructed using the
%% predicates below. Strictly speaking, [term_variables] will include
%% bound forall-quantified variables. However, by construction these
%% variables will be replaced by fresh ones using [inst], and hence
%% will not occur inside any other types. Including the bound
%% variables in [free_vars] therefore makes no difference.
free_vars(A, Vs) :-
        term_variables(A, Vs).

%% All variables that are not in [Alphas] must be identical between
%% [Tau] and [Tau_] to preserve dependencies with other terms in the
%% current environment.
reconstruct_dependencies(Alphas, Tau, Tau_) :-
        ( ( var(Tau), var(Tau_) ) ->
          ( strict_memberchk(Tau, Alphas) ->
            true
          ; Tau = Tau_ )
        ; ( is_list(Tau), is_list(Tau_) ) ->
          ( ( Tau = [], Tau_ = [] ) ->
            true
          ; ( Tau = [Tau0|Ts], Tau_ = [Tau0_|Ts_] ) ->
            reconstruct_dependencies(Alphas, Tau0, Tau0_),
            reconstruct_dependencies(Alphas, Ts, Ts_) )
        ; ( Tau =.. [F|Args], Tau_ =.. [F|Args_] ) ->
          reconstruct_dependencies(Alphas, Args, Args_) ).

strict_diff([], _, []).
strict_diff([A|As], Bs, [A|Cs]) :-
        \+ strict_memberchk(A, Bs),
        strict_diff(As, Bs, Cs).
strict_diff([A|As], Bs, Cs) :-
        strict_memberchk(A, Bs),
        strict_diff(As, Bs, Cs).
strict_memberchk(A, [A_|Bs]) :-
        ( A == A_ ->
          true
        ; strict_memberchk(A, Bs) ).
