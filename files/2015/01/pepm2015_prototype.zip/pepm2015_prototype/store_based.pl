%%% STORE-BASED TYPES WITH DAMAS-MILNER TYPE INFERENCE %%%

:- set_prolog_flag(occurs_check,true).

%% %%%%%%%%%%%% %%
%% TYPING RULES %%
%% %%%%%%%%%%%% %%

infer(_, b(_), S, bool, S).
infer(_, i(_), S, int, S).
infer(A, var(X), S, Tau, S) :-
        memberchk((var(X), Sigma), A),
        inst(Sigma, T), T = Tau, !.
infer(_, l(L), S, l(L), S).
infer(A, abs(var(X), E), S, fun(Tau_, S0, Tau, S_Delta), S) :-
        infer([(var(X), Tau_)|A], E, S0, Tau, S0_),
        sdiff(S0, S0_, S_Delta), !.
infer(A, app(E, E_), S, Tau, S__PlusDelta) :-
        infer(A, E, S, fun(Tau_, S0, Tau, S_Delta), S_),
        infer(A, E_, S_, Tau_, S__),
        ( var(S0) -> S0 = [] ; true ), % Hack
        scompat(S0, S__), !,
        sadd(S__, S_Delta, S__PlusDelta), !.
infer(A, let(var(X), E1, E2), S, Tau, S__) :-
        infer(A, E1, S, Tau_, S_),
        gen(A, Tau_, S_, Sigma),
        infer([(var(X), Sigma)|A], E2, S_, Tau, S__), !.
infer(A, ref(E), S, l(L), [(l(L), Tau)|S_]) :-
        infer(A, E, S, Tau, S_),
        fresh_loc(L), !.
infer(A, deref(E), S, Tau, S_) :-
        infer(A, E, S, l(L), S_),
        memberchk((l(L), Tau), S_), !.
infer(A, assign(E1, E2), S, Tau, S__L) :-
        infer(A, E1, S, l(L), S_),
        infer(A, E2, S_, Tau, S__),
        memberchk((l(L), _), S__),
        strict_update((l(L), Tau), S__, S__L), !.
infer(A, pair(E1, E2), S, tpair(Tau1, Tau2), S__) :-
        infer(A, E1, S, Tau1, S_),
        infer(A, E2, S_, Tau2, S__), !.
infer(A, fst(E), S, Tau1, S_) :-
        infer(A, E, S, tpair(Tau1, _), S_), !.
infer(A, snd(E), S, Tau2, S_) :-
        infer(A, E, S, tpair(_, Tau2), S_), !.
infer(A, seq(E1, E2), S, Tau2, S__) :-
        infer(A, E1, S, _, S_),
        infer(A, E2, S_, Tau2, S__), !.
infer(A, if(E, E1, E2), S, Tau2, S0) :-
        infer(A, E, S, bool, S_),
        infer(A, E1, S_, Tau1, S_1),
        infer(A, E2, S_, Tau2, S_2),
        scompat(S_1, S_2), !,
        strict_union(S_1, S_2, S0),
        Tau1 = Tau2, !.
infer(A, iop(_, E1, E2), S, int, S__) :-
        infer(A, E1, S, int, S_),
        infer(A, E2, S_, int, S__), !.
infer(A, bop(_, E1, E2), S, bool, S__) :-
        infer(A, E1, S, int, S_),
        infer(A, E2, S_, int, S__), !.
infer(A, blop(_, E1, E2), S, bool, S__) :-
        infer(A, E1, S, list(Tau), S_),
        infer(A, E2, S_, list(Tau), S__), !.
%% List handling:
infer(A, cons(E1, E2), S, list(Tau), S__) :-
        infer(A, E1, S, Tau, S_),
        infer(A, E2, S_, list(Tau), S__), !.
infer(_, nil, S, list(_), S).
infer(A, hd(E), S, Tau, S_) :-
        infer(A, E, S, list(Tau), S_), !.
infer(A, tl(E), S, list(Tau), S_) :-
        infer(A, E, S, list(Tau), S_), !.

infergen(E, T, S) :-
        infer([], E, [], T_, S),
        gen([], T_, S, T).

%% %%%%%%%%% %%
%% UTILITIES %%
%% %%%%%%%%% %%

inst(Tau, Tau_) :-
        ( var(Tau) ->
          Tau = Tau_
        ; Tau = forall(Alphas, Tau0) -> % instantiate all free term variables to fresh Prolog variables
          copy_term(Tau0, Tau_),
          reconstruct_dependencies(Alphas, Tau0, Tau_)
        ; Tau = Tau_ ).
gen(A, Tau, S, Sigma) :-
        free_vars(A, Vs_A),
        ( nonvar(S) -> free_vars(S, Vs_S) ; Vs_S = []),
        strict_union(Vs_A, Vs_S, Vs),
        free_vars(Tau, Vs_Tau),
        strict_diff(Vs_Tau, Vs, Alphas),
        ( length(Alphas, 0) ->
          Sigma = Tau
        ; Sigma = forall(Alphas, Tau) ).

%% Computes the union between two lists without unifying any of the
%% members
strict_union([], Ys, Ys).
strict_union(Xs, [], Xs).
strict_union([X|Xs], Ys, XYs) :-
        strict_memberchk(X, Ys), !,
        strict_union(Xs, Ys, XYs).
strict_union([X|Xs], Ys, XYs) :-
        \+ strict_memberchk(X, Ys), !,
        strict_union(Xs, Ys, XYs).

%% Computes the difference between two stores: each location that is
%% updated from S1 to S2 is added to the difference; and each new
%% location in S2 relative to S1 is added to the difference.
sdiff(S1s, [], S1s).
sdiff([], S2s, S2s).
sdiff([(L, Tau)|S1s], S2s, Ss) :- % If L is unchanged
        ( selectchk((L, Tau), S2s, S2s_),
          sdiff(S1s, S2s_, Ss) ).
sdiff([(L, _)|S1s], S2s, [(L, Tau0)|Ss]) :- % If L is changed
        ( selectchk((L, Tau0), S2s, S2s_),
          sdiff(S1s, S2s_, Ss) ).

%% Adds two stores by overwriting all locations that are in the domain
%% of both S1 and S2 by the value of S2.
sadd(S1s, [], S1s).
sadd([], S2s, S2s).
sadd(S1s, [(L, Tau)|S2s], [(L, Tau)|Ss]) :-
        ( selectchk((L, _), S1s, S1s_),
          sadd(S1s_, S2s,Ss) ).
sadd(S1s, [(L, Tau)|S2s], [(L, Tau)|Ss]) :-
        ( \+ memberchk((L, _), S1s),
          sadd(S1s, S2s,Ss) ).

%% scompat(S1, S2) holds whenever all locations that occur in both S1
%% and S2 are compatible.
scompat(S1s, S2s) :- var(S1s), !, unify_tails(S1s, S2s).
scompat([], _) :- !.
scompat([(L, TauA)|S1s], S2s) :-
        memberchk((L, TauB), S2s),
        typecompat(TauA, TauB),
        scompat(S1s, S2s).

%% Auxiliary predicate that avoids unifying the tail with the empty
%% list when both tails are variables.
unify_tails(S1s, S2s) :- var(S1s), var(S2s), !, S1s = S2s.
unify_tails([], []).
unify_tails(S1s, [_|S2s]) :- unify_tails(S1s, S2s).

typecompat(A, A).
typecompat(fun(X1, S1, X2, S2), fun(Y1, T1, Y2, T2)) :-
        typecompat(X1, Y1),
        typecompat(X2, Y2),
        scompat(S1, T1),
        sadd(S1, S2, S0),
        sadd(T1, T2, T0),
        scompat(S0, T0).

%% [free_vars] is a safe approximation of the free variables, under
%% the invariant that all variables are constructed using the
%% predicates below. Strictly speaking, [term_variables] will include
%% bound forall-quantified variables. However, by construction these
%% variables will be replaced by fresh ones using [inst], and hence
%% will not occur inside any other types. Including the bound
%% variables in [free_vars] therefore makes no difference.
free_vars(A, Vs) :-
        term_variables(A, Vs).

%% All variables that are not in [Alphas] must be identical between
%% [Tau] and [Tau_] to preserve dependencies with other terms in the
%% current environment.
reconstruct_dependencies(Alphas, Tau, Tau_) :-
        ( ( var(Tau), var(Tau_) ) ->
          ( strict_memberchk(Tau, Alphas) ->
            true
          ; Tau = Tau_ )
        ; ( is_list(Tau), is_list(Tau_) ) ->
          ( ( Tau = [], Tau_ = [] ) ->
            true
          ; ( Tau = [Tau0|Ts], Tau_ = [Tau0_|Ts_] ) ->
            reconstruct_dependencies(Alphas, Tau0, Tau0_),
            reconstruct_dependencies(Alphas, Ts, Ts_) )
        ; ( Tau =.. [F|Args], Tau_ =.. [F|Args_] ) ->
          reconstruct_dependencies(Alphas, Args, Args_) ).

%% Computes the difference between two sets using strict_memberchk,
%% which does not unify variables.
strict_diff([], _, []).
strict_diff([A|As], Bs, [A|Cs]) :-
        \+ strict_memberchk(A, Bs),
        strict_diff(As, Bs, Cs).
strict_diff([A|As], Bs, Cs) :-
        strict_memberchk(A, Bs),
        strict_diff(As, Bs, Cs).
strict_memberchk(A, [A_|Bs]) :-
        ( A == A_ ->
          true
        ; nonvar(Bs) ->
          strict_memberchk(A, Bs) ).

strict_update((L, X), S, T) :-
        ( var(S) ->
          T = [(L, X)|S]
        ; S = [] ->
          T = []
        ; S = [(L, _)|S_] ->
          T = [(L, X)|S_]
        ; S = [(K, Y)|S_] ->
          K \= L,
          strict_update((L, X), S_, T_),
          T = [(K, Y)|T_] ).

%% Generate fresh location
fresh_loc(M) :-
        loc_counter(N),
        M is N + 1,
        retract(loc_counter(_)),
        assert(loc_counter(M)).

:- dynamic loc_counter/1.
loc_counter(0).
