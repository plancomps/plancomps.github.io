:- module(vanilla,[msos_steps/3]).

:- include('../lib/msos.pl').
:- include('../lib/label_sem.pl').
:- consult('../rules/transition_rules.pl').
:- include('../evaluation/evaluation_rules_no_refocus.pl').
