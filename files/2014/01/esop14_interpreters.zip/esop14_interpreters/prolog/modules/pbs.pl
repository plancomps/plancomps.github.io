:- module(pbs,[msos_steps/3]).

:- include('../lib/msos.pl').
:- include('../lib/label_sem.pl').
:- consult('../rules/pbs.pl').
