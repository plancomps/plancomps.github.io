:- module(refocused,[msos_steps/3]).

:- include('../lib/msos.pl').
:- include('../lib/label_sem.pl').
:- consult('../rules/transition_rules_refocused.pl').
:- include('../evaluation/evaluation_rules_no_refocus.pl').
