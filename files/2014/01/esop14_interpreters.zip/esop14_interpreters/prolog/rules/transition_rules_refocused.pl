%% [eval(3,refocus),funcon(m,31)]
msos_step(t(bop(_G1531,v(_G1535),v(_G1537))),_G1504,v(_G1553)) :-
        msos_label_instance(_G14441,[exc=v(tau),exc+=_G1520|_G6327]),
        msos_label_instance(_G14447,_G6337),
        msos_is_comp(_G1504,_G14441,_G14447),
        msos_unobs_label([exc=v(tau),exc+=_G1520|_G6327]),
        msos_bop(_G1531,_G1535,_G1537,_G1553),
        msos_unobs_label(_G6337),
        msos_is_comp_w(_G1504,[exc=v(tau),exc+=_G1520|_G6327],_G6337).

%% [eval(3,refocus),funcon(m,30)]
msos_step(t(bop(_G1649,v(_G1653),t(_G1655))),_G1622,_G1684) :-
        msos_label_instance(_G11519,[exc=v(tau),exc+=_G1638|_G1635]),
        msos_label_instance(_G11525,_G1624),
        msos_is_comp(_G1622,_G11519,_G11525),
        msos_label_instance(_G11538,[exc=v(tau),exc+=_G1638|_G1635]),
        msos_step(t(_G1655),_G11538,_G1675),
        msos_steps(t(bop(_G1649,v(_G1653),_G1675)),_G1624,_G1684),
        msos_is_comp_w(_G1622,[exc=v(tau),exc+=_G1638|_G1635],_G1624).

%% [eval(3,refocus),funcon(m,29)]
msos_step(t(bop(_G1769,t(_G1773),_G1771)),_G1742,_G1800) :-
        msos_label_instance(_G13432,[exc=v(tau),exc+=_G1758|_G1755]),
        msos_label_instance(_G13438,_G1744),
        msos_is_comp(_G1742,_G13432,_G13438),
        msos_label_instance(_G13451,[exc=v(tau),exc+=_G1758|_G1755]),
        msos_step(t(_G1773),_G13451,_G1792),
        msos_steps(t(bop(_G1769,_G1792,_G1771)),_G1744,_G1800),
        msos_is_comp_w(_G1742,[exc=v(tau),exc+=_G1758|_G1755],_G1744).

%% [eval(3,refocus),funcon(m,28)]
msos_step(t(for(_G1885,_G1886,_G1887)),_G1858,_G1932) :-
        msos_label_instance(_G15327,[exc=v(tau),exc+=_G1874|_G6646]),
        msos_label_instance(_G15333,_G1860),
        msos_is_comp(_G1858,_G15327,_G15333),
        msos_unobs_label([exc=v(tau),exc+=_G1874|_G6646]),
        msos_steps(t(if(_G1885,t(seq(_G1887,t(seq(_G1886,t(for(_G1885,_G1886,_G1887)))))),v(unit))),_G1860,_G1932),
        msos_is_comp_w(_G1858,[exc=v(tau),exc+=_G1874|_G6646],_G1860).

%% [eval(3,refocus),funcon(m,27)]
msos_step(t(seq(v(_G2016),_G2009)),_G1986,_G2037) :-
        msos_label_instance(_G16252,[exc=v(tau),exc+=_G2002|_G6789]),
        msos_label_instance(_G16258,_G1988),
        msos_is_comp(_G1986,_G16252,_G16258),
        msos_unobs_label([exc=v(tau),exc+=_G2002|_G6789]),
        msos_steps(_G2009,_G1988,_G2037),
        msos_is_comp_w(_G1986,[exc=v(tau),exc+=_G2002|_G6789],_G1988).

%% [eval(3,refocus),funcon(m,26)]
msos_step(t(seq(t(_G2121),_G2119)),_G2091,_G2147) :-
        msos_label_instance(_G17873,[exc=v(tau),exc+=_G2107|_G2104]),
        msos_label_instance(_G17879,_G2093),
        msos_is_comp(_G2091,_G17873,_G17879),
        msos_label_instance(_G17892,[exc=v(tau),exc+=_G2107|_G2104]),
        msos_step(t(_G2121),_G17892,_G2139),
        msos_steps(t(seq(_G2139,_G2119)),_G2093,_G2147),
        msos_is_comp_w(_G2091,[exc=v(tau),exc+=_G2107|_G2104],_G2093).

%% [eval(3,refocus),funcon(m,25)]
msos_step(t(assign(v(loc(_G2249)),v(_G2251))),_G2205,v(_G2251)) :-
        msos_label_instance(_G19736,[exc=v(tau),exc+=_G2221,sto=_G2227,sto+=_G2233|_G7018]),
        msos_label_instance(_G19742,_G7028),
        msos_is_comp(_G2205,_G19736,_G19742),
        msos_unobs_label([sto=_G2227,sto+=_G2227,exc=v(tau),exc+=_G2221|_G7018]),
        map_update(_G2227,_G2249,v(_G2251),_G2233),
        msos_unobs_label(_G7028),
        msos_is_comp_w(_G2205,[exc=v(tau),exc+=_G2221,sto=_G2227,sto+=_G2233|_G7018],_G7028).

%% [eval(3,refocus),funcon(m,24)]
msos_step(t(assign(v(loc(_G2382)),t(_G2384))),_G2350,_G2414) :-
        msos_label_instance(_G21750,[exc=v(tau),exc+=_G2366|_G2363]),
        msos_label_instance(_G21756,_G2352),
        msos_is_comp(_G2350,_G21750,_G21756),
        msos_label_instance(_G21769,[exc=v(tau),exc+=_G2366|_G2363]),
        msos_step(t(_G2384),_G21769,_G2403),
        msos_steps(t(assign(v(loc(_G2382)),_G2403)),_G2352,_G2414),
        msos_is_comp_w(_G2350,[exc=v(tau),exc+=_G2366|_G2363],_G2352).

%% [eval(3,refocus),funcon(m,23)]
msos_step(t(assign(t(_G2502),_G2500)),_G2472,_G2528) :-
        msos_label_instance(_G23669,[exc=v(tau),exc+=_G2488|_G2485]),
        msos_label_instance(_G23675,_G2474),
        msos_is_comp(_G2472,_G23669,_G23675),
        msos_label_instance(_G23688,[exc=v(tau),exc+=_G2488|_G2485]),
        msos_step(t(_G2502),_G23688,_G2520),
        msos_steps(t(assign(_G2520,_G2500)),_G2474,_G2528),
        msos_is_comp_w(_G2472,[exc=v(tau),exc+=_G2488|_G2485],_G2474).

%% [eval(3,refocus),funcon(m,22)]
msos_step(t(deref(v(loc(_G2629)))),_G2586,v(_G2645)) :-
        msos_label_instance(_G25550,[exc=v(tau),exc+=_G2602,sto=_G2608,sto+=_G2608|_G7376]),
        msos_label_instance(_G25556,_G7386),
        msos_is_comp(_G2586,_G25550,_G25556),
        msos_unobs_label([sto=_G2608,sto+=_G2608,exc=v(tau),exc+=_G2602|_G7376]),
        map_member(_G2608,_G2629,v(_G2645)),
        msos_unobs_label(_G7386),
        msos_is_comp_w(_G2586,[exc=v(tau),exc+=_G2602,sto=_G2608,sto+=_G2608|_G7376],_G7386).

%% [eval(3,refocus),funcon(m,21)]
msos_step(t(deref(t(_G2756))),_G2727,_G2781) :-
        msos_label_instance(_G27510,[exc=v(tau),exc+=_G2743|_G2740]),
        msos_label_instance(_G27516,_G2729),
        msos_is_comp(_G2727,_G27510,_G27516),
        msos_label_instance(_G27529,[exc=v(tau),exc+=_G2743|_G2740]),
        msos_step(t(_G2756),_G27529,_G2774),
        msos_steps(t(deref(_G2774)),_G2729,_G2781),
        msos_is_comp_w(_G2727,[exc=v(tau),exc+=_G2743|_G2740],_G2729).

%% [eval(3,refocus),funcon(m,20)]
msos_step(t(ref(v(_G2880))),_G2839,v(loc(_G2898))) :-
        msos_label_instance(_G29353,[exc=v(tau),exc+=_G2855,sto=_G2861,sto+=_G2867|_G7655]),
        msos_label_instance(_G29359,_G7668),
        msos_is_comp(_G2839,_G29353,_G29359),
        msos_unobs_label([sto=_G2861,sto+=_G2861,exc=v(tau),exc+=_G2855|_G7655]),
        map_fresh_id(_G2898),
        map_update(_G2861,_G2898,v(_G2880),_G2867),
        msos_unobs_label(_G7668),
        msos_is_comp_w(_G2839,[exc=v(tau),exc+=_G2855,sto=_G2861,sto+=_G2867|_G7655],_G7668).

%% [eval(3,refocus),funcon(m,19)]
msos_step(t(ref(t(_G3015))),_G2986,_G3040) :-
        msos_label_instance(_G31430,[exc=v(tau),exc+=_G3002|_G2999]),
        msos_label_instance(_G31436,_G2988),
        msos_is_comp(_G2986,_G31430,_G31436),
        msos_label_instance(_G31449,[exc=v(tau),exc+=_G3002|_G2999]),
        msos_step(t(_G3015),_G31449,_G3033),
        msos_steps(t(ref(_G3033)),_G2988,_G3040),
        msos_is_comp_w(_G2986,[exc=v(tau),exc+=_G3002|_G2999],_G2988).

%% [eval(3,refocus),funcon(m,18)]
msos_step(t(print(v(_G3125))),_G3098,v(unit)) :-
        msos_label_instance(_G30396,[exc=v(tau),exc+=_G3114,out+=[v(_G3125)]|_G7912]),
        msos_label_instance(_G30402,_G7919),
        msos_is_comp(_G3098,_G30396,_G30402),
        msos_unobs_label([out+=[],exc=v(tau),exc+=_G3114|_G7912]),
        msos_unobs_label(_G7919),
        msos_is_comp_w(_G3098,[exc=v(tau),exc+=_G3114,out+=[v(_G3125)]|_G7912],_G7919).

%% [eval(3,refocus),funcon(m,17)]
msos_step(t(print(t(_G3250))),_G3221,_G3275) :-
        msos_label_instance(_G32107,[exc=v(tau),exc+=_G3237|_G3234]),
        msos_label_instance(_G32113,_G3223),
        msos_is_comp(_G3221,_G32107,_G32113),
        msos_label_instance(_G32126,[exc=v(tau),exc+=_G3237|_G3234]),
        msos_step(t(_G3250),_G32126,_G3268),
        msos_steps(t(print(_G3268)),_G3223,_G3275),
        msos_is_comp_w(_G3221,[exc=v(tau),exc+=_G3237|_G3234],_G3223).

%% [eval(3,refocus),funcon(m,16)]
msos_step(t(catch(t(_G3365),_G3363)),_G3333,_G3409) :-
        msos_label_instance(_G33930,[exc=v(tau),exc+=v(tau)|_G3346]),
        msos_label_instance(_G33936,_G3335),
        msos_is_comp(_G3333,_G33930,_G33936),
        msos_label_instance(_G33949,[exc=v(tau),exc+=_G3389|_G3346]),
        msos_step(t(_G3365),_G33949,_G3396),
        msos_steps(t(if(t(eq(_G3389,v(tau))),t(catch(_G3396,_G3363)),t(app(_G3363,_G3389)))),_G3335,_G3409),
        msos_is_comp_w(_G3333,[exc=v(tau),exc+=v(tau)|_G3346],_G3335).

%% [eval(3,refocus),funcon(m,15)]
msos_step(t(catch(v(_G3505),_G3503)),_G3475,v(_G3505)) :-
        msos_label_instance(_G35945,[exc=v(tau),exc+=_G3491|_G8219]),
        msos_label_instance(_G35951,_G8226),
        msos_is_comp(_G3475,_G35945,_G35951),
        msos_unobs_label([exc=v(tau),exc+=_G3491|_G8219]),
        msos_unobs_label(_G8226),
        msos_is_comp_w(_G3475,[exc=v(tau),exc+=_G3491|_G8219],_G8226).

%% [eval(3,refocus),funcon(m,14)]
msos_step(t(eq(v(_G3612),v(_G3614))),_G3582,v(false)) :-
        msos_label_instance(_G37567,[exc=v(tau),exc+=_G3598|_G8353]),
        msos_label_instance(_G37573,_G8363),
        msos_is_comp(_G3582,_G37567,_G37573),
        msos_unobs_label([exc=v(tau),exc+=_G3598|_G8353]),
        msos_neq(_G3612,_G3614),
        msos_unobs_label(_G8363),
        msos_is_comp_w(_G3582,[exc=v(tau),exc+=_G3598|_G8353],_G8363).

%% [eval(3,refocus),funcon(m,13)]
msos_step(t(eq(v(_G3727),v(_G3729))),_G3697,v(true)) :-
        msos_label_instance(_G39297,[exc=v(tau),exc+=_G3713|_G8498]),
        msos_label_instance(_G39303,_G8508),
        msos_is_comp(_G3697,_G39297,_G39303),
        msos_unobs_label([exc=v(tau),exc+=_G3713|_G8498]),
        msos_eq(_G3727,_G3729),
        msos_unobs_label(_G8508),
        msos_is_comp_w(_G3697,[exc=v(tau),exc+=_G3713|_G8498],_G8508).

%% [eval(3,refocus),funcon(m,12)]
msos_step(t(eq(v(_G3842),t(_G3844))),_G3812,_G3872) :-
        msos_label_instance(_G41011,[exc=v(tau),exc+=_G3828|_G3825]),
        msos_label_instance(_G41017,_G3814),
        msos_is_comp(_G3812,_G41011,_G41017),
        msos_label_instance(_G41030,[exc=v(tau),exc+=_G3828|_G3825]),
        msos_step(t(_G3844),_G41030,_G3863),
        msos_steps(t(eq(v(_G3842),_G3863)),_G3814,_G3872),
        msos_is_comp_w(_G3812,[exc=v(tau),exc+=_G3828|_G3825],_G3814).

%% [eval(3,refocus),funcon(m,11)]
msos_step(t(eq(t(_G3960),_G3958)),_G3930,_G3986) :-
        msos_label_instance(_G42876,[exc=v(tau),exc+=_G3946|_G3943]),
        msos_label_instance(_G42882,_G3932),
        msos_is_comp(_G3930,_G42876,_G42882),
        msos_label_instance(_G42895,[exc=v(tau),exc+=_G3946|_G3943]),
        msos_step(t(_G3960),_G42895,_G3978),
        msos_steps(t(eq(_G3978,_G3958)),_G3932,_G3986),
        msos_is_comp_w(_G3930,[exc=v(tau),exc+=_G3946|_G3943],_G3932).

%% [eval(3,refocus),funcon(m,10)]
msos_step(t(if(v(false),_G4072,_G4067)),_G4044,_G4096) :-
        msos_label_instance(_G44723,[exc=v(tau),exc+=_G4060|_G8788]),
        msos_label_instance(_G44729,_G4046),
        msos_is_comp(_G4044,_G44723,_G44729),
        msos_unobs_label([exc=v(tau),exc+=_G4060|_G8788]),
        msos_steps(_G4067,_G4046,_G4096),
        msos_is_comp_w(_G4044,[exc=v(tau),exc+=_G4060|_G8788],_G4046).

%% [eval(3,refocus),funcon(m,9)]
msos_step(t(if(v(true),_G4173,_G4179)),_G4150,_G4202) :-
        msos_label_instance(_G46359,[exc=v(tau),exc+=_G4166|_G8909]),
        msos_label_instance(_G46365,_G4152),
        msos_is_comp(_G4150,_G46359,_G46365),
        msos_unobs_label([exc=v(tau),exc+=_G4166|_G8909]),
        msos_steps(_G4173,_G4152,_G4202),
        msos_is_comp_w(_G4150,[exc=v(tau),exc+=_G4166|_G8909],_G4152).

%% [eval(3,refocus),funcon(m,8)]
msos_step(t(if(t(_G4287),_G4284,_G4285)),_G4256,_G4314) :-
        msos_label_instance(_G47983,[exc=v(tau),exc+=_G4272|_G4269]),
        msos_label_instance(_G47989,_G4258),
        msos_is_comp(_G4256,_G47983,_G47989),
        msos_label_instance(_G48002,[exc=v(tau),exc+=_G4272|_G4269]),
        msos_step(t(_G4287),_G48002,_G4305),
        msos_steps(t(if(_G4305,_G4284,_G4285)),_G4258,_G4314),
        msos_is_comp_w(_G4256,[exc=v(tau),exc+=_G4272|_G4269],_G4258).

%% [eval(3,refocus),funcon(m,7)]
msos_step(t(throw(v(_G4390))),_G4372,v(unit)) :-
        msos_label_instance(_G49863,[exc=v(tau),exc+=v(_G4390)|_G9103]),
        msos_label_instance(_G49869,_G9110),
        msos_is_comp(_G4372,_G49863,_G49869),
        msos_unobs_label([exc=v(tau),exc+=v(tau)|_G9103]),
        msos_unobs_label(_G9110),
        msos_is_comp_w(_G4372,[exc=v(tau),exc+=v(_G4390)|_G9103],_G9110).

%% [eval(3,refocus),funcon(m,6)]
msos_step(t(app(v(clo(_G4522,v(_G4526),_G4524)),v(_G4528))),_G4490,v(_G4526)) :-
        msos_label_instance(_G51457,[exc=v(tau),exc+=_G4506|_G9231]),
        msos_label_instance(_G51463,_G9238),
        msos_is_comp(_G4490,_G51457,_G51463),
        msos_unobs_label([exc=v(tau),exc+=_G4506|_G9231]),
        msos_unobs_label(_G9238),
        msos_is_comp_w(_G4490,[exc=v(tau),exc+=_G4506|_G9231],_G9238).

%% [eval(3,refocus),funcon(m,5)]
msos_step(t(app(v(clo(_G4643,t(_G4647),_G4645)),v(_G4649))),_G4605,_G4683) :-
        msos_label_instance(_G53139,[exc=v(tau),exc+=_G4621,env=_G4627|_G4624]),
        msos_label_instance(_G53145,_G4607),
        msos_is_comp(_G4605,_G53139,_G53145),
        map_update(_G4645,_G4643,v(_G4649),_G4707),
        msos_label_instance(_G53161,[env=_G4707,exc=v(tau),exc+=_G4621|_G4624]),
        msos_step(t(_G4647),_G53161,_G4673),
        msos_steps(t(app(v(clo(_G4643,_G4673,_G4645)),v(_G4649))),_G4607,_G4683),
        msos_is_comp_w(_G4605,[exc=v(tau),exc+=_G4621,env=_G4627|_G4624],_G4607).

%% [eval(3,refocus),funcon(m,4)]
msos_step(t(app(v(_G4787),t(_G4789))),_G4757,_G4817) :-
        msos_label_instance(_G55400,[exc=v(tau),exc+=_G4773|_G4770]),
        msos_label_instance(_G55406,_G4759),
        msos_is_comp(_G4757,_G55400,_G55406),
        msos_label_instance(_G55419,[exc=v(tau),exc+=_G4773|_G4770]),
        msos_step(t(_G4789),_G55419,_G4808),
        msos_steps(t(app(v(_G4787),_G4808)),_G4759,_G4817),
        msos_is_comp_w(_G4757,[exc=v(tau),exc+=_G4773|_G4770],_G4759).

%% [eval(3,refocus),funcon(m,3)]
msos_step(t(app(t(_G4905),_G4903)),_G4875,_G4931) :-
        msos_label_instance(_G57262,[exc=v(tau),exc+=_G4891|_G4888]),
        msos_label_instance(_G57268,_G4877),
        msos_is_comp(_G4875,_G57262,_G57268),
        msos_label_instance(_G57281,[exc=v(tau),exc+=_G4891|_G4888]),
        msos_step(t(_G4905),_G57281,_G4923),
        msos_steps(t(app(_G4923,_G4903)),_G4877,_G4931),
        msos_is_comp_w(_G4875,[exc=v(tau),exc+=_G4891|_G4888],_G4877).

%% [eval(3,refocus),funcon(m,2)]
msos_step(t(abs(_G5022,_G5023)),_G4989,v(clo(_G5022,_G5023,_G5011))) :-
        msos_label_instance(_G59106,[exc=v(tau),exc+=_G5005,env=_G5011|_G9640]),
        msos_label_instance(_G59112,_G9647),
        msos_is_comp(_G4989,_G59106,_G59112),
        msos_unobs_label([env=_G5011,exc=v(tau),exc+=_G5005|_G9640]),
        msos_unobs_label(_G9647),
        msos_is_comp_w(_G4989,[exc=v(tau),exc+=_G5005,env=_G5011|_G9640],_G9647).

%% [eval(3,refocus),funcon(m,1)]
msos_step(t(var(_G5134)),_G5101,v(_G5150)) :-
        msos_label_instance(_G60860,[exc=v(tau),exc+=_G5117,env=_G5123|_G9803]),
        msos_label_instance(_G60866,_G9813),
        msos_is_comp(_G5101,_G60860,_G60866),
        msos_unobs_label([env=_G5123,exc=v(tau),exc+=_G5117|_G9803]),
        map_member(_G5123,_G5134,v(_G5150)),
        msos_unobs_label(_G9813),
        msos_is_comp_w(_G5101,[exc=v(tau),exc+=_G5117,env=_G5123|_G9803],_G9813).


