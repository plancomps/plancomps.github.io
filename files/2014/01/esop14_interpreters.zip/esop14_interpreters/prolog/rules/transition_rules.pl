%% [funcon(m,31)]
msos_step(t(bop(_G20,v(_G21),v(_G22))),_G1642,v(_G23)) :-
        msos_unobs_label(_G1642),
        msos_bop(_G20,_G21,_G22,_G23).

%% [funcon(m,30)]
msos_step(t(bop(_G69,v(_G73),t(_G61))),_G58,t(bop(_G69,v(_G73),_G59))) :-
        msos_step(t__(refocus,t(_G61)),_G58,t__(refocus,_G59)).

%% [funcon(m,29)]
msos_step(t(bop(_G113,t(_G105),_G115)),_G102,t(bop(_G113,_G103,_G115))) :-
        msos_step(t__(refocus,t(_G105)),_G102,t__(refocus,_G103)).

%% [funcon(m,28)]
msos_step(t(for(_G149,_G150,_G151)),_G1764,t(if(_G149,t(seq(_G151,t(seq(_G150,t(for(_G149,_G150,_G151)))))),v(unit)))) :-
        msos_unobs_label(_G1764).

%% [funcon(m,27)]
msos_step(t(seq(v(_G204),_G197)),_G1824,_G197) :-
        msos_unobs_label(_G1824).

%% [funcon(m,26)]
msos_step(t(seq(t(_G226),_G235)),_G223,t(seq(_G224,_G235))) :-
        msos_step(t__(refocus,t(_G226)),_G223,t__(refocus,_G224)).

%% [funcon(m,25)]
msos_step(t(assign(v(loc(_G278)),v(_G282))),_G5987,v(_G282)) :-
        msos_label_instance(_G5987,[sto=_G266,sto+=_G280|_G1918]),
        msos_unobs_label([sto=_G266,sto+=_G266|_G1918]),
        map_update(_G266,_G278,v(_G282),_G280).

%% [funcon(m,24)]
msos_step(t(assign(v(loc(_G346)),t(_G333))),_G330,t(assign(v(loc(_G346)),_G331))) :-
        msos_step(t__(refocus,t(_G333)),_G330,t__(refocus,_G331)).

%% [funcon(m,23)]
msos_step(t(assign(t(_G379),_G388)),_G376,t(assign(_G377,_G388))) :-
        msos_step(t__(refocus,t(_G379)),_G376,t__(refocus,_G377)).

%% [funcon(m,22)]
msos_step(t(deref(v(loc(_G431)))),_G8245,v(_G434)) :-
        msos_label_instance(_G8245,[sto=_G419,sto+=_G419|_G2091]),
        msos_unobs_label([sto=_G419,sto+=_G419|_G2091]),
        map_member(_G419,_G431,v(_G434)).

%% [funcon(m,21)]
msos_step(t(deref(t(_G482))),_G479,t(deref(_G480))) :-
        msos_step(t__(refocus,t(_G482)),_G479,t__(refocus,_G480)).

%% [funcon(m,20)]
msos_step(t(ref(v(_G541))),_G9742,v(loc(_G531))) :-
        msos_label_instance(_G9742,[sto=_G520,sto+=_G539|_G2227]),
        msos_unobs_label([sto=_G520,sto+=_G520|_G2227]),
        map_fresh_id(_G531),
        map_update(_G520,_G531,v(_G541),_G539).

%% [funcon(m,19)]
msos_step(t(ref(t(_G589))),_G586,t(ref(_G587))) :-
        msos_step(t__(refocus,t(_G589)),_G586,t__(refocus,_G587)).

%% [funcon(m,18)]
msos_step(t(print(v(_G637))),_G11332,v(unit)) :-
        msos_label_instance(_G11332,[out+=[v(_G637)]|_G2339]),
        msos_unobs_label([out+=[]|_G2339]).

%% [funcon(m,17)]
msos_step(t(print(t(_G672))),_G669,t(print(_G670))) :-
        msos_step(t__(refocus,t(_G672)),_G669,t__(refocus,_G670)).

%% [funcon(m,16)]
msos_step(t(catch(t(_G708),_G731)),_G12619,t(if(t(eq(_G722,v(tau))),t(catch(_G706,_G731)),t(app(_G731,_G722))))) :-
        msos_label_instance(_G12619,[exc=v(tau),exc+=v(tau)|_G719]),
        msos_label_instance(_G12637,[exc=v(tau),exc+=_G722|_G719]),
        msos_step(t__(refocus,t(_G708)),_G12637,t__(refocus,_G706)).

%% [funcon(m,15)]
msos_step(t(catch(v(_G801),_G799)),_G2504,v(_G801)) :-
        msos_unobs_label(_G2504).

%% [funcon(m,14)]
msos_step(t(eq(v(_G826),v(_G827))),_G2552,v(false)) :-
        msos_unobs_label(_G2552),
        msos_neq(_G826,_G827).

%% [funcon(m,13)]
msos_step(t(eq(v(_G865),v(_G866))),_G2608,v(true)) :-
        msos_unobs_label(_G2608),
        msos_eq(_G865,_G866).

%% [funcon(m,12)]
msos_step(t(eq(v(_G914),t(_G903))),_G900,t(eq(v(_G914),_G901))) :-
        msos_step(t__(refocus,t(_G903)),_G900,t__(refocus,_G901)).

%% [funcon(m,11)]
msos_step(t(eq(t(_G945),_G954)),_G942,t(eq(_G943,_G954))) :-
        msos_step(t__(refocus,t(_G945)),_G942,t__(refocus,_G943)).

%% [funcon(m,10)]
msos_step(t(if(v(false),_G988,_G983)),_G2723,_G983) :-
        msos_unobs_label(_G2723).

%% [funcon(m,9)]
msos_step(t(if(v(true),_G1013,_G1019)),_G2761,_G1013) :-
        msos_unobs_label(_G2761).

%% [funcon(m,8)]
msos_step(t(if(t(_G1043),_G1052,_G1053)),_G1040,t(if(_G1041,_G1052,_G1053))) :-
        msos_step(t__(refocus,t(_G1043)),_G1040,t__(refocus,_G1041)).

%% [funcon(m,7)]
msos_step(t(throw(v(_G1105))),_G16073,v(unit)) :-
        msos_label_instance(_G16073,[exc=v(tau),exc+=v(_G1105)|_G2839]),
        msos_unobs_label([exc=v(tau),exc+=v(tau)|_G2839]).

%% [funcon(m,6)]
msos_step(t(app(v(clo(_G1154,v(_G1158),_G1156)),v(_G1160))),_G2909,v(_G1158)) :-
        msos_unobs_label(_G2909).

%% [funcon(m,5)]
msos_step(t(app(v(clo(_G1181,t(_G1194),_G1180)),v(_G1185))),_G17392,t(app(v(clo(_G1181,_G1192,_G1180)),v(_G1185)))) :-
        msos_label_instance(_G17392,[env=_G1225|_G1197]),
        map_update(_G1180,_G1181,v(_G1185),_G1183),
        msos_label_instance(_G17413,[env=_G1183|_G1197]),
        msos_step(t__(refocus,t(_G1194)),_G17413,t__(refocus,_G1192)).

%% [funcon(m,4)]
msos_step(t(app(v(_G1271),t(_G1260))),_G1257,t(app(v(_G1271),_G1258))) :-
        msos_step(t__(refocus,t(_G1260)),_G1257,t__(refocus,_G1258)).

%% [funcon(m,3)]
msos_step(t(app(t(_G1302),_G1311)),_G1299,t(app(_G1300,_G1311))) :-
        msos_step(t__(refocus,t(_G1302)),_G1299,t__(refocus,_G1300)).

%% [funcon(m,2)]
msos_step(t(abs(_G1350,_G1351)),_G19997,v(clo(_G1350,_G1351,_G1342))) :-
        msos_label_instance(_G19997,[env=_G1342|_G3100]),
        msos_unobs_label([env=_G1342|_G3100]).

%% [funcon(m,1)]
msos_step(t(var(_G1393)),_G20760,v(_G1396)) :-
        msos_label_instance(_G20760,[env=_G1387|_G3171]),
        msos_unobs_label([env=_G1387|_G3171]),
        map_member(_G1387,_G1393,v(_G1396)).


