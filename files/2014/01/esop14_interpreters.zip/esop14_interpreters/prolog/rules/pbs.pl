%% [eval(0,refl)]
msos_steps(v(_G7679),_G7673,v(_G7679)) :-
        msos_unobs_label(_G7673).

%% [eval(2,exc)]
msos_steps(_G7716,_G29262,_G7716) :-
        msos_label_instance(_G29262,[exc=v(_G7692),exc+=v(_G7692)|_G7709]),
        msos_neq(_G7692,tau),
        msos_unobs_label([exc=v(_G7692),exc+=v(_G7692)|_G7709]).

%% [eval(3,refocus),funcon(m,31)]
msos_steps(t(bop(_G2108,v(_G2112),v(_G2114))),_G2081,v(_G2130)) :-
        msos_label_instance(_G30175,[exc=v(tau),exc+=_G2097|_G12652]),
        msos_label_instance(_G30181,_G12662),
        msos_is_comp(_G2081,_G30175,_G30181),
        msos_unobs_label([exc=v(tau),exc+=_G2097|_G12652]),
        msos_bop(_G2108,_G2112,_G2114,_G2130),
        msos_unobs_label(_G12662),
        msos_is_comp_w(_G2081,[exc=v(tau),exc+=_G2097|_G12652],_G12662).

%% [eval(3,refocus),funcon(m,30)]
msos_steps(t(bop(_G2226,v(_G2230),t(_G2232))),_G2199,_G2261) :-
        msos_label_instance(_G31985,[exc=v(tau),exc+=_G2215|_G2212]),
        msos_label_instance(_G31991,_G2201),
        msos_is_comp(_G2199,_G31985,_G31991),
        msos_label_instance(_G32004,[exc=v(tau),exc+=_G2215|_G2212]),
        msos_steps(t(_G2232),_G32004,_G2252),
        msos_steps(t(bop(_G2226,v(_G2230),_G2252)),_G2201,_G2261),
        msos_is_comp_w(_G2199,[exc=v(tau),exc+=_G2215|_G2212],_G2201).

%% [eval(3,refocus),funcon(m,29)]
msos_steps(t(bop(_G2346,t(_G2350),_G2348)),_G2319,_G2377) :-
        msos_label_instance(_G33904,[exc=v(tau),exc+=_G2335|_G2332]),
        msos_label_instance(_G33910,_G2321),
        msos_is_comp(_G2319,_G33904,_G33910),
        msos_label_instance(_G33923,[exc=v(tau),exc+=_G2335|_G2332]),
        msos_steps(t(_G2350),_G33923,_G2369),
        msos_steps(t(bop(_G2346,_G2369,_G2348)),_G2321,_G2377),
        msos_is_comp_w(_G2319,[exc=v(tau),exc+=_G2335|_G2332],_G2321).

%% [eval(3,refocus),funcon(m,28)]
msos_steps(t(for(_G2462,_G2463,_G2464)),_G2435,_G2509) :-
        msos_label_instance(_G35805,[exc=v(tau),exc+=_G2451|_G14208]),
        msos_label_instance(_G35811,_G2437),
        msos_is_comp(_G2435,_G35805,_G35811),
        msos_unobs_label([exc=v(tau),exc+=_G2451|_G14208]),
        msos_steps(t(if(_G2462,t(seq(_G2464,t(seq(_G2463,t(for(_G2462,_G2463,_G2464)))))),v(unit))),_G2437,_G2509),
        msos_is_comp_w(_G2435,[exc=v(tau),exc+=_G2451|_G14208],_G2437).

%% [eval(3,refocus),funcon(m,27)]
msos_steps(t(seq(v(_G2593),_G2586)),_G2563,_G2614) :-
        msos_label_instance(_G37672,[exc=v(tau),exc+=_G2579|_G14797]),
        msos_label_instance(_G37678,_G2565),
        msos_is_comp(_G2563,_G37672,_G37678),
        msos_unobs_label([exc=v(tau),exc+=_G2579|_G14797]),
        msos_steps(_G2586,_G2565,_G2614),
        msos_is_comp_w(_G2563,[exc=v(tau),exc+=_G2579|_G14797],_G2565).

%% [eval(3,refocus),funcon(m,26)]
msos_steps(t(seq(t(_G2698),_G2696)),_G2668,_G2724) :-
        msos_label_instance(_G39305,[exc=v(tau),exc+=_G2684|_G2681]),
        msos_label_instance(_G39311,_G2670),
        msos_is_comp(_G2668,_G39305,_G39311),
        msos_label_instance(_G39324,[exc=v(tau),exc+=_G2684|_G2681]),
        msos_steps(t(_G2698),_G39324,_G2716),
        msos_steps(t(seq(_G2716,_G2696)),_G2670,_G2724),
        msos_is_comp_w(_G2668,[exc=v(tau),exc+=_G2684|_G2681],_G2670).

%% [eval(3,refocus),funcon(m,25)]
msos_steps(t(assign(v(loc(_G2826)),v(_G2828))),_G2782,v(_G2828)) :-
        msos_label_instance(_G41174,[exc=v(tau),exc+=_G2798,sto=_G2804,sto+=_G2810|_G15747]),
        msos_label_instance(_G41180,_G15757),
        msos_is_comp(_G2782,_G41174,_G41180),
        msos_unobs_label([sto=_G2804,sto+=_G2804,exc=v(tau),exc+=_G2798|_G15747]),
        map_update(_G2804,_G2826,v(_G2828),_G2810),
        msos_unobs_label(_G15757),
        msos_is_comp_w(_G2782,[exc=v(tau),exc+=_G2798,sto=_G2804,sto+=_G2810|_G15747],_G15757).

%% [eval(3,refocus),funcon(m,24)]
msos_steps(t(assign(v(loc(_G2959)),t(_G2961))),_G2927,_G2991) :-
        msos_label_instance(_G43209,[exc=v(tau),exc+=_G2943|_G2940]),
        msos_label_instance(_G43215,_G2929),
        msos_is_comp(_G2927,_G43209,_G43215),
        msos_label_instance(_G43228,[exc=v(tau),exc+=_G2943|_G2940]),
        msos_steps(t(_G2961),_G43228,_G2980),
        msos_steps(t(assign(v(loc(_G2959)),_G2980)),_G2929,_G2991),
        msos_is_comp_w(_G2927,[exc=v(tau),exc+=_G2943|_G2940],_G2929).

%% [eval(3,refocus),funcon(m,23)]
msos_steps(t(assign(t(_G3079),_G3077)),_G3049,_G3105) :-
        msos_label_instance(_G45134,[exc=v(tau),exc+=_G3065|_G3062]),
        msos_label_instance(_G45140,_G3051),
        msos_is_comp(_G3049,_G45134,_G45140),
        msos_label_instance(_G45153,[exc=v(tau),exc+=_G3065|_G3062]),
        msos_steps(t(_G3079),_G45153,_G3097),
        msos_steps(t(assign(_G3097,_G3077)),_G3051,_G3105),
        msos_is_comp_w(_G3049,[exc=v(tau),exc+=_G3065|_G3062],_G3051).

%% [eval(3,refocus),funcon(m,22)]
msos_steps(t(deref(v(loc(_G3206)))),_G3163,v(_G3222)) :-
        msos_label_instance(_G47021,[exc=v(tau),exc+=_G3179,sto=_G3185,sto+=_G3185|_G17459]),
        msos_label_instance(_G47027,_G17469),
        msos_is_comp(_G3163,_G47021,_G47027),
        msos_unobs_label([sto=_G3185,sto+=_G3185,exc=v(tau),exc+=_G3179|_G17459]),
        map_member(_G3185,_G3206,v(_G3222)),
        msos_unobs_label(_G17469),
        msos_is_comp_w(_G3163,[exc=v(tau),exc+=_G3179,sto=_G3185,sto+=_G3185|_G17459],_G17469).

%% [eval(3,refocus),funcon(m,21)]
msos_steps(t(deref(t(_G3333))),_G3304,_G3358) :-
        msos_label_instance(_G49002,[exc=v(tau),exc+=_G3320|_G3317]),
        msos_label_instance(_G49008,_G3306),
        msos_is_comp(_G3304,_G49002,_G49008),
        msos_label_instance(_G49021,[exc=v(tau),exc+=_G3320|_G3317]),
        msos_steps(t(_G3333),_G49021,_G3351),
        msos_steps(t(deref(_G3351)),_G3306,_G3358),
        msos_is_comp_w(_G3304,[exc=v(tau),exc+=_G3320|_G3317],_G3306).

%% [eval(3,refocus),funcon(m,20)]
msos_steps(t(ref(v(_G3457))),_G3416,v(loc(_G3475))) :-
        msos_label_instance(_G50851,[exc=v(tau),exc+=_G3432,sto=_G3438,sto+=_G3444|_G18590]),
        msos_label_instance(_G50857,_G18603),
        msos_is_comp(_G3416,_G50851,_G50857),
        msos_unobs_label([sto=_G3438,sto+=_G3438,exc=v(tau),exc+=_G3432|_G18590]),
        map_fresh_id(_G3475),
        map_update(_G3438,_G3475,v(_G3457),_G3444),
        msos_unobs_label(_G18603),
        msos_is_comp_w(_G3416,[exc=v(tau),exc+=_G3432,sto=_G3438,sto+=_G3444|_G18590],_G18603).

%% [eval(3,refocus),funcon(m,19)]
msos_steps(t(ref(t(_G3592))),_G3563,_G3617) :-
        msos_label_instance(_G52949,[exc=v(tau),exc+=_G3579|_G3576]),
        msos_label_instance(_G52955,_G3565),
        msos_is_comp(_G3563,_G52949,_G52955),
        msos_label_instance(_G52968,[exc=v(tau),exc+=_G3579|_G3576]),
        msos_steps(t(_G3592),_G52968,_G3610),
        msos_steps(t(ref(_G3610)),_G3565,_G3617),
        msos_is_comp_w(_G3563,[exc=v(tau),exc+=_G3579|_G3576],_G3565).

%% [eval(3,refocus),funcon(m,18)]
msos_steps(t(print(v(_G3702))),_G3675,v(unit)) :-
        msos_label_instance(_G54766,[exc=v(tau),exc+=_G3691,out+=[v(_G3702)]|_G19717]),
        msos_label_instance(_G54772,_G19724),
        msos_is_comp(_G3675,_G54766,_G54772),
        msos_unobs_label([out+=[],exc=v(tau),exc+=_G3691|_G19717]),
        msos_unobs_label(_G19724),
        msos_is_comp_w(_G3675,[exc=v(tau),exc+=_G3691,out+=[v(_G3702)]|_G19717],_G19724).

%% [eval(3,refocus),funcon(m,17)]
msos_steps(t(print(t(_G3827))),_G3798,_G3852) :-
        msos_label_instance(_G56498,[exc=v(tau),exc+=_G3814|_G3811]),
        msos_label_instance(_G56504,_G3800),
        msos_is_comp(_G3798,_G56498,_G56504),
        msos_label_instance(_G56517,[exc=v(tau),exc+=_G3814|_G3811]),
        msos_steps(t(_G3827),_G56517,_G3845),
        msos_steps(t(print(_G3845)),_G3800,_G3852),
        msos_is_comp_w(_G3798,[exc=v(tau),exc+=_G3814|_G3811],_G3800).

%% [eval(3,refocus),funcon(m,16)]
msos_steps(t(catch(t(_G3942),_G3940)),_G3910,_G3986) :-
        msos_label_instance(_G58327,[exc=v(tau),exc+=v(tau)|_G3923]),
        msos_label_instance(_G58333,_G3912),
        msos_is_comp(_G3910,_G58327,_G58333),
        msos_label_instance(_G58346,[exc=v(tau),exc+=_G3966|_G3923]),
        msos_steps(t(_G3942),_G58346,_G3973),
        msos_steps(t(if(t(eq(_G3966,v(tau))),t(catch(_G3973,_G3940)),t(app(_G3940,_G3966)))),_G3912,_G3986),
        msos_is_comp_w(_G3910,[exc=v(tau),exc+=v(tau)|_G3923],_G3912).

%% [eval(3,refocus),funcon(m,15)]
msos_steps(t(catch(v(_G4082),_G4080)),_G4052,v(_G4082)) :-
        msos_label_instance(_G60348,[exc=v(tau),exc+=_G4068|_G21347]),
        msos_label_instance(_G60354,_G21354),
        msos_is_comp(_G4052,_G60348,_G60354),
        msos_unobs_label([exc=v(tau),exc+=_G4068|_G21347]),
        msos_unobs_label(_G21354),
        msos_is_comp_w(_G4052,[exc=v(tau),exc+=_G4068|_G21347],_G21354).

%% [eval(3,refocus),funcon(m,14)]
msos_steps(t(eq(v(_G4189),v(_G4191))),_G4159,v(false)) :-
        msos_label_instance(_G61991,[exc=v(tau),exc+=_G4175|_G21783]),
        msos_label_instance(_G61997,_G21793),
        msos_is_comp(_G4159,_G61991,_G61997),
        msos_unobs_label([exc=v(tau),exc+=_G4175|_G21783]),
        msos_neq(_G4189,_G4191),
        msos_unobs_label(_G21793),
        msos_is_comp_w(_G4159,[exc=v(tau),exc+=_G4175|_G21783],_G21793).

%% [eval(3,refocus),funcon(m,13)]
msos_steps(t(eq(v(_G4304),v(_G4306))),_G4274,v(true)) :-
        msos_label_instance(_G63742,[exc=v(tau),exc+=_G4290|_G22272]),
        msos_label_instance(_G63748,_G22282),
        msos_is_comp(_G4274,_G63742,_G63748),
        msos_unobs_label([exc=v(tau),exc+=_G4290|_G22272]),
        msos_eq(_G4304,_G4306),
        msos_unobs_label(_G22282),
        msos_is_comp_w(_G4274,[exc=v(tau),exc+=_G4290|_G22272],_G22282).

%% [eval(3,refocus),funcon(m,12)]
msos_steps(t(eq(v(_G3866),t(_G3868))),_G3836,_G3896) :-
        msos_label_instance(_G41351,[exc=v(tau),exc+=_G3852|_G3849]),
        msos_label_instance(_G41357,_G3838),
        msos_is_comp(_G3836,_G41351,_G41357),
        msos_label_instance(_G41370,[exc=v(tau),exc+=_G3852|_G3849]),
        msos_steps(t(_G3868),_G41370,_G3887),
        msos_steps(t(eq(v(_G3866),_G3887)),_G3838,_G3896),
        msos_is_comp_w(_G3836,[exc=v(tau),exc+=_G3852|_G3849],_G3838).

%% [eval(3,refocus),funcon(m,11)]
msos_steps(t(eq(t(_G3984),_G3982)),_G3954,_G4010) :-
        msos_label_instance(_G43222,[exc=v(tau),exc+=_G3970|_G3967]),
        msos_label_instance(_G43228,_G3956),
        msos_is_comp(_G3954,_G43222,_G43228),
        msos_label_instance(_G43241,[exc=v(tau),exc+=_G3970|_G3967]),
        msos_steps(t(_G3984),_G43241,_G4002),
        msos_steps(t(eq(_G4002,_G3982)),_G3956,_G4010),
        msos_is_comp_w(_G3954,[exc=v(tau),exc+=_G3970|_G3967],_G3956).

%% [eval(3,refocus),funcon(m,10)]
msos_steps(t(if(v(false),_G4096,_G4091)),_G4068,_G4120) :-
        msos_label_instance(_G45075,[exc=v(tau),exc+=_G4084|_G9764]),
        msos_label_instance(_G45081,_G4070),
        msos_is_comp(_G4068,_G45075,_G45081),
        msos_unobs_label([exc=v(tau),exc+=_G4084|_G9764]),
        msos_steps(_G4091,_G4070,_G4120),
        msos_is_comp_w(_G4068,[exc=v(tau),exc+=_G4084|_G9764],_G4070).

%% [eval(3,refocus),funcon(m,9)]
msos_steps(t(if(v(true),_G4197,_G4203)),_G4174,_G4226) :-
        msos_label_instance(_G46714,[exc=v(tau),exc+=_G4190|_G9885]),
        msos_label_instance(_G46720,_G4176),
        msos_is_comp(_G4174,_G46714,_G46720),
        msos_unobs_label([exc=v(tau),exc+=_G4190|_G9885]),
        msos_steps(_G4197,_G4176,_G4226),
        msos_is_comp_w(_G4174,[exc=v(tau),exc+=_G4190|_G9885],_G4176).

%% [eval(3,refocus),funcon(m,8)]
msos_steps(t(if(t(_G4311),_G4308,_G4309)),_G4280,_G4338) :-
        msos_label_instance(_G48341,[exc=v(tau),exc+=_G4296|_G4293]),
        msos_label_instance(_G48347,_G4282),
        msos_is_comp(_G4280,_G48341,_G48347),
        msos_label_instance(_G48360,[exc=v(tau),exc+=_G4296|_G4293]),
        msos_steps(t(_G4311),_G48360,_G4329),
        msos_steps(t(if(_G4329,_G4308,_G4309)),_G4282,_G4338),
        msos_is_comp_w(_G4280,[exc=v(tau),exc+=_G4296|_G4293],_G4282).

%% [eval(3,refocus),funcon(m,7)]
msos_steps(t(throw(v(_G4414))),_G4396,v(unit)) :-
        msos_label_instance(_G50227,[exc=v(tau),exc+=v(_G4414)|_G10079]),
        msos_label_instance(_G50233,_G10086),
        msos_is_comp(_G4396,_G50227,_G50233),
        msos_unobs_label([exc=v(tau),exc+=v(tau)|_G10079]),
        msos_unobs_label(_G10086),
        msos_is_comp_w(_G4396,[exc=v(tau),exc+=v(_G4414)|_G10079],_G10086).

%% [eval(3,refocus),funcon(m,6)]
msos_steps(t(app(v(clo(_G4546,v(_G4550),_G4548)),v(_G4552))),_G4514,v(_G4550)) :-
        msos_label_instance(_G51842,[exc=v(tau),exc+=_G4530|_G10207]),
        msos_label_instance(_G51848,_G10214),
        msos_is_comp(_G4514,_G51842,_G51848),
        msos_unobs_label([exc=v(tau),exc+=_G4530|_G10207]),
        msos_unobs_label(_G10214),
        msos_is_comp_w(_G4514,[exc=v(tau),exc+=_G4530|_G10207],_G10214).

%% [eval(3,refocus),funcon(m,5)]
msos_steps(t(app(v(clo(_G4667,t(_G4671),_G4669)),v(_G4673))),_G4629,_G4707) :-
        msos_label_instance(_G53545,[exc=v(tau),exc+=_G4645,env=_G4651|_G4648]),
        msos_label_instance(_G53551,_G4631),
        msos_is_comp(_G4629,_G53545,_G53551),
        map_update(_G4669,_G4667,v(_G4673),_G4731),
        msos_label_instance(_G53567,[env=_G4731,exc=v(tau),exc+=_G4645|_G4648]),
        msos_steps(t(_G4671),_G53567,_G4697),
        msos_steps(t(app(v(clo(_G4667,_G4697,_G4669)),v(_G4673))),_G4631,_G4707),
        msos_is_comp_w(_G4629,[exc=v(tau),exc+=_G4645,env=_G4651|_G4648],_G4631).

%% [eval(3,refocus),funcon(m,4)]
msos_steps(t(app(v(_G4811),t(_G4813))),_G4781,_G4841) :-
        msos_label_instance(_G55812,[exc=v(tau),exc+=_G4797|_G4794]),
        msos_label_instance(_G55818,_G4783),
        msos_is_comp(_G4781,_G55812,_G55818),
        msos_label_instance(_G55831,[exc=v(tau),exc+=_G4797|_G4794]),
        msos_steps(t(_G4813),_G55831,_G4832),
        msos_steps(t(app(v(_G4811),_G4832)),_G4783,_G4841),
        msos_is_comp_w(_G4781,[exc=v(tau),exc+=_G4797|_G4794],_G4783).

%% [eval(3,refocus),funcon(m,3)]
msos_steps(t(app(t(_G4929),_G4927)),_G4899,_G4955) :-
        msos_label_instance(_G57680,[exc=v(tau),exc+=_G4915|_G4912]),
        msos_label_instance(_G57686,_G4901),
        msos_is_comp(_G4899,_G57680,_G57686),
        msos_label_instance(_G57699,[exc=v(tau),exc+=_G4915|_G4912]),
        msos_steps(t(_G4929),_G57699,_G4947),
        msos_steps(t(app(_G4947,_G4927)),_G4901,_G4955),
        msos_is_comp_w(_G4899,[exc=v(tau),exc+=_G4915|_G4912],_G4901).

%% [eval(3,refocus),funcon(m,2)]
msos_steps(t(abs(_G5046,_G5047)),_G5013,v(clo(_G5046,_G5047,_G5035))) :-
        msos_label_instance(_G59530,[exc=v(tau),exc+=_G5029,env=_G5035|_G10616]),
        msos_label_instance(_G59536,_G10623),
        msos_is_comp(_G5013,_G59530,_G59536),
        msos_unobs_label([env=_G5035,exc=v(tau),exc+=_G5029|_G10616]),
        msos_unobs_label(_G10623),
        msos_is_comp_w(_G5013,[exc=v(tau),exc+=_G5029,env=_G5035|_G10616],_G10623).

%% [eval(3,refocus),funcon(m,1)]
msos_steps(t(var(_G5158)),_G5125,v(_G5174)) :-
        msos_label_instance(_G61305,[exc=v(tau),exc+=_G5141,env=_G5147|_G10779]),
        msos_label_instance(_G61311,_G10789),
        msos_is_comp(_G5125,_G61305,_G61311),
        msos_unobs_label([env=_G5147,exc=v(tau),exc+=_G5141|_G10779]),
        map_member(_G5147,_G5158,v(_G5174)),
        msos_unobs_label(_G10789),
        msos_is_comp_w(_G5125,[exc=v(tau),exc+=_G5141,env=_G5147|_G10779],_G10789).


