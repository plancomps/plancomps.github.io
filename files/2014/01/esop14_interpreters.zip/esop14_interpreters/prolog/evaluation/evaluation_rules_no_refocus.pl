%% [eval(0,mexc)]
msos_steps(v(_G2773),_G2767,v(_G2773)) :-
        msos_unobs_label(_G2767).

%% [eval(1,mtrans)]
msos_steps(_G2722,_G2701,_G2745) :-
        msos_label_instance(_G3366,[exc=v(tau),exc+=_G2717|_G2714]),
        msos_label_instance(_G3372,_G2703),
        msos_is_comp(_G2701,_G3366,_G3372),
        msos_label_instance(_G3385,[exc=v(tau),exc+=_G2717|_G2714]),
        msos_step(_G2722,_G3385,_G2724),
        msos_steps(_G2724,_G2703,_G2745),
        msos_is_comp_w(_G2701,[exc=v(tau),exc+=_G2717|_G2714],_G2703).

%% [eval(2,mexc)]
msos_steps(_G107,_G2051,_G107) :-
        msos_label_instance(_G2051,[exc=v(_G83),exc+=v(_G83)|_G100]),
        msos_neq(_G83,tau),
        msos_unobs_label([exc=v(_G83),exc+=v(_G83)|_G100]).

%% [eval(3,no_refocus)]
msos_step(t__(refocus,_G53),_G54,t__(refocus,_G55)) :-
        msos_step(_G53,_G54,_G55).

%% [eval(4,yield)]
msos_steps(_G25,_G3406,_G25) :-
        msos_label_instance(_G3406,[yld=v(true)|_G18]),
        msos_unobs_label([yld=v(true)|_G18]).


