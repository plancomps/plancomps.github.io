%% [eval(0,mexc)]
msos_steps(v(_G623),_G617,v(_G623)) :-
        msos_unobs_label(_G617).

%% [eval(1,mtrans)]
msos_steps(t(_G572),_G547,_G593) :-
        msos_label_instance(_G1204,[exc=v(tau),exc+=_G563|_G560]),
        msos_label_instance(_G1210,_G549),
        msos_is_comp(_G547,_G1204,_G1210),
        msos_label_instance(_G1223,[exc=v(tau),exc+=_G563|_G560]),
        msos_step(t(_G572),_G1223,_G570),
        msos_steps(_G570,_G549,_G593),
        msos_is_comp_w(_G547,[exc=v(tau),exc+=_G563|_G560],_G549).

%% [eval(2,mexc)]
msos_steps(_G511,_G2734,_G511) :-
        msos_label_instance(_G2734,[exc=v(_G487),exc+=v(_G487)|_G504]),
        msos_neq(_G487,tau),
        msos_unobs_label([exc=v(_G487),exc+=v(_G487)|_G504]).

%% [eval(3,refocus)]
msos_step(t__(refocus,t(_G428)),_G391,t__(refocus,_G449)) :-
        msos_label_instance(_G3613,[exc=v(tau),exc+=_G407,yld=_G413|_G410]),
        msos_label_instance(_G3619,[yld=_G413|_G416]),
        msos_is_comp(_G391,_G3613,_G3619),
        msos_label_instance(_G3632,[exc=v(tau),exc+=_G407|_G410]),
        msos_step(t(_G428),_G3632,_G426),
        msos_label_instance(_G3645,[yld=v(true)|_G416]),
        msos_steps(_G426,_G3645,_G449),
        msos_is_comp_w(_G391,[exc=v(tau),exc+=_G407,yld=_G413|_G410],[yld=_G413|_G416]).

%% [eval(4,yield)]
msos_steps(_G363,_G5549,_G363) :-
        msos_label_instance(_G5549,[yld=v(true)|_G356]),
        msos_unobs_label([yld=v(true)|_G356]).


