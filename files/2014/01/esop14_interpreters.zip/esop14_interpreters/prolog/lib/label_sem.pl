%% LABEL SEMANTICS %%
rw(exc).
ro(env).
wo(out).
rw(sto).
ro(yld).

is_label([exc=_,
          exc+=_,
          env=_,
          out+=_,
          sto=_,
          sto+=_,
          yld=_]).

init_label([exc=v(tau),
            exc+=_,
            env=map_empty,
            out+=_,
            sto=map_empty,
            sto+=_,
            yld=v(false)]).

unobs_default(out+=[]).
comp_write(out+=S2__S1,out+=S1,out+=S2) :- append(S1,S2,S2__S1).
