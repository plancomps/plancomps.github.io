print_result(L,X) :-
        print('Label:'),nl,
        print(L),nl,nl,
        print('Outcome:'),nl,
        print(X),nl,nl.

nest_left_assoc_add(N, R) :-
        nest_left_assoc_add_inner(N, t(bop(+, v(1), v(1))), R).
nest_left_assoc_add_inner(0,R,R).
nest_left_assoc_add_inner(N,Acc,R) :-
        N > 0,
        N_1 is N - 1,
        nest_left_assoc_add_inner(N_1,t(bop(+,Acc,v(1))),R).

nest_left_assoc_catch_exc(N, R) :-
        nest_left_assoc_catch_exc_inner(N, t(throw(v(42))), R).
nest_left_assoc_catch_exc_inner(0,R,R).
nest_left_assoc_catch_exc_inner(N,Acc,R) :-
        N > 0,
        N_1 is N - 1,
        nest_left_assoc_catch_exc_inner(N_1,t(catch(Acc,t(abs(x,t(throw(v(0))))))),R).


nest_left_assoc_abs_nest_throw(N, R) :-
        nest_left_assoc_abs_nest_throw_inner(N, t(throw(v(42))), R).
nest_left_assoc_abs_nest_throw_inner(0,R,R).
nest_left_assoc_abs_nest_throw_inner(N,Acc,R) :-
        N > 0,
        N_1 is N - 1,
        nest_left_assoc_abs_nest_throw_inner(N_1,t(app(t(abs(x,Acc)),v(0))),R).


fib(N,R) :-
        R =
        t(app(t(abs(fib,
                    t(seq(t(assign(t(var(fib)),
                                   t(abs(n,
                                         t(if(t(eq(t(var(n)),
                                                   v(0))),
                                              v(1),
                                              t(if(t(eq(t(var(n)),
                                                        v(1))),
                                                   v(1),
                                                   t(bop(+,
                                                         t(app(t(deref(t(var(fib)))),
                                                               t(bop(-,t(var(n)),v(1))))),
                                                         t(app(t(deref(t(var(fib)))),
                                                               t(bop(-,t(var(n)),v(2))))))))))))))),
                          t(app(t(deref(t(var(fib)))),
                                v(N))))))),
              t(ref(v(true))))).

fac(N,R) :-
        R =
        t(app(t(abs(fac,
                    t(seq(t(assign(t(var(fac)),
                                   t(abs(n,
                                         t(if(t(eq(t(var(n)),
                                                   v(0))),
                                              v(1),
                                              t(bop(*,
                                                    t(var(n)),
                                                    t(app(t(deref(t(var(fac)))),
                                                          t(bop(-,t(var(n)),v(1))))))))))))),
                          t(app(t(deref(t(var(fac)))),
                                v(N))))))),
              t(ref(v(true))))).

print_1_2_3(R) :-
        R =
        t(seq(t(print(v(1))),
              t(seq(t(print(v(2))),
                    t(print(v(3))))))).

for_fib(N,R) :-
        R =
        t(app(t(abs(n,
                    t(app(t(abs(a,
                                t(app(t(abs(b,
                                            t(app(t(abs(c,
                                                        t(for(t(eq(t(eq(t(deref(t(var(n)))),
                                                                        v(0))),
                                                                   v(false))),
                                                              t(assign(t(var(n)),
                                                                       t(bop(-,
                                                                             t(deref(t(var(n)))),
                                                                             v(1))))),
                                                              t(seq(t(assign(t(var(c)),
                                                                             t(bop(+,
                                                                                   t(deref(t(var(a)))),
                                                                                   t(deref(t(var(b)))))))),
                                                                    t(seq(t(assign(t(var(a)),
                                                                                   t(deref(t(var(b)))))),
                                                                          t(assign(t(var(b)),
                                                                                   t(deref(t(var(c)))))))))))))),
                                                  t(ref(v(1))))))),
                                      t(ref(v(1))))))),
                          t(ref(v(0))))))),
              t(ref(v(N))))).

for_fac(N,R) :-
        R =
        t(app(t(abs(n,
                    t(app(t(abs(a,
                                t(for(t(eq(t(eq(t(deref(t(var(n)))),
                                                v(0))),
                                           v(false))),
                                      t(assign(t(var(n)),
                                               t(bop(-,
                                                     t(deref(t(var(n)))),
                                                     v(1))))),
                                      t(assign(t(var(a)),
                                               t(bop(*,
                                                     t(deref(t(var(n)))),
                                                     t(deref(t(var(a)))))))))))),
                          t(ref(v(N))))))),
              t(ref(t(bop(-,v(N),v(1))))))).
