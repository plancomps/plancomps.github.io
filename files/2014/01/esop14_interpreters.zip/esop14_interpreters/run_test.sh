#!/bin/bash
swipl -q -f test.pl -g "test." -t halt
