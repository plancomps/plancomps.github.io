{-# LANGUAGE FlexibleInstances, StandaloneDeriving #-}

module IML.Grammar.Grammar where

import IML.Grammar.Shared hiding (Spec(..))

type Program    = AProgram [Stmts] 

data AProgram t = Program (ASpec t) Queries

type Spec       = ASpec [Stmts]
data ASpec t    = Spec [Cons] {- value ops -} [AnyDecls (ATransDecl t)]

type TransDecl  = ATransDecl [Stmts]
data ATransDecl t = Trans RSymb Cons t

type Stmts      = [Stmt]
data Stmt       = Branches  [Stmts]
                | PM_Args   [Pattern]
                | PM        Expr    Pattern
                | Commit    Term
                | Single    RSymb   Term  MVar    (Maybe Label)
                | Many      RSymb   Term  MVar    (Maybe Label)
                | Unobserv  Label
                | RW_Get    EID     MVar          Label
                | RW_Set    EID     Expr          Label
                | RO_Get    EID     MVar          {- label = 0 -}
                | RO_Set    EID     Expr          Label {- > 0 -}
                | WO_Get    EID     MVar          Label {- > 0 -}
                | WO_Set    EID     Expr          {- label = 0 -}

type Label      = Int

expectedCostOf :: Stmt -> Float 
expectedCostOf s = (expectedSuccessRateOf s *) $ case s of
  PM_Args _               -> low
  PM _ _                  -> low
  Many _ _ _ _            -> high
  Single _ _ _ _          -> medium + dev
  Unobserv _              -> low
  RW_Get _ _ _            -> low 
  RO_Get _ _              -> low 
  WO_Get _ _ _            -> low 
  RW_Set _ _ _            -> low + dev
  RO_Set _ _ _            -> low + dev
  WO_Set _ _              -> low + dev
  _                       -> medium
  where high    = 100
        low     = dev
        none    = 0
        medium  = 50
        dev     = 10

expectedSuccessRateOf :: Stmt -> Float
expectedSuccessRateOf s = case s of
  PM _ (PVar _)           -> succeeds
  PM _ _                  -> low
  Many _ _ _ _            -> succeeds
  Single _ _ _ _          -> medium
  RW_Get _ _ _            -> succeeds
  RO_Get _ _              -> succeeds
  WO_Get _ _ _            -> succeeds
  _                       -> medium
  where medium    = 0.5
        low       = fails + dev
        high      = succeeds - dev
        dev       = 0.2
        succeeds  = 1
        fails     = 0

labelOf :: Stmt -> Maybe Label 
labelOf (RW_Get _ _ l)      = Just l
labelOf (RW_Set _ _ l)      = Just l
labelOf (RO_Get _ _)        = Just 0
labelOf (RO_Set _ _ l)      = Just l
labelOf (WO_Set _ _)        = Just 0
labelOf (WO_Get _ _ l)      = Just l
labelOf (Single _ _ _ ml)   = ml
labelOf (Many _ _ _ ml)     = ml
labelOf (Unobserv l)        = Just l
labelOf _                   = Nothing

-- | Returns whether the statement performs a procedure call
isCaller :: Stmt -> Bool
isCaller (Single _ _ _ _)   = True
isCaller (Many _ _ _ _ )    = True
isCaller _                  = False

instance Functor AProgram where
  fmap f (Program s q) = Program (fmap f s) q

instance Functor ASpec where
  fmap f (Spec ops xs) = Spec ops $ fmap (fmap (fmap f)) xs

instance Functor ATransDecl where
  fmap f (Trans r c ss) = Trans r c (f ss) 

instance Foldable AProgram where
  foldMap f (Program s q) = foldMap f s

instance Foldable ASpec where
  foldMap f (Spec ops ds) = foldMap (foldMap (foldMap f)) ds

instance Foldable ATransDecl where
  foldMap f (Trans r c ss) = f ss

instance Traversable AProgram where
  traverse f (Program s q) = Program <$> traverse f s <*> pure q

instance Traversable ASpec where
  traverse f (Spec ops ds) = 
    Spec <$> pure ops <*> traverse (traverse (traverse f)) ds

instance Traversable ATransDecl where
  sequenceA (Trans r c ss) = Trans r c <$> ss

deriving instance Ord Stmt 
deriving instance Eq Stmt
deriving instance Ord Expr
deriving instance Eq Expr
deriving instance Ord Pattern
deriving instance Eq Pattern
