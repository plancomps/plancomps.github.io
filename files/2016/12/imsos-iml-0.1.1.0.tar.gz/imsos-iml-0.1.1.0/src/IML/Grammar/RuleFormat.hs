
module IML.Grammar.RuleFormat (
  Spec(..), Rule(..), Conclusion(..), Premises, Premise(..), SideCons, SideCon(..),
  Term(..), Rel(..), Pattern(..), ROup(..), RWup(..), WOacc(..), MVar(..),
  Cons, RSymb, ROacc(..), RWacc(..), WOup(..), Rep(..),Expr(..), 
  AnyDecls(..),sRel, mRel, RelDecl(..), RelPred(..),
  RelInfo, RelTable, relEmpty, relInsert, relFromDecls, 
  ) where

import IML.Grammar.Shared hiding (Spec(..))

data Spec       = Spec [Cons] [AnyDecls Rule]

data Rule       = Rule Conclusion [Either Premise SideCon]

type Premises   = [Premise]
data Premise    = Prem Term Rel Pattern [ROup] [RWup] [WOacc]

data Conclusion = Conclusion Cons [Pattern] RSymb Term [ROacc] [RWacc] [WOup]

type SideCons   = [SideCon]
data SideCon    = SideOP Expr Pattern

sRel r          = Rel r NoRep True
mRel r          = Rel r Rep True

type ROacc      = (EID, Pattern)
type ROup       = (EID, Expr)
type WOacc      = (EID, Pattern)
type WOup       = (EID, Expr)
type RWacc      = (EID, Pattern, Expr)
type RWup       = (EID, Expr, Pattern)


