
module IML.Grammar.Mixed (
  module IML.Grammar.Shared,
  module IML.Grammar.Grammar,
  module IML.Grammar.RuleFormat,
  MixedProgram, MixedDecl) where

import IML.Grammar.Grammar hiding (Spec)
import IML.Grammar.Shared hiding (Spec)
import IML.Grammar.RuleFormat

-- A mixed program is some queries + a mixture of:
--    * an inference rule 
--    * single-branched transactions
type MixedProgram = SharedProgram MixedDecl 
type MixedDecl    = Either Rule TransDecl

