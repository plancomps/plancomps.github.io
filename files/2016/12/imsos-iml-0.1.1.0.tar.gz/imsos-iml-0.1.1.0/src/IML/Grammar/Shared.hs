
module IML.Grammar.Shared where

import Prelude hiding (AnEntDecl, ARuleDecl)
import qualified Data.Map as M

type RSymb      = String
type Cons       = String
type EID        = String
type VOP        = String
data MVar       = MVar String {- name -} Int (Maybe Int) {- bounds on # matches -}
                deriving (Ord,Eq)

mVar :: String -> MVar
mVar str = MVar str 1 (Just 1)

data SharedProgram a = SharedProgram (Spec a) Queries

data Spec a     = Spec [Cons] [AnyDecls a]

type Queries    = [Query]
data Query      = Query Term{- closed -} Rel Pattern

data EntDecl    = RODecl EID Expr 
                | RWDecl EID Expr
                | WODecl EID VOP VOP

data Rel        = Rel RSymb Rep Bool {- may have unobserved effects -}
data Rep        = NoRep | Rep
data RelDecl    = RelDecl RSymb [RelPred]
data RelPred    = IsPure 
                | Orderable
                | ValReflexive
{-                | Reflexive
                | Transitive-}
                deriving (Enum, Ord, Eq, Show)


type Exprs      = [Expr]
data Expr       = Val Term {- value -}
                | VOP VOP Exprs

data Term       = TVar MVar
                | TCons Bool {- value cons? -} Cons [Term]
                deriving (Eq, Ord)

data Pattern    = PVar MVar
                | PAny
                | PCons Cons  [Pattern]

data Dir = RO | RW | WO deriving (Ord, Eq, Enum, Show)

-- | Transform a 'Term' into a 'Pattern'.
-- The 'Term' may not contain any meta-variables and must be constructred 
-- by value constructors at all levels.
val2pattern :: Term -> Pattern
val2pattern (TVar _) = error "val2pattern assertion 1"
val2pattern (TCons False _ _ ) = error "val2pattern assertion 2"
val2pattern (TCons _ nm ts) = PCons nm (map val2pattern ts)

dirOfEDecl (RODecl _ _)     = RO
dirOfEDecl (RWDecl _ _)     = RW
dirOfEDecl (WODecl _ _ _ )  = WO

isVal :: Term {- closed -} -> Bool
isVal (TCons b _ _) = b
isVal _ = error "isVal variable"

children :: Term {- closed-} -> [Term]
children (TVar _) = error "children variable"
children (TCons _ _ cs) = cs

eidOfDecl :: EntDecl -> EID
eidOfDecl (RODecl eid _) = eid
eidOfDecl (RWDecl eid _) = eid
eidOfDecl (WODecl eid _ _ ) = eid

data AnyDecls a = AnEntDecl EntDecl
                | ARelDecl RelDecl
                | ARuleDecl a

partition_decls :: [AnyDecls a] -> ([EntDecl], [RelDecl], [a])
partition_decls = foldr op ([],[],[])
  where op (AnEntDecl x)   (xs,ys,zs) = (x:xs,ys,zs)
        op (ARelDecl y) (xs,ys,zs) = (xs,y:ys,zs)
        op (ARuleDecl z)  (xs,ys,zs) = (xs,ys,z:zs)

withDecl :: (EntDecl -> a) -> (RelDecl -> a) -> (b -> a) -> AnyDecls b -> a
withDecl f _ _  (AnEntDecl x)   = f x
withDecl _ f _  (ARelDecl x) = f x
withDecl _ _ f  (ARuleDecl x)  = f x

-- relation info
data RelInfo    = RelInfo { rel_id :: Int, rel_preds :: [RelPred] }
type RelTable   = M.Map RSymb RelInfo 

relEmpty :: RelTable 
relEmpty = M.empty

relFromAnyDecls :: [AnyDecls a] -> RelTable
relFromAnyDecls decls = relFromDecls rels 
  where (_,rels,_) = partition_decls decls  

relFromDecls :: [RelDecl] -> RelTable
relFromDecls = foldr op relEmpty . zip [1..]
    where op (k, RelDecl r ps) = relInsert r k ps

relInsert :: RSymb -> Int -> [RelPred] -> RelTable -> RelTable
relInsert r k ps = M.insert r (RelInfo k ps)

rel_pure tab r = case M.lookup r tab of
                  Nothing -> False
                  Just info -> IsPure `elem` (rel_preds info)
rel_val_refl tab r = case M.lookup r tab of
                  Nothing -> False
                  Just info -> ValReflexive `elem` (rel_preds info)
instance Functor AnyDecls where
  fmap f (AnEntDecl x) = AnEntDecl x
  fmap f (ARelDecl x) = ARelDecl x
  fmap f (ARuleDecl x) = ARuleDecl (f x)

instance Foldable AnyDecls where
  foldMap f (AnEntDecl x)    = mempty 
  foldMap f (ARelDecl x)  = mempty
  foldMap f (ARuleDecl x)   = f x

instance Traversable AnyDecls where
  traverse f (AnEntDecl x)    = pure (AnEntDecl x)
  traverse f (ARelDecl x)  = pure (ARelDecl x)
  traverse f (ARuleDecl x)   = ARuleDecl <$> f x

instance Show MVar where
  show (MVar v 1 (Just 1)) = v
  show (MVar v l Nothing) = v ++ "_" ++ show l ++ "_*"
  show (MVar v l (Just u)) = v ++ "_" ++ show l ++ "_" ++ show u
