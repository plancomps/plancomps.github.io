{-# LANGUAGE FlexibleInstances #-}

module IML.Interpreter.Types where

import IML.Grammar.Shared
import IML.Grammar
import IML.Printer

import Data.Maybe (isJust)
import qualified Data.Map as M
import qualified Data.IntMap as IM

-- meta-environment
type MetaEnv = M.Map MVar Term {- closed term -}

envEmpty :: MetaEnv
envEmpty = M.empty

bind :: MVar -> Term -> MetaEnv
bind x t = M.singleton x t

-- right-biased environment union
envUnite :: MetaEnv -> MetaEnv -> MetaEnv
envUnite = flip M.union

binds :: MetaEnv -> MVar -> Bool
binds = (isJust .) . flip M.lookup

binding :: MetaEnv -> MVar -> Term {- closed -}
binding = (M.!) 

matches :: [Term] {- closed terms-} -> [Pattern] -> Maybe MetaEnv
matches ts ps 
  | length ts == length ps  = foldr merge (Just envEmpty) $ zipWith match ts ps
  | otherwise               = Nothing
  where merge Nothing _                 = Nothing
        merge _ Nothing                 = Nothing
        merge (Just gam1) (Just gam2)   = Just (envUnite gam1 gam2)

match :: Term {-closed term-} -> Pattern -> Maybe MetaEnv
match (TVar _) _ = error "match applied to non-closed term"
match t@(TCons isVal cs ts) p = case p of
  PVar var      -> Just $ bind var t
  PAny          -> Just $ envEmpty
  PCons cs' ps 
    | isVal, cs == cs' -> foldr (flip mappend) (Just envEmpty) $ zipWith match ts ps
  _                    -> Nothing

subs :: MetaEnv -> Term {- non-closed -} -> Term {- closed -}
subs gam t = case t of 
  TVar v | gam `binds` v -> gam `binding` v
         | otherwise     -> error ("substitution, unbound var: " ++ show v) 
  TCons b cs ts -> TCons b cs (map (subs gam) ts)

                      
-- entity storage
type UnionF = EID -> VOP
type UnitF  = EID -> VOP

type Record = M.Map EID (Term,Dir)

recEmpty :: Record
recEmpty = M.empty

recNull :: Record -> Bool
recNull = M.null

recInsert :: EID -> (Term,Dir) -> Record -> Record
recInsert = M.insert

-- right-biased record union
recUnite :: Record -> Record -> Record
recUnite = flip M.union

recUnites :: [Record] -> Record
recUnites = foldr recUnite recEmpty 

recDel :: EID -> Record -> Record
recDel = M.delete

recSingle :: EID -> (Term,Dir) -> Record
recSingle = M.singleton

entValue :: Record -> EID -> Maybe Term
entValue = (fmap fst .) . flip M.lookup

entDir :: Record -> EID -> Maybe Dir
entDir = (fmap snd .) . flip M.lookup

filterDir :: Dir -> Record -> Record
filterDir d = M.filter (((==) d) . snd)

prop_in :: [Record] -> Record
prop_in = foldl (M.unionWithKey biasOp) recEmpty
  where biasOp _ (_,RW) (rw,RW) = (rw,RW)
        biasOp _ (_,RO) (ro,RO) = (ro,RO)
        biasOp k (_,WO) (_,WO)  = error ("write-only entity " ++ k ++ "sent inwards")
        biasOp k _ _            = error ("entity " ++ k ++ " has different directions")

prop_out :: (EID -> Term -> Term -> Term) -> [Record] -> Record
prop_out append = foldl (M.unionWithKey biasOp) recEmpty
  where biasOp _ (_,RW) (rw,RW)   = (rw,RW)
        biasOp k (w1,WO) (w2,WO)  = (append k w1 w2,WO)
        biasOp k (_,RO) (_,RO)    = error("read-only entity "++ k++ "sent outwards") 
        biasOp k _ _              = error ("entity " ++ k ++ " has different directions")

-- deltas over records
type Delta = IM.IntMap Record

delEmpty = IM.empty

delLookup :: Int -> Delta -> Record
delLookup = (maybe recEmpty id .) . IM.lookup

delInsert :: Int -> Record -> Delta -> Delta
delInsert = IM.insert

delAdd :: Int -> EID -> (Term,Dir) -> Delta -> Delta
delAdd k1 k2 t d = IM.unionWith recUnite d (IM.singleton k1 (M.singleton k2 t))

delDelete :: Int -> EID -> Delta -> Delta
delDelete k1 k2 = IM.adjust (M.delete k2) k1 

delRecords :: (Int -> Bool) -> Delta -> [Record]
delRecords pred del = IM.elems $ IM.filterWithKey pred' del
  where pred' k _ = pred k

-- transaction alternatives

type TransMap = M.Map (RSymb,Cons) [Stmts]

transEmpty = M.empty

transAdd :: RSymb -> Cons -> [Stmts] -> TransMap -> TransMap
transAdd r c ss m = M.insert (r,c) ss m

transOf :: RSymb -> Cons -> TransMap -> [Stmts]
-- it is important to return [] here in case lookup fails
-- as this is point where redexes are discovered 
-- (assuming values have no rules defined for them)
transOf r c m = maybe [] id (M.lookup (r,c) m)
