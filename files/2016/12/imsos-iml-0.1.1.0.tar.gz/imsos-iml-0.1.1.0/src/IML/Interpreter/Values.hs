
module IML.Interpreter.Values where

import IML.Grammar.Shared

import Data.Maybe

-- builtin values

id_ :: String -> Term
id_ s = TCons True "identifier" [TCons True s []]

isId :: Term -> Bool
isId (TCons True "identifier" _) = True
isId _ = False

false_, true_ :: Term
false_ = TCons True "false" []
true_  = TCons True "true" []

bool_ :: Bool -> Term
bool_ b | b         = true_
        | otherwise = false_

int_ :: Int -> Term
int_ i  = TCons True "integer" [TCons True (show i) []]

isInt :: Term -> Bool
isInt (TCons True "integer" _) = True
isInt _ = False

readInt :: Term -> Int
readInt (TCons True s []) = read s
readInt _ = error "readInt"

string_ :: String -> Term
string_ s = TCons True "string" [TCons True s []]

unstring :: Term -> String
unstring (TCons True "string" [TCons True str []]) = str
unstring _ = error "unstring"

list_ :: [Term] -> Term
list_ = TCons True "list"

isList :: Term -> Bool
isList (TCons True "list" _) = True
isList _ = False

-- tuples
tuple_ :: [Term] -> Term
tuple_ = TCons True "tuple"

isTuple :: Term -> Bool
isTuple (TCons True "tuple" _) = True
isTuple _ = False

pair_ :: (Term, Term) -> Term
pair_ (f,s) = tuple_ [f,s]

isPair :: Term -> Bool
isPair t = isTuple t && length (children t) == 2

unpair :: Term -> (Term,Term)
unpair (TCons True "tuple" [t1, t2]) = (t1,t2)
unpair _ = error "unpair"

-- maps
map_ :: [(Term,Term)] -> Term
map_ = TCons True "_map" . map pair_ 

isMap (TCons True "_map" ps) = all isPair ps
isMap _ = False

-- builtin value operations

equalTerms :: [Term] -> Maybe Term
equalTerms [x,y] = equal x y
  where equal (TCons b1 cs1 ts1) (TCons b2 cs2 ts2) = 
          Just $ bool_ (b1 == b2 && cs1 == cs2 && all isJust (zipWith equal ts1 ts2))
        equal _ _ = error "equalTerms on non-closed terms" 
equalTerms _     = Nothing

listAppend :: [Term] -> Maybe Term
listAppend lists  | all isList lists = Just $ list_ $ concatMap children lists
                  | otherwise        = Nothing 

tupleOp :: [Term] -> Maybe Term
tupleOp ts | all isVal ts = Just $ tuple_ ts
tupleOp _ = Nothing

listOp :: [Term] -> Maybe Term
listOp ts | all isVal ts = Just $ list_ ts
listOp _ = Nothing

integer_op :: ([Int] -> Int) -> (Int -> Term) -> [Term] -> Maybe Term
integer_op sum int_ ts 
  | all isInt ts = Just $ int_ $ sum $ map readInt $ concatMap children ts 
  | otherwise = Nothing

integer_bin_op :: (Int -> Int-> a) -> (a -> Term) -> [Term] -> Maybe Term
integer_bin_op op int_ ts 
  | all isInt ts, [x,y] <- map readInt (concatMap children ts) = 
      Just $ int_ (x `op` y) 
  | otherwise = Nothing

sat :: (Term -> Bool) -> [Term] -> Maybe Term
sat pred = Just . bool_ . all pred

is_int :: [Term] -> Maybe Term
is_int = sat isInt 

isValOp :: [Term] -> Maybe Term
isValOp = sat isVal 

mapInsertOp [m,k,v] | isMap m = Just $ TCons True "_map" (pair_ (k,v):children m)
mapInsertOp _ = Nothing

mapLookupOp [k,m] | isMap m = lookup k (map unpair (children m))
mapLookupOp _ = Nothing
