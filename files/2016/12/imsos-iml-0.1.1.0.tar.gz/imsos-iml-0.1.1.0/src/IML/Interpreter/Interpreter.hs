
module IML.Interpreter.Interpreter where

import IML.Printer
import IML.Grammar.Shared hiding (Spec(..))
import IML.Grammar
import IML.Interpreter.Values
import IML.Interpreter.Types

import Text.PrettyPrint.HughesPJ
import Data.Maybe (isJust, fromJust)

run :: Program -> [(Term {- closed-}, Record)]
run (Program (Spec _ ds) qs) = map (flip run1 (tm, rt, f2, f0, e0)) qs
  where
   (eds,relds,transds) = partition_decls ds
   tm = foldr eTransDecl transEmpty transds
   rt = relFromDecls relds
   (e0, f2, f0) = foldr eEntDecl (recEmpty, unionError, unitError) eds
      where unionError eid = error ("no monoidal append for: "++ eid)
            unitError eid  = error ("no monoidal unit element for: " ++ eid)

run1 :: Query -> CallC -> (Term {- closed -}, Record) 
run1 (Query ct (Rel r rep _) p) (tm, rt, f2, f0, e0) = 
  case eStmts main (tm, rt, f2, f0, e0, []) (envEmpty, delEmpty, []) of
    (Nothing, _)     -> (ct,recEmpty)
    (Just (t,e0'),_) -> (t,e0')
  where main = gen_main rep r ct p 

gen_main :: Rep -> RSymb -> Term {- closed -} -> Pattern -> Stmts 
gen_main rep r t@(TCons _ f _) pat = 
  [repArr r t (MVar "x0" 1 (Just 1)) (Just 1)] ++
  case pat of PAny  -> [commit]
              _     -> [PM (Val (TVar $ MVar "x0" 1 (Just 1))) pat, commit]
  where repArr = case rep  of Rep   -> Many
                              NoRep -> Single
        commit = Commit (TVar (MVar "x0" 1 (Just 1)))
gen_main _ _ _ _ = error "gen_main applied to non-closed term"

eTransDecl :: TransDecl -> TransMap -> TransMap
eTransDecl (Trans r c ss) = transAdd r c ss

eEntDecl :: EntDecl -> (Record, UnionF, UnitF) -> (Record, UnionF, UnitF)
eEntDecl d (rec, op2Of, op0Of) = case d of
  RODecl eid ss -> (recInsert eid (evalDef ss,RO) rec, op2Of, op0Of)
  RWDecl eid ss -> (recInsert eid (evalDef ss,RW) rec, op2Of, op0Of)
  WODecl eid op2 op0 -> (rec, op2Of', op0Of')
    where op2Of' eid' | eid == eid' = op2
                     | otherwise   = op2Of eid'
          op0Of' eid' | eid == eid' = op0
                      | otherwise   = op0Of eid'
  where   evalDef :: Expr -> Term
          evalDef e = case eExpr envEmpty e of
                        Just (t@(TCons True _ _)) -> t
                        _     -> error "failed to evaluate default value"

eExpr :: MetaEnv -> Expr -> Maybe Term
eExpr gam e = case e of
  Val t -> Just $ subs gam t 
  VOP vop es -> case all isJust es' of
                  True  -> opApp vop (map fromJust es') 
                  _     -> Nothing
    where es' = map (eExpr gam) es
  
          opApp vop = case vop of 
            "is-equal"            -> equalTerms 
            "is-value"            -> isValOp
            -- maps
            "map-empty"           -> const (Just $ map_ [])
            "map-insert"          -> mapInsertOp
            "map-lookup"          -> mapLookupOp
            -- lists
            "nil"                 -> const (Just (list_ []))
            "list"                -> listOp
            "list-append"         -> listAppend
            -- tuples
            "tuple"               -> tupleOp
            -- identifiers
            "is-id"               -> sat isId
            -- booleans
            "true"                -> const (Just true_)
            "false"               -> const (Just false_)
            -- integers
            "integer-add"         -> integer_op sum int_
            "int-add"             -> integer_op sum int_
            "is-integer"          -> is_int
            "is-less-or-equal"    -> integer_bin_op (<=) bool_
            _                     -> error ("unknown operation: " ++ vop)
 

type TransC = (TransMap, RelTable, UnionF, UnitF, Record, [Term])
type CallC  = (TransMap, RelTable, UnionF, UnitF, Record)
type TransS = (MetaEnv, Delta, [Label])

data StmtValue = Nil | Bot | Res (Term {-closed-}, Record)

eStmts :: Stmts -> TransC -> TransS -> (Maybe (Term, Record), TransS)
eStmts [] ctx state = (Nothing, state)
eStmts (s:ss) ctx state = case eStmt s ctx state of
  (Nil,state')        -> eStmts ss ctx state'
  (Bot,state')        -> (Nothing, state')
  (Res (t,r),state')  -> (Just (t,r), state')
  
eStmt :: Stmt -> TransC -> TransS -> (StmtValue, TransS)
eStmt s ctx@(tm, rt, f2, f0, e0, args) state@(gam,del,pord) = case s of 
--  Assert e -> case eExpr gam e of Just (TCons True "true" []) -> skip 
--                                  _                           -> abort
  PM e p -> case eExpr gam e of
    Just source -> case match source p of
                      Just gam1 -> returnGam Nil (gam `envUnite` gam1) 
                      Nothing -> abort
    Nothing -> abort
  PM_Args ps -> case matches args ps of 
      Nothing  -> abort
      Just gam1 -> returnGam Nil (gam `envUnite` gam1)
  RO_Set eid e j -> case eExpr gam e of
      Just t | isVal t  -> returnDel Nil (delAdd j eid (t,RO) del)
      _                 -> abort
  RO_Get eid x   -> case entValue e0 eid of
                      Nothing -> error ("no default value for RO entity: " ++ eid) 
                      Just t  -> returnGam Nil (gam `envUnite` bind x t)
  WO_Set eid e   -> case eExpr gam e of
      Just t | isVal t  -> returnDel Nil (delAdd 0 eid (t,WO) del)
      _                 -> abort
  WO_Get eid x j -> case entValue local_rec eid of
                      Nothing -> returnGam Nil (gam `envUnite` bind x woDefault)
                      Just t  -> (Nil, (gam `envUnite` bind x t
                                       ,delDelete j eid del,pord))
    where local_rec = delLookup j del
          woDefault = case eExpr envEmpty (VOP op []) of
                        Just t | isVal t -> t 
                        _ -> error$"cannot use "++op++" as monoidal unit"
            where op = f0 eid
  RW_Set eid e i -> case eExpr gam e of
    Just t | isVal t  -> returnDel Nil (delAdd i eid (t,RW) del)
    _                 -> abort
  RW_Get eid x i -> case entValue local_rec eid of
                      Nothing -> case entValue e0 eid of
                                    Nothing -> error ("no default value for RW entity:"++eid)
                                    Just t  -> returnGam Nil (gam `envUnite` bind x t)
                      Just t -> (Nil, (gam `envUnite` bind x t 
                                      ,delDelete i eid del, pord))
    where local_rec = delLookup i del
  Commit t -> return (Res (ct, es))
     where  ct  = subs gam t 
            es  = prop_out (append f2) (map (flip delLookup del) (pord++[0]))  
  Single r e x ml -> mkCall NoRep r e x ml
  Many r e x ml -> mkCall Rep r e x ml
  Unobserv l | recNull $ delLookup l del -> skip
             | otherwise                 -> abort
  Branches [] -> abort 
  Branches (ss:sss) -> case eStmts ss ctx state of 
      (Nothing, _)          -> eStmt (Branches sss) ctx state 
      (Just (t,del),state') -> ((Res (t,del)), state')
  where   skip = (Nil, (gam, del, pord))
          abort = (Bot, (gam, del, pord)) 
          return a = (a, (gam, del, pord)) 
          returnGam a gam' = (a, (gam', del, pord))
          returnDel a del' = (a, (gam, del', pord))

          mkCall :: Rep -> RSymb -> Term -> MVar -> Maybe Label -> (StmtValue, TransS)
          mkCall rep r t x ml = case call rep r ct (tm, rt, f2, f0, inh_el) of
                      Just (ct1_,syn_el) -> (Nil, (gam', del', pord')) 
                        where gam'  = gam `envUnite` bind x ct1_
                              pord' = maybe pord ((pord ++) . (:[])) ml
                              del'  = case ml of
                                        Nothing | recNull syn_el -> del
                                                | otherwise -> error "cf-call had effects"
                                        Just l  -> delInsert l syn_el del
                      _ -> abort 
            where ct      = subs gam t 
                  inh_el  = case ml of  
                      Nothing   -> recEmpty
                      Just l    -> prop_in (e0 : map (flip delLookup del) (pord ++ [l]))


call :: Rep -> RSymb -> Term {-closed-} -> CallC -> Maybe (Term, Record)
call _ _ (TVar _) _ = error "call applied to non-closed term"
call NoRep r t0@(TCons True _ _) (_, rt, _, _, _) 
  | rel_val_refl rt r = Just (t0, recEmpty)
  | otherwise         = Nothing
call Rep r t0@(TCons True _ _) _ = Just (t0, recEmpty)
call rep r t0@(TCons False f args) (tm, rt, f2, f0, rec) = 
  case eStmt (Branches branches) (tm, rt, f2, f0, rec, args) (envEmpty, delEmpty, []) of
    (Res (t, rec1),_)  | NoRep <- rep  -> Just (t, rec1)
                       | Rep <- rep    -> 
                            case call rep r t (tm, rt, f2, f0, prop_in [rec,rec1]) of
                              Nothing         -> Just (t, rec1)
                              Just (t2, rec2) -> Just (t2,prop_out (append f2) [rec1,rec2])  
    _ -> case rep of NoRep -> Nothing
                     Rep   -> Just (t0, recEmpty)
  where branches = transOf r f tm 

append :: UnionF -> EID -> Term -> Term -> Term
append f2 e l r = case eExpr envEmpty (VOP (f2 e) [Val l, Val r]) of
                        Just t | isVal t -> t
                        _ -> error$"cannot use " ++ (f2 e) ++ " as monoidal append"

