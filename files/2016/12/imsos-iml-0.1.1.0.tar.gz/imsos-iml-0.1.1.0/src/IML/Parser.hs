{-# LANGUAGE FlexibleInstances #-}

module IML.Parser where

import IML.Grammar.Shared as Shared
import IML.Grammar.Mixed
import IML.Interpreter.Values
import IML.Trans.ProMan

import GLL.Combinators

import Data.Either

type Parser a = BNF Token a

-- A program fragment is
data Fragment = FEntity EntDecl             -- an entity declaration
              | FRelation RelDecl           -- a rule declaration
              | FValCons Cons               -- value-constructor declaration
              | FQuery Query                -- a query
              | FTrans TransDecl            -- transaction declaration
              | FRule Rule                  -- an inference rule

parser :: Component [Token] MixedProgram
parser = component_ iml_parse

iml_parse :: [Token] -> MixedProgram
iml_parse = head . iml_parser

iml_parser :: [Token] -> [MixedProgram]
iml_parser inp = case parseWithOptions [throwErrors] pProgram inp of
  []  -> error "no parse errors, but no result?"
  ps  -> ps

pProgram :: Parser MixedProgram 
pProgram = "PROGRAM" <:=> mkProgram <$$> multiple pFragment
  where mkProgram es = SharedProgram (Shared.Spec vcons restDecls) queries
         where (rest,vcons,queries') = foldr op ([],[],[]) es
                  where op r (rest,vcons,qs) = case r of 
                            FValCons val  -> (rest,val:vcons,qs)
                            FTrans decl   -> (ARuleDecl (Right decl):rest,vcons,qs)
                            FRule rule    -> (ARuleDecl (Left rule):rest,vcons,qs)
                            FEntity ent   -> (AnEntDecl ent:rest,vcons,qs)
                            FRelation rel -> (ARelDecl rel:rest,vcons,qs)
                            FQuery q      -> (rest,vcons,q:qs)
               restDecls = blossom vcons rest
               queries   = blossom vcons queries'
    
pFragment :: Parser Fragment
pFragment = "DECL" 
  <:=  FRelation <$$ keyword "relation" <**> parens pRelDecl 
  <||> FEntity <$$ keyword "entity" <**> parens pEntDecl
  <||> FRule <$$> pInference
  <||> FValCons <$$ keyword "value-constructor" <**> parens id_lit
  <||> FTrans <$$> pTrans 
  <||> FQuery <$$> pQuery

pQuery :: Parser Query 
pQuery = "QUERY" <:=> Query <$$> pTerm <**> pRel <**> (PAny <$$ keychar '?')

pEntDecl :: Parser EntDecl
pEntDecl = "ENT-DECL" <:=> flip ($) <$$> id_lit <** keychar ',' <**> pDefaults

pDefaults :: Parser (EID -> EntDecl)
pDefaults = "VAL-ENT-DECL" 
  <:=> flip RODecl <$$ keyword "RO" <** keychar ',' <**> pExpr 
  <||> flip RWDecl <$$ keyword "RW" <** keychar ',' <**> pExpr 
  <||> (\op1 op2 nm -> WODecl nm op1 op2) <$$ keyword "WO"  <** keychar ',' <**>
                          pOpName <** keychar ',' <**> pOpName

pRelDecl :: Parser RelDecl
pRelDecl = "REL-DECL" <:=> RelDecl <$$> pRSymb <**> mProps
  where mProps = maybe [] id <$$> 
                  optional (keychar ',' **> multipleSepBy1 pProp (keychar ','))
        pProp = "REL-PROP" 
          <:=> IsPure <$$ keyword "CONTEXT-FREE"
          <||> ValReflexive <$$ keyword "VAL-REFLEXIVE"

pTrans :: Parser TransDecl
pTrans = "TRANS" 
  <:=> ($) <$$ keyword "transaction" <**> parens
                (Trans <$$> pRSymb <** keychar ',' <**> id_lit) <**> 
                multiple1 pBranch
       
pBranch :: Parser Stmts
pBranch = "BRANCH" <:=> braces pStmts
 
pStmts :: Parser Stmts
pStmts = "BODY" <:=> 
  optional (keychar '|') **> multipleSepBy pStmt (optional (keychar '|'))

pStmt :: Parser Stmt
pStmt = "STMT" <:=> pStmtAlt <** optional (keychar ';')
  where pStmtAlt :: Parser Stmt
        pStmtAlt = "ALT-STMT" 
--          <||> keyword "branches" **> parens pBranches 
          <:=> arbitrary "pm-args" PM_Args pPattern 
          <||> binary "pm" PM pExpr pPattern
          <||> ternary_ "single" Single pRSymb pTerm pMVar 
          <||> ternary_ "many" Many pRSymb pTerm pMVar
          <||> binary_ "rw-get" rw_get string_lit pMVar
          <||> binary_ "rw-set" rw_set string_lit pExpr 
          <||> binary "ro-get_0" RO_Get string_lit pMVar
          <||> binary_ "ro-set" ro_set string_lit pExpr
          <||> binary "wo-set_0" WO_Set string_lit pExpr 
          <||> binary_ "wo-get" wo_get string_lit pMVar
          <||> unary "commit" Commit pTerm
          <||> Unobserv <$$ keyword "unobs" <** keychar '_' <**> int_lit
     
        ro_set a b Nothing  = error "ro-set without label"
        ro_set a b (Just i) = RO_Set a b i
        wo_get a b Nothing  = error "wo-get without label"
        wo_get a b (Just i) = WO_Get a b i
        rw_get a b Nothing  = error "rw-get without label"
        rw_get a b (Just i) = RW_Get a b i 
        rw_set a b Nothing  = error "rw-set without label"
        rw_set a b (Just i) = RW_Set a b i 

pLabel :: Parser Int
pLabel = "LABEL" <:=> keychar '_' **> int_lit

pExpr :: Parser Expr
pExpr = "EXPR" 
  <::=> Val <$$> pTerm
  <||>  VOP <$$> pOpName <**> 
          (maybe [] id <$$> optional (parens (multipleSepBy1 pExpr (keychar ','))))
        
pTerm :: Parser Term
pTerm = "TERM" 
  <::=> pVar TVar
  <||> tcons <$$> id_lit <**> optional (parens (multipleSepBy pTerm (keychar ',')))
  <||> int_ . (0-) <$$ keychar '-' <**> int_lit
  <||> int_ <$$> int_lit
  <||> string_ <$$> string_lit
  <||> parens (mkRule $ tuple_ <$$> multipleSepBy pTerm (keychar ',')) 
  where tcons "true" _  = true_
        tcons "false" _ = false_
        tcons cs margs = TCons (cs `elem` val_cons) cs (maybe [] id margs)

        val_cons = ["id"]

pPattern :: Parser Pattern
pPattern = "PATTERN"
  <::=> pVar PVar
  <||>  PAny <$$ keychar '_' 
  <||>  PCons <$$> id_lit <**> 
          (maybe [] id <$$> optional (parens (multipleSepBy1 pPattern (keychar ','))))

pMVar :: Parser MVar
pMVar = pVar id

pVar :: (MVar -> a) -> Parser a
pVar cons = "MVAR" <:=> tvar <$$> optional (keychar '_') <**> alt_id_lit
                            <**> optional ranges 
  where tvar m_ altid mr = cons $ MVar var l u
          where var   = maybe altid (const ('_':altid)) m_
                (l,u) = maybe (1,Just 1) id mr
        ranges = "RANGES-MVAR" <:=> (,) <$$ 
                    keychar '_' <**> int_lit <** keychar '_' <**> maxrange
          where maxrange = "MAX-RANGES-MVAR" <:=> Nothing <$$ keychar '*'
                                             <||> Just <$$> int_lit

pRel :: Parser Rel
pRel = "REL" <:=> rel <$$> pRSymb <**> pRep 
  where rel s rep = Rel s rep True 

        pRep = maybe NoRep (const Rep) <$$> optional (keychar '*')

pRSymb :: Parser RSymb
pRSymb = token "REL-SYMB"

pOpName :: Parser VOP
pOpName = "VOP" <:=> keychar '_' **> id_lit

optsemi :: Parser (Maybe Char)
optsemi = "OPTIONAL-SEMI" <:=> optional (keychar ';')

unary :: String -> (a -> b) -> Parser a -> Parser b
unary key f p = mkRule $ f <$$ keyword key <**> parens p

binary :: String -> (a -> b -> c) -> Parser a -> Parser b -> Parser c
binary key f = binary_ key (\a b _ -> f a b) 

ternary :: String -> (a -> b -> c -> d) -> 
            Parser a -> Parser b -> Parser c -> Parser d
ternary key f = ternary_ key (\a b c _ -> f a b c)
 
quaternary :: String -> (a -> b -> c -> d -> e) -> 
                Parser a -> Parser b -> Parser c -> Parser d -> Parser e
quaternary key f p1 p2 p3 p4 = mkRule $ keyword key **> parens args
  where args = mkRule $ f <$$> p1 <** keychar ',' 
                          <**> p2 <** keychar ',' 
                          <**> p3 <** keychar ','
                          <**> p4

arbitrary :: String -> ([a] -> b) -> Parser a -> Parser b
arbitrary key f p1 = mkRule $ keyword key **> parens args
  where args = mkRule $ f <$$> multipleSepBy p1 (keychar ',')

binary_ :: String -> (a -> b -> Maybe Label -> c) -> Parser a -> Parser b -> Parser c
binary_ key f p1 p2 = mkRule $ 
  flip ($) <$$ keyword key <**> optional pLabel <**> parens args
  where args = mkRule $ f <$$> p1 <** keychar ',' <**> p2

ternary_ :: String -> (a -> b -> c -> Maybe Label -> d) -> 
            Parser a -> Parser b -> Parser c -> Parser d
ternary_ key f p1 p2 p3 = mkRule $ 
  flip ($) <$$ keyword key <**> optional pLabel <**> parens args
  where args = mkRule $ f <$$> p1 <** keychar ',' <**> p2 <** keychar ',' <**> p3

pEither :: Parser a -> Parser b -> Parser (Either a b)
pEither p1 p2 = mkRule $ Left <$$> p1 <||> Right <$$> p2

pInference :: Parser Rule
pInference = "INFERENCE"
  <:=> flip Rule <$$> pConditions <** token "BAR" <**> pConclusion
 where 
  pConditions :: Parser [Either Premise SideCon]
  pConditions = "CONDS" <:=> [] <$$ keychar '#' 
                        <||> multiple1 pCondition
    where
      pCondition :: Parser (Either Premise SideCon)
      pCondition = "COND" 
        <:=> Left <$$> pPremise
        <||> Right <$$> pSideCon 

pSideCon :: Parser SideCon
pSideCon = "SIDE" <:=> SideOP <$$> pExpr <** keyword "|>" <**> pPattern

pContext :: Parser a -> Parser [a]
pContext p = mkNt p "-Context" <:=> maybe [] id <$$>  
    optional (multipleSepBy1 p (keychar ',') <** keyword "|-")


pConclusion :: Parser Conclusion
pConclusion = "CONCLUSION"
  <:=> mkConc <$$> pContext pEntPattRef <**> pBefore <**> pRSymb <**> pAfter 
  where pBefore :: Parser (Cons, [Pattern], [(EID,Pattern)])
        pBefore = "CL-BEFORE" <:=> (,,) <$$>
          id_lit <**> 
            (maybe [] id <$$> optional (parens 
                               (multipleSepBy1 pPattern (keychar ',')))) <**> 
            (maybe [] id <$$> optional (keychar ',' **> 
                                multipleSepBy1 pEntPattRef (keychar ',')))

        -- left is read-write update, right is write-only update
        pAfter :: Parser (Term, [Either (EID,Expr) (EID,Expr)])
        pAfter = "CL-AFTER" <:=> (,) <$$> 
          pTerm <**> (maybe [] id <$$> 
                     optional (keychar ',' **> multipleSepBy1 pRHSRef (keychar ',')))
          where pRHSRef = "RHS-REF" 
                  <:=> mkRef <$$> optional (keychar '!') <**> pEntExprRef
                  where mkRef mE ref = case mE of Nothing -> Left ref
                                                  _       -> Right ref
        mkConc :: [ROacc] -> (Cons, [Pattern], [(EID,Pattern)]) -> RSymb -> 
                    (Term, [Either (EID,Expr) (EID,Expr)]) -> Conclusion
        mkConc ros (f,ps,rwAcc) r (t,refs) = Conclusion f ps r t ros rws wos
          where rws = merge rwAcc (lefts refs)
                  where merge accs ups =
                          [ (e1,p,t) | (e1,p) <- accs, (e2,t) <- ups, e1 == e2 ] 
                wos = rights refs

pPremise :: Parser Premise
pPremise = "PREMISE"  
  <:=> mkPrem <$$> pContext pEntExprRef <**> pBefore <**> pRel <**> pAfter 
 where  pBefore :: Parser (Term, [(EID,Expr)])
        pBefore = "PREM-BEFORE" <:=> (,) <$$>
          pTerm <**> (maybe [] id <$$> optional (keychar ',' **> 
                                multipleSepBy1 pEntExprRef (keychar ',')))

        -- left is read-write update, right is write-only update
        pAfter :: Parser (Pattern, [Either (EID,Pattern) (EID,Pattern)])
        pAfter = "PREM-AFTER" <:=> (,) <$$>
          pPattern <**> (maybe [] id <$$>
                     optional (keychar ',' **> multipleSepBy1 pRHSRef (keychar ',')))
          where pRHSRef = "PREM-RHS-REF" 
                  <:=> mkRef <$$> optional (keychar '!') <**> pEntPattRef
                  where mkRef mE ref = case mE of Nothing -> Left ref
                                                  _       -> Right ref

        mkPrem:: [ROup] -> (Term, [(EID,Expr)]) -> Rel -> 
                    (Pattern, [Either (EID,Pattern) (EID,Pattern)]) -> Premise 
        mkPrem ros (t,rwUps) r (p,refs) = Prem t r p ros rws wos
          where rws = merge rwUps (lefts refs)
                  where merge ups accs =
                          [ (e1,f,t) | (e1,f) <- ups, (e2,t) <- accs, e1 == e2 ]
                wos = rights refs

pEntPattRef :: Parser (EID, Pattern)
pEntPattRef = "PATT-REF" <:=> (,) <$$> id_lit <**> parens pPattern

pEntExprRef :: Parser (EID, Expr)
pEntExprRef = "EXPR-REF" <:=> (,) <$$> id_lit <**> parens pExpr

{-
pRWEntAcc = Parser (EID, Pattern, Expr)
pRWEntAcc= "RW-ACC" <:=> (,,) <$$> id_lit <**> pPattern <**> pExpr

pRWEntUp = Parser (EID, Pattern, Expr)
pRWEntUp= "RW-UP" <:=> (,,) <$$> id_lit <**> pExpr <**> pPattern
-}


-- | Flag value constructors in terms
class HasCons a where
  blossom :: [Cons] -> a -> a

instance HasCons a => HasCons [a] where
  blossom cs xs = map (blossom cs) xs

instance HasCons Query where
  blossom cs (Query t r p) = Query (blossom cs t) r p 

instance HasCons a => HasCons (AnyDecls a) where
  blossom cs ad = case ad of
    AnEntDecl _   -> ad
    ARelDecl _    -> ad
    ARuleDecl a   -> ARuleDecl (blossom cs a)

instance (HasCons a, HasCons b) => HasCons (Either a b) where
  blossom cs (Left l) = Left (blossom cs l)
  blossom cs (Right r) = Right (blossom cs r)

instance HasCons a => HasCons (ATransDecl a) where
  blossom cs (Trans r f ss) = Trans r f (blossom cs ss)

instance HasCons Rule where
  blossom cs (Rule (Conclusion f ps r t ros rws wos) es) = 
    Rule (Conclusion f ps r (blossom cs t) (blossom cs ros)
            (blossom cs rws) (blossom cs wos)) (blossom cs es)

instance HasCons SideCon where
  blossom cs (SideOP expr pat) = SideOP (blossom cs expr) pat

instance HasCons Expr where
  blossom cs e = case e of 
    Val t -> Val $ blossom cs t
    VOP op es -> VOP op $ blossom cs es

instance HasCons Premise where
  blossom cs (Prem t r p ros rws wos) = 
    Prem (blossom cs t) r p (blossom cs ros) (blossom cs rws) (blossom cs wos)

instance (HasCons a, HasCons b) => HasCons (a,b) where
  blossom cs (a,b) = (blossom cs a, blossom cs b)

instance (HasCons a, HasCons b, HasCons c) => HasCons (a,b,c) where
  blossom cs (a,b,c) = (blossom cs a, blossom cs b, blossom cs c)

instance HasCons Char where
  blossom cs = id

instance HasCons Pattern where  
  blossom cs = id

instance HasCons Term where
  blossom cs t = case t of 
    TCons b nm args -> TCons (b || nm `elem` cs) nm (blossom cs args)
    TVar _          -> t

instance HasCons Stmt where
  blossom cs stmt = case stmt of
    Commit t          -> Commit (blossom cs t)
    Branches sss      -> Branches (blossom cs sss)
    PM_Args ps        -> PM_Args ps
    PM e p            -> PM (blossom cs e) p
    Unobserv l        -> Unobserv l
    Single r t x l    -> Single r (blossom cs t) x l
    Many r t x l      -> Many r (blossom cs t) x l
    RO_Get eid x      -> RO_Get eid x
    WO_Get eid x l    -> WO_Get eid x l
    RW_Get eid x l    -> RW_Get eid x l
    RO_Set eid e l    -> RO_Set eid (blossom cs e) l
    WO_Set eid e      -> WO_Set eid (blossom cs e)
    RW_Set eid e l    -> RW_Set eid (blossom cs e) l
