
module IML.Trans.ToLower where

import IML.Grammar.Shared 
import IML.Grammar.RuleFormat as HIGH
import IML.Grammar.Grammar as LOW
import IML.Trans.ProMan

import Control.Monad (liftM2)

import Data.List (partition)
import qualified Data.Map as M

infixr 5 <++>
(<++>) :: ProMan Stmts -> ProMan Stmts -> ProMan Stmts
(<++>) = liftM2 (++)

infixr 5 <++
(<++) :: ProMan Stmts -> Stmts -> ProMan Stmts 
p <++ as = p <++> return as

infixr 5 ++>
(++>) :: Stmts -> ProMan Stmts -> ProMan Stmts
as ++> q = return as <++> q

tRule_ :: RelTable -> Rule -> ProMan TransDecl
tRule_ rtab rule = (\(Trans r f ss) -> Trans r f [ss]) <$> tRule rtab rule

tRule :: RelTable -> Rule -> ProMan (ATransDecl Stmts)
tRule rtab rule@(Rule cl@(Conclusion f _ r _ _ _ _) _) = 
  Trans r f <$> gRuleBody rtab rule

mergeBy :: (a -> a -> Bool) -> (a -> a -> a) -> [a] -> [a]
mergeBy eq merge []      = []
mergeBy eq merge (x:xs)  = foldl merge x ys : mergeBy eq merge zs
  where (ys,zs) = partition (eq x) xs 

gRuleBody :: RelTable -> Rule -> ProMan Stmts
gRuleBody rtab (Rule (Conclusion _ pats _ rhs ro rw wo) conds) = 
  gROgets ro <++>
  [PM_Args pats] ++>
  gRWgets 0 rw <++>
  gConditions rtab conds <++
  gRWsets_ 0 rw ++
  gWOsets wo ++ 
  [Commit rhs]

gConditions :: RelTable -> [Either Premise SideCon] -> ProMan Stmts
gConditions tab = (concat <$>) . mapM (either gPremise gSideCond)
                               . snd . foldr mAss (1,[])
  where mAss (Left p@(Prem t (Rel rel _ _) _ _ _ _)) (seed,acc)
          | rel_pure tab rel  = (seed, (Left (Nothing, p)) : acc) 
          | otherwise         = (succ seed, (Left (Just seed, p)) : acc)
        mAss (Right sc) (seed,acc) = (seed, Right sc : acc)

gPremise :: (Maybe Label, Premise) -> ProMan Stmts
gPremise (Nothing, Prem t rel p _ _ _) = gSingleOrMany Nothing t rel p
gPremise (Just l, Prem t rel p ro rw wo) = 
  gROsets l ro ++> 
  gRWsets l rw ++>
  gSingleOrMany (Just l) t rel p <++>
  gRWgets_ l rw <++>
  gWOgets l wo

gSingleOrMany :: Maybe Label -> Term -> Rel -> Pattern -> ProMan Stmts
gSingleOrMany ml t (Rel r rep obser) p = case p of 
    PVar x  -> return ([prem r t x ml] ++ sfx)
    _       -> do   x <- fresh_var_ 
                    return ([prem r t x ml, PM (Val (TVar x)) p] ++ sfx)
  where prem = case rep of NoRep -> Single
                           Rep   -> Many
        sfx = case ml of Just l | obser     -> []
                                | otherwise -> [Unobserv l] 
                         Nothing            -> []

gSideCond :: SideCon -> ProMan Stmts
gSideCond (SideOP e p) = case p of 
  PVar x  -> return [PM e (PVar x)]
  -- split in two:
  -- * increases the efficiency of left-factoring
  -- * makes left-factoring more costly
  _       -> do b <- boolOpt opt_split_pm
                if b then do  x <- fresh_var_ 
                              return [PM e (PVar x), PM  (Val (TVar x)) p]
                     else return [PM e p]

-- ro set
gROsets :: Label -> [ROup] -> Stmts
gROsets = map . gROset

gROset :: Label -> ROup -> Stmt
gROset l (eid, e) = RO_Set eid e l

-- ro get
gROgets :: [ROacc] -> ProMan Stmts
gROgets ro = concat <$> mapM gROget ro

gROget :: ROacc -> ProMan Stmts
gROget (eid, (PVar x)) = return [RO_Get eid x]
gROget (eid, p) = do
  x0 <- fresh_var_
  return [RO_Get eid x0, PM (Val (TVar x0)) p]

-- wo set
gWOsets :: [WOup] -> Stmts
gWOsets = map gWOset

gWOset :: WOup -> Stmt
gWOset (eid, e) = WO_Set eid e

-- wo get
gWOgets :: Label -> [WOacc] -> ProMan Stmts
gWOgets l = (concat <$>) . mapM (gWOget l)

gWOget :: Label -> WOacc -> ProMan Stmts
gWOget l (eid, (PVar x)) = return [WO_Get eid x l]
gWOget l (eid, p) = do
  x <- fresh_var_
  return [WO_Get eid x l, PM (Val (TVar x)) p]

-- rw set
gRWsets :: Label -> [RWup] -> Stmts
gRWsets l = map (gRWset l)

gRWset :: Label -> RWup -> Stmt
gRWset l (eid, e, _) = RW_Set eid e l

gRWsets_ :: Label -> [RWacc] -> Stmts
gRWsets_ l = map (gRWset_ l)

gRWset_ :: Label -> RWacc -> Stmt
gRWset_ l (eid, p, e) = gRWset l (eid, e, p)

-- rw get
gRWgets :: Label -> [RWacc] -> ProMan Stmts
gRWgets l = (concat <$>) . mapM (gRWget l)

gRWget :: Label -> RWacc -> ProMan Stmts
gRWget l (eid, (PVar x), _) = return [RW_Get eid x l]
gRWget l (eid, p, _) = do
  x <- fresh_var_
  return [RW_Get eid x l, PM (Val (TVar x)) p] 

gRWgets_ :: Label -> [RWup] -> ProMan Stmts
gRWgets_ l = (concat <$>) . mapM (gRWget_ l)

gRWget_ :: Label -> RWup -> ProMan Stmts
gRWget_ l (eid, t, p) = gRWget l (eid, p, t)

