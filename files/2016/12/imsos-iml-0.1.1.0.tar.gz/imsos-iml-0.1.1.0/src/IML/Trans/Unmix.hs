
module IML.Trans.Unmix where
 
import IML.Grammar.Grammar as LOW
import IML.Grammar.Mixed as Mixed
import IML.Grammar.Shared as Shared
import IML.Trans.ProMan
import IML.Trans.ToLower

unmix :: Component MixedProgram Program
unmix = component program
  where program (SharedProgram (Shared.Spec ops decls) qs) = do
          decls' <- mergeTrans <$> genTrans decls 
          return (Program (LOW.Spec ops decls') qs)

genTrans :: [AnyDecls (Either Rule TransDecl)] -> ProMan [AnyDecls TransDecl]
genTrans ds = mapM (mapM op) ds
  where 
        op :: Either Rule TransDecl -> ProMan TransDecl 
        op (Left rule)  = tRule_ (relFromAnyDecls ds) rule 
        op (Right d)    = return d

mergeTrans :: [AnyDecls TransDecl] -> [AnyDecls TransDecl]
mergeTrans decls = 
  case foldr merge (Nothing,[]) decls of  (Nothing, acc)  -> acc
                                          (Just t, acc)   -> ARuleDecl t : acc
  where merge (ARuleDecl (Trans r f ss)) (mtd, acc) = 
          case mtd of 
            Nothing   -> (Just (Trans r f ss), acc)
            Just (Trans r2 f2 sss) 
              | r == r2, f == f2 -> (Just (Trans r f (ss++sss)), acc)
              | otherwise -> (Just (Trans r f ss)
                             ,(ARuleDecl (Trans r2 f2 sss)):acc)
        merge odecl (mtd,acc) = 
          case mtd of Nothing -> (Nothing, cast odecl: acc)
                      Just td -> (Nothing, cast odecl: ARuleDecl td: acc)
          where cast (AnEntDecl e) = AnEntDecl e
                cast (ARelDecl e)  = ARelDecl e
                cast _ = error "pProgram cast"

