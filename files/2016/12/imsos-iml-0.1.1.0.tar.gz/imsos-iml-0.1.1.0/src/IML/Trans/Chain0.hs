
module IML.Trans.Chain0 where

import IML.Grammar
import IML.Trans.ProMan

chain :: Component Program Program
chain = component_ id
