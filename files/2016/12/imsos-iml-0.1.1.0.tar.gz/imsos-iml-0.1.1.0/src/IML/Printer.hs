
module IML.Printer where

import IML.Grammar.Shared hiding (Spec(..))
import IML.Grammar

import Data.List (intersperse,intercalate)
import Text.PrettyPrint.HughesPJ

iml_print :: Program -> String
iml_print = render . ppProgram

ppProgram :: Program -> Doc
ppProgram (Program spec qs) = 
  ppQueries qs $+$ text "" $+$ ppSpec spec

ppSpec :: Spec -> Doc
ppSpec (Spec vops ds) = 
  vcat [ text "value-constructor" <> showArgs [text op] | op <- vops ]$+$text ""$+$
  vcat (map ppEntDecl ents) $+$ text "" $+$
  vcat (map ppRelDecl rels) $+$ text "" $+$
  vsep (map ppTransDecl rules) $+$ text "" 
  where (ents,rels,rules) = partition_decls ds

ppQueries :: Queries -> Doc
ppQueries = vcat . map ppQuery

ppQuery :: Query -> Doc
ppQuery (Query t r p) = ppTerm t <+> ppRel r <+> text "?" 

ppEntDecl :: EntDecl -> Doc
ppEntDecl d = case d of
  RODecl eid e -> 
    text "entity" <> showArgs [text eid, text "RO", ppExpr e]
  RWDecl eid e ->
    text "entity" <> showArgs [text eid, text "RW", ppExpr e]
  WODecl eid op2 op0 -> 
    text "entity" <> showArgs [text eid, text "WO", ppOp op2, ppOp op0]

ppRel :: Rel -> Doc
ppRel (Rel r rep _) = (text r <>) $ case rep of NoRep -> empty
                                                Rep   -> text "*"

ppRelDecl :: RelDecl -> Doc
ppRelDecl (RelDecl rel preds) = 
  text "relation" <> showArgs (text rel : map ppPred preds)
  where ppPred IsPure       = text "CONTEXT-FREE"
        ppPred Orderable    = text "ORDERABLE"
        ppPred ValReflexive = text "VAL-REFLEXIVE"

ppTransDecl :: TransDecl -> Doc
ppTransDecl (Trans sym cons stmts) = 
    text "transaction" <> showArgs [text sym,text cons] <> ppBranches 1 stmts

ppStmtsLine :: Stmts -> Doc
ppStmtsLine = hcat . map (enclose . ppStmt)
  where enclose s = s <> semi

ppStmts :: Stmts -> Doc
ppStmts = ppStmtsB 1  

ppStmtsB :: Int -> Stmts -> Doc
ppStmtsB branchnr = vcat . map (enclose . ppStmtB branchnr)
  where enclose s = s <> semi

ppStmt :: Stmt -> Doc
ppStmt = ppStmtB 1

ppStmtB :: Int -> Stmt -> Doc
ppStmtB branchnr s = case s of
--  Skip              -> text "skip"
--  Abort             -> text "aborts"
--  Assert e          -> text "assert" <> showArgs [ppExpr e]
  PM_Args ps        -> text "pm-args" <> showArgs (map ppPattern ps) 
  PM e p            -> text "pm" <> showArgs [ppExpr e, ppPattern p]
  Commit t          -> text "commit" <> showArgs [ppTerm t]
  Single r t x ml   -> text "single" <> ppMLabel ml <> showArgs [text r, ppTerm t, gVar x]
  Many   r t x ml   -> text "many" <> ppMLabel ml <> showArgs [text r, ppTerm t, gVar x]
  Unobserv l        -> text "unobserv" <> ppLabel l
  RO_Set eid e l    -> text "ro-set" <> ppLabel l <> showArgs [dquote eid, ppExpr e]
  RO_Get eid x      -> text "ro-get" <> ppLabel 0 <> showArgs [dquote eid, gVar x]
  RW_Set eid e l    -> text "rw-set" <> ppLabel l <> showArgs [dquote eid, ppExpr e]
  RW_Get eid x l    -> text "rw-get" <> ppLabel l <> showArgs [dquote eid, gVar x]
  WO_Set eid e      -> text "wo-set" <> ppLabel 0 <> showArgs [dquote eid, ppExpr e]
  WO_Get eid x l    -> text "wo-get" <> ppLabel l <> showArgs [dquote eid, gVar x]
  Branches sss      -> text "branches" <> ppBranches branchnr sss 
  where ppMLabel Nothing  = empty
        ppMLabel (Just i) = ppLabel i
        ppLabel i         = text "_" <> text (show i) 

ppBranches :: Int -> [Stmts] -> Doc
ppBranches branchnr sss = text "{" $+$ branches $+$ text "}"
  where branches = vcat $ intersperse (text "}{")
                                  (map (ppStmtsB (branchnr + 1)) sss)

ppExpr :: Expr -> Doc
ppExpr (Val t) = ppTerm t
ppExpr (VOP op es) 
  | null es = ppOp op
  | otherwise =  ppOp op <> showArgs (map ppExpr es)

ppTerm :: Term -> Doc
ppTerm (TVar v) = gVar v 
ppTerm (TCons True "string" [TCons True v []]) = dquote v
ppTerm (TCons True "list" vs) = 
  text "[" <> hsep (intersperse comma (map ppTerm vs)) <> text "]"
ppTerm (TCons True "tuple" ts) = showArgs (map ppTerm ts)
ppTerm (TCons True "integer" [TCons True s []]) = text s
ppTerm m@(TCons True "_map" ps) = 
  text "{" <> hsep (intersperse comma (map ppPair ps)) <> text "}"
  where ppPair (TCons True "tuple" [k,v]) = ppTerm k <+> text "|->" <+> ppTerm v
        ppPair t = ppTerm t
ppTerm (TCons _ cs ts)  | null ts   = text cs
                        | otherwise = text cs <> showArgs (map ppTerm ts)

ppPattern :: Pattern -> Doc
ppPattern (PVar v) = gVar v
ppPattern (PAny)   = text "_"
ppPattern (PCons cons ps) | null ps = text cons
                          | otherwise = text cons <> showArgs (map ppPattern ps)

ppOp :: String -> Doc
ppOp op = text "_" <> text op

showArgs :: [Doc] -> Doc
showArgs args = lparen <> hcat (intersperse comma args) <> rparen

gVar :: MVar -> Doc
gVar v = text (show v)

vsep = vcat . intersperse (text "")

dquote = doubleQuotes . text

instance Show Term where
  show = render . ppTerm
