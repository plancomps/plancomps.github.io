
module Main where

import IML.Grammar
import IML.Trans.ProMan 
import IML.Options
import IML.Printer
import IML.Trans.Unmix
import qualified IML.Trans.UniChain
import qualified IML.Trans.ChainBasicLeftFactor
import qualified IML.Trans.ChainLeftFactor
import qualified IML.Trans.ChainReorderFactor
import qualified IML.Trans.ChainReorder
import qualified IML.Trans.Chain0
import IML.Lexer
import IML.Parser
import qualified IML.Interpreter.Interpreter as INTERPRETER

import Control.Arrow ((>>>))
import Data.List (isSuffixOf)

import System.FilePath
import System.Environment

main = getArgs >>= run

run :: [String] -> IO()
run (imlf:options) | ".iml" `isSuffixOf` imlf = selectPipeline imlf options
run _ = putStrLn ("Please provide a .iml file (first argument)") 

selectPipeline :: FilePath -> [String] -> IO ()
selectPipeline imlf options 
  | otherwise = execProgram imlf options (chain options) >>= 
                      backend imlf options


execProgram :: FilePath -> [String] -> Component Program b -> IO b
execProgram fp opts chain = 
  readFile fp >>= runComponentIO (IML.Trans.ProMan.runOptions opts) 
                    (lexer >>> parser >>> unmix >>> chain)

chain :: [String] -> Component Program Program 
chain options 
  | "--unify-only" `elem` options   = IML.Trans.UniChain.chain 
  | "--basic-left-factor" `elem` options = IML.Trans.ChainBasicLeftFactor.chain
  | "--left-factor" `elem` options  = IML.Trans.ChainLeftFactor.chain
  | "--full-reorder-factor" `elem` options = 
      IML.Trans.ChainReorderFactor.chain >>> IML.Trans.ChainReorder.chain
  | "--reorder" `elem` options      = IML.Trans.ChainReorder.chain
  | otherwise                       = IML.Trans.Chain0.chain

backend :: FilePath -> [String] -> Program -> IO () 
backend imlf options 
  | "--interpret" `elem` options = printer outf options . runProgram
  | "--iml" `elem` options = printer modf options . iml_print
  | "--all" `elem` options = \program -> do writeFile outf (runProgram program)
                                            writeFile modf (iml_print program) 
  | otherwise = printer outf options . runProgram 
  where
  printer :: FilePath -> [String] -> String -> IO ()
  printer file options 
    | "--write-file" `elem` options = writeFile file 
    | otherwise = putStrLn 
  hsf = replaceExtension imlf "hs"
  outf = replaceExtension imlf "output"
  modf = replaceBaseName imlf (takeBaseName imlf ++ "_mod")

runProgram = unlines . concatMap (\(a,b) -> [show a, show b]) . INTERPRETER.run  
