#/usr/bash

# Example usage (dynamic semantics only)
# > ./run-fct.sh -f Tests/Danvy89/Test1.fct

# Example usage (with type checking)
# > ./run-fct.sh -t -f Tests/Danvy89/Test1.fct

START="startf_nt"

while getopts tf: OPTION
do
  case "$OPTION" in
    t) START="startf";;
    f) FILE="$OPTARG";;
  esac
done

swipl -s Prolog/run_fct.pl -q -g "$START('"$FILE"'),halt."
