% Generated from Funcon/Caml-Light/CL-Auxillary-Funcons.csf

sigdec(cl_match_failure,nominal_vals,[]).

onestep(cl_match_failure,A,B,resolve) :-     unobs(A),     rewrites(cl_match_failure,B).

onestep(cl_match_failure,A,B,typeval) :-     unobs(A),     rewrites(cl_match_failure,B).

onestep(cl_match_failure,A,bound_type(nameid(q(builtin),id(q(exn)))),inhabit) :-     unobs(A).

onestep(cl_match_failure,A,M,run) :-     unobs(A),     rewrites(q('Match_failure_builtin'),C),     rewrites(nomtag(C),K),     rewrites(q('Match_failure'),I),     rewrites(q('""'),E),     rewrites(str(E),F),     rewrites(q(0),G),     rewrites(q(0),H),     rewrites(tuple3(F,G,H),J),     rewrites(variant(I,J),L),     rewrites(nomval(K,L),M).

sigdec(cl_division_by_zero,nominal_vals,[]).

onestep(cl_division_by_zero,A,B,resolve) :-     unobs(A),     rewrites(cl_division_by_zero,B).

onestep(cl_division_by_zero,A,B,typeval) :-     unobs(A),     rewrites(cl_division_by_zero,B).

onestep(cl_division_by_zero,A,bound_type(nameid(q(builtin),id(q(exn)))),inhabit) :-     unobs(A).

onestep(cl_division_by_zero,A,I,run) :-     unobs(A),     rewrites(q('Division_by_zero_builtin'),C),     rewrites(nomtag(C),G),     rewrites(q('Division_by_zero'),E),     rewrites(tuple_empty,F),     rewrites(variant(E,F),H),     rewrites(nomval(G,H),I).

sigdec(cl_invalid_argument,nominal_vals,[strings]).

onestep(cl_invalid_argument(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(cl_invalid_argument(E),F).

onestep(cl_invalid_argument(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(cl_invalid_argument(E),F).

onestep(cl_invalid_argument(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(cl_invalid_argument(E),F).

sigdec(cl_invalid_argument,computes(nominal_vals),[computes(strings)]).

onestep(cl_invalid_argument(A),D,bound_type(nameid(q(builtin),id(q(exn)))),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,strings).

onestep(cl_invalid_argument(A),D,M,run) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,val),     checktag(C,val,H),     unobs(D),     rewrites(q('Invalid_argument_builtin'),F),     rewrites(nomtag(F),K),     rewrites(q('Invalid_argument'),I),     rewrites(H,J),     rewrites(variant(I,J),L),     rewrites(nomval(K,L),M).

sigdec(cl_throw_invalid_argument,computes(_),[strings]).

onestep(cl_throw_invalid_argument(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(cl_throw_invalid_argument(E),F).

onestep(cl_throw_invalid_argument(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(cl_throw_invalid_argument(E),F).

onestep(cl_throw_invalid_argument(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(cl_throw_invalid_argument(E),F).

sigdec(cl_throw_invalid_argument,computes(_),[computes(strings)]).

onestep(cl_throw_invalid_argument(A),D,_,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,strings).

onestep(cl_throw_invalid_argument(A),D,N,run) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,val),     checktag(C,val,H),     unobs(D),     rewrites(q('Invalid_argument_builtin'),F),     rewrites(nomtag(F),K),     rewrites(q('Invalid_argument'),I),     rewrites(H,J),     rewrites(variant(I,J),L),     rewrites(nomval(K,L),M),     rewrites(throw(M),N).

sigdec(cl_comparable,booleans,[_]).

onestep(cl_comparable(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(cl_comparable(E),F).

onestep(cl_comparable(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(cl_comparable(E),F).

onestep(cl_comparable(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(cl_comparable(E),F).

sigdec(cl_comparable,computes(booleans),[_]).

onestep(cl_comparable(A),D,booleans,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,_).

rewrite(cl_comparable(A),E) :-     rewrites(A,C),     rewrites(C,B),     runcheck(B,nullary),     checktag(B,nullary,_),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,_),     rewrites(true,E).

rewrite(cl_comparable(A),C) :-     rewrites(A,abs(B)),     rewrites(B,_),     rewrites(false,C).

rewrite(cl_comparable(A),J) :-     decompose(B,G,[C]),     rewrites(A,B),     decompose(B,G,[C]),     rewrites(C,H),     decompose(D,G,[H]),     rewrites(D,E),     decompose(D,G,[H]),     runcheck(E,val),     checktag(E,val,_),     decompose(F,G,[H]),     different(F,abs(H)),     decompose(F,G,[H]),     rewrites(H,I),     rewrites(cl_comparable(I),J).

rewrite(cl_comparable(A),N) :-     decompose(B,F,[C,D]),     rewrites(A,B),     decompose(B,F,[C,D]),     rewrites(C,H),     rewrites(D,J),     decompose(E,F,[H,J]),     rewrites(E,G),     decompose(E,F,[H,J]),     runcheck(G,val),     checktag(G,val,_),     rewrites(H,I),     rewrites(cl_comparable(I),L),     rewrites(J,K),     rewrites(cl_comparable(K),M),     rewrites(and(L,M),N).

rewrite(cl_comparable(A),S) :-     decompose(B,G,[C,D,E]),     rewrites(A,B),     decompose(B,G,[C,D,E]),     rewrites(C,I),     rewrites(D,K),     rewrites(E,M),     decompose(F,G,[I,K,M]),     rewrites(F,H),     decompose(F,G,[I,K,M]),     runcheck(H,val),     checktag(H,val,_),     rewrites(I,J),     rewrites(cl_comparable(J),Q),     rewrites(K,L),     rewrites(cl_comparable(L),O),     rewrites(M,N),     rewrites(cl_comparable(N),P),     rewrites(and(O,P),R),     rewrites(and(Q,R),S).

sigdec(cl_struct_equal,computes(booleans),[A,A]).

onestep(cl_struct_equal(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(cl_struct_equal(G,H),I).

onestep(cl_struct_equal(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(cl_struct_equal(G,H),I).

onestep(cl_struct_equal(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(cl_struct_equal(J,K),L).

onestep(cl_struct_equal(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(cl_struct_equal(J,K),L).

sigdec(cl_struct_equal,computes(booleans),[A,A]).

rewrite(cl_struct_equal(A,B),M) :-     rewrites(A,E),     rewrites(B,G),     rewrites(E,C),     runcheck(C,val),     checktag(C,val,_),     rewrites(G,D),     runcheck(D,val),     checktag(D,val,_),     rewrites(E,F),     runcheck(F,nullary),     checktag(F,nullary,I),     rewrites(G,H),     runcheck(H,nullary),     checktag(H,nullary,J),     rewrites(I,K),     rewrites(J,L),     rewrites(equal(K,L),M).

rewrite(cl_struct_equal(A,C),M) :-     rewrites(A,var(B)),     rewrites(B,E),     rewrites(C,var(D)),     rewrites(D,H),     rewrites(E,F),     rewrites(var(F),G),     rewrites(assigned_value(G),K),     rewrites(H,I),     rewrites(var(I),J),     rewrites(assigned_value(J),L),     rewrites(cl_struct_equal(K,L),M).

rewrite(cl_struct_equal(A,D),R) :-     decompose(B,L,[C]),     rewrites(A,B),     decompose(B,L,[C]),     rewrites(C,N),     decompose(E,L,[F]),     rewrites(D,E),     decompose(E,L,[F]),     rewrites(F,O),     decompose(G,L,[N]),     rewrites(G,H),     decompose(G,L,[N]),     runcheck(H,val),     checktag(H,val,_),     decompose(I,L,[O]),     rewrites(I,J),     decompose(I,L,[O]),     runcheck(J,val),     checktag(J,val,_),     decompose(K,L,[M]),     \+rewrites(K,var(_)),     decompose(K,L,[M]),     rewrites(N,P),     rewrites(O,Q),     rewrites(cl_struct_equal(P,Q),R).

rewrite(cl_struct_equal(A,D),S) :-     decompose(B,N,[C]),     rewrites(A,B),     decompose(B,N,[C]),     rewrites(C,H),     decompose(E,Q,[F]),     rewrites(D,E),     decompose(E,Q,[F]),     rewrites(F,K),     decompose(G,N,[H]),     rewrites(G,I),     decompose(G,N,[H]),     runcheck(I,val),     checktag(I,val,_),     decompose(J,Q,[K]),     rewrites(J,L),     decompose(J,Q,[K]),     runcheck(L,val),     checktag(L,val,_),     decompose(M,N,[O]),     decompose(P,Q,[R]),     \+rewrites(M,P),     decompose(M,N,[O]),     decompose(P,Q,[R]),     rewrites(false,S).

rewrite(cl_struct_equal(A,E),X) :-     decompose(B,L,[C,D]),     rewrites(A,B),     decompose(B,L,[C,D]),     rewrites(C,N),     rewrites(D,R),     decompose(F,L,[G,H]),     rewrites(E,F),     decompose(F,L,[G,H]),     rewrites(G,O),     rewrites(H,S),     decompose(I,L,[N,R]),     rewrites(I,J),     decompose(I,L,[N,R]),     runcheck(J,val),     checktag(J,val,_),     decompose(K,L,[O,S]),     rewrites(K,M),     decompose(K,L,[O,S]),     runcheck(M,val),     checktag(M,val,_),     rewrites(N,P),     rewrites(O,Q),     rewrites(cl_struct_equal(P,Q),V),     rewrites(R,T),     rewrites(S,U),     rewrites(cl_struct_equal(T,U),W),     rewrites(and(V,W),X).

rewrite(cl_struct_equal(A,E),Y) :-     decompose(B,R,[C,D]),     rewrites(A,B),     decompose(B,R,[C,D]),     rewrites(C,J),     rewrites(D,K),     decompose(F,V,[G,H]),     rewrites(E,F),     decompose(F,V,[G,H]),     rewrites(G,N),     rewrites(H,O),     decompose(I,R,[J,K]),     rewrites(I,L),     decompose(I,R,[J,K]),     runcheck(L,val),     checktag(L,val,_),     decompose(M,V,[N,O]),     rewrites(M,P),     decompose(M,V,[N,O]),     runcheck(P,val),     checktag(P,val,_),     decompose(Q,R,[S,T]),     decompose(U,V,[W,X]),     \+rewrites(Q,U),     decompose(Q,R,[S,T]),     decompose(U,V,[W,X]),     rewrites(false,Y).

rewrite(cl_struct_equal(A,F),ZF) :-     decompose(B,N,[C,D,E]),     rewrites(A,B),     decompose(B,N,[C,D,E]),     rewrites(C,P),     rewrites(D,T),     rewrites(E,Z),     decompose(G,N,[H,I,J]),     rewrites(F,G),     decompose(G,N,[H,I,J]),     rewrites(H,Q),     rewrites(I,U),     rewrites(J,ZA),     decompose(K,N,[P,T,Z]),     rewrites(K,L),     decompose(K,N,[P,T,Z]),     runcheck(L,val),     checktag(L,val,_),     decompose(M,N,[Q,U,ZA]),     rewrites(M,O),     decompose(M,N,[Q,U,ZA]),     runcheck(O,val),     checktag(O,val,_),     rewrites(P,R),     rewrites(Q,S),     rewrites(cl_struct_equal(R,S),X),     rewrites(T,V),     rewrites(U,W),     rewrites(cl_struct_equal(V,W),Y),     rewrites(and(X,Y),ZD),     rewrites(Z,ZB),     rewrites(ZA,ZC),     rewrites(cl_struct_equal(ZB,ZC),ZE),     rewrites(and(ZD,ZE),ZF).

rewrite(cl_struct_equal(A,F),ZE) :-     decompose(B,V,[C,D,E]),     rewrites(A,B),     decompose(B,V,[C,D,E]),     rewrites(C,L),     rewrites(D,M),     rewrites(E,N),     decompose(G,ZA,[H,I,J]),     rewrites(F,G),     decompose(G,ZA,[H,I,J]),     rewrites(H,Q),     rewrites(I,R),     rewrites(J,S),     decompose(K,V,[L,M,N]),     rewrites(K,O),     decompose(K,V,[L,M,N]),     runcheck(O,val),     checktag(O,val,_),     decompose(P,ZA,[Q,R,S]),     rewrites(P,T),     decompose(P,ZA,[Q,R,S]),     runcheck(T,val),     checktag(T,val,_),     decompose(U,V,[W,X,Y]),     decompose(Z,ZA,[ZB,ZC,ZD]),     \+rewrites(U,Z),     decompose(U,V,[W,X,Y]),     decompose(Z,ZA,[ZB,ZC,ZD]),     rewrites(false,ZE).

rewrite(cl_struct_equal(A,B),I) :-     rewrites(A,E),     rewrites(B,G),     rewrites(E,C),     runcheck(C,val),     checktag(C,val,_),     rewrites(G,D),     runcheck(D,val),     checktag(D,val,_),     rewrites(E,F),     runcheck(F,nullary),     checktag(F,nullary,_),     \+ (rewrites(G,H),runcheck(H,nullary),checktag(H,nullary,_)),     rewrites(false,I).

rewrite(cl_struct_equal(A,D),M) :-     decompose(B,K,[C]),     rewrites(A,B),     decompose(B,K,[C]),     rewrites(C,F),     rewrites(D,I),     decompose(E,K,[F]),     rewrites(E,G),     decompose(E,K,[F]),     runcheck(G,val),     checktag(G,val,_),     rewrites(I,H),     runcheck(H,val),     checktag(H,val,_),     decompose(J,K,[L]),     \+rewrites(I,J),     decompose(J,K,[L]),     rewrites(false,M).

rewrite(cl_struct_equal(A,E),P) :-     decompose(B,M,[C,D]),     rewrites(A,B),     decompose(B,M,[C,D]),     rewrites(C,G),     rewrites(D,H),     rewrites(E,K),     decompose(F,M,[G,H]),     rewrites(F,I),     decompose(F,M,[G,H]),     runcheck(I,val),     checktag(I,val,_),     rewrites(K,J),     runcheck(J,val),     checktag(J,val,_),     decompose(L,M,[N,O]),     \+rewrites(K,L),     decompose(L,M,[N,O]),     rewrites(false,P).

rewrite(cl_struct_equal(A,F),S) :-     decompose(B,O,[C,D,E]),     rewrites(A,B),     decompose(B,O,[C,D,E]),     rewrites(C,H),     rewrites(D,I),     rewrites(E,J),     rewrites(F,M),     decompose(G,O,[H,I,J]),     rewrites(G,K),     decompose(G,O,[H,I,J]),     runcheck(K,val),     checktag(K,val,_),     rewrites(M,L),     runcheck(L,val),     checktag(L,val,_),     decompose(N,O,[P,Q,R]),     \+rewrites(M,N),     decompose(N,O,[P,Q,R]),     rewrites(false,S).

