% Generated from Funcon/Higher/type_vars#2.csf

sigdec(type_vars,lists(typevars),[_]).

onestep(type_vars(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(type_vars(E),F).

onestep(type_vars(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(type_vars(E),F).

onestep(type_vars(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(type_vars(E),F).

sigdec(type_vars,computes(lists(typevars)),[_]).

rewrite(type_vars(A),D) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,nullary),     checktag(C,nullary,_),     rewrites(list_empty,D).

rewrite(type_vars(A),G) :-     rewrites(A,typevar(B)),     rewrites(B,C),     rewrites(C,D),     rewrites(typevar(D),E),     rewrites(list_empty,F),     rewrites(list_prefix(E,F),G).

rewrite(type_vars(A),H) :-     decompose(B,E,[C]),     rewrites(A,B),     decompose(B,E,[C]),     rewrites(C,F),     decompose(D,E,[F]),     different(D,typevar(_)),     decompose(D,E,[F]),     rewrites(F,G),     rewrites(type_vars(G),H).

rewrite(type_vars(A),L) :-     decompose(B,C,[D,E]),     rewrites(A,B),     decompose(B,C,[D,E]),     rewrites(D,F),     rewrites(E,H),     rewrites(F,G),     rewrites(type_vars(G),J),     rewrites(H,I),     rewrites(type_vars(I),K),     rewrites(list_union(J,K),L).

rewrite(type_vars(A),Q) :-     decompose(B,C,[D,E,F]),     rewrites(A,B),     decompose(B,C,[D,E,F]),     rewrites(D,G),     rewrites(E,I),     rewrites(F,M),     rewrites(G,H),     rewrites(type_vars(H),K),     rewrites(I,J),     rewrites(type_vars(J),L),     rewrites(list_union(K,L),O),     rewrites(M,N),     rewrites(type_vars(N),P),     rewrites(list_union(O,P),Q).

sigdec(free_vars,lists(typevars),[_]).

onestep(free_vars(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(free_vars(E),F).

onestep(free_vars(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(free_vars(E),F).

rewrite(free_vars(A),D) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,nullary),     checktag(C,nullary,_),     rewrites(list_empty,D).

rewrite(free_vars(A),G) :-     rewrites(A,typevar(B)),     rewrites(B,C),     rewrites(C,D),     rewrites(typevar(D),E),     rewrites(list_empty,F),     rewrites(list_prefix(E,F),G).

rewrite(free_vars(A),H) :-     decompose(B,E,[C]),     rewrites(A,B),     decompose(B,E,[C]),     rewrites(C,F),     decompose(D,E,[F]),     different(D,typevar(_)),     decompose(D,E,[F]),     rewrites(F,G),     rewrites(free_vars(G),H).

rewrite(free_vars(A),I) :-     rewrites(A,type_abs(B,C)),     rewrites(B,F),     rewrites(C,D),     rewrites(D,E),     rewrites(free_vars(E),G),     rewrites(F,H),     rewrites(list_removes(G,H),I).

rewrite(free_vars(A),I) :-     rewrites(A,forall(B,C)),     rewrites(B,F),     rewrites(C,D),     rewrites(D,E),     rewrites(free_vars(E),G),     rewrites(F,H),     rewrites(list_removes(G,H),I).

rewrite(free_vars(A),N) :-     decompose(B,G,[C,D]),     rewrites(A,B),     decompose(B,G,[C,D]),     rewrites(C,H),     rewrites(D,J),     decompose(E,G,[H,J]),     \+rewrites(E,type_abs(_,_)),     decompose(E,G,[H,J]),     decompose(F,G,[H,J]),     \+rewrites(F,forall(_,_)),     decompose(F,G,[H,J]),     rewrites(H,I),     rewrites(free_vars(I),L),     rewrites(J,K),     rewrites(free_vars(K),M),     rewrites(list_union(L,M),N).

rewrite(free_vars(A),Q) :-     decompose(B,C,[D,E,F]),     rewrites(A,B),     decompose(B,C,[D,E,F]),     rewrites(D,G),     rewrites(E,I),     rewrites(F,M),     rewrites(G,H),     rewrites(free_vars(H),K),     rewrites(I,J),     rewrites(free_vars(J),L),     rewrites(list_union(K,L),O),     rewrites(M,N),     rewrites(free_vars(N),P),     rewrites(list_union(O,P),Q).

