% Generated from Funcon/Entities/env.csf

readable(env).

default(env,map_empty).

sigdec(environments,types,[]).

onestep(environments,A,B,resolve) :-     unobs(A),     rewrites(environments,B).

onestep(environments,A,B,typeval) :-     unobs(A),     rewrites(environments,B).

typedef(environments,maps(ids,val)).

valsort(environments).

