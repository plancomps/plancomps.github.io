% Generated from Funcon/Entities/tokens.csf

readable(token).

writeable(token).

default(token,q(0)).

sigdec(tokens,types,[]).

onestep(tokens,A,B,resolve) :-     unobs(A),     rewrites(tokens,B).

onestep(tokens,A,B,typeval) :-     unobs(A),     rewrites(tokens,B).

typedef(tokens,atoms).

valsort(tokens).

