% Generated from Funcon/Entities/answer.csf

readable(answer).

default(answer,_).

