% Generated from Funcon/Entities/given.csf

readable(given).

default(given,null).

