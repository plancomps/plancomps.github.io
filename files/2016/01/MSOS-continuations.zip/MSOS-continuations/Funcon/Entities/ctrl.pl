% Generated from Funcon/Entities/ctrl.csf

writeable(ctrl).

default(ctrl,none).

rewrite(monop(A,B,C),E) :-     rewrites(A,ctrl),     rewrites(B,none),     rewrites(C,D),     rewrites(D,E).

rewrite(monop(A,B,D),G) :-     rewrites(A,ctrl),     rewrites(B,some(C)),     rewrites(C,E),     rewrites(D,_),     rewrites(E,F),     rewrites(some(F),G).

