% Generated from Funcon/Entities/aux_env.csf

readable(aux_env).

default(aux_env,map_empty).

