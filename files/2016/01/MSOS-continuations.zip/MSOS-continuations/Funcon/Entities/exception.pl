% Generated from Funcon/Entities/exception.csf

writeable(exception).

default(exception,none).

rewrite(monop(A,B,C),E) :-     rewrites(A,exception),     rewrites(B,none),     rewrites(C,D),     rewrites(D,E).

rewrite(monop(A,B,D),G) :-     rewrites(A,exception),     rewrites(B,some(C)),     rewrites(C,E),     rewrites(D,_),     rewrites(E,F),     rewrites(some(F),G).

