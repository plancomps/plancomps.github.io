% Generated from Funcon/Entities/store.csf

readable(store).

writeable(store).

default(store,map_empty).

sigdec(stores,types,[]).

onestep(stores,A,B,resolve) :-     unobs(A),     rewrites(stores,B).

onestep(stores,A,B,typeval) :-     unobs(A),     rewrites(stores,B).

typedef(stores,maps(variables,val)).

valsort(stores).

sigdec(fresh_var,variables,[stores]).

onestep(fresh_var(A),D,variables,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,stores).

onestep(fresh_var(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(fresh_var(E),F).

onestep(fresh_var(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(fresh_var(E),F).

onestep(fresh_var(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(fresh_var(E),F).

sigdec(fresh_var,computes(variables),[computes(stores)]).

rewrite(fresh_var(A),C) :-     rewrites(A,map_empty),     rewrites(q(0),B),     rewrites(var(B),C).

rewrite(fresh_var(A),G) :-     rewrites(A,B),     rewrites(B,map_prefix(_,_,_)),     rewrites(largest_key(B),var(C)),     rewrites(C,D),     rewrites(q(1),E),     rewrites(int_plus(D,E),F),     rewrites(var(F),G).

