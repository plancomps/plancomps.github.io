% Generated from Funcon/Entities/forward.csf

readable(forward).

writeable(forward).

default(forward,map_empty).

sigdec(forwards,types,[]).

onestep(forwards,A,B,resolve) :-     unobs(A),     rewrites(forwards,B).

onestep(forwards,A,B,typeval) :-     unobs(A),     rewrites(forwards,B).

typedef(forwards,maps(fwds,val)).

valsort(forwards).

sigdec(fwd_fresh,fwds,[forwards]).

onestep(fwd_fresh(A),D,fwds,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,forwards).

onestep(fwd_fresh(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(fwd_fresh(E),F).

onestep(fwd_fresh(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(fwd_fresh(E),F).

onestep(fwd_fresh(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(fwd_fresh(E),F).

sigdec(fwd_fresh,computes(fwds),[computes(forwards)]).

rewrite(fwd_fresh(A),C) :-     rewrites(A,map_empty),     rewrites(q(0),B),     rewrites(fwd(B),C).

rewrite(fwd_fresh(A),G) :-     rewrites(A,B),     rewrites(B,map_prefix(_,_,_)),     rewrites(largest_key(B),fwd(C)),     rewrites(C,D),     rewrites(q(1),E),     rewrites(int_plus(D,E),F),     rewrites(fwd(F),G).

