% Generated from Funcon/Sorts/comms.csf

sigdec(comms,types,[]).

onestep(comms,A,B,resolve) :-     unobs(A),     rewrites(comms,B).

onestep(comms,A,B,typeval) :-     unobs(A),     rewrites(comms,B).

typedef(comms,computes(unit)).

