% Generated from Funcon/Values/peano_nats.csf

sigdec(zero,peano_nats,[]).

onestep(zero,A,B,resolve) :-     unobs(A),     rewrites(zero,B).

onestep(zero,A,B,typeval) :-     unobs(A),     rewrites(zero,B).

valcons(zero).

sigdec(succ,peano_nats,[peano_nats]).

onestep(succ(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(succ(E),F).

onestep(succ(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(succ(E),F).

onestep(succ(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(succ(E),F).

sigdec(succ,computes(peano_nats),[computes(peano_nats)]).

valcons(succ).

sigdec(peano_nats,types,[]).

onestep(peano_nats,A,B,resolve) :-     unobs(A),     rewrites(peano_nats,B).

onestep(peano_nats,A,B,typeval) :-     unobs(A),     rewrites(peano_nats,B).

valsort(peano_nats).

onestep(peano_nat,A,types,inhabit) :-     unobs(A).

onestep(zero,A,peano_nats,inhabit) :-     unobs(A).

onestep(succ(A),D,peano_nats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,peano_nats).

sigdec(one,peano_nats,[]).

onestep(one,A,peano_nats,inhabit) :-     unobs(A).

onestep(one,A,B,resolve) :-     unobs(A),     rewrites(one,B).

onestep(one,A,B,typeval) :-     unobs(A),     rewrites(one,B).

sigdec(two,peano_nats,[]).

onestep(two,A,peano_nats,inhabit) :-     unobs(A).

onestep(two,A,B,resolve) :-     unobs(A),     rewrites(two,B).

onestep(two,A,B,typeval) :-     unobs(A),     rewrites(two,B).

sigdec(three,peano_nats,[]).

onestep(three,A,peano_nats,inhabit) :-     unobs(A).

onestep(three,A,B,resolve) :-     unobs(A),     rewrites(three,B).

onestep(three,A,B,typeval) :-     unobs(A),     rewrites(three,B).

rewrite(one,B) :-     rewrites(zero,A),     rewrites(succ(A),B).

rewrite(two,B) :-     rewrites(one,A),     rewrites(succ(A),B).

rewrite(three,B) :-     rewrites(two,A),     rewrites(succ(A),B).

