% Generated from Funcon/Values/nomtype.csf

sigdec(nomtype,types,[atoms,tokens]).

onestep(nomtype(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(nomtype(G,H),I).

onestep(nomtype(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(nomtype(G,H),I).

onestep(nomtype(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(nomtype(J,K),L).

onestep(nomtype(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(nomtype(J,K),L).

sigdec(nomtype,types,[computes(atoms),computes(tokens)]).

onestep(nomtype(A,B),C,types,inhabit) :-     rewrites(A,_),     rewrites(B,_),     unobs(C).

sigdec(nomtype_poly,types,[atoms,tokens,lists(types)]).

onestep(nomtype_poly(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,G),     rewrites(C,D),     runstep(D,E,H) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(nomtype_poly(I,J,K),L).

onestep(nomtype_poly(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,D),     rewrites(C,H),     runstep(D,E,G) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(nomtype_poly(I,J,K),L).

onestep(nomtype_poly(A,B,C),E,L,run) :-     rewrites(A,D),     rewrites(B,G),     rewrites(C,H),     runstep(D,E,F) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(nomtype_poly(I,J,K),L).

onestep(nomtype_poly(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(nomtype_poly(O,P,Q),R).

onestep(nomtype_poly(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(nomtype_poly(O,P,Q),R).

sigdec(nomtype_poly,types,[computes(atoms),computes(tokens),computes(lists(types))]).

onestep(nomtype_poly(A,B,C),F,types,inhabit) :-     rewrites(A,_),     rewrites(B,_),     rewrites(C,D),     rewrites(D,E),     inhabit(E,F,lists(types)).

