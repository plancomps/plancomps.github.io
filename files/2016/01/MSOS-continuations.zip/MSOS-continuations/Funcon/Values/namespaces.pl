% Generated from Funcon/Values/namespaces.csf

sigdec(namespaces,types,[]).

onestep(namespaces,A,B,resolve) :-     unobs(A),     rewrites(namespaces,B).

onestep(namespaces,A,B,typeval) :-     unobs(A),     rewrites(namespaces,B).

typedef(namespaces,atoms).

valsort(namespaces).

