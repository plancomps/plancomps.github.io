% Generated from Funcon/Values/floats.csf

sigdec(floats,types,[]).

onestep(floats,A,B,resolve) :-     unobs(A),     rewrites(floats,B).

onestep(floats,A,B,typeval) :-     unobs(A),     rewrites(floats,B).

valsort(floats).

onestep(floats,A,types,inhabit) :-     unobs(A).

sigdec(float_round,ints,[floats]).

onestep(float_round(A),D,ints,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_round(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_round(E),F).

onestep(float_round(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_round(E),F).

onestep(float_round(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_round(E),F).

sigdec(float_round,computes(ints),[computes(floats)]).

sigdec(float_floor,ints,[floats]).

onestep(float_floor(A),D,ints,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_floor(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_floor(E),F).

onestep(float_floor(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_floor(E),F).

onestep(float_floor(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_floor(E),F).

sigdec(float_floor,computes(ints),[computes(floats)]).

sigdec(float_ceiling,ints,[floats]).

onestep(float_ceiling(A),D,ints,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_ceiling(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_ceiling(E),F).

onestep(float_ceiling(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_ceiling(E),F).

onestep(float_ceiling(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_ceiling(E),F).

sigdec(float_ceiling,computes(ints),[computes(floats)]).

sigdec(float_truncate,ints,[floats]).

onestep(float_truncate(A),D,ints,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_truncate(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_truncate(E),F).

onestep(float_truncate(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_truncate(E),F).

onestep(float_truncate(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_truncate(E),F).

sigdec(float_truncate,computes(ints),[computes(floats)]).

sigdec(int_to_float,floats,[ints]).

onestep(int_to_float(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,ints).

onestep(int_to_float(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(int_to_float(E),F).

onestep(int_to_float(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(int_to_float(E),F).

onestep(int_to_float(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(int_to_float(E),F).

sigdec(int_to_float,computes(floats),[computes(ints)]).

sigdec(float_negate,floats,[floats]).

onestep(float_negate(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_negate(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_negate(E),F).

onestep(float_negate(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_negate(E),F).

onestep(float_negate(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_negate(E),F).

sigdec(float_negate,computes(floats),[computes(floats)]).

sigdec(float_plus,floats,[floats,floats]).

onestep(float_plus(A,B),I,floats,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,floats) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,floats) ->     post_comp(G,H,I). 

onestep(float_plus(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_plus(G,H),I).

onestep(float_plus(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_plus(G,H),I).

onestep(float_plus(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_plus(J,K),L).

onestep(float_plus(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_plus(J,K),L).

sigdec(float_plus,computes(floats),[computes(floats),computes(floats)]).

sigdec(float_minus,floats,[floats,floats]).

onestep(float_minus(A,B),I,floats,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,floats) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,floats) ->     post_comp(G,H,I). 

onestep(float_minus(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_minus(G,H),I).

onestep(float_minus(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_minus(G,H),I).

onestep(float_minus(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_minus(J,K),L).

onestep(float_minus(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_minus(J,K),L).

sigdec(float_minus,computes(floats),[computes(floats),computes(floats)]).

sigdec(float_times,floats,[floats,floats]).

onestep(float_times(A,B),I,floats,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,floats) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,floats) ->     post_comp(G,H,I). 

onestep(float_times(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_times(G,H),I).

onestep(float_times(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_times(G,H),I).

onestep(float_times(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_times(J,K),L).

onestep(float_times(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_times(J,K),L).

sigdec(float_times,computes(floats),[computes(floats),computes(floats)]).

sigdec(float_divide,floats,[floats,floats]).

onestep(float_divide(A,B),I,floats,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,floats) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,floats) ->     post_comp(G,H,I). 

onestep(float_divide(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_divide(G,H),I).

onestep(float_divide(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_divide(G,H),I).

onestep(float_divide(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_divide(J,K),L).

onestep(float_divide(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_divide(J,K),L).

sigdec(float_divide,computes(floats),[computes(floats),computes(floats)]).

sigdec(float_power,floats,[floats,floats]).

onestep(float_power(A,B),I,floats,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,floats) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,floats) ->     post_comp(G,H,I). 

onestep(float_power(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_power(G,H),I).

onestep(float_power(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_power(G,H),I).

onestep(float_power(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_power(J,K),L).

onestep(float_power(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_power(J,K),L).

sigdec(float_power,computes(floats),[computes(floats),computes(floats)]).

sigdec(float_less,booleans,[floats,floats]).

onestep(float_less(A,B),I,booleans,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,floats) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,floats) ->     post_comp(G,H,I). 

onestep(float_less(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_less(G,H),I).

onestep(float_less(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_less(G,H),I).

onestep(float_less(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_less(J,K),L).

onestep(float_less(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_less(J,K),L).

sigdec(float_less,computes(booleans),[computes(floats),computes(floats)]).

sigdec(float_less_equal,booleans,[floats,floats]).

onestep(float_less_equal(A,B),I,booleans,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,floats) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,floats) ->     post_comp(G,H,I). 

onestep(float_less_equal(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_less_equal(G,H),I).

onestep(float_less_equal(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_less_equal(G,H),I).

onestep(float_less_equal(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_less_equal(J,K),L).

onestep(float_less_equal(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_less_equal(J,K),L).

sigdec(float_less_equal,computes(booleans),[computes(floats),computes(floats)]).

sigdec(float_greater,booleans,[floats,floats]).

onestep(float_greater(A,B),I,booleans,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,floats) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,floats) ->     post_comp(G,H,I). 

onestep(float_greater(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_greater(G,H),I).

onestep(float_greater(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_greater(G,H),I).

onestep(float_greater(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_greater(J,K),L).

onestep(float_greater(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_greater(J,K),L).

sigdec(float_greater,computes(booleans),[computes(floats),computes(floats)]).

sigdec(float_greater_equal,booleans,[floats,floats]).

onestep(float_greater_equal(A,B),I,booleans,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,floats) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,floats) ->     post_comp(G,H,I). 

onestep(float_greater_equal(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_greater_equal(G,H),I).

onestep(float_greater_equal(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_greater_equal(G,H),I).

onestep(float_greater_equal(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_greater_equal(J,K),L).

onestep(float_greater_equal(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_greater_equal(J,K),L).

sigdec(float_greater_equal,computes(booleans),[computes(floats),computes(floats)]).

sigdec(float_pi,floats,[]).

onestep(float_pi,A,floats,inhabit) :-     unobs(A).

onestep(float_pi,A,B,resolve) :-     unobs(A),     rewrites(float_pi,B).

onestep(float_pi,A,B,typeval) :-     unobs(A),     rewrites(float_pi,B).

sigdec(float_e,floats,[]).

onestep(float_e,A,floats,inhabit) :-     unobs(A).

onestep(float_e,A,B,resolve) :-     unobs(A),     rewrites(float_e,B).

onestep(float_e,A,B,typeval) :-     unobs(A),     rewrites(float_e,B).

sigdec(float_sqrt,floats,[floats]).

onestep(float_sqrt(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_sqrt(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_sqrt(E),F).

onestep(float_sqrt(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_sqrt(E),F).

onestep(float_sqrt(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_sqrt(E),F).

sigdec(float_sqrt,computes(floats),[computes(floats)]).

sigdec(float_log,floats,[floats]).

onestep(float_log(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_log(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_log(E),F).

onestep(float_log(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_log(E),F).

onestep(float_log(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_log(E),F).

sigdec(float_log,computes(floats),[computes(floats)]).

sigdec(float_log10,floats,[floats]).

onestep(float_log10(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_log10(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_log10(E),F).

onestep(float_log10(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_log10(E),F).

onestep(float_log10(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_log10(E),F).

sigdec(float_log10,computes(floats),[computes(floats)]).

sigdec(float_exp,floats,[floats]).

onestep(float_exp(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_exp(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_exp(E),F).

onestep(float_exp(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_exp(E),F).

onestep(float_exp(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_exp(E),F).

sigdec(float_exp,computes(floats),[computes(floats)]).

sigdec(float_sin,floats,[floats]).

onestep(float_sin(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_sin(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_sin(E),F).

onestep(float_sin(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_sin(E),F).

onestep(float_sin(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_sin(E),F).

sigdec(float_sin,computes(floats),[computes(floats)]).

sigdec(float_cos,floats,[floats]).

onestep(float_cos(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_cos(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_cos(E),F).

onestep(float_cos(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_cos(E),F).

onestep(float_cos(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_cos(E),F).

sigdec(float_cos,computes(floats),[computes(floats)]).

sigdec(float_tan,floats,[floats]).

onestep(float_tan(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_tan(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_tan(E),F).

onestep(float_tan(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_tan(E),F).

onestep(float_tan(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_tan(E),F).

sigdec(float_tan,computes(floats),[computes(floats)]).

sigdec(float_asin,floats,[floats]).

onestep(float_asin(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_asin(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_asin(E),F).

onestep(float_asin(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_asin(E),F).

onestep(float_asin(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_asin(E),F).

sigdec(float_asin,computes(floats),[computes(floats)]).

sigdec(float_acos,floats,[floats]).

onestep(float_acos(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_acos(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_acos(E),F).

onestep(float_acos(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_acos(E),F).

onestep(float_acos(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_acos(E),F).

sigdec(float_acos,computes(floats),[computes(floats)]).

sigdec(float_atan,floats,[floats]).

onestep(float_atan(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_atan(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_atan(E),F).

onestep(float_atan(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_atan(E),F).

onestep(float_atan(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_atan(E),F).

sigdec(float_atan,computes(floats),[computes(floats)]).

sigdec(float_sinh,floats,[floats]).

onestep(float_sinh(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_sinh(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_sinh(E),F).

onestep(float_sinh(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_sinh(E),F).

onestep(float_sinh(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_sinh(E),F).

sigdec(float_sinh,computes(floats),[computes(floats)]).

sigdec(float_cosh,floats,[floats]).

onestep(float_cosh(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_cosh(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_cosh(E),F).

onestep(float_cosh(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_cosh(E),F).

onestep(float_cosh(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_cosh(E),F).

sigdec(float_cosh,computes(floats),[computes(floats)]).

sigdec(float_tanh,floats,[floats]).

onestep(float_tanh(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_tanh(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_tanh(E),F).

onestep(float_tanh(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_tanh(E),F).

onestep(float_tanh(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_tanh(E),F).

sigdec(float_tanh,computes(floats),[computes(floats)]).

sigdec(float_asinh,floats,[floats]).

onestep(float_asinh(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_asinh(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_asinh(E),F).

onestep(float_asinh(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_asinh(E),F).

onestep(float_asinh(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_asinh(E),F).

sigdec(float_asinh,computes(floats),[computes(floats)]).

sigdec(float_acosh,floats,[floats]).

onestep(float_acosh(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_acosh(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_acosh(E),F).

onestep(float_acosh(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_acosh(E),F).

onestep(float_acosh(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_acosh(E),F).

sigdec(float_acosh,computes(floats),[computes(floats)]).

sigdec(float_atanh,floats,[floats]).

onestep(float_atanh(A),D,floats,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,floats).

onestep(float_atanh(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_atanh(E),F).

onestep(float_atanh(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_atanh(E),F).

onestep(float_atanh(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_atanh(E),F).

sigdec(float_atanh,computes(floats),[computes(floats)]).

sigdec(float_atan2,floats,[floats,floats]).

onestep(float_atan2(A,B),I,floats,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,floats) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,floats) ->     post_comp(G,H,I). 

onestep(float_atan2(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_atan2(G,H),I).

onestep(float_atan2(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_atan2(G,H),I).

onestep(float_atan2(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_atan2(J,K),L).

onestep(float_atan2(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_atan2(J,K),L).

sigdec(float_atan2,computes(floats),[computes(floats),computes(floats)]).

