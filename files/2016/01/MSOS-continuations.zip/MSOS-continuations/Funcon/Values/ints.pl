% Generated from Funcon/Values/ints.csf

sigdec(ints,types,[]).

onestep(ints,A,B,resolve) :-     unobs(A),     rewrites(ints,B).

onestep(ints,A,B,typeval) :-     unobs(A),     rewrites(ints,B).

valsort(ints).

onestep(ints,A,types,inhabit) :-     unobs(A).

sigdec(int_negate,ints,[ints]).

onestep(int_negate(A),D,ints,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,ints).

onestep(int_negate(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(int_negate(E),F).

onestep(int_negate(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(int_negate(E),F).

onestep(int_negate(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(int_negate(E),F).

sigdec(int_negate,computes(ints),[computes(ints)]).

sigdec(int_plus,ints,[ints,ints]).

onestep(int_plus(A,B),I,ints,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_plus(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_plus(G,H),I).

onestep(int_plus(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_plus(G,H),I).

onestep(int_plus(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_plus(J,K),L).

onestep(int_plus(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_plus(J,K),L).

sigdec(int_plus,computes(ints),[computes(ints),computes(ints)]).

sigdec(int_minus,ints,[ints,ints]).

onestep(int_minus(A,B),I,ints,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_minus(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_minus(G,H),I).

onestep(int_minus(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_minus(G,H),I).

onestep(int_minus(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_minus(J,K),L).

onestep(int_minus(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_minus(J,K),L).

sigdec(int_minus,computes(ints),[computes(ints),computes(ints)]).

sigdec(int_times,ints,[ints,ints]).

onestep(int_times(A,B),I,ints,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_times(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_times(G,H),I).

onestep(int_times(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_times(G,H),I).

onestep(int_times(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_times(J,K),L).

onestep(int_times(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_times(J,K),L).

sigdec(int_times,computes(ints),[computes(ints),computes(ints)]).

sigdec(int_divide,ints,[ints,ints]).

onestep(int_divide(A,B),I,ints,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_divide(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_divide(G,H),I).

onestep(int_divide(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_divide(G,H),I).

onestep(int_divide(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_divide(J,K),L).

onestep(int_divide(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_divide(J,K),L).

sigdec(int_divide,computes(ints),[computes(ints),computes(ints)]).

sigdec(int_modulo,ints,[ints,ints]).

onestep(int_modulo(A,B),I,ints,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_modulo(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_modulo(G,H),I).

onestep(int_modulo(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_modulo(G,H),I).

onestep(int_modulo(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_modulo(J,K),L).

onestep(int_modulo(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_modulo(J,K),L).

sigdec(int_modulo,computes(ints),[computes(ints),computes(ints)]).

sigdec(int_or,ints,[ints,ints]).

onestep(int_or(A,B),I,ints,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_or(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_or(G,H),I).

onestep(int_or(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_or(G,H),I).

onestep(int_or(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_or(J,K),L).

onestep(int_or(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_or(J,K),L).

sigdec(int_or,computes(ints),[computes(ints),computes(ints)]).

sigdec(int_and,ints,[ints,ints]).

onestep(int_and(A,B),I,ints,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_and(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_and(G,H),I).

onestep(int_and(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_and(G,H),I).

onestep(int_and(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_and(J,K),L).

onestep(int_and(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_and(J,K),L).

sigdec(int_and,computes(ints),[computes(ints),computes(ints)]).

sigdec(int_xor,ints,[ints,ints]).

onestep(int_xor(A,B),I,ints,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_xor(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_xor(G,H),I).

onestep(int_xor(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_xor(G,H),I).

onestep(int_xor(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_xor(J,K),L).

onestep(int_xor(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_xor(J,K),L).

sigdec(int_xor,computes(ints),[computes(ints),computes(ints)]).

sigdec(int_not,ints,[ints]).

onestep(int_not(A),D,ints,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,ints).

onestep(int_not(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(int_not(E),F).

onestep(int_not(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(int_not(E),F).

onestep(int_not(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(int_not(E),F).

sigdec(int_not,computes(ints),[computes(ints)]).

sigdec(int_logical_shift_left,ints,[ints,ints]).

onestep(int_logical_shift_left(A,B),I,ints,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_logical_shift_left(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_logical_shift_left(G,H),I).

onestep(int_logical_shift_left(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_logical_shift_left(G,H),I).

onestep(int_logical_shift_left(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_logical_shift_left(J,K),L).

onestep(int_logical_shift_left(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_logical_shift_left(J,K),L).

sigdec(int_logical_shift_left,computes(ints),[computes(ints),computes(ints)]).

sigdec(int_logical_shift_right,ints,[ints,ints]).

onestep(int_logical_shift_right(A,B),I,ints,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_logical_shift_right(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_logical_shift_right(G,H),I).

onestep(int_logical_shift_right(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_logical_shift_right(G,H),I).

onestep(int_logical_shift_right(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_logical_shift_right(J,K),L).

onestep(int_logical_shift_right(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_logical_shift_right(J,K),L).

sigdec(int_logical_shift_right,computes(ints),[computes(ints),computes(ints)]).

sigdec(int_arithmetic_shift_left,ints,[ints,ints]).

onestep(int_arithmetic_shift_left(A,B),I,ints,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_arithmetic_shift_left(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_arithmetic_shift_left(G,H),I).

onestep(int_arithmetic_shift_left(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_arithmetic_shift_left(G,H),I).

onestep(int_arithmetic_shift_left(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_arithmetic_shift_left(J,K),L).

onestep(int_arithmetic_shift_left(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_arithmetic_shift_left(J,K),L).

sigdec(int_arithmetic_shift_left,computes(ints),[computes(ints),computes(ints)]).

sigdec(int_arithmetic_shift_right,ints,[ints,ints]).

onestep(int_arithmetic_shift_right(A,B),I,ints,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_arithmetic_shift_right(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_arithmetic_shift_right(G,H),I).

onestep(int_arithmetic_shift_right(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_arithmetic_shift_right(G,H),I).

onestep(int_arithmetic_shift_right(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_arithmetic_shift_right(J,K),L).

onestep(int_arithmetic_shift_right(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_arithmetic_shift_right(J,K),L).

sigdec(int_arithmetic_shift_right,computes(ints),[computes(ints),computes(ints)]).

sigdec(int_less,booleans,[ints,ints]).

onestep(int_less(A,B),I,booleans,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_less(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_less(G,H),I).

onestep(int_less(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_less(G,H),I).

onestep(int_less(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_less(J,K),L).

onestep(int_less(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_less(J,K),L).

sigdec(int_less,computes(booleans),[computes(ints),computes(ints)]).

sigdec(int_less_equal,booleans,[ints,ints]).

onestep(int_less_equal(A,B),I,booleans,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_less_equal(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_less_equal(G,H),I).

onestep(int_less_equal(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_less_equal(G,H),I).

onestep(int_less_equal(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_less_equal(J,K),L).

onestep(int_less_equal(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_less_equal(J,K),L).

sigdec(int_less_equal,computes(booleans),[computes(ints),computes(ints)]).

sigdec(int_greater,booleans,[ints,ints]).

onestep(int_greater(A,B),I,booleans,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_greater(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_greater(G,H),I).

onestep(int_greater(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_greater(G,H),I).

onestep(int_greater(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_greater(J,K),L).

onestep(int_greater(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_greater(J,K),L).

sigdec(int_greater,computes(booleans),[computes(ints),computes(ints)]).

sigdec(int_greater_equal,booleans,[ints,ints]).

onestep(int_greater_equal(A,B),I,booleans,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_greater_equal(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_greater_equal(G,H),I).

onestep(int_greater_equal(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_greater_equal(G,H),I).

onestep(int_greater_equal(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_greater_equal(J,K),L).

onestep(int_greater_equal(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_greater_equal(J,K),L).

sigdec(int_greater_equal,computes(booleans),[computes(ints),computes(ints)]).

sigdec(int_closed_interval,lists(ints),[ints,ints]).

onestep(int_closed_interval(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_closed_interval(G,H),I).

onestep(int_closed_interval(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_closed_interval(G,H),I).

onestep(int_closed_interval(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_closed_interval(J,K),L).

onestep(int_closed_interval(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_closed_interval(J,K),L).

sigdec(int_closed_interval,computes(lists(ints)),[computes(ints),computes(ints)]).

rewrite(int_closed_interval(A,B),E) :-     rewrites(A,C),     rewrites(B,D),     rewrites(int_greater(C,D),true),     rewrites(list_empty,E).

rewrite(int_closed_interval(A,B),K) :-     rewrites(A,C),     rewrites(B,F),     rewrites(int_less_equal(C,F),true),     rewrites(C,I),     rewrites(C,D),     rewrites(q(1),E),     rewrites(int_plus(D,E),G),     rewrites(F,H),     rewrites(int_closed_interval(G,H),J),     rewrites(list_prefix(I,J),K).

onestep(int_closed_interval(A,B),I,lists(ints),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

sigdec(int_min,ints,[ints,ints]).

onestep(int_min(A,B),I,ints,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_min(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_min(G,H),I).

onestep(int_min(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_min(G,H),I).

onestep(int_min(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_min(J,K),L).

onestep(int_min(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_min(J,K),L).

sigdec(int_min,computes(ints),[computes(ints),computes(ints)]).

sigdec(int_max,ints,[ints,ints]).

onestep(int_max(A,B),I,ints,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,ints) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,ints) ->     post_comp(G,H,I). 

onestep(int_max(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_max(G,H),I).

onestep(int_max(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_max(G,H),I).

onestep(int_max(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_max(J,K),L).

onestep(int_max(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_max(J,K),L).

sigdec(int_max,computes(ints),[computes(ints),computes(ints)]).

rewrite(int_min(A,B),N) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,I),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,J),     rewrites(I,G),     rewrites(J,H),     rewrites(int_less(G,H),K),     rewrites(I,L),     rewrites(J,M),     rewrites(if_true(K,L,M),N).

rewrite(int_max(A,B),N) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,I),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,J),     rewrites(I,G),     rewrites(J,H),     rewrites(int_greater(G,H),K),     rewrites(I,L),     rewrites(J,M),     rewrites(if_true(K,L,M),N).

