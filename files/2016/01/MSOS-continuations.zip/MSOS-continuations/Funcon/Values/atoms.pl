% Generated from Funcon/Values/atoms.csf

sigdec(atoms,types,[]).

onestep(atoms,A,B,resolve) :-     unobs(A),     rewrites(atoms,B).

onestep(atoms,A,B,typeval) :-     unobs(A),     rewrites(atoms,B).

valsort(atoms).

onestep(atoms,A,types,inhabit) :-     unobs(A).

