% Generated from Funcon/Values/vectors.csf

sigdec(vector,vectors,[lists(variables)]).

onestep(vector(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(vector(E),F).

onestep(vector(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(vector(E),F).

onestep(vector(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(vector(E),F).

sigdec(vector,computes(vectors),[computes(lists(variables))]).

valcons(vector).

sigdec(vectors,types,[]).

onestep(vectors,A,B,resolve) :-     unobs(A),     rewrites(vectors,B).

onestep(vectors,A,B,typeval) :-     unobs(A),     rewrites(vectors,B).

valsort(vectors).

sigdec(vectors,types,[types]).

onestep(vectors(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(vectors(E),F).

onestep(vectors(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(vectors(E),F).

onestep(vectors(A),D,types,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,types).

onestep(vector(A),D,vectors(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,lists(variables(E))).

sigdec(vector_empty,vectors,[]).

onestep(vector_empty,A,B,resolve) :-     unobs(A),     rewrites(vector_empty,B).

onestep(vector_empty,A,B,typeval) :-     unobs(A),     rewrites(vector_empty,B).

rewrite(vector_empty,B) :-     rewrites(list_empty,A),     rewrites(vector(A),B).

onestep(vector_empty,A,vectors(_),inhabit) :-     unobs(A).

sigdec(vector1,vectors,[variables]).

onestep(vector1(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(vector1(E),F).

onestep(vector1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(vector1(E),F).

onestep(vector1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(vector1(E),F).

sigdec(vector1,computes(vectors),[computes(variables)]).

rewrite(vector1(A),G) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,val),     checktag(C,val,D),     rewrites(D,E),     rewrites(list1(E),F),     rewrites(vector(F),G).

onestep(vector1(A),D,vectors(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,variables(E)).

sigdec(vector_append,vectors,[vectors,vectors]).

onestep(vector_append(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(vector_append(G,H),I).

onestep(vector_append(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(vector_append(G,H),I).

onestep(vector_append(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(vector_append(J,K),L).

onestep(vector_append(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(vector_append(J,K),L).

sigdec(vector_append,computes(vectors),[computes(vectors),computes(vectors)]).

rewrite(vector_append(A,C),J) :-     rewrites(A,vector(B)),     rewrites(B,E),     rewrites(C,vector(D)),     rewrites(D,F),     rewrites(E,G),     rewrites(F,H),     rewrites(list_append(G,H),I),     rewrites(vector(I),J).

onestep(vector_append(A,B),J,vectors(G),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,vectors(G)) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,vectors(G)) ->     post_comp(H,I,J). 

sigdec(vector_select,variables,[vectors,ints]).

onestep(vector_select(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(vector_select(G,H),I).

onestep(vector_select(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(vector_select(G,H),I).

onestep(vector_select(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(vector_select(J,K),L).

onestep(vector_select(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(vector_select(J,K),L).

sigdec(vector_select,computes(variables),[computes(vectors),computes(ints)]).

rewrite(vector_select(A,C),H) :-     rewrites(A,vector(B)),     rewrites(B,D),     rewrites(C,E),     rewrites(D,F),     rewrites(E,G),     rewrites(list_select(F,G),H).

onestep(vector_select(A,B),J,variables(G),inhabit) :-     rewrites(A,E),     rewrites(B,C),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,ints) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,vectors(G)) ->     post_comp(H,I,J). 

sigdec(vector_length,ints,[vectors]).

onestep(vector_length(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(vector_length(E),F).

onestep(vector_length(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(vector_length(E),F).

onestep(vector_length(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(vector_length(E),F).

sigdec(vector_length,computes(ints),[computes(vectors)]).

rewrite(vector_length(A),E) :-     rewrites(A,vector(B)),     rewrites(B,C),     rewrites(C,D),     rewrites(list_length(D),E).

onestep(vector_length(A),D,ints,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,vectors(_)).

