% Generated from Funcon/Values/options.csf

sigdec(none,options(_),[]).

onestep(none,A,B,resolve) :-     unobs(A),     rewrites(none,B).

onestep(none,A,B,typeval) :-     unobs(A),     rewrites(none,B).

valcons(none).

sigdec(some,options(A),[A]).

onestep(some(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(some(E),F).

onestep(some(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(some(E),F).

valcons(some).

sigdec(options(_),types,[]).

onestep(options(A),B,E,resolve) :-     rewrites(A,C),     unobs(B),     rewrites(C,D),     rewrites(options(D),E).

onestep(options(A),B,E,typeval) :-     rewrites(A,C),     unobs(B),     rewrites(C,D),     rewrites(options(D),E).

valsort(options(_)).

onestep(options(A),D,types,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,types).

onestep(none,A,options(_),inhabit) :-     unobs(A).

onestep(some(A),D,options(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

