% Generated from Funcon/Values/typevars.csf

sigdec(typevar,typevars,[atoms]).

onestep(typevar(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(typevar(E),F).

onestep(typevar(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(typevar(E),F).

onestep(typevar(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(typevar(E),F).

sigdec(typevar,computes(typevars),[computes(atoms)]).

valcons(typevar).

sigdec(typevars,types,[]).

onestep(typevars,A,B,resolve) :-     unobs(A),     rewrites(typevars,B).

onestep(typevars,A,B,typeval) :-     unobs(A),     rewrites(typevars,B).

valsort(typevars).

subsort(typevars,ids).

onestep(typevar(A),B,types,inhabit) :-     rewrites(A,F),     rewrites(E,D),     eq_label(B,[env=C|G]),     rewrites(C,D),     rewrites(contains_key(E,typevar(F)),true),     unobs(G).

