% Generated from Funcon/Values/variables.csf

sigdec(var,variables,[ints]).

onestep(var(A),D,variables(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

onestep(var(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(var(E),F).

onestep(var(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(var(E),F).

onestep(var(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(var(E),F).

sigdec(var,computes(variables),[computes(ints)]).

valcons(var).

sigdec(variables,types,[]).

onestep(variables,A,B,resolve) :-     unobs(A),     rewrites(variables,B).

onestep(variables,A,B,typeval) :-     unobs(A),     rewrites(variables,B).

valsort(variables).

sigdec(variables,types,[types]).

onestep(variables(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(variables(E),F).

onestep(variables(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(variables(E),F).

onestep(variables(A),D,types,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,types).

