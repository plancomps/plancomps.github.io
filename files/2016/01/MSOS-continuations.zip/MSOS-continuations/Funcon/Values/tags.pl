% Generated from Funcon/Values/tags.csf

sigdec(tags,types,[]).

onestep(tags,A,B,resolve) :-     unobs(A),     rewrites(tags,B).

onestep(tags,A,B,typeval) :-     unobs(A),     rewrites(tags,B).

typedef(tags,atoms).

valsort(tags).

