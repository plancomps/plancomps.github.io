% Generated from Funcon/Values/metas.csf

sigdec(meta,metas,[atoms]).

onestep(meta(A),D,metas(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

onestep(meta(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(meta(E),F).

onestep(meta(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(meta(E),F).

onestep(meta(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(meta(E),F).

sigdec(meta,computes(metas),[computes(atoms)]).

valcons(meta).

sigdec(metas,types,[]).

onestep(metas,A,B,resolve) :-     unobs(A),     rewrites(metas,B).

onestep(metas,A,B,typeval) :-     unobs(A),     rewrites(metas,B).

valsort(metas).

subsort(metas,ids).

