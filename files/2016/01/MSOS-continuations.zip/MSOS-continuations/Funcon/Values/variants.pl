% Generated from Funcon/Values/variants.csf

sigdec(variant,variants,[tags,val]).

onestep(variant(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(variant(G,H),I).

onestep(variant(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(variant(G,H),I).

onestep(variant(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(variant(J,K),L).

onestep(variant(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(variant(J,K),L).

sigdec(variant,computes(variants),[computes(tags),computes(val)]).

valcons(variant).

sigdec(variants,types,[]).

onestep(variants,A,B,resolve) :-     unobs(A),     rewrites(variants,B).

onestep(variants,A,B,typeval) :-     unobs(A),     rewrites(variants,B).

valsort(variants).

sigdec(variants,types,[maps(tags,types)]).

onestep(variants(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(variants(E),F).

onestep(variants(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(variants(E),F).

onestep(variants(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(variants(E),F).

sigdec(variants,types,[computes(maps(tags,types))]).

onestep(variants(A),D,types,inhabit) :-     rewrites(A,B),     rewrites(map_to_list(B),C),     inhabit(C,D,lists(types)).

onestep(variant(A,B),E,variants(F),inhabit) :-     rewrites(A,G),     rewrites(B,C),     rewrites(C,D),     inhabit(D,E,map_select(F,G)).

