% Generated from Funcon/Values/characters.csf

sigdec(char,characters,[atoms]).

onestep(char(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(char(E),F).

onestep(char(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(char(E),F).

onestep(char(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(char(E),F).

sigdec(char,computes(characters),[computes(atoms)]).

valcons(char).

sigdec(characters,types,[]).

onestep(characters,A,B,resolve) :-     unobs(A),     rewrites(characters,B).

onestep(characters,A,B,typeval) :-     unobs(A),     rewrites(characters,B).

valsort(characters).

onestep(characters,A,types,inhabit) :-     unobs(A).

onestep(char(A),B,characters,inhabit) :-     rewrites(A,_),     unobs(B).

