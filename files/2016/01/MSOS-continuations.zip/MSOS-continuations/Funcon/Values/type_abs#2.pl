% Generated from Funcon/Values/type_abs#2.csf

sigdec(type_abs,types,[lists(typevars),types]).

onestep(type_abs(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(type_abs(G,H),I).

onestep(type_abs(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(type_abs(J,K),L).

onestep(type_abs(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(type_abs(J,K),L).

sigdec(type_abs,types,[computes(lists(typevars)),types]).

onestep(type_abs(A,B),C,types,inhabit) :-     rewrites(A,F),     rewrites(B,J),     rewrites(G,E),     eq_label(C,[env=D|I]),     rewrites(D,E),     rewrites(map_over(map_zip(F,F),G),H),     L=[env=H|I],     rewrites(J,K),     inhabit(K,L,types).

