% Generated from Funcon/Values/abs.csf

sigdec(abs,abs(A,B),[depends(A,B)]).

onestep(abs(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(abs(E),F).

onestep(abs(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(abs(E),F).

sigdec(abs,computes(abs(A,B)),[depends(A,B)]).

valcons(abs).

sigdec(abs(_,_),types,[]).

onestep(abs(A,B),C,H,resolve) :-     rewrites(A,D),     rewrites(B,E),     unobs(C),     rewrites(D,F),     rewrites(E,G),     rewrites(abs(F,G),H).

onestep(abs(A,B),C,H,typeval) :-     rewrites(A,D),     rewrites(B,E),     unobs(C),     rewrites(D,F),     rewrites(E,G),     rewrites(abs(F,G),H).

valsort(abs(_,_)).

sigdec(abs,types,[types,types,types]).

onestep(abs(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(abs(O,P,Q),R).

onestep(abs(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(abs(O,P,Q),R).

onestep(abs(A,B,C),N,types,inhabit) :-     rewrites(A,D),     rewrites(B,F),     rewrites(C,H),     pre_comp(N,L),     rewrites(D,E),     inhabit(E,L,types) ->     mid_comp(L,M),     pre_comp(M,J),     rewrites(F,G),     inhabit(G,J,types) ->     mid_comp(J,K),     rewrites(H,I),     inhabit(I,K,types) ->     post_comp(J,K,M),     post_comp(L,M,N).

onestep(abs(A),B,abs(J,H,Q),inhabit) :-     rewrites(A,N),     rewrites(_,D),     eq_label(B,[given=C|E]),     rewrites(C,D),     rewrites(_,G),     eq_label(E,[answer=F|M]),     rewrites(F,G),     rewrites(H,I),     P=[given=I|K],     rewrites(J,L),     K=[answer=L|M],     rewrites(N,O),     inhabit(O,P,Q).

