% Generated from Funcon/Funcons/partial_app#2.csf

sigdec(partial_app,abs(_,A),[abs(tuples,A),_]).

onestep(partial_app(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(partial_app(G,H),I).

onestep(partial_app(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(partial_app(G,H),I).

onestep(partial_app(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(partial_app(J,K),L).

onestep(partial_app(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(partial_app(J,K),L).

sigdec(partial_app,computes(abs(_,A)),[computes(abs(tuples,A)),_]).

rewrite(partial_app(A,B),N) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,G),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,H),     rewrites(G,K),     rewrites(H,I),     rewrites(given,J),     rewrites(tuple2(I,J),L),     rewrites(apply(K,L),M),     rewrites(abs(M),N).

onestep(partial_app(A,B),M,abs(G,I,J),inhabit) :-     rewrites(A,E),     rewrites(B,C),     pre_comp(M,K),     rewrites(C,D),     inhabit(D,K,H) ->     mid_comp(K,L),     rewrites(E,F),     inhabit(F,L,abs(G,tuple_type2(H,I),J)) ->     post_comp(K,L,M). 

sigdec(partial_app_N,abs(tuples,A),[abs(tuples,A),_]).

onestep(partial_app_N(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(partial_app_N(G,H),I).

onestep(partial_app_N(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(partial_app_N(G,H),I).

onestep(partial_app_N(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(partial_app_N(J,K),L).

onestep(partial_app_N(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(partial_app_N(J,K),L).

sigdec(partial_app_N,computes(abs(tuples,A)),[computes(abs(tuples,A)),_]).

rewrite(partial_app_N(A,B),N) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,G),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,H),     rewrites(G,K),     rewrites(H,I),     rewrites(given,J),     rewrites(tuple_prefix(I,J),L),     rewrites(apply(K,L),M),     rewrites(abs(M),N).

onestep(partial_app_N(A,B),M,abs(G,I,J),inhabit) :-     rewrites(A,E),     rewrites(B,C),     pre_comp(M,K),     rewrites(C,D),     inhabit(D,K,H) ->     mid_comp(K,L),     rewrites(E,F),     inhabit(F,L,abs(G,tuple_type_prefix(H,I),J)) ->     post_comp(K,L,M). 

