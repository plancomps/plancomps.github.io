% Generated from Funcon/Funcons/fresh_id#0.csf

sigdec(fresh_id,computes(ids),[]).

onestep(fresh_id,A,B,resolve) :-     unobs(A),     rewrites(fresh_id,B).

onestep(fresh_id,A,B,typeval) :-     unobs(A),     rewrites(fresh_id,B).

onestep(fresh_id,A,D,run) :-     runstep(fresh_token,A,B) ->     rewrites(B,C),     rewrites(id(C),D).

onestep(fresh_id,A,ids,inhabit) :-     unobs(A).

