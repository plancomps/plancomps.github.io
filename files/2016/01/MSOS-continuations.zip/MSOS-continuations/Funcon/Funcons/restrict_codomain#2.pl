% Generated from Funcon/Funcons/restrict_codomain#2.csf

sigdec(restrict_codomain,abs(A,B),[abs(A,B),types]).

onestep(restrict_codomain(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(restrict_codomain(G,H),I).

onestep(restrict_codomain(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(restrict_codomain(J,K),L).

onestep(restrict_codomain(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(restrict_codomain(J,K),L).

sigdec(restrict_codomain,computes(abs(A,B)),[computes(abs(A,B)),types]).

onestep(restrict_codomain(A,B),C,E,run) :-     rewrites(A,D),     rewrites(B,_),     unobs(C),     rewrites(D,E).

onestep(restrict_codomain(A,B),N,abs(G,H,I),inhabit) :-     rewrites(A,E),     rewrites(B,C),     pre_comp(N,L),     rewrites(C,D),     inhabit(D,L,types) ->     mid_comp(L,M),     pre_comp(M,J),     typeval(D,J,I) ->     mid_comp(J,K),     rewrites(E,F),     inhabit(F,K,abs(G,H,I)) ->     post_comp(J,K,M),     post_comp(L,M,N).

