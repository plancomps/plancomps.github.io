% Generated from Funcon/Funcons/record_match#2.csf

sigdec(record_match,decls,[records,maps(fields,patts)]).

onestep(record_match(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_match(G,H),I).

onestep(record_match(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_match(G,H),I).

onestep(record_match(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_match(J,K),L).

onestep(record_match(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_match(J,K),L).

sigdec(record_match,decls,[computes(records),computes(maps(fields,patts))]).

onestep(record_match(A,B),C,H,run) :-     rewrites(A,D),     rewrites(B,E),     unobs(C),     rewrites(D,F),     rewrites(E,G),     rewrites(record_match_loose(F,G),H).

onestep(record_match(A,B),L,I,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(L,J),     rewrites(C,D),     inhabit(D,J,records(G)) ->     mid_comp(J,K),     rewrites(E,F),     inhabit(F,K,H) ->     rewrites(record_match_types(G,H),some(I)),     post_comp(J,K,L).

sigdec(record_match_types,options(maps(ids,types)),[maps(fields,types),maps(fields,types)]).

onestep(record_match_types(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_match_types(G,H),I).

onestep(record_match_types(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_match_types(G,H),I).

onestep(record_match_types(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_match_types(J,K),L).

onestep(record_match_types(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_match_types(J,K),L).

sigdec(record_match_types,computes(options(maps(ids,types))),[computes(maps(fields,types)),computes(maps(fields,types))]).

rewrite(record_match_types(A,B),D) :-     rewrites(A,map_empty),     rewrites(B,map_empty),     rewrites(map_empty,C),     rewrites(some(C),D).

rewrite(record_match_types(A,E),T) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,G),     rewrites(C,K),     rewrites(D,N),     rewrites(E,map_prefix(F,H,M)),     rewrites(F,G),     rewrites(H,abs(I,J,L)),     rewrites(I,none),     rewrites(J,K),     rewrites(L,P),     rewrites(M,O),     rewrites(record_match_types(N,O),some(Q)),     rewrites(map_union(P,Q),R),     rewrites(R,S),     rewrites(some(S),T).

sigdec(record_match_loose,decls,[records,maps(fields,patts)]).

onestep(record_match_loose(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_match_loose(G,H),I).

onestep(record_match_loose(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_match_loose(G,H),I).

onestep(record_match_loose(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_match_loose(J,K),L).

onestep(record_match_loose(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_match_loose(J,K),L).

sigdec(record_match_loose,decls,[computes(records),computes(maps(fields,patts))]).

onestep(record_match_loose(A,B),E,F,run) :-     rewrites(A,C),     rewrites(B,map_empty),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,_),     unobs(E),     rewrites(map_empty,F).

onestep(record_match_loose(A,B),I,T,run) :-     rewrites(A,G),     rewrites(B,map_prefix(C,D,E)),     rewrites(C,H),     rewrites(D,K),     rewrites(E,O),     rewrites(G,F),     runcheck(F,val),     checktag(F,val,N),     rewrites(record_select(G,H),J),     unobs(I),     rewrites(J,L),     rewrites(K,M),     rewrites(match(L,M),R),     rewrites(N,P),     rewrites(O,Q),     rewrites(record_match_loose(P,Q),S),     rewrites(accum(R,S),T).

onestep(record_match_loose(A,B),L,I,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(L,J),     rewrites(C,D),     inhabit(D,J,records(G)) ->     mid_comp(J,K),     rewrites(E,F),     inhabit(F,K,H) ->     rewrites(record_match_loose_types(G,H),some(I)),     post_comp(J,K,L).

sigdec(record_match_loose_types,options(maps(ids,types)),[maps(fields,types),maps(fields,types)]).

onestep(record_match_loose_types(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_match_loose_types(G,H),I).

onestep(record_match_loose_types(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_match_loose_types(G,H),I).

onestep(record_match_loose_types(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_match_loose_types(J,K),L).

onestep(record_match_loose_types(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_match_loose_types(J,K),L).

sigdec(record_match_loose_types,computes(options(maps(ids,types))),[computes(maps(fields,types)),computes(maps(fields,types))]).

rewrite(record_match_loose_types(A,B),D) :-     rewrites(A,_),     rewrites(B,map_empty),     rewrites(map_empty,C),     rewrites(some(C),D).

rewrite(record_match_loose_types(A,B),Q) :-     rewrites(A,K),     rewrites(B,map_prefix(C,D,H)),     rewrites(C,I),     rewrites(D,abs(E,F,G)),     rewrites(E,none),     rewrites(F,J),     rewrites(G,M),     rewrites(H,L),     rewrites(map_select(K,I),J),     rewrites(record_match_loose_types(K,L),some(N)),     rewrites(map_union(M,N),O),     rewrites(O,P),     rewrites(some(P),Q).

