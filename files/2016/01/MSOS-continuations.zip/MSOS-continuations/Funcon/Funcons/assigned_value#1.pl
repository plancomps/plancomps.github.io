% Generated from Funcon/Funcons/assigned_value#1.csf

sigdec(assigned_value,computes(_),[variables]).

onestep(assigned_value(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(assigned_value(E),F).

onestep(assigned_value(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(assigned_value(E),F).

onestep(assigned_value(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(assigned_value(E),F).

sigdec(assigned_value,computes(_),[computes(variables)]).

onestep(assigned_value(A),J,H,run) :-     rewrites(A,E),     rewrites(I,C),     eq_label(J,[store=B|D]),     rewrites(B,C),     eq_label(D,[store+=_|F]),     rewrites(contains_key(I,E),true),     rewrites(map_select(I,E),G),     unobs(F),     rewrites(G,H),     rewrites(I,K),     eq_label(J,[store+=K|_]).

onestep(assigned_value(A),D,E,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,variables(E)).

