% Generated from Funcon/Funcons/patt_non_binding#1.csf

sigdec(patt_non_binding,patts,[patts]).

onestep(patt_non_binding(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(patt_non_binding(E),F).

onestep(patt_non_binding(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(patt_non_binding(E),F).

onestep(patt_non_binding(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(patt_non_binding(E),F).

sigdec(patt_non_binding,computes(patts),[computes(patts)]).

onestep(patt_non_binding(A),B,D,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D).

onestep(patt_non_binding(A),D,abs(E,F,map_empty),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,abs(E,F,map_empty)).

