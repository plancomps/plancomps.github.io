% Generated from Funcon/Funcons/nominal.csf

sigdec(nomtag,nominal_tags,[tokens]).

onestep(nomtag(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(nomtag(E),F).

onestep(nomtag(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(nomtag(E),F).

onestep(nomtag(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(nomtag(E),F).

sigdec(nomtag,computes(nominal_tags),[computes(tokens)]).

valcons(nomtag).

sigdec(nominal_tags,types,[]).

onestep(nominal_tags,A,B,resolve) :-     unobs(A),     rewrites(nominal_tags,B).

onestep(nominal_tags,A,B,typeval) :-     unobs(A),     rewrites(nominal_tags,B).

valsort(nominal_tags).

onestep(nomtag(A),B,nomtag(tokens),inhabit) :-     rewrites(A,tokens),     unobs(B).

sigdec(nomco,nominal_coercions,[types,types]).

onestep(nomco(A,B),K,nominal_coercions(E,H),inhabit) :-     rewrites(A,C),     rewrites(B,F),     pre_comp(K,I),     rewrites(C,D),     inhabit(D,I,E) ->     mid_comp(I,J),     rewrites(F,G),     inhabit(G,J,H) ->     post_comp(I,J,K). 

onestep(nomco(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(nomco(J,K),L).

onestep(nomco(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(nomco(J,K),L).

valcons(nomco).

sigdec(nominal_coercions,types,[]).

onestep(nominal_coercions,A,B,resolve) :-     unobs(A),     rewrites(nominal_coercions,B).

onestep(nominal_coercions,A,B,typeval) :-     unobs(A),     rewrites(nominal_coercions,B).

valsort(nominal_coercions).

readable(nomcoenv).

default(nomcoenv,map_empty).

sigdec(scope_nominal_coercion,computes(A),[types,types,abs(nominal_tags,computes(A))]).

onestep(scope_nominal_coercion(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,G),     rewrites(C,D),     runstep(D,E,H) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(scope_nominal_coercion(I,J,K),L).

onestep(scope_nominal_coercion(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(scope_nominal_coercion(O,P,Q),R).

onestep(scope_nominal_coercion(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(scope_nominal_coercion(O,P,Q),R).

sigdec(scope_nominal_coercion,computes(A),[types,types,computes(abs(nominal_tags,computes(A)))]).

onestep(scope_nominal_coercion(A,B,C),D,ZG,inhabit) :-     rewrites(A,M),     rewrites(B,R),     rewrites(C,ZB),     rewrites(ZE,F),     eq_label(D,[answer=E|G]),     rewrites(E,F),     rewrites(W,I),     eq_label(G,[nomcoenv=H|ZR]),     rewrites(H,I),     pre_comp(ZR,ZP),     rewrites(ZE,J),     N=[answer=J|K],     rewrites(W,L),     K=[nomcoenv=L|ZP],     rewrites(M,T),     inhabit(T,N,types) ->     mid_comp(ZP,ZQ),     pre_comp(ZQ,ZN),     rewrites(ZE,O),     S=[answer=O|P],     rewrites(W,Q),     P=[nomcoenv=Q|ZN],     rewrites(R,U),     inhabit(U,S,types) ->     mid_comp(ZN,ZO),     pre_comp(ZO,ZL),     typeval(T,ZL,X) ->     mid_comp(ZL,ZM),     pre_comp(ZM,ZJ),     typeval(U,ZJ,Y) ->     mid_comp(ZJ,ZK),     pre_comp(ZK,ZH),     typeval(fresh_token,ZH,ZF) ->     mid_comp(ZH,ZI),     rewrites(ZE,V),     ZD=[answer=V|Z],     rewrites(map_update(W,nomtag(ZF),nomco(X,Y)),ZA),     Z=[nomcoenv=ZA|ZI],     rewrites(ZB,ZC),     inhabit(ZC,ZD,abs(ZE,nomtag(ZF),ZG)) ->     post_comp(ZH,ZI,ZK),     post_comp(ZJ,ZK,ZM),     post_comp(ZL,ZM,ZO),     post_comp(ZN,ZO,ZQ),     post_comp(ZP,ZQ,ZR).

onestep(scope_nominal_coercion(A,B,C),D,J,run) :-     rewrites(A,_),     rewrites(B,_),     rewrites(C,E),     runstep(fresh_token,D,F) ->     rewrites(E,H),     rewrites(F,G),     rewrites(nomtag(G),I),     rewrites(apply(H,I),J).

sigdec(nomval,nominal_vals,[nominal_tags,val]).

onestep(nomval(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(nomval(G,H),I).

onestep(nomval(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(nomval(G,H),I).

onestep(nomval(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(nomval(J,K),L).

onestep(nomval(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(nomval(J,K),L).

sigdec(nomval,computes(nominal_vals),[computes(nominal_tags),computes(val)]).

valcons(nomval).

sigdec(nominal_vals,types,[]).

onestep(nominal_vals,A,B,resolve) :-     unobs(A),     rewrites(nominal_vals,B).

onestep(nominal_vals,A,B,typeval) :-     unobs(A),     rewrites(nominal_vals,B).

valsort(nominal_vals).

onestep(nomval(A,B),C,K,inhabit) :-     rewrites(A,G),     rewrites(B,N),     rewrites(L,E),     eq_label(C,[nomcoenv=D|T]),     rewrites(D,E),     pre_comp(T,R),     rewrites(L,F),     I=[nomcoenv=F|R],     rewrites(G,H),     inhabit(H,I,nomtag(J)) ->     mid_comp(R,S),     rewrites(map_select(L,nomtag(J)),nomco(Q,K)),     rewrites(L,M),     P=[nomcoenv=M|S],     rewrites(N,O),     inhabit(O,P,Q) ->     post_comp(R,S,T). 

sigdec(nomval_select,computes(val),[nominal_tags,nominal_vals]).

onestep(nomval_select(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(nomval_select(G,H),I).

onestep(nomval_select(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(nomval_select(G,H),I).

onestep(nomval_select(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(nomval_select(J,K),L).

onestep(nomval_select(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(nomval_select(J,K),L).

sigdec(nomval_select,computes(val),[computes(nominal_tags),computes(nominal_vals)]).

onestep(nomval_select(A,B),E,M,run) :-     rewrites(A,F),     rewrites(B,nomval(C,D)),     rewrites(C,G),     rewrites(D,J),     unobs(E),     rewrites(F,H),     rewrites(G,I),     rewrites(equal(H,I),K),     rewrites(J,L),     rewrites(when_true(K,L),M).

onestep(nomval_select(A,B),C,K,inhabit) :-     rewrites(A,G),     rewrites(B,N),     rewrites(L,E),     eq_label(C,[nomcoenv=D|T]),     rewrites(D,E),     pre_comp(T,R),     rewrites(L,F),     I=[nomcoenv=F|R],     rewrites(G,H),     inhabit(H,I,nomtag(J)) ->     mid_comp(R,S),     rewrites(map_select(L,nomtag(J)),nomco(K,Q)),     rewrites(L,M),     P=[nomcoenv=M|S],     rewrites(N,O),     inhabit(O,P,Q) ->     post_comp(R,S,T). 

sigdec(nomval_poly,nominal_vals,[nominal_tags,_]).

onestep(nomval_poly(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(nomval_poly(G,H),I).

onestep(nomval_poly(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(nomval_poly(G,H),I).

onestep(nomval_poly(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(nomval_poly(J,K),L).

onestep(nomval_poly(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(nomval_poly(J,K),L).

sigdec(nomval_poly,computes(nominal_vals),[computes(nominal_tags),_]).

onestep(nomval_poly(A,B),G,L,run) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,H),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,I),     unobs(G),     rewrites(H,J),     rewrites(I,K),     rewrites(nomval(J,K),L).

onestep(nomval_poly(A,B),C,T,inhabit) :-     rewrites(A,G),     rewrites(B,M),     rewrites(K,E),     eq_label(C,[nomcoenv=D|W]),     rewrites(D,E),     pre_comp(W,U),     rewrites(K,F),     I=[nomcoenv=F|U],     rewrites(G,H),     inhabit(H,I,nomtag(J)) ->     mid_comp(U,V),     rewrites(map_select(K,nomtag(J)),nomco(P,R)),     rewrites(K,L),     O=[nomcoenv=L|V],     rewrites(M,N),     inhabit(N,O,Q) ->     rewrites(instantiate_type(P,S),Q),     rewrites(instantiate_type(R,S),T),     post_comp(U,V,W).

sigdec(nomval_select_poly,computes(_),[nominal_tags,nominal_vals]).

onestep(nomval_select_poly(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(nomval_select_poly(G,H),I).

onestep(nomval_select_poly(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(nomval_select_poly(G,H),I).

onestep(nomval_select_poly(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(nomval_select_poly(J,K),L).

onestep(nomval_select_poly(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(nomval_select_poly(J,K),L).

sigdec(nomval_select_poly,computes(_),[computes(nominal_tags),computes(nominal_vals)]).

onestep(nomval_select_poly(A,B),C,T,inhabit) :-     rewrites(A,G),     rewrites(B,M),     rewrites(K,E),     eq_label(C,[nomcoenv=D|W]),     rewrites(D,E),     pre_comp(W,U),     rewrites(K,F),     I=[nomcoenv=F|U],     rewrites(G,H),     inhabit(H,I,nomtag(J)) ->     mid_comp(U,V),     rewrites(map_select(K,nomtag(J)),nomco(R,P)),     rewrites(K,L),     O=[nomcoenv=L|V],     rewrites(M,N),     inhabit(N,O,Q) ->     rewrites(instantiate_type(P,S),Q),     rewrites(instantiate_type(R,S),T),     post_comp(U,V,W).

onestep(nomval_select_poly(A,B),C,H,run) :-     rewrites(A,D),     rewrites(B,E),     unobs(C),     rewrites(D,F),     rewrites(E,G),     rewrites(nomval_select(F,G),H).

