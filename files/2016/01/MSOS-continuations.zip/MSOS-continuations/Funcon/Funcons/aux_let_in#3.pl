% Generated from Funcon/Funcons/aux_let_in#3.csf

sigdec(aux_let_in,A,[ids,_,A]).

onestep(aux_let_in(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,D),     rewrites(C,H),     runstep(D,E,G) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(aux_let_in(I,J,K),L).

onestep(aux_let_in(A,B,C),E,L,run) :-     rewrites(A,D),     rewrites(B,G),     rewrites(C,H),     runstep(D,E,F) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(aux_let_in(I,J,K),L).

onestep(aux_let_in(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(aux_let_in(O,P,Q),R).

onestep(aux_let_in(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(aux_let_in(O,P,Q),R).

sigdec(aux_let_in,A,[computes(ids),_,A]).

onestep(aux_let_in(A,B,C),J,L,run) :-     rewrites(A,D),     rewrites(B,F),     rewrites(C,H),     rewrites(D,E),     runcheck(E,val),     checktag(E,val,_),     rewrites(F,G),     runcheck(G,val),     checktag(G,val,_),     rewrites(H,I),     runcheck(I,val),     checktag(I,val,K),     unobs(J),     rewrites(K,L).

onestep(aux_let_in(A,B,C),D,V,run) :-     rewrites(A,G),     rewrites(B,I),     rewrites(C,N),     rewrites(K,F),     eq_label(D,[aux_env=E|M]),     rewrites(E,F),     rewrites(G,H),     runcheck(H,val),     checktag(H,val,P),     rewrites(I,J),     runcheck(J,val),     checktag(J,val,Q),     rewrites(map_update(K,P,Q),L),     O=[aux_env=L|M],     runstep(N,O,R) ->     rewrites(P,S),     rewrites(Q,T),     rewrites(R,U),     rewrites(aux_let_in(S,T,U),V).

