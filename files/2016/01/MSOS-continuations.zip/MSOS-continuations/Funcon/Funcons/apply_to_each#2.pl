% Generated from Funcon/Funcons/apply_to_each#2.csf

sigdec(apply_to_each,comms,[procs,lists(_)]).

onestep(apply_to_each(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(apply_to_each(G,H),I).

onestep(apply_to_each(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(apply_to_each(G,H),I).

onestep(apply_to_each(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(apply_to_each(J,K),L).

onestep(apply_to_each(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(apply_to_each(J,K),L).

sigdec(apply_to_each,comms,[computes(procs),computes(lists(_))]).

onestep(apply_to_each(A,B),E,F,run) :-     rewrites(A,C),     rewrites(B,list_empty),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,_),     unobs(E),     rewrites(null,F).

onestep(apply_to_each(A,B),G,Q,run) :-     rewrites(A,E),     rewrites(B,list_prefix(C,D)),     rewrites(C,H),     rewrites(D,L),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,K),     unobs(G),     rewrites(K,I),     rewrites(H,J),     rewrites(apply(I,J),O),     rewrites(K,M),     rewrites(L,N),     rewrites(apply_to_each(M,N),P),     rewrites(seq(O,P),Q).

onestep(apply_to_each(A,B),C,unit,inhabit) :-     rewrites(A,G),     rewrites(B,L),     rewrites(J,E),     eq_label(C,[answer=D|R]),     rewrites(D,E),     pre_comp(R,P),     rewrites(J,F),     I=[answer=F|P],     rewrites(G,H),     inhabit(H,I,abs(J,O,unit)) ->     mid_comp(P,Q),     rewrites(J,K),     N=[answer=K|Q],     rewrites(L,M),     inhabit(M,N,lists(O)) ->     post_comp(P,Q,R). 

