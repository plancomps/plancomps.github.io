% Generated from Funcon/Funcons/any#0.csf

sigdec(any,patts,[]).

onestep(any,A,patts,inhabit) :-     unobs(A).

onestep(any,A,B,resolve) :-     unobs(A),     rewrites(any,B).

onestep(any,A,B,typeval) :-     unobs(A),     rewrites(any,B).

rewrite(any,B) :-     rewrites(map_empty,A),     rewrites(abs(A),B).

