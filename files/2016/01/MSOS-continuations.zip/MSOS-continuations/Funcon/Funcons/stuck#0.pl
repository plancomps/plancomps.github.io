% Generated from Funcon/Funcons/stuck#0.csf

sigdec(stuck,computes(_),[]).

onestep(stuck,A,B,resolve) :-     unobs(A),     rewrites(stuck,B).

onestep(stuck,A,B,typeval) :-     unobs(A),     rewrites(stuck,B).

sigdec(stuck,computes(_),[]).

onestep(stuck,A,_,inhabit) :-     unobs(A).

