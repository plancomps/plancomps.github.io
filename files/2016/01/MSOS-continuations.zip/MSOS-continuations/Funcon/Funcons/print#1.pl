% Generated from Funcon/Funcons/print#1.csf

sigdec(print,comms,[_]).

onestep(print(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(print(E),F).

onestep(print(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(print(E),F).

onestep(print(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(print(E),F).

sigdec(print,comms,[_]).

onestep(print(A),G,E,run) :-     rewrites(A,B),     eq_label(G,[output+=_|D]),     rewrites(B,C),     runcheck(C,val),     checktag(C,val,F),     unobs(D),     rewrites(null,E),     rewrites(list1(F),H),     eq_label(G,[output+=H|_]).

onestep(print(A),D,unit,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,_).

