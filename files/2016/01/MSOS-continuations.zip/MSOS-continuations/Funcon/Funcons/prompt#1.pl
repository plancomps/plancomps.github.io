% Generated from Funcon/Funcons/prompt#1.csf

sigdec(prompt,A,[A]).

onestep(prompt(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(prompt(E),F).

onestep(prompt(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(prompt(E),F).

onestep(prompt(A),B,J,inhabit) :-     rewrites(A,G),     rewrites(_,D),     eq_label(B,[answer=C|F]),     rewrites(C,D),     rewrites(J,E),     I=[answer=E|F],     rewrites(G,H),     inhabit(H,I,J).

onestep(prompt(A),J,I,run) :-     rewrites(A,C),     eq_label(J,[ctrl+=_|B]),     D=[ctrl+=_|B],     runstep(C,D,G) ->     rewrites(none,F),     eq_label(D,[ctrl+=E|_]),     rewrites(E,F),     rewrites(G,H),     rewrites(prompt(H),I),     rewrites(none,K),     eq_label(J,[ctrl+=K|_]).

onestep(prompt(A),P,O,run) :-     rewrites(A,C),     eq_label(P,[ctrl+=_|B]),     D=[ctrl+=_|B],     runstep(C,D,I) ->     rewrites(some(G),F),     eq_label(D,[ctrl+=E|_]),     rewrites(E,F),     rewrites(G,tuple_prefix(J,tuple_prefix(H,tuple_empty))),     rewrites(lambda(H,aux_let_in(H,bound_value(H),I)),K),     rewrites(J,L),     rewrites(K,M),     rewrites(apply(L,M),N),     rewrites(prompt(N),O),     rewrites(none,Q),     eq_label(P,[ctrl+=Q|_]).

onestep(prompt(A),D,F,run) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,val),     checktag(C,val,E),     unobs(D),     rewrites(E,F).

