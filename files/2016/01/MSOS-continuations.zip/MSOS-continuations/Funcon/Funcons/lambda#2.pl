% Generated from Funcon/Funcons/lambda#2.csf

sigdec(lambda,abs(A,B),[ids,depends(A,B)]).

onestep(lambda(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(lambda(G,H),I).

onestep(lambda(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(lambda(J,K),L).

onestep(lambda(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(lambda(J,K),L).

sigdec(lambda,computes(abs(A,B)),[computes(ids),depends(A,B)]).

rewrite(lambda(A,B),K) :-     rewrites(A,C),     rewrites(B,F),     rewrites(C,D),     rewrites(given,E),     rewrites(bind_value(D,E),G),     rewrites(F,H),     rewrites(scope(G,H),I),     rewrites(abs(I),J),     rewrites(close(J),K).

