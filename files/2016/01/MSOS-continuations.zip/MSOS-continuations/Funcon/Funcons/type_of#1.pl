% Generated from Funcon/Funcons/type_of#1.csf

sigdec(type_of,types,[_]).

onestep(type_of(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(type_of(E),F).

onestep(type_of(A),H,types,inhabit) :-     rewrites(A,B),     pre_comp(H,F),     rewrites(B,C),     inhabit(C,F,D) ->     mid_comp(F,G),     rewrites(D,E),     inhabit(E,G,types) ->     post_comp(F,G,H). 

onestep(type_of(A),D,F,typeval) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E) ->     rewrites(E,F). 

