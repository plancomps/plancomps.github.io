% Generated from Funcon/Funcons/patt_at_type#2.csf

sigdec(patt_at_type,patts,[patts,types]).

onestep(patt_at_type(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(patt_at_type(G,H),I).

onestep(patt_at_type(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(patt_at_type(J,K),L).

onestep(patt_at_type(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(patt_at_type(J,K),L).

sigdec(patt_at_type,computes(patts),[computes(patts),types]).

rewrite(patt_at_type(A,B),G) :-     rewrites(A,C),     rewrites(B,D),     rewrites(C,E),     rewrites(D,F),     rewrites(restrict_domain(E,F),G).

