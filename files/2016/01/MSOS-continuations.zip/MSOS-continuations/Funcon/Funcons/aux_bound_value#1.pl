% Generated from Funcon/Funcons/aux_bound_value#1.csf

sigdec(aux_bound_value,computes(_),[ids]).

onestep(aux_bound_value(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(aux_bound_value(E),F).

onestep(aux_bound_value(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(aux_bound_value(E),F).

onestep(aux_bound_value(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(aux_bound_value(E),F).

sigdec(aux_bound_value,computes(_),[computes(ids)]).

onestep(aux_bound_value(A),B,L,run) :-     rewrites(A,E),     rewrites(H,D),     eq_label(B,[aux_env=C|G]),     rewrites(C,D),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,I),     unobs(G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_select(J,K),L).

