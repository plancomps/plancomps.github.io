% Generated from Funcon/Funcons/only#1.csf

sigdec(only,patts,[_]).

onestep(only(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(only(E),F).

onestep(only(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(only(E),F).

onestep(only(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(only(E),F).

sigdec(only,computes(patts),[_]).

rewrite(only(A),J) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,ground),     checktag(C,ground,D),     rewrites(D,E),     rewrites(given,F),     rewrites(equal(E,F),G),     rewrites(map_empty,H),     rewrites(when_true(G,H),I),     rewrites(abs(I),J).

onestep(only(A),D,abs(_,E,map_empty),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

