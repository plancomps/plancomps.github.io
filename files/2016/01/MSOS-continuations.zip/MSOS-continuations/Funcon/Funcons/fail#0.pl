% Generated from Funcon/Funcons/fail#0.csf

sigdec(fail,computes(_),[]).

onestep(fail,A,B,resolve) :-     unobs(A),     rewrites(fail,B).

onestep(fail,A,B,typeval) :-     unobs(A),     rewrites(fail,B).

sigdec(fail,computes(_),[]).

onestep(fail,C,B,run) :-     eq_label(C,[failure+=_|A]),     unobs(A),     rewrites(stuck,B),     rewrites(true,D),     eq_label(C,[failure+=D|_]).

onestep(fail,A,_,inhabit) :-     unobs(A).

