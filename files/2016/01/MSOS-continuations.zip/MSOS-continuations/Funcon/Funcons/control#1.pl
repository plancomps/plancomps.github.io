% Generated from Funcon/Funcons/control#1.csf

sigdec(control,A,[abs(abs(A,B),B)]).

onestep(control(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(control(E),F).

onestep(control(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(control(E),F).

onestep(control(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(control(E),F).

sigdec(control,A,[computes(abs(abs(A,B),B))]).

onestep(control(A),B,J,inhabit) :-     rewrites(A,G),     rewrites(K,D),     eq_label(B,[answer=C|F]),     rewrites(C,D),     rewrites(K,E),     I=[answer=E|F],     rewrites(G,H),     inhabit(H,I,abs(K,abs(K,J,K),K)).

onestep(control(A),I,F,run) :-     rewrites(A,B),     eq_label(I,[ctrl+=_|D]),     rewrites(B,C),     runcheck(C,val),     checktag(C,val,G),     runstep(fresh_id,D,H) ->     rewrites(H,E),     rewrites(aux_bound_value(E),F),     rewrites(some(tuple2(G,H)),J),     eq_label(I,[ctrl+=J|_]).

