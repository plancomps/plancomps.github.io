% Generated from Funcon/Funcons/patt_abs#2.csf

sigdec(patt_abs,abs(A,B),[patts,depends(A,B)]).

onestep(patt_abs(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(patt_abs(G,H),I).

onestep(patt_abs(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(patt_abs(J,K),L).

onestep(patt_abs(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(patt_abs(J,K),L).

sigdec(patt_abs,computes(abs(A,B)),[computes(patts),depends(A,B)]).

onestep(patt_abs(A,B),E,M,run) :-     rewrites(A,C),     rewrites(B,I),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,F),     unobs(E),     rewrites(given,G),     rewrites(F,H),     rewrites(match(G,H),J),     rewrites(I,K),     rewrites(scope(J,K),L),     rewrites(abs(L),M).

onestep(patt_abs(A,B),C,abs(ZB,V,ZH),inhabit) :-     rewrites(A,S),     rewrites(B,ZE),     rewrites(L,E),     eq_label(C,[given=D|F]),     rewrites(D,E),     rewrites(Y,H),     eq_label(F,[env=G|I]),     rewrites(G,H),     rewrites(P,K),     eq_label(I,[answer=J|ZK]),     rewrites(J,K),     pre_comp(ZK,ZI),     rewrites(L,M),     U=[given=M|N],     rewrites(Y,O),     N=[env=O|Q],     rewrites(P,R),     Q=[answer=R|ZI],     rewrites(S,T),     inhabit(T,U,abs(ZB,V,X)) ->     mid_comp(ZI,ZJ),     rewrites(V,W),     ZG=[given=W|Z],     rewrites(map_over(X,Y),ZA),     Z=[env=ZA|ZC],     rewrites(ZB,ZD),     ZC=[answer=ZD|ZJ],     rewrites(ZE,ZF),     inhabit(ZF,ZG,ZH) ->     post_comp(ZI,ZJ,ZK). 

