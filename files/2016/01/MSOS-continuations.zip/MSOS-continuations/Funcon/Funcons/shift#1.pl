% Generated from Funcon/Funcons/shift#1.csf

sigdec(shift,A,[abs(abs(A,B),B)]).

onestep(shift(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(shift(E),F).

onestep(shift(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(shift(E),F).

onestep(shift(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(shift(E),F).

sigdec(shift,A,[computes(abs(abs(A,B),B))]).

onestep(shift(A),B,J,inhabit) :-     rewrites(A,G),     rewrites(K,D),     eq_label(B,[answer=C|F]),     rewrites(C,D),     rewrites(K,E),     I=[answer=E|F],     rewrites(G,H),     inhabit(H,I,abs(K,abs(_,J,K),K)).

onestep(shift(A),D,U,run) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,val),     checktag(C,val,E),     runstep(fresh_id,D,G) ->     rewrites(G,R),     rewrites(E,P),     rewrites(q(x),F),     rewrites(id(F),N),     rewrites(G,H),     rewrites(bound_value(H),K),     rewrites(q(x),I),     rewrites(id(I),J),     rewrites(bound_value(J),L),     rewrites(apply(K,L),M),     rewrites(reset(M),O),     rewrites(lambda(N,O),Q),     rewrites(apply(P,Q),S),     rewrites(lambda(R,S),T),     rewrites(control(T),U).

