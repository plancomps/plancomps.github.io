% Generated from Funcon/Funcons/abort#1.csf

sigdec(abort,computes(_),[_]).

onestep(abort(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(abort(E),F).

onestep(abort(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(abort(E),F).

onestep(abort(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(abort(E),F).

sigdec(abort,computes(_),[_]).

onestep(abort(A),B,_,inhabit) :-     rewrites(A,G),     rewrites(J,D),     eq_label(B,[answer=C|F]),     rewrites(C,D),     rewrites(J,E),     I=[answer=E|F],     rewrites(G,H),     inhabit(H,I,J).

onestep(abort(A),D,J,run) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,val),     checktag(C,val,F),     runstep(fresh_id,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(lambda(G,H),I),     rewrites(control(I),J).

