% Generated from Funcon/Funcons/follow_fwd#1.csf

sigdec(follow_fwd,computes(_),[fwds]).

onestep(follow_fwd(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(follow_fwd(E),F).

onestep(follow_fwd(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(follow_fwd(E),F).

onestep(follow_fwd(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(follow_fwd(E),F).

sigdec(follow_fwd,computes(_),[computes(fwds)]).

onestep(follow_fwd(A),J,H,run) :-     rewrites(A,E),     rewrites(I,C),     eq_label(J,[forward=B|D]),     rewrites(B,C),     eq_label(D,[forward+=_|F]),     rewrites(map_select(I,E),G),     unobs(F),     rewrites(G,H),     rewrites(I,K),     eq_label(J,[forward+=K|_]).

onestep(follow_fwd(A),D,E,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,fwds(E)).

