% Generated from Funcon/Funcons/reset#1.csf

sigdec(reset,A,[A]).

onestep(reset(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(reset(E),F).

onestep(reset(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(reset(E),F).

rewrite(reset(A),D) :-     rewrites(A,B),     rewrites(B,C),     rewrites(prompt(C),D).

