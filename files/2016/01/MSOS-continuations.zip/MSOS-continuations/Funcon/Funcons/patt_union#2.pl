% Generated from Funcon/Funcons/patt_union#2.csf

sigdec(patt_union,patts,[patts,patts]).

onestep(patt_union(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(patt_union(G,H),I).

onestep(patt_union(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(patt_union(G,H),I).

onestep(patt_union(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(patt_union(J,K),L).

onestep(patt_union(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(patt_union(J,K),L).

sigdec(patt_union,computes(patts),[computes(patts),computes(patts)]).

rewrite(patt_union(A,C),J) :-     rewrites(A,abs(B)),     rewrites(B,E),     rewrites(C,abs(D)),     rewrites(D,F),     rewrites(E,G),     rewrites(F,H),     rewrites(map_union(G,H),I),     rewrites(abs(I),J).

onestep(patt_union(A,B),M,abs(H,I,map_union(E,J)),inhabit) :-     rewrites(A,C),     rewrites(B,F),     pre_comp(M,K),     rewrites(C,D),     inhabit(D,K,abs(H,I,E)) ->     mid_comp(K,L),     rewrites(F,G),     inhabit(G,L,abs(H,I,J)) ->     post_comp(K,L,M). 

