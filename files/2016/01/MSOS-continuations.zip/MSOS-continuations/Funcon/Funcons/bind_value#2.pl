% Generated from Funcon/Funcons/bind_value#2.csf

sigdec(bind_value,environments,[ids,_]).

onestep(bind_value(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(bind_value(G,H),I).

onestep(bind_value(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(bind_value(G,H),I).

onestep(bind_value(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(bind_value(J,K),L).

onestep(bind_value(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(bind_value(J,K),L).

sigdec(bind_value,computes(environments),[computes(ids),_]).

rewrite(bind_value(A,B),K) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,G),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,H),     rewrites(G,I),     rewrites(H,J),     rewrites(map1(I,J),K).

onestep(bind_value(A,C),F,map1(B,G),inhabit) :-     rewrites(A,B),     rewrites(C,D),     rewrites(D,E),     inhabit(E,F,G).

