% Generated from Funcon/Funcons/callcc#1.csf

sigdec(callcc,A,[abs(abs(A,_),A)]).

onestep(callcc(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(callcc(E),F).

onestep(callcc(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(callcc(E),F).

onestep(callcc(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(callcc(E),F).

sigdec(callcc,A,[computes(abs(abs(A,_),A))]).

onestep(callcc(A),B,K,inhabit) :-     rewrites(A,G),     rewrites(J,D),     eq_label(B,[answer=C|F]),     rewrites(C,D),     rewrites(J,E),     I=[answer=E|F],     rewrites(G,H),     inhabit(H,I,abs(J,abs(J,K,_),K)).

onestep(callcc(A),D,X,run) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,val),     checktag(C,val,F),     runstep(fresh_id,D,H) ->     rewrites(H,U),     rewrites(H,E),     rewrites(bound_value(E),S),     rewrites(F,Q),     rewrites(q(x),G),     rewrites(id(G),O),     rewrites(H,I),     rewrites(bound_value(I),L),     rewrites(q(x),J),     rewrites(id(J),K),     rewrites(bound_value(K),M),     rewrites(apply(L,M),N),     rewrites(abort(N),P),     rewrites(lambda(O,P),R),     rewrites(apply(Q,R),T),     rewrites(apply(S,T),V),     rewrites(lambda(U,V),W),     rewrites(control(W),X).

