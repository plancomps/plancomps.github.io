% Generated from Funcon/Funcons/follow_if_fwd#1.csf

sigdec(follow_if_fwd,computes(_),[_]).

onestep(follow_if_fwd(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(follow_if_fwd(E),F).

onestep(follow_if_fwd(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(follow_if_fwd(E),F).

onestep(follow_if_fwd(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(follow_if_fwd(E),F).

sigdec(follow_if_fwd,computes(_),[_]).

rewrite(follow_if_fwd(A),F) :-     rewrites(A,fwd(B)),     rewrites(B,C),     rewrites(C,D),     rewrites(fwd(D),E),     rewrites(follow_fwd(E),F).

rewrite(follow_if_fwd(A),E) :-     rewrites(A,C),     rewrites(C,B),     runcheck(B,val),     checktag(B,val,D),     different(C,fwd(_)),     rewrites(D,E).

onestep(follow_if_fwd(A),D,E,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E) ->     different(E,fwds(_)). 

onestep(follow_if_fwd(A),D,E,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,fwds(E)).

