% Generated from Funcon/Funcons/bound_value#1.csf

sigdec(bound_value,computes(_),[ids]).

onestep(bound_value(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(bound_value(E),F).

onestep(bound_value(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(bound_value(E),F).

onestep(bound_value(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(bound_value(E),F).

sigdec(bound_value,computes(_),[computes(ids)]).

onestep(bound_value(A),B,J,run) :-     rewrites(A,G),     rewrites(F,D),     eq_label(B,[env=C|E]),     rewrites(C,D),     unobs(E),     rewrites(F,H),     rewrites(G,I),     rewrites(map_select(H,I),J).

onestep(bound_value(A),B,map_select(E,F),inhabit) :-     rewrites(A,F),     rewrites(E,D),     eq_label(B,[env=C|G]),     rewrites(C,D),     rewrites(contains_key(E,F),true),     unobs(G).

