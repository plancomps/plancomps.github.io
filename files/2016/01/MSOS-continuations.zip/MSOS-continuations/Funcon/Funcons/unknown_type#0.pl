% Generated from Funcon/Funcons/unknown_type#0.csf

sigdec(unknown_type,types,[]).

onestep(unknown_type,A,B,resolve) :-     unobs(A),     rewrites(unknown_type,B).

onestep(unknown_type,A,types,inhabit) :-     unobs(A).

onestep(unknown_type,A,B,typeval) :-     unobs(A),     rewrites(_,B).

