% Generated from Funcon/Funcons/effect#1.csf

sigdec(effect,unit,[_]).

onestep(effect(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(effect(E),F).

onestep(effect(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(effect(E),F).

onestep(effect(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(effect(E),F).

sigdec(effect,computes(unit),[_]).

rewrite(effect(A),D) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,val),     checktag(C,val,_),     rewrites(null,D).

onestep(effect(A),D,unit,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,_).

