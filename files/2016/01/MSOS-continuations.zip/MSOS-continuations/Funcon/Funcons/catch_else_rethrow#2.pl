% Generated from Funcon/Funcons/catch_else_rethrow#2.csf

sigdec(catch_else_rethrow,computes(A),[computes(A),abs(_,A)]).

onestep(catch_else_rethrow(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(catch_else_rethrow(G,H),I).

onestep(catch_else_rethrow(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(catch_else_rethrow(J,K),L).

onestep(catch_else_rethrow(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(catch_else_rethrow(J,K),L).

sigdec(catch_else_rethrow,computes(A),[computes(A),computes(abs(_,A))]).

rewrite(catch_else_rethrow(A,B),K) :-     rewrites(A,C),     rewrites(B,D),     rewrites(C,I),     rewrites(D,G),     rewrites(given,E),     rewrites(throw(E),F),     rewrites(abs(F),H),     rewrites(prefer_over(G,H),J),     rewrites(catch(I,J),K).

