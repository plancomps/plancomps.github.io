% Generated from Funcon/Funcons/bound_type#1.csf

sigdec(bound_type,types,[ids]).

onestep(bound_type(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(bound_type(E),F).

onestep(bound_type(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(bound_type(E),F).

sigdec(bound_type,types,[computes(ids)]).

onestep(bound_type(A),B,types,inhabit) :-     rewrites(A,F),     rewrites(E,D),     eq_label(B,[env=C|G]),     rewrites(C,D),     rewrites(contains_key(E,F),true),     unobs(G).

onestep(bound_type(A),B,J,typeval) :-     rewrites(A,G),     rewrites(F,D),     eq_label(B,[env=C|E]),     rewrites(C,D),     rewrites(contains_key(F,G),true),     unobs(E),     rewrites(F,H),     rewrites(G,I),     rewrites(map_select(H,I),J).

