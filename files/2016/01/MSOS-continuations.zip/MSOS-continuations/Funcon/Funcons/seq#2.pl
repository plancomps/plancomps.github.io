% Generated from Funcon/Funcons/seq#2.csf

sigdec(seq,A,[unit,A]).

onestep(seq(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(seq(G,H),I).

onestep(seq(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(seq(J,K),L).

onestep(seq(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(seq(J,K),L).

sigdec(seq,A,[computes(unit),A]).

onestep(seq(A,B),C,E,run) :-     rewrites(A,null),     rewrites(B,D),     unobs(C),     rewrites(D,E).

onestep(seq(A,B),J,G,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,unit) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,G) ->     post_comp(H,I,J). 

