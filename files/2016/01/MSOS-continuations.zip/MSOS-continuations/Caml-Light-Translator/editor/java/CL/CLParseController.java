package CL;

public class CLParseController extends CLParseControllerGenerated 
{ }