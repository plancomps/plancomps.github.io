% Literals

valcons(q(_)).


% Atoms

sigdec(q(_),atoms,[]).

onestep(q(M),L,atoms,inhabit) :- atom(M), name(M,_), unobs(L).


% Integers

onestep(q(M),L,ints,inhabit) :- integer(M), unobs(L).

sigdec(q(M),ints,[]) :- integer(M).

rewrite(int_negate(M),q(Z)) :- rewrites(M,q(M1)), integer(M1), Z is - M1.

rewrite(int_plus(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), Z is M1 + N1.

rewrite(int_minus(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), Z is M1 - N1.

rewrite(int_times(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), Z is M1 * N1.

rewrite(int_divide(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), Z is M1 // N1.

rewrite(int_modulo(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), Z is M1 mod N1.

rewrite(int_less(M,N),Z) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), ( M1 < N1 -> Z = true ; Z = false).

rewrite(int_less_equal(M,N),Z) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), ( M1 =< N1 -> Z = true ; Z = false).

rewrite(int_greater(M,N),Z) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), ( M1 > N1 -> Z = true ; Z = false).

rewrite(int_greater_equal(M,N),Z) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), ( M1 >= N1 -> Z = true ; Z = false).

rewrite(int_or(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), Z is M1 \/ N1.

rewrite(int_and(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), Z is M1 /\ N1.

rewrite(int_xor(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), Z is M1 xor N1.

rewrite(int_not(M),q(Z)) :- rewrites(M,q(M1)), integer(M1), Z is \ M1.

rewrite(int_logical_shift_left(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), Z is M1 << N1.

% not provided by Prolog
% rewrite(int_logical_shift_right(M,N),q(Z)) :-
% rewrite(int_arithmetic_shift_left(M,N),q(Z)) :-

rewrite(int_arithmetic_shift_right(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), Z is M1 >> N1.

% Floats

onestep(q(M),L,floats,inhabit) :- float(M), unobs(L).

sigdec(q(M),floats,[]) :- float(M).

rewrite(float_round(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is round(M1).

rewrite(float_floor(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is floor(M1).

rewrite(float_ceiling(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is ceiling(M1).

rewrite(float_truncate(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is truncate(M1).

rewrite(int_to_float(M),q(Z)) :- rewrites(M,q(M1)), integer(M1), Z is float(M1).

rewrite(float_negate(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is - M1.

rewrite(float_plus(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), float(M1), float(N1), Z is M1 + N1.

rewrite(float_minus(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), float(M1), float(N1), Z is M1 - N1.

rewrite(float_times(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), float(M1), float(N1), Z is M1 * N1.

rewrite(float_divide(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), float(M1), float(N1), Z is M1 / N1.

rewrite(float_power(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), float(M1), float(N1), Z is M1 ** N1.

rewrite(float_less(M,N),Z) :- rewrites(M,q(M1)), rewrites(N,q(N1)), float(M1), float(N1), ( M1 < N1 -> Z = true ; Z = false).

rewrite(float_less_equal(M,N),Z) :- rewrites(M,q(M1)), rewrites(N,q(N1)), float(M1), float(N1), ( M1 =< N1 -> Z = true ; Z = false).

rewrite(float_greater(M,N),Z) :- rewrites(M,q(M1)), rewrites(N,q(N1)), float(M1), float(N1), ( M1 > N1 -> Z = true ; Z = false).

rewrite(float_greater_equal(M,N),Z) :- rewrites(M,q(M1)), rewrites(N,q(N1)), float(M1), float(N1), ( M1 >= N1 -> Z = true ; Z = false).

rewrite(float_pi,q(Z)) :- Z is pi.

rewrite(float_e,q(Z)) :- Z is e.

rewrite(float_sqrt(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is sqrt(M1).

rewrite(float_log(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is log(M1).

rewrite(float_log10(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is log10(M1).

rewrite(float_exp(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is exp(M1).

rewrite(float_sin(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is sin(M1).

rewrite(float_cos(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is cos(M1).

rewrite(float_tan(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is tan(M1).

rewrite(float_asin(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is asin(M1).

rewrite(float_acos(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is acos(M1).

rewrite(float_atan(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is atan(M1).

rewrite(float_sinh(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is sinh(M1).

rewrite(float_cosh(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is cosh(M1).

rewrite(float_tanh(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is tanh(M1).

rewrite(float_asinh(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is asinh(M1).

rewrite(float_acosh(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is acosh(M1).

rewrite(float_atanh(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is atanh(M1).

rewrite(float_atan2(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), float(M1), float(N1), Z is atan2(M1,N1).


% Strings

onestep(str(q(M)),L,strings,inhabit) :- atom(M), name(M,_), unobs(L).

sigdec(str,strings,[atoms]).

rewrite(string_append(M,N),str(q(Z))) :- rewrites(M,str(q(M1))), rewrites(N,str(q(N1))), name(M1,M1n), name(N1,N1n),
           append(["\"",M1ncore,"\""],M1n), append(["\"",N1ncore,"\""], N1n),
           append(M1ncore,N1ncore,Zncore), append(["\"",Zncore,"\""],Zn), name(Z,Zn).

rewrite(int_to_string(M),str(q(S))) :- rewrites(M,q(Z)), integer(Z), name(Z,Zn), append(["\"",Zn,"\""],Sn), name(S,Sn).

valcons(str).


% Builtins

subsort(Type,computes(Type)) :- valsort(Type).
subsort(computes(Type1),computes(Type2)) :- valsort(Type1), subsort(Type1,Type2), valsort(Type2).
typedef(computes(X),computes(Y)) :- valsort(X), typedef(X,Y).

subsort(computes(Y),depends(_,Y)) :- valsort(Y).
typedef(depends(Z,X),depends(Z,Y)) :- valsort(X), typedef(X,Y).
typedef(depends(X,Z),depends(Y,Z)) :- valsort(X), typedef(X,Y).
subsort(depends(Z,Type1),depends(Z,Type2)) :- valsort(Type1), subsort(Type1,Type2), valsort(Type2).
%subsort(depends(Type1,Z),depends(Type2,Z)) :- valsort(Type1), subsort(Type1,Type2), valsort(Type2).

subsort(lists(X),lists(Y)) :- \+ var(X), subsort(X,Y).
subsort(maps(X,Y),maps(X,Z)) :- \+ var(X), \+ var(Y), subsort(Y,Z).
typedef(maps(Z,X),maps(Z,Y)) :- \+ var(X), typedef(X,Y).
typedef(maps(X,Z),maps(Y,Z)) :- \+ var(X), typedef(X,Y).

valsort(val).
valsort(ground).

onestep(q(A),L,q(A),resolve) :- unobs(L).
onestep(computes(A),L,computes(B),resolve) :- onestep(A,L,B,resolve).
onestep(depends(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(depends(J,K),L).
onestep(depends(A,B),G,L,typeval) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), typeval(C,E,H), mid_comp(E,F), typeval(D,F,I), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(depends(J,K),L).

%valsort(constant).
valsort(nullary).

% Prolog implementation of instantiate_meta

:- ensure_loaded(imsos_sem). % uses strict_member

rewrite(instantiate_meta(X),X1) :- rewrite(type_vars(X),TV), removechecks(TV,TV1), to_funcon_list(TV2,TV1), instantiate_metavars(X,[],_,X1,TV2).

snd(_=Y,Y).
untypevar(typevar(Y),Y).

to_funcon_list([],list_empty).
to_funcon_list([X|Xs],list_prefix(X,Xs1)) :- to_funcon_list(Xs,Xs1).

% instantiate_metavars(Term,List1,List2,Output,TV)
% Instantiates metavariables in Term to Output
% List1 and List2 are lists of equations X=Y
% where: X is prolog var, Y is atom (to become a type variable)
% List1 is input (used / generated bindings so far)
% List2 is List1 plus additional bindings generated.
% TV is a list of typevariables to be avoided
instantiate_metavars(T,Usedvars,Usedvars,typevar(A),_) :- var(T), strict_member(T,Usedvars,A), !.
instantiate_metavars(T,Usedvars,[T=A|Usedvars],typevar(A),TV) :- var(T), !, nextvar1(Usedvars,A,TV).
instantiate_metavars(T,Usedvars,Newvars,T1,TV) :- nonvar(T), !, T =.. [F|Xs], instantiate_metavars1(Xs,Usedvars,Newvars,Xs1,TV), T1 =.. [F|Xs1].

% instantiate_metavars1 is like instantiate_metavars, except
% consumes and produces a list of terms
instantiate_metavars1([],Usedvars,Usedvars,[],_).
instantiate_metavars1([T|Ts],Usedvars,Newvars1,[T1|Ts1],TV) :- instantiate_metavars(T,Usedvars,Newvars,T1,TV), instantiate_metavars1(Ts,Newvars,Newvars1,Ts1,TV).

nextvar1(List,Out,TV) :- maplist(snd,List,List1), maplist(untypevar,TV,TV1), append(List1,TV1,List2), sort(List2,List3), reverse(List3,List4), nextvar2(List4,Out).

nextvar2([],q('a')).
nextvar2([q(A)|_],q(B)) :- atom_codes(A,[N|Ns]), M is N + 1, atom_codes(B,[M|Ns]).
