:- ensure_loaded(imsos_sem).
:- ensure_loaded(csf_sem).
:- ensure_loaded(imsos_lib).

dirs(['Funcon/Funcons','Funcon/Sorts','Funcon/Entities','Funcon/Values', 'Funcon/Caml-Light', 'Funcon/Higher' ]).

dir_csf(Dir,NewFiles) :- directory_files(Dir,Files), csf_files(Files,Files1), atom_concat(Dir,'/',Dir1), maplist(atom_concat(Dir1),Files1,NewFiles).

all_csf(NewFiles) :- dirs(Xs), maplist(dir_csf,Xs,Files), append(Files,NewFiles).

csf2pl :- all_csf(NewFiles), csfs_parse(NewFiles,CFiles), csf2imsos(CFiles,IFile), %printout(IFile),
        imsos2pl_abs(IFile,'repos.pl'), repos, !.

% add printout(IFile) to get IMSOS representation printed.

repos :- reconsult(repos).

printout(IFile) :- IFile = imsos_file(IList), filterrun(IList,IFile1), printout1(IFile1).

filterrun([],[]).
filterrun([X|Xs],[X|Ys]) :- X = imsos_rule(_,imsos_onestep(_,_,_,run)), !, filterrun(Xs,Ys).
filterrun([X|Xs],[X|Ys]) :- X = imsos_rule(_,imsos_termeq(_,_)), !, filterrun(Xs,Ys).
% filterrun([X|Xs],[X|Ys]) :- X = imsos_subsort(_,_), !, filterrun(Xs,Ys).
filterrun([X|Xs],[X|Ys]) :- X = imsos_valcons(_), !, filterrun(Xs,Ys).
filterrun([_|Xs],Ys) :- filterrun(Xs,Ys).

printout1([]).
printout1([X|Xs]) :-
        retract(varcounter(_)), assert(varcounter(1)), vars2terms(X),
        print(X), write('.'), nl, nl, printout1(Xs).

/*
%% Add single quotes to distinguish Prolog atoms from Prolog variables
%% in printed terms:
portray(X) :-
        nonvar(X), \+ is_list(X), X =.. [F|Args] ->
        ( F = q -> write(q), portray_args_quote(Args)
        ; Args \= [], atom_to_chars(F,[C|_]), is_upper(C) ->
          portray_quote(F), portray_args(Args)
        ; Args = [], atom_to_chars(F,[C]), [C] == "F" -> % F-constructors are not variables.
          portray_quote(F) ).

portray_quote(X) :-
        ( nonvar(X), is_list(X), X = [Y|Ys] -> write('['), print(Y), portray_list_quote(Ys), write(']')
        ; nonvar(X), X =.. [F|Args] ->
          ( is_string_atom(F) -> write(F)
          ; write('\''), write(F), write('\'') ),
          portray_args_quote(Args)
        ; write(X) ).

portray_list(X) :-
        ( var(X) -> write(X)
        ; X = [] -> true
        ; X = [Y|Ys] -> write(','), print(Y), portray_list(Ys) ).

portray_list_quote(X) :-
        ( var(X) -> write(X)
        ; X = [] -> true
        ; X = [Y|Ys] -> write(','), portray_quote(Y), portray_list_quote(Ys) ).

portray_args(X) :-
        ( var(X) -> write(X)
        ; X = [] -> true
        ; X = [Y|Ys] -> write('('), print(Y), portray_list(Ys), write(')') ).

portray_args_quote(X) :-
        ( var(X) -> write(X)
        ; X = [] -> true
        ; X = [Y|Ys] -> write('('), portray_quote(Y), portray_list_quote(Ys), write(')') ).
*/


%% Utility predicates
is_string_atom(S) :-
        atom_to_chars(S,[C|Cs]),
        char_code('"',C),
        last_char(Cs,C).

last_char([C],C) :- !.
last_char([_|Cs],C) :- last_char(Cs,C).

:- dynamic varcounter/1.
varcounter(1).

vars2terms(X) :-
        ( var(X) -> var2term(X)
        ; is_list(X), X = [] -> true
        ; is_list(X), X = [Y|Ys] -> vars2terms(Y), vars2terms(Ys)
        ; X =.. [_|Args] -> vars2terms(Args) ).

var2term(X) :-
        ( var(X) ->
          retract(varcounter(N)),
          number_codes(N,N_C),
          append("T_",N_C,Y_N),
          name(X,Y_N),
          N_1 is N + 1,
          assert(varcounter(N_1))
        ; true ).

% Generating individual Prolog files.

csf2pls :- all_csf(NewFiles), csfs_parse(NewFiles,CFiles), csf2imsoss(CFiles,IFiles), %printout(IFile),
           process(NewFiles,IFiles), ensure_loaded('Prolog/run_fct').

process([],[]).
process([NewFile|Xs],[IFile|Ys]) :- pl_filename(NewFile,NewFilePl),atom_concat('Generated from ',NewFile,Comment),
             imsos2pl_abs(imsos_file(IFile),NewFilePl,Comment), process(Xs,Ys).

pl_filename(X,Y) :- name(X,N), append(N1,".csf",N), append(N1,".pl",N2), name(Y,N2).
