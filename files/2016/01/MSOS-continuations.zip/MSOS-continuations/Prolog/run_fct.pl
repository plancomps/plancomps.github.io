:- ensure_loaded(imsos_syn).
:- ensure_loaded(imsos_lib).
:- ensure_loaded(builtin).

% For individual Prolog files

:- ensure_loaded(csf_pl).

pl_files([],[]).
pl_files([X|Xs],[X|Ys]) :- file_name_extension(_,'pl',X), !, pl_files(Xs,Ys).
pl_files([_|Xs],Ys) :- pl_files(Xs,Ys).

dir_pl(Dir,NewFiles) :- directory_files(Dir,Files), pl_files(Files,Files1), atom_concat(Dir,'/',Dir1), maplist(atom_concat(Dir1),Files1,NewFiles).

all_pl(NewFiles) :- dirs(Xs), maplist(dir_pl,Xs,Files), append(Files,NewFiles).

:- all_pl(Files),maplist(ensure_loaded,Files).

% Funcon running terms

start(FctString) :- iterm(ITerm,FctString,[]), run_control(ITerm), nl.

start_type(FctString) :- iterm(ITerm,FctString,[]), typeinfer_control(ITerm).

start_tcheck(FctString1,FctString2) :- iterm(ITerm1,FctString1,[]), iterm(ITerm2,FctString2,[]),
                         typecheck(ITerm1,ITerm2), nl.

start1(FctString) :- iterm(ITerm,FctString,[]), run(ITerm), nl.

startf(Filename) :- open(Filename,read,Str), read_entire_file_variant(Str,ITerm), close(Str),
                    trystatic(ITerm), nl,
                    start(ITerm).

startf1(Filename) :- open(Filename,read,Str), read_entire_file_variant(Str,ITerm), close(Str),
                    trystatic(ITerm),
                    start1(ITerm).

startf_nt(Filename) :- open(Filename,read,Str), read_entire_file_variant(Str,ITerm), close(Str),
                    start(ITerm).

trystatic(ITerm) :- print('Type checking'), nl, print('-------------'), nl, start_type(ITerm), !.
trystatic(_) :- print('Failed.'),nl.

trace(FctString) :- gspy(--->*), start(FctString).

compute_type1(Term,L,Type) :- iterm(Term1,Term,[]), compute_type(Term1,L,Type).

compute1(Term,L,Type) :- iterm(Term1,Term,[]), compute(Term1,L,Type).

check_type1(Term,L,Type) :- iterm(Term1,Term,[]), iterm(Type1,Type,[]), check_type(Term1,L,Type1).

% Custom run for Caml Light.

run_cl(T) :- time(compute(T,L,T1)), eq_label(L,[forward += _|L1]), nondefaults(L1,L2),
     omitfunctionbodies(L2,L2p),
     print(L2p), print(' --> '),
     ( runcheck(T1,environments) -> print('an environment') ; print('a stuck term') ), nl.

% Custom run to support Continuations paper
run_control(T) :- time(compute(T,L,T1)), eq_label(L,[output += O|_]),
     omitfunctionbodies(O,Op),
     print('Output'), nl, print('------'), nl, pplist(Op),
     ( runcheck(T1,environments) -> true ; print('Error: Stuck, no more transitions.') ), nl.

tcheck(Term,Sort) :- iterm(ITerm,Term,[]), supcheck(ITerm,Sort).

omitfunctionbodies(L2,L2p) :-
   select(store += S, L2, L1), !,
   omitfunctionbodies1(S,S1),
   append(L1,[store += S1],L2p).
omitfunctionbodies(L2,L2).

omitfunctionbodies1(map_empty,map_empty).
omitfunctionbodies1(map_prefix(X,abs(_),XYs),map_prefix(X,abs('...'),XYs1)) :- !, omitfunctionbodies1(XYs,XYs1).
omitfunctionbodies1(map_prefix(X,Y,XYs),map_prefix(X,Y,XYs1)) :- omitfunctionbodies1(XYs,XYs1).

pplist(list_empty) :- true.
pplist(list_prefix(H,T)) :- print(H), nl, pplist(T).

pptype(map_empty) :- true.
pptype(map_prefix(K,V,M)) :- print(K), print(' : '), print(V), nl, pptype(M).


% Used only in this module

read_entire_file_variant(Stream,"") :- at_end_of_stream(Stream), !.
read_entire_file_variant(Stream,String) :- read_line_to_codes(Stream,X),
  read_entire_file_variant(Stream,Xs), 
  ( Xs == "" -> String = X; append([X,"\n",Xs],String) ). % changed by peter

