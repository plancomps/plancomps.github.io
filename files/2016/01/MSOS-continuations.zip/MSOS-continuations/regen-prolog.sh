#!/bin/bash

swipl -s Prolog/csf_pl.pl -g "csf2pls, halt."
