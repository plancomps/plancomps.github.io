let rec append lst = match lst with
                         []        -> shift (fun k -> k)
                       | a :: rest -> a :: append rest
;;

let append123 = reset (append [1; 2; 3])
;;

append123 [4]
;;
(* [1;2;3;4] *)

(* Does not type check in our type system. *)

