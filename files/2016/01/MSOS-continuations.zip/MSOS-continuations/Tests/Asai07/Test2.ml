let add1 x = x + 1
;;

reset (add1 2 ; ()  ) ;
reset (add1 3 ; true)
;;
(* true *)

