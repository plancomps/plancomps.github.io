let int x = string_of_int x ;;

let str (x : string) = x ;;

let o to_str = shift (fun k -> fun x -> k (to_str x)) ;;

let sprintf p = reset (p ()) ;;

sprintf (fun () -> "Hello world!") ;;
(* "Hello world!" *)

sprintf (fun () -> "Hello " ^ o str ^ "!") "world" ;;
(* "Hello world!" *)

sprintf (fun () -> "The value of " ^ o str ^ " is " ^ o int) "x" 3 ;;
(* "The value of x is 3" *)

(* Does not type check in our type system. *)
