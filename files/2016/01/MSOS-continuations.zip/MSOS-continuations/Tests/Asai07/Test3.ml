let rec visit lst = match lst with
                        []        -> shift (fun h -> [])
                      | a :: rest -> a :: shift (fun k -> k [] :: reset (k (visit rest)))
;;

let rec prefixes lst = reset (visit lst)
;;

prefixes [1; 2; 3] ;;
(* [ [1]; [1; 2]; [1; 2; 3] ] *)

(* Does not type check in our type system. *)

