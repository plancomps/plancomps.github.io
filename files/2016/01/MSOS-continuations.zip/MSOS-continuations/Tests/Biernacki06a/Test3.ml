prompt ( (control (function k -> 10 + prompt (k 100)))
       + (control (function k1 -> 1))
       ) ;;
(* 11 *)

