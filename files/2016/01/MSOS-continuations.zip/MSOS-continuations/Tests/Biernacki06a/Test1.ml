reset ( (shift (function k -> 10 + (k 100)))
      + (shift (function k1 -> 1))
      ) ;;
(* 11 *)

