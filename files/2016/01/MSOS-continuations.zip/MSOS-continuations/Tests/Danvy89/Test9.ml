let hd = function x :: _  -> x  ;;
let tl = function _ :: xs -> xs ;;

let make_palindrome l = let rec mirror l = if l = []
                                            then []
                                            else shift (function c -> hd l :: (c (hd l :: mirror (tl l))))
                         in reset (mirror l) ;;

make_palindrome [1;2;3] ;;
(* [3;2;1;1;2;3] *)
