let add1 = function x -> x + 1 ;;

let f n = control (function k -> n)
and g x = control (function c -> add1 (c x))
 in prompt (f (g 2)) ;;
(* 2 *)