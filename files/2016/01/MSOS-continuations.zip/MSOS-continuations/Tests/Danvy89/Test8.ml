let hd = function x :: _  -> x  ;;
let tl = function _ :: xs -> xs ;;

let make_palindrome s = let rec mirror l = if l = []
                                            then s
                                            else shift (function c -> hd l :: c (mirror (tl l)))
                         in reset (mirror s) ;;

make_palindrome [1;2;3] ;;
(* [3;2;1;1;2;3] *)
