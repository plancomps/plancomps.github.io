let c = reset (if shift (function k -> k) then 2 else 3)
 in c true + c false ;;
(* 5 *)

(* Does not type check in our type system. *)

