let add1 = function x -> x + 1 ;;

let f n = shift (function k -> n)
and g x = shift (function c -> add1 (c x))
 in reset (f (g 2)) ;;
(* 3 *)