reset (1 + shift (function c -> 0)) ;;
(* 0 *)
