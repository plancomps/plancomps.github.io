type tree = Empty_tree | Node of int | Branch of (tree * tree) ;;

let flatten2 t = let rec aux2 t = reset (match t with
                                           | Empty_tree          -> shift (function a -> a)
                                           | Node i              -> i :: shift (function a -> a)
                                           | Branch (left,right) -> aux2 left (aux2 right (shift (function a -> a))))
                  in aux2 t [] ;;

let tree1 = Branch (Node 1, Branch (Empty_tree, Node 2)) ;;

flatten2 tree1 ;;
(* [1;2] *)

(* Does not type check in our type system. *)

