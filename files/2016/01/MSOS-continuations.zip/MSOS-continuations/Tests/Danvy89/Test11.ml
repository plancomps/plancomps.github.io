let hd = function x :: _  -> x  ;;
let tl = function _ :: xs -> xs ;;

let append x = let rec aux x = if x = []
                                then shift (function k -> k)
                                else hd x :: aux (tl x)
                    in reset (aux x) ;;

append [1 ; 2] [ 3 ; 4 ; 5] ;;
(* [1;2;3;4;5] *)

(* Does not type check in our type system. *)

