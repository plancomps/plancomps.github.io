let hd = function x :: _  -> x  ;;
let tl = function _ :: xs -> xs ;;

let bar l = let rec baz l = if l = []
                             then []
                             else shift (function c -> hd l :: c (hd l :: (c (hd l :: baz (tl l)))))
             in reset (baz l) ;;

bar [1;2;3] ;;
(* [3;2;1;1;1;2;1;1;1;2;3;2;1;1;1;2;1;1;1;2;3] *)
