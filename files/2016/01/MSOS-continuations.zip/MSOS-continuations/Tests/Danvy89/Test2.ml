let hd = function x :: _  -> x  ;;
let tl = function _ :: xs -> xs ;;

let reverse l = let rec reverse_s l = if l = []
                                       then []
                                       else shift (function c -> hd l :: c (reverse_s (tl l)))
                 in reset (reverse_s l) ;;

reverse [1; 2; 3] ;;
(* [3; 2; 1] *)
