let fix1 = reset (let x = shift (function c -> c c)
                   in function g -> g (function a -> x x g a)) ;;

let fact f = function
               | 1 -> 1
               | n -> n * f (n - 1) ;;

let factorial = fix1 fact ;;

factorial 3 ;;
(* 6 *)

(* Does not type check in our type system. *)
