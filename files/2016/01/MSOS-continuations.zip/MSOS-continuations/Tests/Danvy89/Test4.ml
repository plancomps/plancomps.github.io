reset (1 + shift (function c -> c 0)) ;;
(* 1 *)
