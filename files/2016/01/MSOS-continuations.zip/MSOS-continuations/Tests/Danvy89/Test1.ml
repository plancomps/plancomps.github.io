5 + reset (3 + shift (function c -> c 0 + c 1)) ;;
(* 12 *)
