reset (1 + shift (function c -> c (c 0))) ;;
(* 2 *)
