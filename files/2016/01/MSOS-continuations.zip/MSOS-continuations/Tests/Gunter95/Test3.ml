type tree = Null | Cell of int | Pair of tree * tree ;;

type answer = None | Some of int ;;


let resume = ref (function (x : answer) -> x) ;;

let suspend v = control (function k -> (resume := k) ; v) ;;

let rec walk = function Null         -> None
                      | Cell i       -> suspend (Some i)
                      | Pair (t1,t2) -> (walk t1 ; walk t2)
               ;;


let get_first t = prompt (walk t) ;;

let get_next () = prompt (!resume None) ;;


let tree = Pair (Pair (Cell 1, Null), Pair (Cell 2, Cell 3)) ;;

get_next () ;;
(* None *)

get_first tree ;;
(* Some 1 *)

get_next () ;;
(* Some 2 *)

get_next () ;;
(* Some 3 *)

get_next () ;;
(* None *)
