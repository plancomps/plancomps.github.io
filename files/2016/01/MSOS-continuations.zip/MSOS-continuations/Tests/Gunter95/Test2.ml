let c = prompt (callcc (function k -> function x ->
                        k (function y -> x + 4))) ;;

let g = prompt (function () -> 5 > c 2) ;;

let h = prompt (g ()) ;;

prompt (h 77) ;;
(* 6 *)

(* Does not type check in our type system. *)
