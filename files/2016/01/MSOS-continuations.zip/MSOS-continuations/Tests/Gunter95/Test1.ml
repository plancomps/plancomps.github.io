let size = function _ -> 7 ;;

let s = "a" ;;

prompt (5 > (1 + callcc (function k -> if s = "a"
                                        then k 2
                                        else size s))) ;;
(* true *)
