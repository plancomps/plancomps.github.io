prompt( print `A` ; control(function k -> (k () ; k ())) ; print `B` ) ;;
(* ABB
   ()
*)
