1 + prompt(2 * control(function k -> k 7)) ;;
(* 15 *)

1 + prompt(2 * control(function k -> k(k 7))) ;;
(* 29 *)

1 + prompt(2 * control(function k -> 7)) ;;
(* 8 *)

