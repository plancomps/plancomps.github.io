let outermost_return = ref (function x -> x) ;;

prompt (callcc (function k -> outermost_return := k)) ;;
(* () *)

prompt (!outermost_return 1) ;;
(* 1 *)

prompt [ 1 ; (!outermost_return 2) ; 3 ] ;;
(* 2 *)

prompt (let rec useless = function n -> if n = 0
                                         then !outermost_return "What, me worry?"
                                         else "worry" :: useless (n - 1)
         in useless 5
       ) ;;
(* "What, me worry?" *)

(* Does not type check in our type system. *)


