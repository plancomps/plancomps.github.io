(* Example originally created by Eugene Kohlbecker. *)
let mondo_bizarro = function () ->
  let k = callcc (function c -> c)
  in print 1 ;
     callcc k ;
     print 2 ;
     callcc k ;
     print 3
;;

prompt (mondo_bizarro ()) ;;
(* [1;1;2;1;3] *)

(* Does not type check in our type system. *)

