let null = function [] -> true
                  | _  -> false ;;

let zero = function n -> n = 0.0 ;;

let car = function hd :: _  -> hd ;;
let cdr = function _  :: tl -> tl ;;


let parallel_resistance resistances =
      callcc (function return -> let rec sum_of_reciprocals l = if null l
                                                                 then 0.0
                                                                 else if zero (car l)
                                                                       then return 0.0
                                                                       else (1.0 /. car l) +. sum_of_reciprocals (cdr l)
                                  in 1.0 /. sum_of_reciprocals resistances
             ) ;;


prompt (parallel_resistance [4.0 ; 6.0 ; 12.0]) ;;
(* 2.0 *)

