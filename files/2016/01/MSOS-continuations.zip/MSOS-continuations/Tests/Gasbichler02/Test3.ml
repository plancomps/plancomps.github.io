1 + reset (2 * shift (function k -> k 4)) ;;
(* 9 *)