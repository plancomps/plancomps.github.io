1 + reset (2 * shift (function k -> k (k 4))) ;;
(* 17 *)