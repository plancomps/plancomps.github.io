1 + reset 3 ;;
(* 4 *)