1 + reset (2 * shift (function k -> 4)) ;;
(* 5 *)