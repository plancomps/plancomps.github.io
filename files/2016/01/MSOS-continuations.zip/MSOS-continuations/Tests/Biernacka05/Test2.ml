let find_all_prefixes (p, xs) =
	   let rec visit = function
	                     | []      -> shift (function k -> [])
	                     | x :: xs -> x :: if p x
	                                         then shift (function k1 -> (reset (k1 [])) :: reset (k1 (visit xs)))
	                                         else visit xs
	    in reset (visit xs) ;;

let isB = function c -> `B` = c ;;

let abb = [`A` ; `B` ; `B`] ;;

find_all_prefixes (isB, abb) ;;
(* [ [ `A` ; `B` ] ; [ `A` ; `B` ; `B` ] ] *)

(* Does not type check in our type system. *)
