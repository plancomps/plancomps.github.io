let foo xs = let rec visit = function
                               | []      -> []
                               | x :: xs -> visit (shift (function k -> x :: k xs))
              in reset (visit xs) ;;

foo [1;2;3] ;;
(* [1;2;3] *)

