let foo xs = let rec visit = function
                               | []      -> []
                               | x :: xs -> visit (control (function k -> x :: k xs))
              in prompt (visit xs) ;;

foo [1;2;3] ;;
(* [3;2;1] *)

