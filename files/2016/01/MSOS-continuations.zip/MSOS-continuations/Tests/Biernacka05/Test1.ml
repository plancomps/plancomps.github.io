let find_first_prefix (p, xs) =
	   let rec visit = function
	                     | []      -> shift (function k -> [])
	                     | x :: xs -> x :: (if p x then [] else visit xs)
	    in reset (visit xs) ;;

let isB = function c -> `B` = c ;;

let abb = [`A` ; `B` ; `B`] ;;

find_first_prefix (isB, abb) ;;
(* [ `A` ; `B` ] *)
