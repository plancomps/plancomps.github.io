type tree = EMPTY | NODE of tree * int * tree ;;

let traverse_cp t = let rec visit = function (EMPTY, a)            -> a
                                           | (NODE (t1, i, t2), a) -> visit (t1, visit (t2, control (function k -> i :: k a)))
                     in prompt (visit (t, [])) ;;
(* Post-order, left-to-right *)

let tree1 = NODE (NODE (EMPTY, 1, EMPTY), 2, NODE (EMPTY, 3, EMPTY)) ;;

traverse_cp tree1 ;;
(* [ 1; 3; 2 ] *)

