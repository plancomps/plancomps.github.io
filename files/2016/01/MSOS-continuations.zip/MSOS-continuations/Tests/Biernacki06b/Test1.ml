type tree = EMPTY | NODE of tree * int * tree ;;

let traverse_sr t = let rec visit = function (EMPTY, a)            -> a
                                           | (NODE (t1, i, t2), a) -> visit (t1, visit (t2, shift (function k -> i :: k a)))
                     in reset (visit (t, [])) ;;
(* Pre-order, right-to-left *)

let tree1 = NODE (NODE (EMPTY, 1, EMPTY), 2, NODE (EMPTY, 3, EMPTY)) ;;

traverse_sr tree1 ;;
(* [ 2; 3; 1 ] *)

