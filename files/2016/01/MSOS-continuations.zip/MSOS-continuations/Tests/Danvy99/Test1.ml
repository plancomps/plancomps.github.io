1 + reset (50 + shift (function k -> (k 0) + (k 10))) ;;
(* 111 *)

