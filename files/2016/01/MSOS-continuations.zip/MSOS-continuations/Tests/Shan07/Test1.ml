let safediv x y c0 = if y = 0 then c0 x else (x / y) ;;

prompt (callcc (function c0 -> not (safediv 5 3 c0 > 4))) ;;
(* true *)

prompt (callcc (function c0 -> not (safediv 5 0 c0 > 4))) ;;
(* 5 *)

(* Does not type check in our type system. *)

