prompt (prompt (`a` :: reset (let y = control (function f -> control (function g -> `b` :: f [] ))
                               in control (function h -> y)
                           ))) ;;
(* [ `a` ] *)
