reset (reset (`a` :: reset (let y = shift (function f -> shift (function g -> `b` :: f [] ))
                             in shift (function h -> y)
                         ))) ;;
(* [ `a` ; `b` ] *)
