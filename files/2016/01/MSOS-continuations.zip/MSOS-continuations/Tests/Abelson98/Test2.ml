let v = [| 54; 0; 37; -3; 245; 19 |] ;;

prompt (callcc (function exit -> for i = 0 to vect_length v
                                  do
                                     let x = v.(i)
                                      in if x < 0 then exit x else ()
                                  done ;
                                  0)
       ) ;;
(* -3 *)

