let get () = shift (function k -> function i -> k i i) ;;

let set i = shift (function k -> function _ -> k () i) ;;

let with_int_state (i, t) = (reset (let result = t () in function _ -> result)) i ;;

with_int_state (1, function () ->     let x1 = get ()
                                   in let () = set 10
                                   in let x2 = get ()
                                   in let () = set 100
                                       in [ x1; x2; get () ]
               ) ;;
(* [1,10,100] *)

