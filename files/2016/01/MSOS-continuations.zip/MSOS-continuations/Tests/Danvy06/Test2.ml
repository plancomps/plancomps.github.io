type mobile = OBJ of int
            | BAR of int * mobile * mobile
     ;;


let c f = callcc (function k -> abort (f k)) ;;
(* Does not type check. *)

let bal4 m = c (function k -> let rec visit = function OBJ n           -> n
                                                     | BAR (n, m1, m2) -> let n1 = visit m1
                                                                          and n2 = visit m2
                                                                           in if n1 = n2
                                                                               then n + n1 + n2
                                                                               else k false
                               in let _ = visit m
                                   in k true
               ) ;;

let m0 = OBJ 3 ;;

let m1 = BAR (2, m0, m0) ;;

let m2 = BAR (1, OBJ 4, m1) ;;

prompt (bal4 m0) ;;
(* true *)

prompt (bal4 m1) ;;
(* true *)

prompt (bal4 m2) ;;
(* false *)

(* Does not type check in our type system. *)
