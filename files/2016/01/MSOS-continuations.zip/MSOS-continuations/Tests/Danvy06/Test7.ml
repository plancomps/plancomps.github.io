type tree = LEAF of int
          | NODE of tree * int * tree
          ;;

let label_infix2 t (* label_infix2 : tree -> tree *)
                   = let
                         inc () = shift (function k -> function i -> k i (i+1))
                      in
                         let rec visit = function LEAF _           -> LEAF (inc ())
                                                | NODE (t1, _, t2) -> NODE (visit t1, inc (), visit t2)
                          in
                             (reset (let tr = visit t in function _ -> tr)) 1
                   ;;


let tree1 = NODE (LEAF 0, 0, NODE (LEAF 0, 0, LEAF 0)) ;;

label_infix2 tree1 ;;
(* NODE (LEAF 5, 4, NODE (LEAF 3, 2, LEAF 1)) *)
(* Note: The reason this ordering is backwards is that our translation of Caml Light evaluates products from right-to-left. *)

