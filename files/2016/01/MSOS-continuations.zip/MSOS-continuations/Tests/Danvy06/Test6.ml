type ide == char ;;  

type expression = IDE of ide
                | ADD of expression * expression
                | MUL of expression * expression
                ;;

type product = IDE_PROD of ide
             | MUL_PROD of product * product
             ;;

type sum_of_products = PROD of product
                     | ADD_PROD of sum_of_products * sum_of_products
                     ;;

(* distribute_ds : expression -> sum_of_products *)
let distribute_ds e = let rec (* visit : expression -> product *)
                              visit = function IDE x        -> IDE_PROD x
                                             | ADD (e1, e2) -> shift (function k -> ADD_PROD ( reset (k (visit e1)),
                                                                                               reset (k (visit e2))
                                                                                             )
                                                                     )
                                             | MUL (e1, e2) -> MUL_PROD (visit e1, visit e2)
                       in reset (PROD (visit e))
                      ;;


let expr1 = MUL (ADD (IDE `a`, IDE `b`), MUL (IDE `c`, IDE `d`)) ;;

distribute_ds expr1 ;;
(*
   ADD_PROD (PROD (MUL_PROD (IDE_PROD `a`, MUL_PROD (IDE_PROD `c`, IDE_PROD `d`))),
             PROD (MUL_PROD (IDE_PROD `b`, MUL_PROD (IDE_PROD `c`, IDE_PROD `d`))))
*)

