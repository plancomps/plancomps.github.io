1 + reset (10 + shift (function k -> k 100 + 1000)) ;;
(* 1111 *)
