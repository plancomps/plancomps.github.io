1 + reset (10 + shift (function k -> k (k (k 100)) + 1000)) ;;
(* 1131 *)

