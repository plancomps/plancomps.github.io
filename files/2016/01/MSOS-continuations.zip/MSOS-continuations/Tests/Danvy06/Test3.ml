type mobile = OBJ of int
            | BAR of int * mobile * mobile
     ;;


let bal6 m = let rec visit = function OBJ n           -> n
                                    | BAR (n, m1, m2) -> let n1 = visit m1
                                                         and n2 = visit m2
                                                          in if n1 = n2
                                                              then n + n1 + n2
                                                              else abort false
              in reset (let _ = visit m
                         in true)
               ;;


let m0 = OBJ 3 ;;

let m1 = BAR (2, m0, m0) ;;

let m2 = BAR (1, OBJ 4, m1) ;;

bal6 m0 ;;
(* true *)

bal6 m1 ;;
(* true *)

bal6 m2 ;;
(* false *)
