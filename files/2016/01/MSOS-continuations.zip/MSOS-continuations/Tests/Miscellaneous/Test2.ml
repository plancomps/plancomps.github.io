(* Taken from:
   http://community.schemewiki.org/?call-with-current-continuation
*)

let return = ref false ;;

prompt (1 + callcc (function cont -> return := cont ; 1)) ;;
(* 2 *)

prompt (!return 22) ;;
(* 23 *)

(* Does not type check in our type system. *)

