(* Taken from:
   http://en.wikipedia.org/wiki/Delimited_continuation
*)

let yield x = shift (function k -> x :: k ()) ;;

reset (begin
         yield 1 ;
         yield 2 ;
         yield 3 ;
         []
       end) ;;
(* [ 1 ; 2 ; 3 ] *)

