(* Taken from a suggestion by an anonymous reviewer. *)

prompt (print "A" ;
        print (control (function k -> k "B" ; k "C")) ;
        print "D"
       ) ;;
(* "A" "B" "D" "C" "D" () *)

