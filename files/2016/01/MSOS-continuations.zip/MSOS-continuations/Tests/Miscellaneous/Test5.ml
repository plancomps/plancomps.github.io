(* Taken from a suggestion by an anonymous reviewer. *)

prompt (print "A" ;
        prompt (print "B" ;
                print (control (function k -> k "C1" ; k "C2")) ;
                print "D"
               ) ;
        print "E"
       ) ;;
(* "A" "B" "C1" "D" "C2" "D" "E" () *)

