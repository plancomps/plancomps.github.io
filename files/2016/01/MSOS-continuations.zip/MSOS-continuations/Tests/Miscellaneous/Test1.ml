(* Taken from:
   http://community.schemewiki.org/?call-with-current-continuation
   Due to performance limitations of our interpreter, we omit the loops from the original example.
*)

let rec foreach p = function []      -> ()
                           | x :: xs -> p x ; foreach p xs
;;

let hefty_computation = function do_stuff ->
   let do_other_stuff = ref do_stuff
    in print "Hefty computation (a)" ;
       do_other_stuff := callcc (!do_other_stuff) ;
       print "Hefty computation (b)" ;
       do_other_stuff := callcc (!do_other_stuff) ;
       print "Hefty computation (c)"
;;

let superfluous_computation = function do_stuff ->
   let do_other_stuff = ref do_stuff
    in foreach (function graphic -> print graphic ;
                                    do_other_stuff := callcc (!do_other_stuff) )
               [ "Straight up."; "Quarter after."; "Half past."; "Quarter til;" ]
;;
  
prompt (hefty_computation superfluous_computation) ;;
(* "Hefty computation (a)" "Straight up." "Hefty computation (b)" "Quarter after." "Hefty computation (c)" () *)

(* Does not type check in our type system. *)
