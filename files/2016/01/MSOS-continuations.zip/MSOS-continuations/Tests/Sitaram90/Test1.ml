1 + prompt (1 + control (function k -> 0)) ;;
(* 1 *)
