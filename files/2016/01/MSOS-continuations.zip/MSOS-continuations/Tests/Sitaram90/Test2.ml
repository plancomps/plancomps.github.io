let g = prompt (2 * control (function k -> k))
 in 3 * prompt (5 * abort (g 7))
;;
(* 42 *)

(* Does not type check in our type system. *)

