prompt ("Goldilocks said: " ^ prompt ("This porridge is " ^ "too hot" ^ ".")) ;;
(* Goldilocks said: This porridge is too hot. *)

