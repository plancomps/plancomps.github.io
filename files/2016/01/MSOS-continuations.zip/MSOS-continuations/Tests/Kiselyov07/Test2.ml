prompt ("Goldilocks said: " ^ prompt ("This porridge is " ^ (shift (function k -> (k "too hot") ^ (k "too cold") ^ (k "just right"))) ^ ". ")) ;;
(* Goldilocks said: This porridge is too hot. This porridge is too cold. This porridge is just right. *)

