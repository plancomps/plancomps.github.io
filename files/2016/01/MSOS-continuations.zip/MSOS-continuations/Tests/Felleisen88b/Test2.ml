prompt ( (prompt ( (control (function f -> f))
                   (control (function g -> g (g 0))) ))
         (function x -> 1 + x)
       ) ;;
(* 2 *)

(* Does not type check in our type system. *)
