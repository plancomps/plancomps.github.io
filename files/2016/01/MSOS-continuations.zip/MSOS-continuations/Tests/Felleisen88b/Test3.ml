prompt ( (function x -> control (function d -> x))
         (control (function l -> 1 + l 0))
       ) ;;
(* 0 *)

