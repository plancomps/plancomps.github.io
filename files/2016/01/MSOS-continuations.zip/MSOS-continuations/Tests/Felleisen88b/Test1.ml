prompt (1 + control (function f -> f (f 0))) ;;
(* 2 *)

