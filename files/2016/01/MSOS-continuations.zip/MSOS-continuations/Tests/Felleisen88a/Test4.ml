let pi1 = function l ->
            callcc (function k -> 
                      let rec iterate = function | []      -> 1
                                                 | x :: xs -> if x = 0
                                                               then k 0
                                                               else x * iterate xs
                       in iterate l)
;;

prompt (pi1 [ 1 ; 0 ; 7 ]) ;;
(* 0 *)
