let pi2 = function l ->
            prompt (let rec iterate = function | []      -> 1
                                               | x :: xs -> if x = 0
                                                             then control (function d -> 0)
                                                             else x * iterate xs
                     in iterate l)
;;

pi2 [ 1 ; 0 ; 7 ] ;;
(* 0 *)