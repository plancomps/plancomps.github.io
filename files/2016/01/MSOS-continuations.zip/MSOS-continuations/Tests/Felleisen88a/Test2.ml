prompt (1 + control (function k -> k (k 0))) ;;
(* 2 *)
