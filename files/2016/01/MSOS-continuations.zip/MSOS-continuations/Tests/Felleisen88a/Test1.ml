prompt (1 + control (function d -> 0)) ;;
(* 0 *)
