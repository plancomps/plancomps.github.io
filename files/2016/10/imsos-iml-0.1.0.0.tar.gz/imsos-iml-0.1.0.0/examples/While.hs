
import Prelude hiding (seq, print)

import IML.Grammar.Shared
import IML.Grammar (Program(..),AProgram(..))
import IML.Grammar.RuleFormat
import IML.Trans.ToLower (tSpec)
import IML.Trans.Chain2 
import IML.Interpreter.Values
import IML.Interpreter.Tools

main = printFiles ["--debug"] "examples/while.iml" 1 (chain whileProgram)

whileProgram = Program (tSpec whileSpec) 
  [Query Rep "=>" (plus_ (int_ 2, plus_ (int_ 3, int_ 4)))
  ,Query Rep "=>" (leq_ (int_ 3, int_ 3))
  ,Query Rep "=>" (leq_ (plus_ (int_ 2, int_ 2),int_ 3))
  ,Query Rep "=>" (iden_ (id_ "x"))
  ,Query Rep "->" (seq_ (assign_ (id_ "x", plus_(int_ 1, int_ 2))
                  ,print_ (iden_ (id_ "x"))))
  ,Query Rep "->" (seq_ (assign_ (id_ "x", int_ 0)
                        ,while_ (leq_ (iden_ (id_ "x"),int_ 10)
                                ,seq_ (assign_ (id_ "x", plus_(iden_(id_ "x"),int_ 1))
                                      ,print_ (iden_ (id_ "x"))
                                      )
                                )
                        )
                  )
  ]

plus_ (x,y) = TCons False "plus" [x,y]
leq_ (x,y)  = TCons False "leq" [x,y]
iden_ (x)   = TCons False "iden" [x]
assign_ (x,y)  = TCons False "assign" [x,y]
seq_ (x,y)  = TCons False "seq" [x,y]
print_ x    = TCons False "print" [x]
while_ (x,y)= TCons False "while" [x,y]

whileSpec = 
  [ Left env
  , Left store
  , Left out
  , Right whilett
  , Right whileff
  , Right assign
  , Right seq
  , Right seq_nil
  , Right print
  , Right iden
  , Right plus
  , Right leqtt
  , Right leqff
  ]

env = RODecl "env" (VOP "map-empty" [])
store = RWDecl "store" (VOP "map-empty" [])
out = WODecl "out" "list-append" "nil"

{- ONE CURRENTLY IN PAPER
print = Rule con prems ss
  where con = Conclusion "print" [PVar "E"] "->" (tuple_ []) [] [] 
                  [("out", VOP "list" [Term (TVar "V")])]
        prems = [Prem (TVar "E") (mRel "=>") (PVar "V") [] [] []]
        ss    = []
-}
print = Rule con prems ss
  where con = Conclusion "print" [PVar "E"] "->" (tuple_ []) 
                  [] [("store", PVar "Sig", Val (TVar "Sig"))] 
                  [("out", VOP "list" [Val (TVar "V")])]
        prems = [Prem (TVar "E") (mRel "=>") (PVar "V") [("env", Val (TVar "Sig"))] [] []]
        ss    = []

whileff = Rule con prems ss
  where con = Conclusion "while" [PVar "E",PVar "C"] "->" (tuple_ []) 
                  [] [("store", PVar "Sig", Val (TVar "Sig"))] []
        prems = [Prem (TVar "E") (mRel "=>") (PCons "false" []) 
                  [("env", Val (TVar "Sig"))] [] []]
        ss    = []

whilett = Rule con prems ss
  where con = Conclusion "while" [PVar "E",PVar "C"] "->" (TVar "C'") 
                  [] [("store", PVar "Sig", Val (TVar "Sig'"))] []
        prems = [Prem (TVar "E") (mRel "=>") (PCons "true" []) 
                  [("env", Val (TVar "Sig"))] [] []
                ,Prem (seq_ (TVar "C",while_ (TVar "E",TVar "C"))) (sRel "->") (PVar "C'")
                  [] [("store", Val (TVar "Sig"), PVar "Sig'")] []
                ]
        ss    = []


seq = Rule con prems ss
  where con = Conclusion "seq" [PVar "C1",PVar "C2"] "->" (seq_ (TVar "C1'", TVar "C2"))
                  [] [] []
        prems = [Prem (TVar "C1") (sRel "->") (PVar "C1'") [] [] []]
        ss    = []

seq_nil = Rule con prems ss
  where con = Conclusion "seq" [PCons "tuple" [],PVar "C2"] "->" (TVar "C2") [] [] []
        prems = []
        ss    = []

assign = Rule con prems ss
  where con = Conclusion "assign" [PVar "R",PVar "E"] "->" (tuple_ []) 
                  [] [("store", PVar "Sig", Val (TVar "Sig'"))] []
        prems = [Prem (TVar "E") (mRel "=>") (PVar "V") [("env", Val (TVar "Sig"))] [] []]
        ss    = [SideOP (VOP "map-insert" [Val (TVar "R"),Val (TVar "V"),Val (TVar "Sig")])
                                          (PVar "Sig'")
                ]

iden = Rule con prems ss
  where con = Conclusion "iden" [PVar "R"] "=>" (TVar "R1") [("env", (PVar "Sig"))] [] []
        prems = []
        ss    = [SideOP (VOP "map-lookup" [Val (TVar "R"), Val (TVar "Sig")]) (PVar "R1")
                ]

plus = Rule con prems ss
  where con = Conclusion "plus" [PVar "E1", PVar "E2"] "=>" (TVar "R") [] [] []
        prems = [Prem (TVar "E1") (mRel "=>") (PVar "I1") [] [] []
                ,Prem (TVar "E2") (mRel "=>") (PVar "I2") [] [] []
                ]
        ss    = [SideOP (VOP "is-int" [Val (TVar "I1")]) (PCons "true" [])
                ,SideOP (VOP "is-int" [Val (TVar "I2")]) (PCons "true" [])
                ,SideOP (VOP "int-add" [Val (TVar "I1"), Val (TVar "I2")]) (PVar "R")
                ]

leqtt = Rule con prems ss
  where con = Conclusion "leq" [PVar "E1", PVar "E2"] "=>" true_ [] [] []
        prems = [Prem (TVar "E1") (mRel "=>") (PVar "I1") [] [] []
                ,Prem (TVar "E2") (mRel "=>") (PVar "I2") [] [] []
                ]
        ss    = [SideOP (VOP "is-int" [Val (TVar "I1")]) (PCons "true" [])
                ,SideOP (VOP "is-int" [Val (TVar "I2")]) (PCons "true" [])
                ,SideOP (VOP "is-leq" [Val (TVar "I1"), Val (TVar "I2")]) (PCons "true" [])
                ]

leqff = Rule con prems ss
  where con = Conclusion "leq" [PVar "E1", PVar "E2"] "=>" false_ [] [] []
        prems = [Prem (TVar "E1") (mRel "=>") (PVar "I1") [] [] []
                ,Prem (TVar "E2") (mRel "=>") (PVar "I2") [] [] []
                ]
        ss    = [SideOP (VOP "is-int" [Val (TVar "I1")]) (PCons "true" [])
                ,SideOP (VOP "is-int" [Val (TVar "I2")]) (PCons "true" [])
                ,SideOP (VOP "is-leq" [Val (TVar "I1"), Val (TVar "I2")]) (PCons "false" [])
                ]

