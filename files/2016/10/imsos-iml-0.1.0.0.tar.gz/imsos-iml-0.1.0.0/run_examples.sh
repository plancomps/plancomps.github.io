#!/bin/bash

run_test() {
  $(dist/build/runiml/runiml $1);
}
export -f run_test
find examples -name "*.iml" | xargs -n1 -I{} bash -c 'run_test "$@"' _ {} 
