{-# LANGUAGE FlexibleInstances #-}

module IML.Trans.Sanitiser where

import Control.Monad.Writer

type San a = Writer ([String]   --warnings
                    ,[String])  --errors
                    a

warn :: a -> String -> San a
warn a str = writer (a, ([str],[]))

err :: String -> San a 
err str = writer (error str,([],[str]))

runSan :: San a -> (a, [String], [String])
runSan m = (a,ws,es)
  where (a,(ws,es)) = runWriter m
