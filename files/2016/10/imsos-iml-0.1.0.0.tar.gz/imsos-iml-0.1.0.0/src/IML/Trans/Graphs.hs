
module IML.Trans.Graphs (
  Graph (..), empty, initialise, 
  succs, preds, entries, 
  insert, inserts,
  deleteWithEntries,
  ) where

import qualified Data.Map as M
import qualified Data.Set as S

type Graph n  = ( M.Map n (S.Set n)  -- successor
                , M.Map n (S.Set n)  -- predecessors
                )

-- | An empty graph
empty :: Graph n
empty = (M.empty, M.empty)

initialise :: (Ord n) => [n] -> Graph n
initialise ns = (M.fromList empts, M.fromList empts)
  where empts = [ (n, S.empty) | n <- ns ]

-- | Get the successor of a node in a given graph
succs :: (Ord n) => n -> Graph n -> [n]
succs  n gr = maybe [] S.toList $ M.lookup n (fst gr)

(!>) :: (Ord n) => Graph n -> n -> [n]
(!>) = flip succs

-- | Get the predecessors of a node in a given graph
preds :: (Ord n) => n -> Graph n -> [n]
preds n gr = maybe [] S.toList $ M.lookup n (snd gr)

(<!) :: (Ord n) => Graph n -> n -> [n]
(<!) = flip preds

-- | Create an edge between two nodes in a given graph,
-- keeping the graph closed under transitivity
insert :: (Ord n) => n -> n -> Graph n -> Graph n
insert n1 n2 gr = edges ((n1,n2):pairs) gr
  where   pairs = [ (f,t) | f <- preds n1 gr, t <- succs n2 gr ]

-- | Create an edge between all given pairs of nodes,
-- keeping the graph closed under transitivity
inserts :: (Ord n) => [(n,n)] -> Graph n -> Graph n
inserts es gr = foldr (uncurry insert) gr es 

-- | Create an edge between two nodes, disregarding transitivity
edge :: (Ord n) => n -> n -> Graph n -> Graph n
edge n1 n2 (fwd,bwd) =  (M.insertWith S.union n1 (S.singleton n2) fwd
                        ,M.insertWith S.union n2 (S.singleton n1) bwd)

-- | Create an edge between all pairs of nodes, disregarding transitivity
edges :: (Ord n) => [(n,n)] -> Graph n -> Graph n
edges ps gr = foldr (uncurry edge) gr ps

-- | Get the entry points of the graph
entries :: Graph n -> [n]
entries (_,bwd) = M.foldrWithKey sel [] bwd
  where sel k ns acc  | null ns     = k:acc
                      | otherwise   = acc

-- | Deletes a node from the graph,
-- returning the new graph and all nodes that became an entry point by the deletion
deleteWithEntries :: (Ord n) => n -> Graph n -> (Graph n, [n])
deleteWithEntries f gr@(fwd, bwd) = (gr', newEntries)
  where   fwd'        = M.map (S.delete f) (M.delete f fwd)
          bwd'        = M.map (S.delete f) (M.delete f bwd)
          gr'         = (fwd', bwd')
          newEntries  = filter pred (succs f gr)
            where pred t = null (preds t gr') 
    
