
module IML.Trans.ToLower where

import IML.Grammar.Shared
import IML.Grammar.RuleFormat
import IML.Grammar.Grammar
import IML.Trans.Fresh

import Control.Monad (liftM2)

import Data.List (partition)

infixr 5 <++>
(<++>) :: Fresh Stmts -> Fresh Stmts -> Fresh Stmts
(<++>) = liftM2 (++)

infixr 5 <++
(<++) :: Fresh Stmts -> Stmts -> Fresh Stmts 
p <++ as = p <++> return as

infixr 5 ++>
(++>) :: Stmts -> Fresh Stmts -> Fresh Stmts
as ++> q = return as <++> q

tSpec :: IML.Grammar.RuleFormat.Spec -> IML.Grammar.Grammar.Spec 
tSpec = mergeBy eq merge . map tEither
  where tEither (Left d)  = Left d
        tEither (Right d) = Right (tRule d)
        
        eq (Right (Trans r1 f1 _)) (Right (Trans r2 f2 _)) = r1 == r2 && f1 == f2
        eq _ _ = False
        merge (Right (Trans r f b1)) (Right (Trans _ _ b2)) = 
            Right $ Trans r f (b1 ++ b2)

tRule :: Rule -> TransDecl
tRule rule@(Rule cl@(Conclusion f _ r _ _ _ _) _ _) = 
  Trans r f [body]
  where body = evalFresh (gBody rule)

mergeBy :: (a -> a -> Bool) -> (a -> a -> a) -> [a] -> [a]
mergeBy eq merge []      = []
mergeBy eq merge (x:xs)  = foldl merge x ys : mergeBy eq merge zs
  where (ys,zs) = partition (eq x) xs 

gBody :: Rule -> Fresh Stmts
gBody (Rule (Conclusion _ pats _ rhs ro rw wo) prems ss) = 
  gROgets ro <++>
  [PM_Args pats] ++>
  gRWgets 0 rw <++>
  gPremises prems <++>
  gSideConds ss <++
  gRWsets_ 0 rw ++
  gWOsets wo ++ 
  [Commit rhs]

gPremises :: [Premise] -> Fresh Stmts
gPremises = (concat <$>) . sequence . zipWith gPremise [1..]

gPremise :: Label -> Premise -> Fresh Stmts
gPremise l (Prem t rel p ro rw wo) = 
  gROsets l ro ++> 
  gRWsets l rw ++>
  gSingleOrMany l t rel p <++>
  gRWgets_ l rw <++>
  gWOgets l wo

gSingleOrMany :: Label -> Term -> Rel -> Pattern -> Fresh Stmts
gSingleOrMany l t (Rel r rep obser) p = case p of 
    PVar x  -> return ([prem r t x (Just l)] ++ sfx)
    _       -> do   x <- fresh_var 
                    return ([prem r t x (Just l), PM (Val (TVar x)) p] ++ sfx)
  where prem = case rep of NoRep -> Single
                           Rep   -> Many
        sfx | obser     = []
            | otherwise = [Unobserv l] 

gSideConds :: SideCons -> Fresh Stmts
gSideConds = (concat <$>) . mapM gSideCond
  where gSideCond (SideOP e p)  = case p of 
          PVar x  -> return [PM e (PVar x)]
          _       -> do   x <- fresh_var 
                          return [PM e (PVar x), PM  (Val (TVar x)) p]

-- ro set
gROsets :: Label -> [ROup] -> Stmts
gROsets = map . gROset

gROset :: Label -> ROup -> Stmt
gROset l (eid, e) = RO_Set eid e l

-- ro get
gROgets :: [ROacc] -> Fresh Stmts
gROgets ro = concat <$> mapM gROget ro

gROget :: ROacc -> Fresh Stmts
gROget (eid, (PVar x)) = return [RO_Get eid x]
gROget (eid, p) = do
  x0 <- fresh_var
  return [RO_Get eid x0, PM (Val (TVar x0)) p]

-- wo set
gWOsets :: [WOup] -> Stmts
gWOsets = map gWOset

gWOset :: WOup -> Stmt
gWOset (eid, e) = WO_Set eid e

-- wo get
gWOgets :: Label -> [WOacc] -> Fresh Stmts
gWOgets l = (concat <$>) . mapM (gWOget l)

gWOget :: Label -> WOacc -> Fresh Stmts
gWOget l (eid, (PVar x)) = return [WO_Get eid x l]
gWOget l (eid, p) = do
  x <- fresh_var
  return [WO_Get eid x l, PM (Val (TVar x)) p]

-- rw set
gRWsets :: Label -> [RWup] -> Stmts
gRWsets l = map (gRWset l)

gRWset :: Label -> RWup -> Stmt
gRWset l (eid, e, _) = RW_Set eid e l

gRWsets_ :: Label -> [RWacc] -> Stmts
gRWsets_ l = map (gRWset_ l)

gRWset_ :: Label -> RWacc -> Stmt
gRWset_ l (eid, p, e) = gRWset l (eid, e, p)

-- rw get
gRWgets :: Label -> [RWacc] -> Fresh Stmts
gRWgets l = (concat <$>) . mapM (gRWget l)

gRWget :: Label -> RWacc -> Fresh Stmts
gRWget l (eid, (PVar x), _) = return [RW_Get eid x l]
gRWget l (eid, p, _) = do
  x <- fresh_var
  return [RW_Get eid x l, PM (Val (TVar x)) p] 

gRWgets_ :: Label -> [RWup] -> Fresh Stmts
gRWgets_ l = (concat <$>) . mapM (gRWget_ l)

gRWget_ :: Label -> RWup -> Fresh Stmts
gRWget_ l (eid, t, p) = gRWget l (eid, p, t)

