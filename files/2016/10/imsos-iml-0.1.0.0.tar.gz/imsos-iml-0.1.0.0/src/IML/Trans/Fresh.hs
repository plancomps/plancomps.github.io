
module IML.Trans.Fresh where

import IML.Grammar.Shared (MVar)
import Control.Monad.State

type Fresh a = State Int a  

fresh_var :: Fresh MVar
fresh_var = do 
  i <- get
  put (i+1)
  return ("_X" ++ show i)

evalFresh :: Fresh a -> a
evalFresh fa = evalState fa 0
