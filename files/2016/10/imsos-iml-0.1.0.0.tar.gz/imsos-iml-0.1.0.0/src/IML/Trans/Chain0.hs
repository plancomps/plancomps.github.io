
module IML.Trans.Chain0 where

import IML.Grammar

chain :: Program -> Program
chain = id
