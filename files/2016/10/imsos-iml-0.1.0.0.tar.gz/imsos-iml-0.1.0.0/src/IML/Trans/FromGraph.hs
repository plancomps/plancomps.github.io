
module IML.Trans.FromGraph where

import IML.Grammar
import IML.Trans.DepGraphs
import IML.Trans.Graphs

transify :: AProgram DepGraph -> Program
transify = fmap toTrans

toTrans :: DepGraph -> Stmts
toTrans (DepGraph gr end) = schedule gr ++ [continuation end]

continuation :: BranchEnd DepGraph -> Stmt
continuation (Cmt t)  = Commit t
continuation (Br grs) = Branches (map toTrans grs)

schedule :: Graph Stmt -> Stmts
schedule gr = schedule' gr (entries gr) []
  where schedule' gr []     uset = uset
        schedule' gr (e:es) uset = schedule' gr' (es++ents) uset' 
          where uset'       = uset ++ [e]
                (gr',ents)  = deleteWithEntries e gr

