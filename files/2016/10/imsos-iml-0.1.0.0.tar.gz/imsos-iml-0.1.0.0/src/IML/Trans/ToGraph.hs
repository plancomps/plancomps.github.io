{-# LANGUAGE FlexibleInstances #-}

module IML.Trans.ToGraph where

import IML.Grammar.Grammar
import IML.Grammar.Bindings
import IML.Trans.DepGraphs
import IML.Trans.Graphs
import IML.Trans.Sanitiser

import qualified Data.Set as S

graphify :: Program -> AProgram DepGraph
graphify = select . runSan . traverse (fmap toGraph . toBranch)
  where select (pr,[],[]) = pr
        select (pr,ws,[]) = error (unlines ("Warnings:" : ws))
        select (_,_,es)   = error (unlines ("Errors:" : es))

toBranch :: Stmts -> San Branch
toBranch [] = warn (Branch [] (Br [])) "empty branch"
toBranch ss = Branch (filter notF (init ss)) <$> end
  where end = case last ss of
                Commit t    -> return $ Cmt t
                Branches ss -> Br <$> mapM toBranch ss
                _           -> warn (Br []) "branch not terminated correctly"
        notF (Commit _)     = False
        notF (Branches _)   = False
        notF _              = True

toGraph :: Branch -> DepGraph
toGraph (Branch ss end) = DepGraph (inserts es (initialise ss)) (fmap toGraph end)
  where es = filter pred (allPairs ss)
          where pred args = or $ map (($ args) . uncurry) 
                              [binds_for, sets_for, from_gets, pre_unobs]

allPairs :: [a] -> [(a,a)]
allPairs []       = []
allPairs (x:xs)   = bothDirs ++ allPairs xs
  where bothDirs  = concat [ [(x,t),(t,x)] | t <- xs ]

instance Functor BranchEnd where
  fmap _ (Cmt t) = Cmt t
  fmap f (Br ss) = Br (fmap f ss)

-- | Decide whether the first statement binds a meta-variable
-- that is required by the second statement
binds_for :: Stmt -> Stmt -> Bool
binds_for f t = not $ S.null $ pvars f `S.intersection` tvars t

-- | Decide whether the first statement sets an entity value
-- required by the second statement
sets_for :: Stmt -> Stmt -> Bool
sets_for f t = case f of 
      RO_Set _ _ l  -> required l
      RW_Set _ _ l  -> required l
      _             -> False
    where required l1 = case t of
            Single _ _ _ (Just l2)  -> l1 == l2
            Many _ _ _ (Just l2)    -> l1 == l2
            _                       -> False

-- | Decide whether the first statements provide an entity value
-- that is obtained by the second statement (second is getter)
from_gets :: Stmt -> Stmt -> Bool
from_gets f t = case f of 
    Single _ _ _ (Just l) -> required l
    Many _ _ _ (Just l)   -> required l
    _                     -> False
  where required l1 = case t of
          RW_Get _ _ l2 -> l1 == l2
          WO_Get _ _ l2 -> l1 == l2
          _             -> False

-- | Decide whether the first statement should preceed the second
-- statement if the second statement is `unobs`
pre_unobs :: Stmt -> Stmt -> Bool
pre_unobs s (Unobserv l) = maybe False (==l) (sLabel s)
  where   sLabel :: Stmt -> Maybe Label
          sLabel (Single _ _ _ ml) = ml
          sLabel (Many _ _ _ ml) = ml
          sLabel (RW_Get _ _ l) = Just l
          sLabel (WO_Get _ _ l) = Just l
          sLabel _ = Nothing
pre_unobs _ _ = False  


