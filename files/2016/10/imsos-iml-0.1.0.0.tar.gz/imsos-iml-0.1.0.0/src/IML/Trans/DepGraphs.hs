{-# LANGUAGE StandaloneDeriving #-}

module IML.Trans.DepGraphs where

import IML.Grammar
import IML.Trans.Graphs

data Branch       =   Branch  [Stmt] {- no branches or commits -}
                              (BranchEnd Branch)

data BranchEnd b  =   Br  [b]
                  |   Cmt Term

data DepGraph     = DepGraph (Graph Stmt) (BranchEnd DepGraph) -- graph and sink 

deriving instance Ord Stmt 
deriving instance Eq Stmt
deriving instance Ord Expr
deriving instance Eq Expr
deriving instance Ord Pattern
deriving instance Eq Pattern
