
module IML.Trans.Chain1 where

import IML.Grammar
import IML.Trans.ToGraph
import IML.Trans.FromGraph

chain :: Program -> Program
chain = transify . graphify 
