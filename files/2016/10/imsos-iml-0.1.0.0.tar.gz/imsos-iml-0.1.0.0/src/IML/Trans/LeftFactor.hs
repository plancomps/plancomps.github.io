
module IML.Trans.LeftFactor where

import IML.Grammar
import IML.Grammar.Bindings

import IML.Trans.Graphs
import IML.Trans.DepGraphs
import IML.Trans.Fresh

lfactor :: AProgram DepGraph -> AProgram DepGraph
lfactor (Program spec qs) = Program spec' qs
  where spec' = map op spec
          where op (Left d) = Left d
                op (Right td) = Right $ case td of 
                  Trans r f dgs -> Trans r f (schedule dgs)

schedule :: [DepGraph] -> [DepGraph]
schedule [x,y]  = lock_step x y
schedule dgs    = dgs

lock_step :: DepGraph -> DepGraph -> [DepGraph]
lock_step x@(DepGraph gr1 end1) y@(DepGraph gr2 end2) = evalFresh $ do
  mres <- find_common (subsEmpty, subsEmpty) (entries gr1) (entries gr2)
  -- we must have some kind of start node, pointing t othe first selected stmt
  -- then we can make a recursive call, rather to wrap calls to find_common
  case mres of  
    Nothing -> return [x,y]
    Just ((the1,s1,ss1),(the2,s2,ss2)) -> 
      next_step (the1,the2) (gr1,s1,ss1,[],end1) (gr2,s2,ss2,[],end2)
  
 where  
  next_step :: SubsPair -> (Graph Stmt, Stmt, Stmts, Stmts, BranchEnd DepGraph) 
                        -> (Graph Stmt, Stmt, Stmts, Stmts, BranchEnd DepGraph) 
                        -> Fresh [DepGraph]
  next_step _ (gr1,_,_,_,end1) (gr2,_,_,_,end2) = 
    return [DepGraph gr1 end1, DepGraph gr2 end2]

find_common :: SubsPair -> Stmts -> Stmts -> Fresh (Maybe 
                  ((SubsEnv, Stmt, Stmts), (SubsEnv, Stmt, Stmts)))
find_common thep xall yall = try xall []
  where try [] _    = return Nothing
        try (x:xs) xsd = try2 x xsd yall []
          where try2 x xsd [] ysd = try xs (x:xsd)
                try2 x xsd (y:ys) ysd = do 
                  mres <- unify thep x y 
                  case mres of  Nothing -> try2 x xsd ys (y:ysd)
                                Just (the1,the2) ->  
                                  return (Just ((the1,x,xsd++xs),(the2,y,ysd++ys)))
