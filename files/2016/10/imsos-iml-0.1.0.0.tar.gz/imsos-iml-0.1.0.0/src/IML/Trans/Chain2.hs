
module IML.Trans.Chain2 where

import IML.Grammar
import IML.Trans.ToGraph
import IML.Trans.LeftFactor
import IML.Trans.FromGraph

chain :: Program -> Program
chain = transify . lfactor . graphify 
