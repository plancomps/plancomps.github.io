{-# LANGUAGE FlexibleInstances #-}

module IML.Grammar.Grammar where

import IML.Grammar.Shared

type Program    = AProgram Stmts 

data AProgram t = Program (ASpec t) Queries

type Spec       = ASpec Stmts
type ASpec t    = [Either EntDecl (ATransDecl t)]

type TransDecl  = ATransDecl Stmts
data ATransDecl t = Trans RSymb Cons [t] 

type Stmts      = [Stmt]
data Stmt       = Branches  [Stmts]
                | PM_Args   [Pattern]
                | PM        Expr    Pattern
                | Commit    Term
                | Single    RSymb   Term  MVar    (Maybe Label)
                | Many      RSymb   Term  MVar    (Maybe Label)
                | Unobserv  Label
                | RW_Get    EID     MVar          Label
                | RW_Set    EID     Expr          Label
                | RO_Get    EID     MVar          {- label = 0 -}
                | RO_Set    EID     Expr          Label {- > 0 -}
                | WO_Get    EID     MVar          Label {- > 0 -}
                | WO_Set    EID     Expr          {- label = 0 -}

type Label      = Int

instance Functor AProgram where
  fmap f (Program s q) = Program (map (fmap (fmap f)) s) q

instance Functor ATransDecl where
  fmap f (Trans r c sss) = Trans r c (map f sss)

instance Foldable AProgram where
  foldMap f (Program s q) = mconcat (map (foldMap (foldMap f)) s)

instance Foldable ATransDecl where
  foldMap f (Trans r c sss) = mconcat (map f sss)

instance Traversable AProgram where
  traverse f (Program s q) = Program <$> traverse (traverse (traverse f)) s <*> pure q

instance Traversable ATransDecl where
  sequenceA (Trans r c sss) = Trans r c <$> sequenceA sss
