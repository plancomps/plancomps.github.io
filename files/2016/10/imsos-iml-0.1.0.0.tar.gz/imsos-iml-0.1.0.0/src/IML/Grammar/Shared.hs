
module IML.Grammar.Shared where

type RSymb      = String
type Cons       = String
type MVar       = String
type EID        = String
type VOP        = String

type Queries    = [Query]
data Query      = Query Rep RSymb Term {- closed -}

data Rep        = NoRep | Rep

data EntDecl    = RODecl EID Expr 
                | RWDecl EID Expr
                | WODecl EID VOP VOP

type Exprs      = [Expr]
data Expr       = Val Term {- value -}
                | VOP VOP Exprs

data Term       = TVar MVar
                | TCons Bool {- value cons? -} Cons [Term]
                deriving (Eq, Ord)

data Pattern    = PVar MVar
                | PAny
                | PCons Cons  [Pattern]

isVal :: Term {- closed -} -> Bool
isVal (TCons b _ _) = b
isVal _ = error "isVal variable"

children :: Term {- closed-} -> [Term]
children (TVar _) = error "children variable"
children (TCons _ _ cs) = cs

