{-# LANGUAGE FlexibleInstances, StandaloneDeriving #-}

module IML.Grammar.Bindings where

import IML.Grammar
import IML.Trans.Fresh

import Data.Maybe (isJust, fromJust)
import qualified Data.Map as M
import qualified Data.Set as S

type SubsPair = (SubsEnv, SubsEnv) 
type UnificationRes = Fresh (Maybe (SubsEnv, SubsEnv))

type SubsEnv = M.Map MVar MVar

replaces :: SubsEnv -> MVar -> Bool
replaces = (maybe False (const True) .) . flip M.lookup 

replace :: SubsEnv -> MVar -> MVar
replace = (maybe (error "replace") id .) . flip M.lookup

mreplace :: SubsEnv -> MVar -> MVar
mreplace the x = maybe x id $ M.lookup x the

rep :: MVar -> MVar -> SubsEnv
rep = M.singleton

subsEmpty :: SubsEnv
subsEmpty = M.empty

subsUnion :: SubsEnv -> SubsEnv -> SubsEnv
subsUnion = M.unionWithKey op
  where op k = error ("meta-variable " ++ k ++ " occurs in multiple patterns")

subsPairsUnion :: [SubsPair] -> (SubsEnv, SubsEnv)
subsPairsUnion = foldr subsPairUnion (subsEmpty, subsEmpty)

subsPairUnion :: SubsPair -> SubsPair -> (SubsEnv, SubsEnv)
subsPairUnion (the1, the2) (the11, the22) = 
  (the1 `subsUnion` the11, the2 `subsUnion` the22)

un_success :: UnificationRes
un_success = return (return (subsEmpty,subsEmpty))

un_failure :: UnificationRes
un_failure = return Nothing

un_and :: UnificationRes -> UnificationRes -> UnificationRes
un_and m1 m2 = (\mres1 mres2 -> subsPairUnion <$> mres1 <*> mres2) <$> m1 <*> m2

-- | Class of types that contain meta-variables
class HasMVar a where
  -- | Replace any occurring meta-variables bound in the given |SubsEnv|
  --  by the meta-variable to which they are bound
  sub_mvars :: SubsEnv -> a -> a

  -- | Perform unification on two values, subject to a substitution-environment,
  -- resulting in:
  --  * two substitution-environments, one for each operand
  --  * failure (Nothing)
  -- may involve the generation of fresh meta-variables
  unify :: SubsPair -> a -> a -> UnificationRes 

unify_pvar :: MVar -> MVar -> UnificationRes
unify_pvar x1 x2 
  |  x1 == x2 =   un_success
  | otherwise =   do   x <- fresh_var
                       return (Just (rep x1 x, rep x2 x))

instance HasMVar a => HasMVar [a] where
  sub_mvars the = map (sub_mvars the)

  unify thep xs ys = do
        msenvs <- sequence (zipWith (unify thep) xs ys)
        case all isJust msenvs of
          True  -> return $ Just (subsPairsUnion (map fromJust msenvs))
          False -> return Nothing

-- | Class of types that have meta-variables in `binding positions'
class HasPVar a where
  -- | Return the meta-variables in bindings positions as a set
  pvars :: a -> S.Set MVar

-- Class of types that have meta-variables in `term positions'
class HasTVar a where
  -- | Return the meta-variables in "term positions"
  tvars  :: a -> S.Set MVar

sub_var :: SubsEnv -> MVar -> MVar
sub_var the x  | the `replaces` x  = the `replace` x
               | otherwise         = x

-- HasMVar instances
instance HasMVar Stmt where 
  sub_mvars the s = case s of 
    Commit t            -> Commit (sub_mvars the t)
    Single r t x ml     -> Single r (sub_mvars the t) (sub_var the x) ml
    Many r t x ml       -> Many r (sub_mvars the t) (sub_var the x) ml
    PM_Args ps          -> PM_Args (sub_mvars the ps)
    PM e p              -> PM (sub_mvars the e) (sub_mvars the p)
    Unobserv l          -> Unobserv l
    RW_Get eid x l      -> RW_Get eid (sub_var the x) l
    WO_Get eid x l      -> WO_Get eid (sub_var the x) l
    RO_Get eid x        -> RO_Get eid (sub_var the x)
    RW_Set eid e l      -> RW_Set eid (sub_mvars the e) l
    WO_Set eid e        -> WO_Set eid (sub_mvars the e)
    RO_Set eid e l      -> RO_Set eid (sub_mvars the e) l
    Branches sss        -> Branches (sub_mvars the sss)

  unify the s1 s2 = case (s1, s2) of
    (Commit t1, Commit t2) -> unify the t1 t2
    (Single r1 t1 x1 ml1, Single r2 t2 x2 ml2) -> unifyCall r1 t1 x1 ml1 r2 t2 x2 ml2
    (Many r1 t1 x1 ml1, Many r2 t2 x2 ml2) -> unifyCall r1 t1 x1 ml1 r2 t2 x2 ml2
    (PM_Args ps1, PM_Args ps2)  -> unify the ps1 ps2 
    (PM e1 p1, PM e2 p2)  -> unify the e1 e2 `un_and` unify the p1 p2
    (Unobserv l1, Unobserv l2) | l1 == l2 -> un_success
    (RW_Get eid1 x1 l1, RW_Get eid2 x2 l2) | eid1 == eid2, l1 == l2 -> unify_pvar x1 x2
    (WO_Get eid1 x1 l1, WO_Get eid2 x2 l2) | eid1 == eid2, l1 == l2 -> unify_pvar x1 x2
    (RO_Get eid1 x1, RO_Get eid2 x2) | eid1 == eid2 -> unify_pvar x1 x2 
    (RW_Set eid1 e1 l1, RW_Set eid2 e2 l2) | eid1 == eid2, l1 == l2 -> unify the e1 e2
    (WO_Set eid1 e1, WO_Set eid2 e2) | eid1 == eid2 -> unify the e1 e2
    (RO_Set eid1 e1 l1, RO_Set eid2 e2 l2) | eid1 == eid2, l1 == l2 -> unify the e1 e2
    (Branches _, _) -> error "unification on branches?"
    (_, Branches _) -> error "unification on branches?"
    (_,_) -> un_failure 
   where
      unifyCall r1 t1 x1 ml1 r2 t2 x2 ml2 =
        if r1 == r2 && ml1 == ml2 then unify the t1 t2 `un_and` unify_pvar x1 x2
                                  else un_failure

instance HasMVar Expr where
  sub_mvars the (Val t)      = Val (sub_mvars the t) 
  sub_mvars the (VOP op es)  = VOP op (sub_mvars the es) 

  unify the e1 e2 = case (e1, e2) of 
    (Val v1, Val v2) -> unify the v1 v2 
    (VOP o1 es1, VOP o2 es2) | o1 == o2 -> unify the es1 es2 
    (_,_) -> return Nothing

instance HasMVar Term where
  sub_mvars the (TVar x)       = TVar (sub_var the x) 
  sub_mvars the (TCons b f ts) = TCons b f (sub_mvars the ts)

  unify thep@(the1,the2) t1 t2 = case (t1, t2) of 
    (TVar x1, TVar x2) | x1' == x2' -> un_success
      where x1' = mreplace the1 x1
            x2' = mreplace the2 x2
    (TCons b1 f1 ts1, TCons b2 f2 ts2) | b1 == b2, f1 == f2 -> do
      msenvs <- sequence (zipWith (unify thep) ts1 ts2)
      -- we know all substitution-environments will be empty
      case all isJust msenvs of
        True    -> un_success
        False   -> return Nothing
    (_,_) -> return Nothing

instance HasMVar Pattern where
  sub_mvars the (PVar x)     = PVar (sub_var the x) 
  sub_mvars the PAny         = PAny
  sub_mvars the (PCons f ts) = PCons f (sub_mvars the ts)

  unify the p1 p2 = case (p1,p2) of
    (PVar x1, PVar x2)  -> unify_pvar x1 x2
    (PAny, PAny)        -> un_success
    (PCons f1 ps1, PCons f2 ps2) | f1 == f2 -> unify the ps1 ps2
    (_, _) -> return Nothing

-- HasTVar instances
instance HasTVar Stmt where
  tvars s = case s of
    Single _ t _ _      -> tvars t
    Many _ t _ _        -> tvars t
    PM_Args _           -> S.empty
    PM e _              -> tvars e
    Unobserv _          -> S.empty
    RW_Get _ _ _        -> S.empty
    WO_Get _ _ _        -> S.empty
    RO_Get _ _          -> S.empty
    RW_Set _ e _        -> tvars e
    WO_Set _ e          -> tvars e
    RO_Set _ e _        -> tvars e
    -- should not be executed
    Commit t            -> tvars t
    Branches sss        -> error "read_vars of branches"

instance HasTVar Expr where
  tvars e = case e of 
    Val t               -> tvars t
    VOP _ es            -> S.unions (map tvars es)   

instance HasTVar Term where
  tvars t = case t of
    TVar x              -> S.singleton x
    TCons _ _ ts        -> S.unions (map tvars ts)

-- HasPVar instances 
instance HasPVar Stmt where
  pvars s = case s of 
    Commit _            -> S.empty
    Single _ _ x _      -> S.singleton x
    Many _ _ x _        -> S.singleton x
    PM_Args ps          -> S.unions (map pvars ps)
    PM _ p              -> pvars p
    Unobserv _          -> S.empty
    RW_Get _ x _        -> S.singleton x
    WO_Get _ x _        -> S.singleton x
    RO_Get _ x          -> S.singleton x
    RW_Set _ _ _        -> S.empty
    WO_Set _ _          -> S.empty
    RO_Set _ _ _        -> S.empty
    -- should not be executed
    Branches sss        -> error "pvars of branches"--S.unions (map pvars sss)

instance HasPVar Pattern where
  pvars p = case p of
    PVar x              -> S.singleton x
    PAny                -> S.empty
    PCons _ ps          -> S.unions (map pvars ps)


