
module IML.Grammar.RuleFormat where

import IML.Grammar.Shared

type Spec       = [Either EntDecl Rule]

data Rule       = Rule Conclusion Premises SideCons

type Premises   = [Premise]
data Premise    = Prem Term Rel Pattern [ROup] [RWup] [WOacc]

data Conclusion = Conclusion Cons [Pattern] RSymb Term [ROacc] [RWacc] [WOup]

type SideCons   = [SideCon]
data SideCon    = SideOP Expr Pattern

data Rel        = Rel RSymb Rep Bool {- may have unobserved effects -}
sRel r          = Rel r NoRep True
mRel r          = Rel r Rep True

type ROacc      = (EID, Pattern)
type ROup       = (EID, Expr)
type WOacc      = (EID, Pattern)
type WOup       = (EID, Expr)
type RWacc      = (EID, Pattern, Expr)
type RWup       = (EID, Expr, Pattern)

data RPred      = IsPure 
                | Orderable
{-                | Reflexive
                | ValReflexive
                | Transitive-}
                deriving (Enum, Ord, Eq)
