
module IML.Printer where

import IML.Grammar.Shared
import IML.Grammar

import Data.List (intersperse)
import Text.PrettyPrint.HughesPJ

iml_print :: Doc -> String
iml_print = render 

ppProgram :: Program -> Doc
ppProgram (Program spec qs) = 
  ppQueries qs $+$ text "" $+$ ppSpec spec

ppSpec :: Spec -> Doc
ppSpec = vsep . map (either ppDecl ppTransDecl)

ppQueries :: Queries -> Doc
ppQueries = vcat . map ppQuery

ppQuery :: Query -> Doc
ppQuery (Query call r t) = text "?" <+> callee <> showArgs [text r, ppTerm t]
 where callee = case call of  Rep    -> text "many"
                              NoRep  -> text "single"

ppDecl :: EntDecl -> Doc
ppDecl d = case d of
  RODecl eid e -> 
    text "ro-decl" <> showArgs [dquote eid, ppExpr e]
  RWDecl eid e ->
    text "rw-decl" <> showArgs [dquote eid, ppExpr e]
  WODecl eid op2 op0 -> 
    text "wo-decl" <> showArgs [dquote eid, dquote op2, dquote op0]

ppTransDecl :: TransDecl -> Doc
ppTransDecl (Trans sym cons stmts) = 
    text sym <+> text "TRANSACTION" <+> text cons $+$ ppBranches 1 stmts

ppStmtsLine :: Stmts -> Doc
ppStmtsLine = hcat . map (enclose . ppStmt)
  where enclose s = s <> semi

ppStmts :: Stmts -> Doc
ppStmts = ppStmtsB 1  

ppStmtsB :: Int -> Stmts -> Doc
ppStmtsB branchnr = vcat . map (enclose . ppStmtB branchnr)
  where enclose s = text "|" <+> s <> semi

ppStmt :: Stmt -> Doc
ppStmt = ppStmtB 1

ppStmtB :: Int -> Stmt -> Doc
ppStmtB branchnr s = case s of
--  Skip              -> text "skip"
--  Abort             -> text "aborts"
--  Assert e          -> text "assert" <> showArgs [ppExpr e]
  PM_Args ps        -> text "pm-args" <> showArgs (map ppPattern ps) 
  PM e p            -> text "pm" <> showArgs [ppExpr e, ppPattern p]
  Commit t          -> text "commit" <> showArgs [ppTerm t]
  Single r t x ml   -> text "single" <> ppMLabel ml <> showArgs [text r, ppTerm t, text x]
  Many   r t x ml   -> text "many" <> ppMLabel ml <> showArgs [text r, ppTerm t, text x]
  Unobserv l        -> text "unobserv" <> ppLabel l
  RO_Set eid e l    -> text "ro-set" <> ppLabel l <> showArgs [dquote eid, ppExpr e]
  RO_Get eid x      -> text "ro-get" <> ppLabel 0 <> showArgs [dquote eid, text x]
  RW_Set eid e l    -> text "rw-set" <> ppLabel l <> showArgs [dquote eid, ppExpr e]
  RW_Get eid x l    -> text "rw-get" <> ppLabel l <> showArgs [dquote eid, text x]
  WO_Set eid e      -> text "wo-set" <> ppLabel 0 <> showArgs [dquote eid, ppExpr e]
  WO_Get eid x l    -> text "wo-get" <> ppLabel l <> showArgs [dquote eid, text x]
  Branches sss      -> ppBranches branchnr sss 
  where ppMLabel Nothing  = empty
        ppMLabel (Just i) = ppLabel i
        ppLabel i         = text "_" <> text (show i) 

ppBranches :: Int -> [Stmts] -> Doc
ppBranches branchnr sss = vcat $ intersperse (text "====") $ 
                            zipWith (ppBranch branchnr) ['a'..] sss 
  where ppBranch nr chr ss = text "BRANCH" <+> text (show nr ++ [chr]) $+$ 
                              ppStmtsB (nr + 1) ss

ppExpr :: Expr -> Doc
ppExpr (Val t) = ppTerm t
ppExpr (VOP op es) = text "value-op" <> showArgs (dquote op : map ppExpr es)

ppTerm :: Term -> Doc
ppTerm (TVar v) = text v
ppTerm (TCons True "string" [TCons True v []]) = dquote v
ppTerm (TCons True "list" vs) = 
  text "[" <> hsep (intersperse comma (map ppTerm vs)) <> text "]"
ppTerm (TCons True "tuple" ts) = showArgs (map ppTerm ts)
ppTerm (TCons True "integer" [TCons True s []]) = text s
ppTerm m@(TCons True "_map" ps) = 
  text "{" <> hsep (intersperse comma (map ppPair ps)) <> text "}"
  where ppPair (TCons True "tuple" [k,v]) = ppTerm k <+> text "|->" <+> ppTerm v
        ppPair t = ppTerm t
ppTerm (TCons _ cs ts)  | null ts   = text cs
                        | otherwise = text cs <> showArgs (map ppTerm ts)

ppPattern :: Pattern -> Doc
ppPattern (PVar v) = text v
ppPattern (PAny)   = text "_"
ppPattern (PCons cons ps) = text cons <> showArgs (map ppPattern ps)

showArgs :: [Doc] -> Doc
showArgs args = lparen <> hcat (intersperse comma args) <> rparen

vsep = vcat . intersperse (text "")

dquote = doubleQuotes . text
