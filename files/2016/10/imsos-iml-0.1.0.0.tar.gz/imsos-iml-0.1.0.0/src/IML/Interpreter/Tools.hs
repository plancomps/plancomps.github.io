
module IML.Interpreter.Tools where

import IML.Grammar
import IML.Printer
import qualified IML.Interpreter as IP

import Control.Monad (when)

import System.FilePath

printFiles :: [String] -> FilePath -> Int -> Program -> IO ()
printFiles args imlFile i pr = do
  writeFile outFile manipulated_version 
  writeFile resFile outcome
  when (any (== "--debug") args) (putStrLn outcome)
  where outFile = replaceExtension imlFile "siml" 
        resFile = replaceExtension imlFile "output" 
        (path,ext) = splitExtension imlFile
        outcome = unlines $ map show_query_res $ IP.run pr 
          where show_query_res (t,rec) = iml_print (ppTerm t) ++ "\n" ++ show rec

        manipulated_version = iml_print (ppProgram pr)
