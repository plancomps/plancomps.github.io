
module IML.Interpreter.Parser where

import IML.Grammar.Shared
import IML.Grammar
import IML.Interpreter.Values

import GLL.Combinators

import Data.Either

type Parser a = BNF Token a

type PTransDecl = (RSymb, Cons, Stmts)

iml_parser :: [Token] -> [Program]
iml_parser inp = case parseWithOptions [throwErrors] pProgram inp of
  []  -> error "no parse errors, but no result?"
  ps  -> ps

pProgram :: Parser Program 
pProgram = "PROGRAM" <:=> mkProgram <$$> multiple (pEither pDecl pQuery)
  where mkProgram es = Program mkTransDecl queries
          where (decls,queries) = partitionEithers es 
                mkTransDecl = case foldr merge (Nothing,[]) decls of
                                (Nothing, acc)  -> acc
                                (Just t, acc)   -> Right t : acc
                  where merge (Left edecl) (mtd,acc) = 
                          case mtd of Nothing -> (Nothing, (Left edecl):acc)
                                      Just td -> (Nothing, (Left edecl):Right td:acc)
                        merge (Right (r, f, ss)) (mtd, acc) = 
                          case mtd of 
                            Nothing   -> (Just (Trans r f [ss]), acc)
                            Just (Trans r2 f2 sss) 
                              | r == r2, f == f2 -> (Just (Trans r f (ss:sss)), acc)
                              | otherwise -> (Just (Trans r f [ss])
                                             ,(Right (Trans r2 f2 sss)):acc)

pQuery :: Parser Query 
pQuery = "MAIN" <:=> keychar '?' **> pMainAlt <** optsemi
  where pMainAlt = "ALT-MAIN" 
          <:=> binary "many" (Query Rep) pRSymb pTerm
          <||> binary "single" (Query NoRep) pRSymb pTerm

pDecl :: Parser (Either EntDecl PTransDecl)
pDecl = "DECL" 
  <:=> binary "ro-decl" ((Left .) . RODecl) string_lit pExpr <** optsemi
  <||> binary "rw-decl" ((Left .) . RWDecl) string_lit pExpr <** optsemi
  <||> ternary "wo-decl" (((Left .) .) . WODecl) string_lit string_lit string_lit <** optsemi
  <||> Right <$$> pTrans

pTrans :: Parser PTransDecl 
pTrans = "TRANS" 
  <:=> (,,) <$$> pRSymb <** keyword "TRANSACTION" <**> id_lit <**> pStmts
        
pStmts :: Parser Stmts
pStmts = "BODY" <:=> optional (keychar '|') **> multipleSepBy pStmt (optional (keychar '|'))

pStmt :: Parser Stmt
pStmt = "STMT" <:=> pStmtAlt <** optional (keychar ';')
  where pStmtAlt :: Parser Stmt
        pStmtAlt = "ALT-STMT" 
--          <||> keyword "branches" **> parens pBranches 
          <:=> arbitrary "pm-args" PM_Args pPattern 
          <||> binary "pm" PM pExpr pPattern
          <||> ternary_ "single" Single pRSymb pTerm pMVar 
          <||> ternary_ "many" Many pRSymb pTerm pMVar
          <||> binary_ "rw-get" rw_get string_lit pMVar
          <||> binary_ "rw-set" rw_set string_lit pExpr 
          <||> binary "ro-get_0" RO_Get string_lit pMVar
          <||> binary_ "ro-set" ro_set string_lit pExpr
          <||> binary "wo-set_0" WO_Set string_lit pExpr 
          <||> binary_ "wo-get" wo_get string_lit pMVar
          <||> unary "commit" Commit pTerm
          <||> Unobserv <$$ keyword "unobs" <** keychar '_' <**> int_lit
     
        ro_set a b Nothing  = error "ro-set without label"
        ro_set a b (Just i) = RO_Set a b i
        wo_get a b Nothing  = error "wo-get without label"
        wo_get a b (Just i) = WO_Get a b i
        rw_get a b Nothing  = error "rw-get without label"
        rw_get a b (Just i) = RW_Get a b i 
        rw_set a b Nothing  = error "rw-set without label"
        rw_set a b (Just i) = RW_Set a b i 

pLabel :: Parser Int
pLabel = "LABEL" <:=> keychar '_' **> int_lit

pExpr :: Parser Expr
pExpr = "EXPR" 
  <::=> Val <$$> pTerm
  <||>  keyword "value-op" **> parens pVOP
  where pVOP = "VOP" <:=> 
                  vop <$$> string_lit <**> optional (
                            keychar ',' **> multipleSepBy pExpr (keychar ','))
         where vop op = VOP op . maybe [] id 
        
pTerm :: Parser Term
pTerm = "TERM" 
  <::=> pVar TVar
  <||> tcons <$$> id_lit <**> optional (parens (multipleSepBy pTerm (keychar ',')))
  <||> int_ <$$> int_lit
  <||> string_ <$$> string_lit
  <||> parens (mkRule $ tuple_ <$$> multipleSepBy pTerm (keychar ',')) 
  where tcons "true" _  = true_
        tcons "false" _ = false_
        tcons cs margs = TCons (cs `elem` val_cons) cs (maybe [] id margs)

        val_cons = ["id"]

pPattern :: Parser Pattern
pPattern = "PATTERN"
  <::=> pVar PVar
  <||>  PAny <$$ keychar '_' 
  <||>  PCons <$$> id_lit <**> parens (multipleSepBy pPattern (keychar ','))

pMVar :: Parser MVar
pMVar = pVar id

pVar :: (MVar -> a) -> Parser a
pVar cons = "MVAR" <:=> tvar <$$> optional (keychar '_') <**> alt_id_lit 
  where tvar m_ altid = cons $ maybe altid (const ('_':altid)) m_

pRSymb :: Parser RSymb
pRSymb = token "REL-SYMB"

optsemi :: Parser (Maybe Char)
optsemi = "OPTIONAL-SEMI" <:=> optional (keychar ';')

unary :: String -> (a -> b) -> Parser a -> Parser b
unary key f p = mkRule $ f <$$ keyword key <**> parens p

binary :: String -> (a -> b -> c) -> Parser a -> Parser b -> Parser c
binary key f = binary_ key (\a b _ -> f a b) 

ternary :: String -> (a -> b -> c -> d) -> 
            Parser a -> Parser b -> Parser c -> Parser d
ternary key f = ternary_ key (\a b c _ -> f a b c)
 
quaternary :: String -> (a -> b -> c -> d -> e) -> 
                Parser a -> Parser b -> Parser c -> Parser d -> Parser e
quaternary key f p1 p2 p3 p4 = mkRule $ keyword key **> parens args
  where args = mkRule $ f <$$> p1 <** keychar ',' 
                          <**> p2 <** keychar ',' 
                          <**> p3 <** keychar ','
                          <**> p4

arbitrary :: String -> ([a] -> b) -> Parser a -> Parser b
arbitrary key f p1 = mkRule $ keyword key **> parens args
  where args = mkRule $ f <$$> multipleSepBy p1 (keychar ',')

binary_ :: String -> (a -> b -> Maybe Label -> c) -> Parser a -> Parser b -> Parser c
binary_ key f p1 p2 = mkRule $ 
  flip ($) <$$ keyword key <**> optional pLabel <**> parens args
  where args = mkRule $ f <$$> p1 <** keychar ',' <**> p2

ternary_ :: String -> (a -> b -> c -> Maybe Label -> d) -> 
            Parser a -> Parser b -> Parser c -> Parser d
ternary_ key f p1 p2 p3 = mkRule $ 
  flip ($) <$$ keyword key <**> optional pLabel <**> parens args
  where args = mkRule $ f <$$> p1 <** keychar ',' <**> p2 <** keychar ',' <**> p3

pEither :: Parser a -> Parser b -> Parser (Either a b)
pEither p1 p2 = mkRule $ Left <$$> p1 <||> Right <$$> p2 
