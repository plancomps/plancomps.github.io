
module IML.Interpreter.Lexer where

import GLL.Combinators (Token(..), SubsumesToken(..))

import Data.Char
import Text.Read (readEither)
import Text.Regex.Applicative


iml_lexer :: String -> [Token]
iml_lexer = lState "DEF" True lTokens (const iml_lexer) Just 

lState :: String -> Bool -> RE Char t -> (t -> String -> [Token]) ->
                  (t -> Maybe Token) -> String -> [Token]
lState _ _ _ _ _ [] = []
lState stateName discardLayout myTokens mySelector adder s =
    let re | discardLayout = Just <$> myTokens <|> ws
           | otherwise     = Just <$> myTokens
        ws =      (Nothing <$ some (psym isSpace))
              <|> (Nothing <$ string "//" <* many (psym ((/=) '\n')))
    in case findLongestPrefix re s of
        Just (Just tok, rest)   -> (maybe id (:) (adder tok)) (mySelector tok rest)
        Just (Nothing,rest)     -> lState stateName discardLayout myTokens mySelector adder rest
        Nothing                 -> error ("lexical error at " ++ stateName ++ ": " ++ show (take 10 s))


lTokens :: SubsumesToken t => RE Char t
lTokens =
        lCharacters
    <|> lKeywords
    <|> upcast . Token "REL-SYMB" . Just <$> lRelSymbs
    <|> upcast . IDLit . Just <$> lName
    <|> upcast . AltIDLit . Just <$> lVar
    <|> upcast . StringLit . Just <$> lStringLit
    <|> upcast . IntLit . Just . read <$> some (psym isDigit)
    where
            lCharacters = foldr ((<|>) . lChar) empty keycharacters
              where lChar c = upcast (Char c) <$ sym c

            lKeywords = foldr ((<|>) . lKeyword) empty keywords
              where lKeyword k  = upcast (Keyword k) <$ string k

            lRelSymbs = many (anyOf symcharacters)
              where anyOf = foldr ((<|>) . sym) empty
 
            lStringLit = toString <$ sym '\"' <*> many strChar <* sym '\"'
             where strChar =  sym '\\' *> sym '\"'
                              <|> psym ((/=) '\"')
                   toString inner = case readEither ("\"" ++ inner ++ "\"") of
                      Left _  -> inner
                      Right v -> v

            keycharacters = "()_;,|?"
   
            symcharacters = "-=><+}{[]"
  
            keywords =  ["branches", "pm-args", "pm"
                        ,"single", "many", "commit", "unobs"
                        ,"rw-get", "rw-set", "ro-get_0", "ro-set", "wo-set_0", "wo-get"
                        ] ++ ["sseq"] ++
                        ["value-op"] ++
                        ["ro-decl", "rw-decl", "wo-decl", "trans"] ++
                        ["program", "TRANSACTION"]
                        

lName = (:) <$> psym isLower <*> many (psym (\c -> isAlphaNum c || c == '-'))
lVar  = merge <$> psym isUpper <*> many (psym (\c -> isAlpha c || isDigit c)) 
                    <*> optional (sym '\'')
  where merge s ss ms = s:ss++(maybe [] (:[]) ms)
