IMP-cbs
=======

Before proceeding, ensure you have built the CBS-Editor project in Eclipse.
(See /CBS/README.txt)

Import the IMP-cbs project into Eclipse.  It contains:
 * IMP: The CBS definition of the IMP language.
 * Funcons: The CBS definitions of all funcons in the funcon library.

If CBS-Editor has been built successfully, the CBS files should be displayed
with coloured syntax.

* * *

Note: If you only want to view the CBS files, then this is all you need.
The remaining instructions pertain to executing the translation functions and
executing the generated funcon terms.


IMP-Editor
==========

This is the Spoofax Editor project for editing IMP programs, and
translating them to funcon terms.

Import and build this project in Eclipse prior to viewing any IMP test
programs in Eclipse.  This is not required for running the IMP tests from
the command line.


IMP-Tests
=========

This contains a collection of IMP test programs.

See IMP-Tests/README.txt for instructions on how to run the translated
funcon terms from the command line.

Once IMP-Editor has been built, you can import IMP-Tests into Eclipse.
Then:
  - you can view the *.imp programs with syntax colouring.
  - you can translate IMP programs to funcon terms by clicking on the
    "Generation" button while viewing a *.imp file.

To execute a generated funcon term from within Eclipse, follow the
instructions in "/CBS/FCT-Interpeter/README.txt", but add the following flag
before "${resource_loc}":

--config <absolute-path-to-IMP-Tests>/IMP.config

This sets some display options suitable for FCTs generated from IMP programs.
