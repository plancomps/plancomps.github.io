# Example usage:
#   ./regen-funcons.sh Coverage

SpooDir="../IMP-Editor"

echo "Generating funcons for all .imp files in ./$1"
java -jar ${SpooDir}/spoofax-sunshine.jar --auto-lang ${SpooDir}/include --project "$1" --builder "Generate Funcons" --build-on-all ./ --non-incremental
