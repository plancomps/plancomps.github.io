IMP TESTS
=========

This directors contains two sets of IMP test programs:
  - Coverage
  - K-Tutorial
The former are unit tests that together cover the entire IMP syntax.
The latter are more interesting programs taken from the K Framework distribution.

Each directory contains several test programs (*.imp), the funcon terms generated from those test
programs (*.fct).


Running Funcon Terms
--------------------

To run a test, you will first need to have built the funcon interpreter (see ../../../FCT-Interpreter/README.txt).
Then invoke it as follows (using sum.fct as an example):

> runfct --config IMP.config K-Tutorial/sum.fct


Regenerating Funcon Terms
-------------------------

Note: All funcon terms have already been generated, so regenerating them is only necessary if you have added
or modified a test program, or changed the CBS definition of IMP.

To generate the funcon terms from test files, you first need to have imported and built the "IMP-Editor"
Spoofax project in Eclipse.

Then you can run the "regen-funcons" script.  E.g.

> ./regen-funcons.sh Coverage

will generate a *.fct file for each *.imp file in the folder "Coverage".
