Creating a translator using CBS
===============================

Here is how to create a translator from a programming language to funcons in the 
PLanCompS SVN repository.  Most of it is generated from specifications in the 
CBS meta-notation.

Platform requirements
---------------------

The creation and use of Spoofax-based editors in Eclipse should be 
platform-independent. The process described below has been tested on 
the following platform:

* Spoofax-1.5 as a pre-packaged Eclipse distribution (see `http://metaborg.org/download/`)
* CBS-Editor (PLanCompS project internal SVN: `CBS/CBS-Editor`)
	* checkout the project into Eclipse then build
* Mac OSX El Capitan (10.11.3)

Required files and folders
--------------------------

As a running example, we explain how to create a translator for a language 
called IMP. Language names should be short, start with a capital letter, 
and may consist of letters, digits and hyphens.

The name of the folder containing the CBS specification of IMP and the 
IMP translator could be simply `IMP`. Below, we use `IMP-Lang` instead, 
to avoid confusion with sub-folders whose name has to match the language name `IMP`.

1. Create a folder `CBS/Languages/IMP-Lang/IMP-cbs`in the PLanCompS SVN repository.
Then:
	- Add the following `svn:externals` property to `IMP-cbs` to create 
	  an external link from `CBS/Languages/IMP-Lang/IMP-cbs/Funcons` to the 
	  evolving funcon library in `CBS/Funcons`, which is shared by all 
	  CBS language specifications:
	  
		```
		Funcons svn://svn.plancomps.org/resources/CBS/Funcons
		```
		Commit the change to SVN, then synchronise.

	- Create a folder `IMP` within `IMP-cbs` containing CBS files specifying IMP, 
	with `IMP/IMP-Start.cbs` including the syntax and semantics of a nonterminal 
	named `start`. 
	
	- Assuming that the CBS-Editor project has been successfully built, files 	with extension `cbs` containing well-formed CBS specifications should be 	displayed with different colours for different kinds of names.

2. Create a _minimal_ Spoofax editor project:
	- Project name: __`IMP-Editor`__
	
	- Language name: __`IMP`__
	
	- Plugin ID and package name (e.g.): __`IMPEditor`__

	- Filename extension (e.g.): __`imp`__ 

	In `IMP-Editor/editor/IMP.esv`, insert __`, fct`__ after
	`extensions: imp`.
	
	The file `syntax/Common.sdf3` is not used by CBS-generated editors, and may be deleted.
	
	Create an empty folder `IMP-Editor/cbs`.
	
	Share the project on SVN as `CBS/Languages/IMP-Lang/IMP-Editor`.  	Note that the subdirectories "include" and "utils" do not need to be shared on SVN.

	__*The remaining steps all concern files located in this `IMP-Editor` project.*__

	----
	
3. Add the following `svn:externals` property to the empty folder `IMP-Editor/cbs`, 
	to create links from `cbs/IMP` to `CBS/Languages/IMP-Lang/IMP-cbs/IMP`, 
	and from `cbs/Funcons` to `CBS/Funcons`:
	
	```
	IMP svn://svn.plancomps.org/resources/CBS/Languages/IMP-Lang/IMP-cbs/IMP
	Funcons svn://svn.plancomps.org/resources/CBS/Funcons

	```
	
	Commit the changes to the `IMP-Editor` project, then update the project from SVN. 
	The `IMP` and `Funcons` links in `cbs` should now give access to their target folders.
	

	
Generating SDF and Stratego from CBS
------------------------------------

_Note: Eclipse will initially flag various errors and warnings in the generated files. 
The errors should all disappear when the IMP-Editor project has been successfully built; 
some warnings (e.g., about overloaded constructors in SDF3 files) will remain, 
but can be ignored._

1. `cbs/IMP/IMP-Start.cbs`: Open this file in the CBS editor.

	Check that all references to names in all the CBS files have been successfully
	resolved to their definitions. If not, click the __`Reset and reanalyze`__ button. 
	If that doesn't work, select the `IMP-Editor` project and use the pop-up menu 
	items __`Unload analysis`__ followed by __`Reload analysis`__.

	Click the __`Generation`__ button.

	The generation of all the required components should be reported in a console window.
	
2. Edit `syntax/IMP.sdf3` to have the following contents:

	```
	module IMP
	
	imports
		IMP/IMP-Start
	
	context-free start-symbols
	  
	  Start
	
	context-free syntax
	  
	  Start = L-start
	
	``` 

	This is also the file where one may add or import SDF3 disambiguation rules, 
	based on copies of the productions generated in `syntax/cbs-gen/IMP/`.


Building the project
--------------------

* Close all other projects that involve Stratego meta-syntax (in case of interaction).

* Clean the IMP-Editor project.

* Build the project. It should _fail_, reporting that it cannot find a file 
in the include path.

* Build the project again. It may fail again, reporting an unexpected symbol.

* __Quit Eclipse!__

* Reopen Eclipse.

* Build again (once without cleaning, or twice after cleaning). It should succeed.


Testing the generated editor
----------------------------

* Open an IMP file, e.g., `test/test.imp`.

* Click on the __`Generation`__ button to generate an FCT in `test/test.fct`.

----
