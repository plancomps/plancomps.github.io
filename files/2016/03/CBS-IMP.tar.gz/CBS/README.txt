Component-Based Semantics (CBS)
===============================

CBS is a unified meta-language for defining:
 - abstract syntax grammars;
 - translation functions from abstract syntax to funcon terms;
 - funcons and semantic entities.

CBS specifications can be viewed in any text editor.  However, we strongly
recommend using the CBS-Editor Spoofax project within Eclipse.

This directory contains:

- CBS-Editor: a Spoofax editor project for viewing CBS specifications
- Languages: definitions of source languages, with accompanying Spoofax editors.
             For this release, the only language is IMP.
- FCT-Interpreter: A Haskell-based interpreter for funcon terms.


Setup Instructions
------------------

(1) Install Eclipse 4.5 (Mars), and the Spoofax 1.5 plugin.

  (a) You will probably find it easiest to download a version of Eclipse with Spoofax
      pre-installed.  This is available at:

      http://www.metaborg.org/spoofax/spoofax-1-5-0/

      Note that you should deselect "Build Automatically" from the Project menu before
      building any projects.

  OR

  (b) Spoofax can also be installed in a standard Eclipse installation as follows:
       * Within Eclipse, select "Install New Software" from the "Help" menu
       * Add the location "http://download.spoofax.org/update/stable"
       * Select "Spoofax Core", and then proceed with the installation.
       * Make the following changes to your "eclipse.ini" file:
           - Increase the "-Xmx512m" flag to "-Xmx1024m"
           - Add the "-Xss8m" flag
         Or start Eclipse with the flags "-vmargs -Xms40m -Xmx512m"

(2)  Import and build the "CBS-Editor" project.


Viewing CBS Specifications
--------------------------

Import the project "Languages/IMP/IMP-cbs".

Opening a .cbs file within Eclipse should cause the file to be parsed
and displayed with coloured syntax.

*NOTE*: If you are using CBS for the first time, then browsing the files in the
IMP-cbs project is probably what you want to do.  The remaining instructions
pertain to executing translation functions and funcon terms, which you are unlikely
to need initially.


Viewing and Translating IMP programs
------------------------------------

See "Languages/IMP/README.txt" for instructions on how to view and translate
IMP programs.


Executing Funcon Terms
----------------------

See "FCT-Interpreter/README.txt" and follow the "Installation Instructions".

Then see "Languages/IMP/README.txt" for instructions on how to use the
interpreter to execute funcon terms generated from IMP programs.
