This README explains how to generate Haskell modules from CBS files.

Generating Haskell modules is not required for interpreting funcon terms.
However, it can be used to generate code for modified or new funcons.

NOTE: .cbs files with large amounts of  comments will trigger an efficiency issue.

Installation
------------

This package provides an executable for converting .aterm files to .hs files
    (dist/build/aterm2hs/aterm2hs)

(1) Requires GHC 7.10.x (available via the Haskell Platform)

(2) Install additional Haskell libraries

cabal update
cabal install split, pretty, uu-cco

(3) Extract the tarball funcons-intgen-<version>.tar.gz
      
tar -xf funcons-intgen-<version>.tar.gz

(4) Change current directory

cd funcons-intgen-<version>.tar.gz

(5) Build the compiler

cabal build

Executable funcons-intgen-<version>/dist/build/aterm2hs/aterm2hs is now available.


Add the compiler in Eclipse
---------------------------

1) Run > External Tools > External Tool Configurations...

2) Double click on 'Program'

3) Give the tool a name, e.g. "CBS-Compiler"

4) Select as location the interpreter's executable, e.g.:
    <local-path-to-executable>/aterm2hs

5) Click on the 'build' tab and *de*select 'Build before launch'

6) The execute should receive three arguments (in the arguments field)

    "${resource_loc}" <src-folder> <LANG> 

    where "${resource_loc}" should include the quotes,
    <src-folder> is the source in which the Haskell module should be generated,
        (surround in quotes if the path contains spaces)
    <LANG> is the name of the object language 
        (should be valid Haskell module name)

    set ${project_loc} as 'working directory', 
    press Apply and Close

7) Run > External Tools > Organize Favourites...

8) Press Add and select "CBS-Compiler", press OK


Generating Haskell modules
--------------------------

Requires the CBS-Editor (../CBS-Editor/README.txt)

1) In Eclipse, open a .cbs file.

2) Under "Syntax" select "Show abstract syntax"
    This will open an aterm representation of the .cbs file.

3) Select CBS-Compiler from 'external tools' (play button with toolbox).

4) The console will report the location of the generated Haskell module
    (or errors if unsuccessful). 
