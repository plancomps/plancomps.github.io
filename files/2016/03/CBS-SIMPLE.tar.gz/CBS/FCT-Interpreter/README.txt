Funcon Interpretation in Haskell
================================

An interpreter for funcon terms, written in Haskell, is available as a Cabal package on Hackage.

https://hackage.haskell.org/package/funcons-tools

The package provides:
    a) An executable for interpreting funcon terms (dist/build/runfct/runfct)
    b) A library for:
        i)  Defining funcons
        ii) Extending the interpreter with language specific funcons

Installation Instructions
-------------------------

(1) Requires GHC 7.10.x (available via the Haskell Platform)

(2) Additional Haskell libraries:

cabal update
cabal install bv mtl vector multisets

(3) Installation of the interpreter from Hackage

    cabal install funcons-tools

Executing Funcon Terms
----------------------

A funcon program in a file "myfunconterm.fct" can be executed as follows:

runfct myfunconterm.fct

There are several runtime options available, which may precede or follow the .fct file argument.

For an up to date list see the documentation of "Funcons.Tools" at https://hackage.haskell.org/package/funcons-tools

Add the Interpreter to Eclipse
-----------------------------

1) Run > External Tools > External Tool Configurations...

2) Double click on 'Program'

3) Give the tool a name, e.g. "FCT-interpreter"

4) Select as location the interpreter's executable, e.g.:
    <path-to-funcons-tools-directory>/dist/build/runfct/runfct

5) Click on the 'build' tab and *de*select 'Build before launch'

6) Add ${resource_loc} as an argument, press Apply and Close

7) Run > External Tools > Organize Favourites...

8) Press Add and select "FCT-interpreter" > OK

The interpreter can now be selected from the dropdown next to the play button
    with the little toolbox to execute .fct files.
The .fct file has to be open when the interpreter is ran.
The interpreter's output is printed to the console.
Interpreter flags can be added before or after ${resource_loc}, at step (7).


Manual Definition of Funcons
----------------------------

Funcons are defined by

(1) Writing `evaluation functions'
        (see package's documentation)
(2) Adding the evaluation functions to a `funcon library'.
        (see package's documentation)
(3) Extending the default interpreter with the funcon library.
        (see next section).


Extending the Interpreter
-------------------------

An executable <exec> is made from a Haskell module "Main",
    which must contain a function "main" of type "IO ()",
    with the following command

ghc --make <path_to>/Main.hs -o <exec>

Module Funcons.Tools exports helpers to create "main" functions, for example:

module Main where

main = mkMainWithLibrary <library>

where <library> is a `funcon library' containing additional funcons.
