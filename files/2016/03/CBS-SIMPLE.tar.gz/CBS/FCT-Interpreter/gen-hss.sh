#!/bin/bash
ATERM2HS=aterm2hs
FDIR=${3%/}/$4
HSDIR=${2%/}
LANG=$1
LIBRARYPATH=$HSDIR/Funcons/$LANG
LIBRARY=$LIBRARYPATH/Library.hs
LIBRARYMOD="Funcons.$LANG.Library"

if [[ -z ${3+x} || -z ${2+x} || -z ${1+x} ]]; then 
    echo "usage: gen-hss.sh <LANG> <HS-DIR> <FUNCONS-DIR> <SUB-DIR>
            for example: ./gen-hss.hs CamlLight hs-gen/ ../Funcons"
    exit
fi
echo "Generating Haskell modules in $HSDIR for language $LANG from .aterm files found in $FDIR."

find $FDIR -type f -name "*.aterm" -exec $ATERM2HS {} $HSDIR $LANG \;

