package CBSEditor;

public class CBSParseController extends CBSParseControllerGenerated 
{ }