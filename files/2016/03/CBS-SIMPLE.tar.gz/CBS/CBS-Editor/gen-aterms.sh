#! /bin/zsh

# Example usage:
#   ./gen-aterms.sh  ../Funcons

SpooDir="./"

echo "Deleting all .aterm files in $1"
rm -f "$1"/**/*.aterm
echo "[Done]"

echo "Generating A-Terms for all .cbs files in $1"
java -jar ${SpooDir}/spoofax-sunshine.jar --auto-lang ${SpooDir}/include --project "$1" --builder "Show abstract syntax" --no-analysis --build-on-all ./ --non-incremental
echo "[Done]"
