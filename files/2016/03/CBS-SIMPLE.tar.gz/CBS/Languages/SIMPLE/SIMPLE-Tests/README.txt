SIMPLE TESTS
============

This directors contains several sets of SIMPLE test programs:
  - Basic
  - Advanced
  - KExceptions
  - Kdiverse
The latter two sets are taken from the K Framework distribution.

Each directory contains several test programs (*.smp), the funcon terms generated from those test
programs (*.fct), and in some cases, configuration files providing sample input values (*.config).


Running Funcon Terms
--------------------

To run a test, you will first need to have built the SIMPLE interpreter (see ../README.txt).
Then invoke it as follows (using Kdiverse2.fct as an example):

> runfct-SIMPLE Kdiverse/Kdiverse2.fct

Tests involving reading input take their input from the individual .config files, e.g. Kdiverse/Kdiverse2.config.

To run a test interactively, you should load the "SIMPLE-interactive.config" configuration file:

> runfct-SIMPLE --config SIMPLE-interactive.config Kdiverse/Kdiverse2.fct


Regenerating Funcon Terms
-------------------------

Note: All funcon terms have already been generated, so regenerating them is only necessary if you have added
or modified a test program, or changed the CBS definition of SIMPLE.

To generate the funcon terms from test files, you first need to have imported and built the "SIMPLE-Editor"
Spoofax project in Eclipse.

Then you can run the "regen-funcons" script.  E.g.

> ./regen-funcons.sh Basic

will generate a *.fct file for each *.smp file in the folder "Basic".
