# Example usage:
#   ./regen-funcons.sh Basic

SpooDir="../SIMPLE-Editor"

echo "Generating funcons for all .smp files in ./$1"
java -jar ${SpooDir}/spoofax-sunshine.jar --auto-lang ${SpooDir}/include --project "$1" --builder "Generate Funcons" --build-on-all ./ --non-incremental
