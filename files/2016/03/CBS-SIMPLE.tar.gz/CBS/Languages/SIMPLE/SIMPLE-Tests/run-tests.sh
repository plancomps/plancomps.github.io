#!/bin/bash

function run-test-set {
  testName=$1
  testDir="$testName"
  runfct="../SIMPLE-interpreter/dist/build/runfct-SIMPLE/runfct-SIMPLE"
  fileext="smp"

  for i in $(seq -w $2 $3)
  do

    echo -e "$testName Test $i:"
    echo "=== Program ===" > ${testDir}/${testName}$i.output
    cat ${testDir}/${testName}$i.$fileext >> ${testDir}/${testName}$i.output
    echo "=== Output ===" >> ${testDir}/${testName}$i.output
    ${runfct} ${testDir}/${testName}$i.fct >> ${testDir}/${testName}$i.output

  done
}

run-test-set "Basic" 1 26
run-test-set "Advanced" 1 5
run-test-set "Kexceptions" 1 15
run-test-set "Kdiverse" 1 6
