-- GeNeRaTeD fOr: ../SIMPLE-cbs/SIMPLE/SIMPLE-4-Declarations.aterm
{-# LANGUAGE OverloadedStrings #-}

module Funcons.SIMPLE.SIMPLE4Declarations where

import Funcons.EDSL

entities = []

types = typeEnvFromList
    []

funcons = libFromList
    [("allocate-nested-vectors",StrictFuncon stepAllocate_nested_vectors)]

allocate_nested_vectors_ fargs = FApp "allocate-nested-vectors" (FTuple fargs)
stepAllocate_nested_vectors fargs =
    evalRules [rewrite1,rewrite2] []
    where rewrite1 = do
            let env = emptyEnv
            env <- vsMatch fargs [PList [VPMetaVar "N"]] env
            rewriteTermTo (TApp "allocate-initialised-variable" (TTuple [TApp "vectors" (TTuple [TApp "variables" (TTuple [TName "values"])]),TApp "allocate-vector" (TTuple [TName "values",TVar "N"])])) env
          rewrite2 = do
            let env = emptyEnv
            env <- vsMatch fargs [PList [VPMetaVar "N",VPSeqVar "N+" PlusOp]] env
            rewriteTermTo (TApp "allocate-initialised-variable" (TTuple [TApp "vectors" (TTuple [TApp "variables" (TTuple [TName "values"])]),TApp "vector-map" (TTuple [TApp "allocate-nested-vectors" (TList [TVar "N+"]),TApp "vector-repeat" (TTuple [TVar "N",TName "null"])])])) env