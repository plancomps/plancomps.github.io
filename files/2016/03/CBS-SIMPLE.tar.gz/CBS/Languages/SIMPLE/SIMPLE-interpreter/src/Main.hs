import Funcons.Tools (mkMainWithLibraryEntitiesTypes)
import Funcons.SIMPLE.Library
main = mkMainWithLibraryEntitiesTypes funcons entities types
