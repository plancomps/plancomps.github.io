module Funcons.SIMPLE.Library (
    funcons, entities, types,
   module Funcons.SIMPLE.SIMPLE4Declarations,
    ) where 
import Funcons.EDSL
import Funcons.SIMPLE.SIMPLE4Declarations hiding (funcons,types,entities)
import qualified Funcons.SIMPLE.SIMPLE4Declarations
funcons = libUnions
    [
     Funcons.SIMPLE.SIMPLE4Declarations.funcons
    ]
entities = concat 
    [
     Funcons.SIMPLE.SIMPLE4Declarations.entities
    ]
types = typeEnvUnions 
    [
     Funcons.SIMPLE.SIMPLE4Declarations.types
    ]
