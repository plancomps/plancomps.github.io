SIMPLE-cbs
==========

Before proceeding, ensure you have built the CBS-Editor project in Eclipse.
(See /CBS/README.txt)

Import the SIMPLE-cbs project into Eclipse.  It contains:
 * SIMPLE: The CBS definition of the SIMPLE language.
 * Funcons: The CBS definitions of all funcons in the funcon library.

If CBS-Editor has been built successfully, the CBS files should be displayed
with coloured syntax.

* * *

Note: If you only want to view the CBS files, then this is all you need.
The remaining instructions pertain to executing the translation functions and
executing the generated funcon terms.


SIMPLE-Editor
-------------

This is the Spoofax Editor project for editing SIMPLE programs, and
translating them to funcon terms.

Import and build this project in Eclipse prior to viewing any SIMPLE test
programs in Eclipse.  This is not required for running the SIMPLE tests from
the command line.


SIMPLE-Tests
------------

This contains a collection of SIMPLE test programs.

See SIMPLE-Tests/README.txt for instructions on how to run the translated
funcon terms from the command line.

Once SIMPLE-Editor has been built, you can import SIMPLE-Tests into Eclipse.
Then:
  - you can view the *.smp programs with syntax colouring.
  - you can translate SIMPLE programs to funcon terms by clicking on the
    "Generation" button while viewing a *.smp file.


SIMPLE-interpreter
------------------

To use the SIMPLE-specific funcon interpreter, you will first need to install
the main funcon interpreter (see /CBS/FCT-Interpeter/README.txt).

Then the SIMPLE-specific interpreter can be installed:

> cabal install

To run the interpreter from the command line, see the instructions in
SIMPLE-Tests/README.txt

To run the interpreter as an "external tool" from within Eclipse, follow the
instructions in "/CBS/FCT-Interpeter/README.txt", but use

"<path-to-SIMPLE-interpreter>/dist/build/runfct-SIMPLE/runfct-SIMPLE"

as the location of the interpreter executable.

To run the tests involving user-input interactively, also load the interactive
configuration file by providing the following flag before "${resource_loc}":

--config <path-to-SIMPLE-Tests>/SIMPLE-interactive.config
