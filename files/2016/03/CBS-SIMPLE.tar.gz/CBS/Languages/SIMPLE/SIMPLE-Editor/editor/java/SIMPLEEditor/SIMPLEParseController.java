package SIMPLEEditor;

public class SIMPLEParseController extends SIMPLEParseControllerGenerated 
{ }