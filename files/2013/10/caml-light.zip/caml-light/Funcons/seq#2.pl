% Generated from Funcons/seq#2.csf

sigdec(seq,A,[comm,A]).

onestep(seq(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(seq(J,K),L).

onestep(seq(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(seq(J,K),L).

onestep(seq(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(seq(G,H),I).

rewrite(seq(A,B),D) :-     rewrites(A,skip),     rewrites(B,C),     rewrites(C,D).

onestep(seq(A,B),J,G,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,skip) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,G) ->     post_comp(H,I,J). 

