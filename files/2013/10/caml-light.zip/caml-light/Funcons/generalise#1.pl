% Generated from Funcons/generalise#1.csf

sigdec(generalise,A,[A]).

onestep(generalise(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(generalise(E),F).

onestep(generalise(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(generalise(E),F).

onestep(generalise(A),D,forall(G,F),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E) ->     rewrites(instantiate_meta(E),F),     rewrites(free_vars(F),G).

onestep(generalise(A),B,D,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D).

sigdec(generalise_if_poly,A,[A]).

onestep(generalise_if_poly(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(generalise_if_poly(E),F).

onestep(generalise_if_poly(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(generalise_if_poly(E),F).

onestep(generalise_if_poly(A),D,E,inhabit) :-     rewrites(A,B),     rewrites(generalise(B),C),     inhabit(C,D,forall(list_empty,E)).

onestep(generalise_if_poly(A),D,forall(F,E),inhabit) :-     rewrites(A,B),     rewrites(generalise(B),C),     inhabit(C,D,forall(F,E)) ->     \+rewrites(F,list_empty). 

onestep(generalise_if_poly(A),B,D,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D).

sigdec(generalise_all,A,[A]).

onestep(generalise_all(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(generalise_all(E),F).

onestep(generalise_all(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(generalise_all(E),F).

onestep(generalise_all(A),D,F,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E) ->     rewrites(generalise_map(E),F). 

onestep(generalise_all(A),B,D,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D).

rewrite(generalise_map(A),B) :-     rewrites(A,map_empty),     rewrites(map_empty,B).

rewrite(generalise_map(A),O) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,G),     rewrites(C,J),     rewrites(D,F),     rewrites(instantiate_meta(J),E),     rewrites(free_vars(E),list_empty),     rewrites(generalise_map(F),K),     rewrites(G,H),     runcheck(H,id),     checktag(H,id,I),     rewrites(I,L),     rewrites(J,M),     rewrites(K,N),     rewrites(map_prefix(L,M,N),O).

rewrite(generalise_map(A),R) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,G),     rewrites(C,E),     rewrites(D,F),     rewrites(instantiate_meta(E),K),     rewrites(free_vars(K),J),     \+rewrites(J,list_empty),     rewrites(generalise_map(F),N),     rewrites(G,H),     runcheck(H,id),     checktag(H,id,I),     rewrites(I,O),     rewrites(J,L),     rewrites(K,M),     rewrites(forall(L,M),P),     rewrites(N,Q),     rewrites(map_prefix(O,P,Q),R).

