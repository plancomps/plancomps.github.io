% Generated from Funcons/close#1.csf

sigdec(close,abs,[abs]).

onestep(close(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(close(E),F).

onestep(close(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(close(E),F).

onestep(close(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(close(E),F).

sigdec(close,computes(abs),[computes(abs)]).

onestep(close(A),C,N,run) :-     rewrites(A,abs(B)),     rewrites(B,I),     rewrites(F,E),     eq_label(C,[env=D|H]),     rewrites(D,E),     rewrites(F,G),     runcheck(G,env),     checktag(G,env,J),     unobs(H),     rewrites(I,K),     rewrites(J,L),     rewrites(closure(K,L),M),     rewrites(abs(M),N).

onestep(close(A),D,depends(E,F),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,depends(E,F)).

