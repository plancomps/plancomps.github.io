% Generated from Funcons/instantiate_type#2.csf

sigdec(instantiate_type,type,[type,list(type)]).

onestep(instantiate_type(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(instantiate_type(G,H),I).

onestep(instantiate_type(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(instantiate_type(J,K),L).

onestep(instantiate_type(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(instantiate_type(J,K),L).

sigdec(instantiate_type,type,[type,computes(list(type))]).

sigdec(type_abs,type,[list(typevar),type]).

onestep(type_abs(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(type_abs(G,H),I).

onestep(type_abs(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(type_abs(J,K),L).

onestep(type_abs(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(type_abs(J,K),L).

sigdec(type_abs,type,[computes(list(typevar)),type]).

rewrite(instantiate_type(A,D),L) :-     rewrites(A,type_abs(B,C)),     rewrites(B,F),     rewrites(C,E),     rewrites(D,G),     rewrites(E,J),     rewrites(F,H),     rewrites(G,I),     rewrites(map_zip(H,I),K),     rewrites(subst(J,K),L).

