% Generated from Funcons/scope#2.csf

sigdec(scope,A,[env,A]).

onestep(scope(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(scope(G,H),I).

onestep(scope(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(scope(J,K),L).

onestep(scope(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(scope(J,K),L).

sigdec(scope,A,[computes(env),A]).

onestep(scope(A,B),C,R,run) :-     rewrites(A,J),     rewrites(B,H),     rewrites(L,E),     eq_label(C,[env=D|G]),     rewrites(D,E),     rewrites(map_over(J,L),F),     I=[env=F|G],     runstep(H,I,O) ->     rewrites(J,K),     runcheck(K,env),     checktag(K,env,N),     rewrites(L,M),     runcheck(M,env),     checktag(M,env,_),     rewrites(N,P),     rewrites(O,Q),     rewrites(scope(P,Q),R).

rewrite(scope(A,B),H) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,env),     checktag(D,env,_),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,G),     rewrites(G,H).

onestep(scope(A,B),C,P,inhabit) :-     rewrites(A,G),     rewrites(B,M),     rewrites(K,E),     eq_label(C,[env=D|S]),     rewrites(D,E),     pre_comp(S,Q),     rewrites(K,F),     I=[env=F|Q],     rewrites(G,H),     inhabit(H,I,J) ->     mid_comp(Q,R),     rewrites(map_over(J,K),L),     O=[env=L|R],     rewrites(M,N),     inhabit(N,O,P) ->     post_comp(Q,R,S). 

