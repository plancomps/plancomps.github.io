% Generated from Funcons/forward#1.csf

sigdec(forward,computes(bindable),[fwd]).

onestep(forward(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(forward(E),F).

onestep(forward(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(forward(E),F).

onestep(forward(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(forward(E),F).

sigdec(forward,computes(bindable),[computes(fwd)]).

onestep(forward(A),M,K,run) :-     rewrites(A,E),     rewrites(L,C),     eq_label(M,[forwards=B|D]),     rewrites(B,C),     eq_label(D,[forwards+=_|G]),     rewrites(E,F),     runcheck(F,fwd),     checktag(F,fwd,H),     unobs(G),     rewrites(L,I),     rewrites(H,J),     rewrites(map_select(I,J),K),     rewrites(L,N),     eq_label(M,[forwards+=N|_]).

onestep(forward(A),D,map_select(C,B),inhabit) :-     rewrites(A,B),     rewrites(C,F),     eq_label(D,[forwards=E|G]),     rewrites(E,F),     unobs(G).

