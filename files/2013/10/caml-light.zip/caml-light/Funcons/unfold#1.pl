% Generated from Funcons/unfold#1.csf

sigdec(unfold,A,[A]).

onestep(unfold(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(unfold(E),F).

onestep(unfold(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(unfold(E),F).

onestep(unfold(A),B,N,inhabit) :-     rewrites(A,F),     rewrites(I,D),     eq_label(B,[env=C|Q]),     rewrites(C,D),     pre_comp(Q,O),     rewrites(I,E),     H=[env=E|O],     rewrites(F,G),     inhabit(G,H,rectype(J,L)) ->     mid_comp(O,P),     rewrites(map_update(I,J,rectype(J,L)),K),     M=[env=K|P],     typeval(L,M,N) ->     post_comp(O,P,Q). 

onestep(unfold(A),B,D,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D).

onestep(abs_1(A),B,depends(rectype(F,I),K),inhabit) :-     rewrites(A,unfold),     rewrites(E,D),     eq_label(B,[env=C|H]),     rewrites(C,D),     rewrites(map_update(E,F,rectype(F,I)),G),     J=[env=G|H],     typeval(I,J,K).

sigdec(unfold_poly,A,[A]).

onestep(unfold_poly(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(unfold_poly(E),F).

onestep(unfold_poly(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(unfold_poly(E),F).

onestep(unfold_poly(A),B,P,inhabit) :-     rewrites(A,F),     rewrites(J,D),     eq_label(B,[env=C|S]),     rewrites(C,D),     pre_comp(S,Q),     rewrites(J,E),     H=[env=E|Q],     rewrites(F,G),     inhabit(G,H,instantiate_type(rectype(K,L),I)) ->     mid_comp(Q,R),     rewrites(instantiate_type(L,I),N),     rewrites(map_update(J,K,rectype(K,L)),M),     O=[env=M|R],     typeval(N,O,P) ->     post_comp(Q,R,S). 

onestep(unfold_poly(A),B,N,inhabit) :-     rewrites(A,F),     rewrites(I,D),     eq_label(B,[env=C|Q]),     rewrites(C,D),     pre_comp(Q,O),     rewrites(I,E),     H=[env=E|O],     rewrites(F,G),     inhabit(G,H,rectype(J,L)) ->     mid_comp(O,P),     rewrites(map_update(I,J,rectype(J,L)),K),     M=[env=K|P],     typeval(L,M,N) ->     post_comp(O,P,Q). 

onestep(unfold_poly(A),B,D,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D).

