% Generated from Funcons/partial_app#2.csf

sigdec(partial_app,abs,[abs,expressible]).

onestep(partial_app(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(partial_app(G,H),I).

onestep(partial_app(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(partial_app(G,H),I).

onestep(partial_app(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(partial_app(J,K),L).

onestep(partial_app(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(partial_app(J,K),L).

sigdec(partial_app,computes(abs),[computes(abs),computes(expressible)]).

rewrite(partial_app(A,B),N) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,abs),     checktag(D,abs,G),     rewrites(E,F),     runcheck(F,expressible),     checktag(F,expressible,H),     rewrites(G,K),     rewrites(H,I),     rewrites(given,J),     rewrites(tuple2(I,J),L),     rewrites(apply(K,L),M),     rewrites(abs(M),N).

onestep(partial_app(A,B),L,depends(H,I),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(L,J),     rewrites(C,D),     inhabit(D,J,G) ->     mid_comp(J,K),     rewrites(E,F),     inhabit(F,K,depends(tuple2(G,H),I)) ->     post_comp(J,K,L). 

