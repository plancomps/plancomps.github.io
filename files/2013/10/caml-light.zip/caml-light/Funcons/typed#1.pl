% Generated from Funcons/typed#1.csf

sigdec(typed,type,[computes(val),type]).

onestep(typed(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(typed(J,K),L).

onestep(typed(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(typed(J,K),L).

onestep(typed(A,B),E,F,inhabit) :-     rewrites(A,C),     rewrites(B,F),     rewrites(C,D),     inhabit(D,E,F).

onestep(typed(A,B),C,E,run) :-     rewrites(A,D),     rewrites(B,_),     unobs(C),     rewrites(D,E).

