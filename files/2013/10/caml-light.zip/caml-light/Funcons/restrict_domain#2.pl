% Generated from Funcons/restrict_domain#2.csf

sigdec(restrict_domain,abs,[abs,type]).

onestep(restrict_domain(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(restrict_domain(G,H),I).

onestep(restrict_domain(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(restrict_domain(J,K),L).

onestep(restrict_domain(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(restrict_domain(J,K),L).

sigdec(restrict_domain,computes(abs),[computes(abs),type]).

onestep(restrict_domain(A,B),E,G,run) :-     rewrites(A,C),     rewrites(B,_),     rewrites(C,D),     runcheck(D,abs),     checktag(D,abs,F),     unobs(E),     rewrites(F,G).

onestep(restrict_domain(A,B),J,depends(F,G),inhabit) :-     rewrites(A,D),     rewrites(B,C),     pre_comp(J,H),     typeval(C,H,F) ->     mid_comp(H,I),     rewrites(D,E),     inhabit(E,I,depends(F,G)) ->     post_comp(H,I,J). 

