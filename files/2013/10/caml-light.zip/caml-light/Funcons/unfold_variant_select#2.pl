% Generated from Funcons/unfold_variant_select#2.csf

sigdec(unfold_variant_select,patt,[atom,patt]).

onestep(unfold_variant_select(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(unfold_variant_select(G,H),I).

onestep(unfold_variant_select(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(unfold_variant_select(G,H),I).

onestep(unfold_variant_select(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(unfold_variant_select(J,K),L).

onestep(unfold_variant_select(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(unfold_variant_select(J,K),L).

sigdec(unfold_variant_select,computes(patt),[computes(atom),computes(patt)]).

onestep(unfold_variant_select(A,B),E,O,run) :-     rewrites(A,F),     rewrites(B,C),     rewrites(C,D),     runcheck(D,patt),     checktag(D,patt,H),     unobs(E),     rewrites(variant,I),     rewrites(F,G),     rewrites(only(G),J),     rewrites(H,K),     rewrites(invert_1(I,J,K),M),     rewrites(unfold_poly,L),     rewrites(abs_1(L),N),     rewrites(compose(M,N),O).

onestep(unfold_variant_select(A,B),C,depends(instantiate_type(rectype(H,I),F),S),inhabit) :-     rewrites(A,O),     rewrites(B,P),     rewrites(G,E),     eq_label(C,[env=D|V]),     rewrites(D,E),     rewrites(instantiate_type(I,F),K),     pre_comp(V,T),     rewrites(map_update(G,H,rectype(H,I)),J),     L=[env=J|T],     typeval(K,L,M) ->     mid_comp(T,U),     rewrites(M,variant(N)),     rewrites(map_select(N,O),R),     rewrites(P,Q),     inhabit(Q,U,depends(R,S)) ->     post_comp(T,U,V). 

onestep(unfold_variant_select(A,B),C,depends(rectype(G,I),Q),inhabit) :-     rewrites(A,M),     rewrites(B,N),     rewrites(F,E),     eq_label(C,[env=D|T]),     rewrites(D,E),     pre_comp(T,R),     rewrites(map_update(F,G,rectype(G,I)),H),     J=[env=H|R],     typeval(I,J,K) ->     mid_comp(R,S),     rewrites(K,variant(L)),     rewrites(map_select(L,M),P),     rewrites(N,O),     inhabit(O,S,depends(P,Q)) ->     post_comp(R,S,T). 

