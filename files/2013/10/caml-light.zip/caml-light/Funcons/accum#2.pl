% Generated from Funcons/accum#2.csf

sigdec(accum,decl,[env,decl]).

onestep(accum(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(accum(G,H),I).

onestep(accum(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(accum(J,K),L).

onestep(accum(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(accum(J,K),L).

sigdec(accum,decl,[computes(env),decl]).

rewrite(accum(A,B),K) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,env),     checktag(D,env,F),     rewrites(F,I),     rewrites(E,G),     rewrites(F,H),     rewrites(map_over(G,H),J),     rewrites(scope(I,J),K).

onestep(accum(A,B),C,map_over(P,J),inhabit) :-     rewrites(A,G),     rewrites(B,M),     rewrites(K,E),     eq_label(C,[env=D|S]),     rewrites(D,E),     pre_comp(S,Q),     rewrites(K,F),     I=[env=F|Q],     rewrites(G,H),     inhabit(H,I,J) ->     mid_comp(Q,R),     rewrites(map_over(J,K),L),     O=[env=L|R],     rewrites(M,N),     inhabit(N,O,P) ->     post_comp(Q,R,S). 

