% Generated from Funcons/any#0.csf

sigdec(any,patt,[]).

onestep(any,A,B,resolve) :-     unobs(A),     rewrites(any,B).

onestep(any,A,B,typeval) :-     unobs(A),     rewrites(any,B).

rewrite(any,B) :-     rewrites(map_empty,A),     rewrites(abs(A),B).

onestep(any,A,depends(_,map_empty),inhabit) :-     unobs(A).

