% Generated from Funcons/else#2.csf

sigdec(else,A,[A,A]).

onestep(else(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(else(J,K),L).

onestep(else(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(else(J,K),L).

onestep(else(A,B),M,L,run) :-     rewrites(A,D),     rewrites(B,I),     eq_label(M,[failure+=_|C]),     E=[failure+=_|C],     runstep(D,E,H) ->     rewrites(false,G),     eq_label(E,[failure+=F|_]),     rewrites(F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(else(J,K),L),     rewrites(false,N),     eq_label(M,[failure+=N|_]).

onestep(else(A,B),J,I,run) :-     rewrites(A,D),     rewrites(B,H),     eq_label(J,[failure+=_|C]),     E=[failure+=_|C],     runstep(D,E,_) ->     rewrites(true,G),     eq_label(E,[failure+=F|_]),     rewrites(F,G),     rewrites(H,I),     rewrites(false,K),     eq_label(J,[failure+=K|_]).

rewrite(else(A,B),F) :-     rewrites(A,C),     rewrites(B,_),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,E),     rewrites(E,F).

onestep(else(A,B),J,G,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,G) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,G) ->     post_comp(H,I,J). 

