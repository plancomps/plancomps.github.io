% Generated from Funcons/alloc#1.csf

sigdec(alloc,computes(variable),[storable]).

onestep(alloc(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(alloc(E),F).

onestep(alloc(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(alloc(E),F).

onestep(alloc(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(alloc(E),F).

sigdec(alloc,computes(variable),[computes(storable)]).

onestep(alloc(A),L,H,run) :-     rewrites(A,E),     rewrites(I,C),     eq_label(L,[store=B|D]),     rewrites(B,C),     eq_label(D,[store+=_|G]),     rewrites(store_freshvar(I),J),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,K),     unobs(G),     rewrites(J,H),     rewrites(map_update(I,J,K),M),     eq_label(L,[store+=M|_]).

onestep(alloc(A),D,variable(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

sigdec(fresh_alloc,variable,[type]).

onestep(fresh_alloc(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(fresh_alloc(E),F).

onestep(fresh_alloc(A),J,F,resolve) :-     rewrites(A,I),     rewrites(G,C),     eq_label(J,[store=B|D]),     rewrites(B,C),     eq_label(D,[store+=_|E]),     rewrites(store_freshvar(G),H),     unobs(E),     rewrites(H,F),     rewrites(map_update(G,H,I),K),     eq_label(J,[store+=K|_]).

