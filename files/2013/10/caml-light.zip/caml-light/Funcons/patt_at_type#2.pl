% Generated from Funcons/patt_at_type#2.csf

sigdec(patt_at_type,computes(patt),[patt,type]).

onestep(patt_at_type(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(patt_at_type(G,H),I).

onestep(patt_at_type(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(patt_at_type(J,K),L).

onestep(patt_at_type(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(patt_at_type(J,K),L).

sigdec(patt_at_type,computes(patt),[computes(patt),type]).

onestep(patt_at_type(A,B),E,G,run) :-     rewrites(A,C),     rewrites(B,_),     rewrites(C,D),     runcheck(D,patt),     checktag(D,patt,F),     unobs(E),     rewrites(F,G).

onestep(patt_at_type(A,B),J,depends(F,G),inhabit) :-     rewrites(A,D),     rewrites(B,C),     pre_comp(J,H),     onestep(C,H,F,resolve) ->     mid_comp(H,I),     rewrites(D,E),     inhabit(E,I,depends(F,G)) ->     post_comp(H,I,J). 

onestep(patt_at_type(A,B),E,depends(F,G),inhabit) :-     rewrites(A,C),     rewrites(B,F),     rewrites(C,D),     inhabit(D,E,depends(F,G)).

