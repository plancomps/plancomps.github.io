% Generated from Funcons/patt_union#2.csf

sigdec(patt_union,patt,[patt,patt]).

onestep(patt_union(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(patt_union(G,H),I).

onestep(patt_union(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(patt_union(G,H),I).

onestep(patt_union(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(patt_union(J,K),L).

onestep(patt_union(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(patt_union(J,K),L).

sigdec(patt_union,computes(patt),[computes(patt),computes(patt)]).

rewrite(patt_union(A,C),J) :-     rewrites(A,abs(B)),     rewrites(B,E),     rewrites(C,abs(D)),     rewrites(D,F),     rewrites(E,G),     rewrites(F,H),     rewrites(map_union(G,H),I),     rewrites(abs(I),J).

onestep(patt_union(A,B),M,depends(G,J),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(M,K),     rewrites(C,D),     inhabit(D,K,depends(G,H)) ->     mid_comp(K,L),     rewrites(E,F),     inhabit(F,L,depends(G,I)) ->     rewrites(map_union(H,I),J),     post_comp(K,L,M).

