% Generated from Funcons/rectype#2.csf

sigdec(rectype,type,[typeid,type]).

onestep(rectype(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(rectype(G,H),I).

onestep(rectype(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(rectype(J,K),L).

sigdec(rectype,type,[computes(typeid),type]).

onestep(rectype(A,B),C,H,typeval) :-     rewrites(A,D),     rewrites(B,E),     unobs(C),     rewrites(D,F),     rewrites(E,G),     rewrites(rectype(F,G),H).

