% Generated from Funcons/curry#1.csf

sigdec(curry_expr,abs,[abs]).

onestep(curry_expr(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(curry_expr(E),F).

onestep(curry_expr(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(curry_expr(E),F).

onestep(curry_expr(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(curry_expr(E),F).

sigdec(curry_expr,computes(abs),[computes(abs)]).

sigdec(curry,abs,[abs]).

onestep(curry(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(curry(E),F).

onestep(curry(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(curry(E),F).

onestep(curry(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(curry(E),F).

sigdec(curry,computes(abs),[computes(abs)]).

onestep(curry_expr(A),B,N,run) :-     rewrites(A,G),     rewrites(E,D),     eq_label(B,[given=C|I]),     rewrites(C,D),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,K),     rewrites(G,H),     runcheck(H,abs),     checktag(H,abs,J),     unobs(I),     rewrites(J,L),     rewrites(K,M),     rewrites(partial_app(L,M),N).

onestep(curry_expr(A),B,I,inhabit) :-     rewrites(A,E),     rewrites(H,D),     eq_label(B,[given=C|G]),     rewrites(C,D),     rewrites(E,F),     inhabit(F,G,depends(tuple_prefix(H,tuple_prefix(J,tuple_empty)),K)) ->     rewrites(I,depends(J,K)). 

rewrite(curry(A),G) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,abs),     checktag(C,abs,D),     rewrites(D,E),     rewrites(curry_expr(E),F),     rewrites(abs(F),G).

onestep(curry(A),D,G,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,depends(tuple_prefix(H,tuple_prefix(E,tuple_empty)),F)) ->     rewrites(I,depends(E,F)),     rewrites(G,depends(H,I)).

