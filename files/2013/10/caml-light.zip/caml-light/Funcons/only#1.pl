% Generated from Funcons/only#1.csf

sigdec(only,patt,[expressible]).

onestep(only(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(only(E),F).

onestep(only(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(only(E),F).

onestep(only(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(only(E),F).

sigdec(only,computes(patt),[computes(expressible)]).

rewrite(only(A),G) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,expressible),     checktag(C,expressible,D),     rewrites(D,E),     rewrites(only_decl(E),F),     rewrites(abs(F),G).

onestep(only(A),D,depends(E,map_empty),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

sigdec(only_decl,decl,[expressible]).

onestep(only_decl(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(only_decl(E),F).

onestep(only_decl(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(only_decl(E),F).

onestep(only_decl(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(only_decl(E),F).

sigdec(only_decl,decl,[computes(expressible)]).

onestep(only_decl(A),B,I,run) :-     rewrites(A,F),     rewrites(F,D),     eq_label(B,[given=C|H]),     rewrites(C,D),     rewrites(F,E),     runcheck(E,ground),     checktag(E,ground,_),     rewrites(F,G),     runcheck(G,expressible),     checktag(G,expressible,_),     unobs(H),     rewrites(map_empty,I).

onestep(only_decl(A),M,L,run) :-     rewrites(A,I),     rewrites(G,C),     eq_label(M,[given=B|D]),     rewrites(B,C),     eq_label(D,[failure+=_|K]),     rewrites(G,E),     runcheck(E,ground),     checktag(E,ground,_),     rewrites(I,F),     runcheck(F,ground),     checktag(F,ground,_),     \+rewrites(G,I),     rewrites(G,H),     runcheck(H,expressible),     checktag(H,expressible,_),     rewrites(I,J),     runcheck(J,expressible),     checktag(J,expressible,_),     unobs(K),     rewrites(stuck,L),     rewrites(true,N),     eq_label(M,[failure+=N|_]).

onestep(only_decl(A),B,map_empty,inhabit) :-     rewrites(A,E),     rewrites(H,D),     eq_label(B,[given=C|G]),     rewrites(C,D),     rewrites(E,F),     inhabit(F,G,H).

