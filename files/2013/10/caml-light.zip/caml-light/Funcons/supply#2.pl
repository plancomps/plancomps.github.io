% Generated from Funcons/supply#2.csf

sigdec(supply,computes(A),[_,computes(A)]).

onestep(supply(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(supply(G,H),I).

onestep(supply(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(supply(J,K),L).

onestep(supply(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(supply(J,K),L).

sigdec(supply,computes(A),[_,computes(A)]).

onestep(supply(A,B),C,P,run) :-     rewrites(A,J),     rewrites(B,H),     rewrites(_,E),     eq_label(C,[given=D|G]),     rewrites(D,E),     rewrites(J,F),     I=[given=F|G],     runstep(H,I,M) ->     rewrites(J,K),     runcheck(K,val),     checktag(K,val,L),     rewrites(L,N),     rewrites(M,O),     rewrites(supply(N,O),P).

rewrite(supply(A,B),H) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,_),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,G),     rewrites(G,H).

onestep(supply(A,B),M,J,inhabit) :-     rewrites(A,C),     rewrites(B,G),     pre_comp(M,K),     rewrites(C,D),     inhabit(D,K,E) ->     mid_comp(K,L),     rewrites(E,F),     I=[given=F|L],     rewrites(G,H),     inhabit(H,I,J) ->     post_comp(K,L,M). 

