% Generated from Funcons/instantiate_poly#1.csf

sigdec(forall,type,[list(typevar),type]).

onestep(forall(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(forall(G,H),I).

onestep(forall(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(forall(J,K),L).

sigdec(forall,type,[computes(list(typevar)),type]).

onestep(forall(A,B),D,F,typeval) :-     rewrites(A,list_empty),     rewrites(B,C),     typeval(C,D,E) ->     rewrites(E,F). 

sigdec(instantiate_poly,A,[A]).

onestep(instantiate_poly(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(instantiate_poly(E),F).

onestep(instantiate_poly(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(instantiate_poly(E),F).

onestep(instantiate_poly(A),B,K,inhabit) :-     rewrites(A,H),     rewrites(E,D),     eq_label(B,[env=C|G]),     rewrites(C,D),     rewrites(E,F),     J=[env=F|G],     rewrites(H,I),     inhabit(I,J,forall(M,L)) ->     rewrites(K,subst(L,list_to_map(M))). 

onestep(instantiate_poly(A),B,D,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D).

sigdec(list_to_map,map(A,_),[list(A)]).

onestep(list_to_map(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(list_to_map(E),F).

onestep(list_to_map(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(list_to_map(E),F).

onestep(list_to_map(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(list_to_map(E),F).

sigdec(list_to_map,computes(map(A,_)),[computes(list(A))]).

rewrite(list_to_map(A),B) :-     rewrites(A,list_empty),     rewrites(map_empty,B).

rewrite(list_to_map(A),J) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,F),     rewrites(C,D),     rewrites(D,E),     rewrites(list_to_map(E),G),     rewrites(F,H),     rewrites(_,I),     rewrites(map_update(G,H,I),J).

sigdec(instantiate_if_poly,A,[A]).

onestep(instantiate_if_poly(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(instantiate_if_poly(E),F).

onestep(instantiate_if_poly(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(instantiate_if_poly(E),F).

onestep(instantiate_if_poly(A),H,D,inhabit) :-     rewrites(A,B),     pre_comp(H,F),     rewrites(B,C),     inhabit(C,F,D) ->     mid_comp(F,G),     typeval(D,G,E) ->     different(E,forall(_,_)),     post_comp(F,G,H).

onestep(instantiate_if_poly(A),D,E,inhabit) :-     rewrites(A,B),     rewrites(instantiate_poly(B),C),     inhabit(C,D,E).

onestep(instantiate_if_poly(A),B,D,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D).

