% Generated from Funcons/print#1.csf

sigdec(print,comm,[expressible]).

onestep(print(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(print(E),F).

onestep(print(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(print(E),F).

onestep(print(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(print(E),F).

sigdec(print,comm,[computes(expressible)]).

onestep(print(A),G,E,run) :-     rewrites(A,B),     eq_label(G,[output+=_|D]),     rewrites(B,C),     runcheck(C,expressible),     checktag(C,expressible,F),     unobs(D),     rewrites(skip,E),     rewrites(list_prefix(F,list_empty),H),     eq_label(G,[output+=H|_]).

onestep(print(A),D,skip,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,_).

