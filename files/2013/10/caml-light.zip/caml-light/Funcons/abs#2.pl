% Generated from Funcons/abs#2.csf

sigdec(abs,abs,[patt,expr]).

onestep(abs(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(abs(G,H),I).

onestep(abs(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(abs(J,K),L).

onestep(abs(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(abs(J,K),L).

sigdec(abs,computes(abs),[computes(patt),expr]).

rewrite(abs(A,B),L) :-     rewrites(A,C),     rewrites(B,H),     rewrites(C,D),     runcheck(D,patt),     checktag(D,patt,E),     rewrites(given,F),     rewrites(E,G),     rewrites(match(F,G),I),     rewrites(H,J),     rewrites(scope(I,J),K),     rewrites(abs(K),L).

onestep(abs(A,B),C,depends(J,Q),inhabit) :-     rewrites(A,G),     rewrites(B,N),     rewrites(L,E),     eq_label(C,[env=D|T]),     rewrites(D,E),     pre_comp(T,R),     rewrites(L,F),     I=[env=F|R],     rewrites(G,H),     inhabit(H,I,depends(J,K)) ->     mid_comp(R,S),     rewrites(map_over(K,L),M),     P=[env=M|S],     rewrites(N,O),     inhabit(O,P,Q) ->     post_comp(R,S,T). 

