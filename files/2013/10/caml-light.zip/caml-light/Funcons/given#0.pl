% Generated from Funcons/given#0.csf

sigdec(given,computes(val),[]).

onestep(given,A,B,resolve) :-     unobs(A),     rewrites(given,B).

onestep(given,A,B,typeval) :-     unobs(A),     rewrites(given,B).

onestep(given,A,H,run) :-     rewrites(D,C),     eq_label(A,[given=B|F]),     rewrites(B,C),     \+rewrites(D,null),     rewrites(D,E),     runcheck(E,val),     checktag(E,val,G),     unobs(F),     rewrites(G,H).

onestep(given,B,A,inhabit) :-     rewrites(A,D),     eq_label(B,[given=C|E]),     rewrites(C,D),     unobs(E).

