% Generated from Funcons/typedef#2.csf

sigdec(typedef,decl,[typeid,type]).

onestep(typedef(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(typedef(G,H),I).

onestep(typedef(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(typedef(J,K),L).

onestep(typedef(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(typedef(J,K),L).

sigdec(typedef,decl,[computes(typeid),type]).

onestep(typedef(A,C),E,map1(B,F),inhabit) :-     rewrites(A,B),     rewrites(C,D),     typeval(D,E,F).

onestep(typedef(A,C),E,map1(B,D),inhabit) :-     rewrites(A,B),     rewrites(C,D),     unobs(E).

onestep(typedef(A,B),E,F,run) :-     rewrites(A,C),     rewrites(B,_),     rewrites(C,D),     runcheck(D,typeid),     checktag(D,typeid,_),     unobs(E),     rewrites(map_empty,F).

