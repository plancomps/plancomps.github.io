% Generated from Funcons/assigned_value#1.csf

sigdec(assigned_value,computes(storable),[variable]).

onestep(assigned_value(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(assigned_value(E),F).

onestep(assigned_value(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(assigned_value(E),F).

onestep(assigned_value(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(assigned_value(E),F).

sigdec(assigned_value,computes(storable),[computes(variable)]).

onestep(assigned_value(A),M,K,run) :-     rewrites(A,E),     rewrites(L,C),     eq_label(M,[store=B|D]),     rewrites(B,C),     eq_label(D,[store+=_|G]),     rewrites(E,F),     runcheck(F,variable),     checktag(F,variable,H),     unobs(G),     rewrites(L,I),     rewrites(H,J),     rewrites(map_select(I,J),K),     rewrites(L,N),     eq_label(M,[store+=N|_]).

onestep(assigned_value(A),H,E,inhabit) :-     rewrites(A,B),     pre_comp(H,F),     rewrites(B,C),     inhabit(C,F,D) ->     mid_comp(F,G),     subtype(D,G,variable(E)),     post_comp(F,G,H).

onestep(abs_1(B),C,depends(variable(A),A),inhabit) :-     rewrites(B,assigned_value),     unobs(C).

