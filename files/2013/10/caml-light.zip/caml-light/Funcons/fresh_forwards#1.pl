% Generated from Funcons/fresh_forwards#1.csf

sigdec(fresh_forwards,computes(map(A,fwd)),[list(A)]).

onestep(fresh_forwards(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(fresh_forwards(E),F).

onestep(fresh_forwards(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(fresh_forwards(E),F).

onestep(fresh_forwards(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(fresh_forwards(E),F).

sigdec(fresh_forwards,computes(map(A,fwd)),[computes(list(A))]).

rewrite(fresh_forwards(A),B) :-     rewrites(A,list_empty),     rewrites(map_empty,B).

onestep(fresh_forwards(A),S,P,run) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,J),     rewrites(C,K),     rewrites(Q,E),     eq_label(S,[forwards=D|F]),     rewrites(D,E),     eq_label(F,[forwards+=_|I]),     rewrites(forwards_fresh(Q),G),     rewrites(G,H),     runcheck(H,fwd),     checktag(H,fwd,R),     unobs(I),     rewrites(J,M),     rewrites(R,N),     rewrites(K,L),     rewrites(fresh_forwards(L),O),     rewrites(map_prefix(M,N,O),P),     rewrites(map_update(Q,R,undefined),T),     eq_label(S,[forwards+=T|_]).

