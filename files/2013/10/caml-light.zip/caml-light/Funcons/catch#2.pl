% Generated from Funcons/catch#2.csf

sigdec(catch,expr,[expr,abs]).

onestep(catch(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(catch(G,H),I).

onestep(catch(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(catch(J,K),L).

onestep(catch(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(catch(J,K),L).

sigdec(catch,expr,[expr,computes(abs)]).

onestep(catch(A,B),O,N,run) :-     rewrites(A,D),     rewrites(B,H),     eq_label(O,[exception+=_|C]),     E=[exception+=_|C],     runstep(D,E,J) ->     rewrites(none,G),     eq_label(E,[exception+=F|_]),     rewrites(F,G),     rewrites(H,I),     runcheck(I,abs),     checktag(I,abs,K),     rewrites(J,L),     rewrites(K,M),     rewrites(catch(L,M),N),     rewrites(none,P),     eq_label(O,[exception+=P|_]).

onestep(catch(A,B),Q,P,run) :-     rewrites(A,D),     rewrites(B,H),     eq_label(Q,[exception+=_|C]),     E=[exception+=_|C],     runstep(D,E,_) ->     rewrites(some(J),G),     eq_label(E,[exception+=F|_]),     rewrites(F,G),     rewrites(H,I),     runcheck(I,abs),     checktag(I,abs,L),     rewrites(J,K),     runcheck(K,throwable),     checktag(K,throwable,M),     rewrites(L,N),     rewrites(M,O),     rewrites(apply(N,O),P),     rewrites(none,R),     eq_label(Q,[exception+=R|_]).

rewrite(catch(A,B),H) :-     rewrites(A,E),     rewrites(B,C),     rewrites(C,D),     runcheck(D,abs),     checktag(D,abs,_),     rewrites(E,F),     runcheck(F,expressible),     checktag(F,expressible,G),     rewrites(G,H).

onestep(catch(A,B),P,I,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(P,N),     rewrites(C,D),     inhabit(D,N,G) ->     mid_comp(N,O),     pre_comp(O,L),     rewrites(E,F),     inhabit(F,L,depends(_,H)) ->     mid_comp(L,M),     pre_comp(M,J),     subtype(G,J,I),     mid_comp(J,K),     subtype(H,K,I),     post_comp(J,K,M),     post_comp(L,M,O),     post_comp(N,O,P).

