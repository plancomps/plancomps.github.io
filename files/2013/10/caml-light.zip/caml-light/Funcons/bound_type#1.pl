% Generated from Funcons/bound_type#1.csf

sigdec(bound_type,type,[id]).

onestep(bound_type(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(bound_type(E),F).

onestep(bound_type(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(bound_type(E),F).

sigdec(bound_type,type,[computes(id)]).

onestep(bound_type(A),B,I,typeval) :-     rewrites(A,F),     rewrites(E,D),     eq_label(B,[env=C|G]),     rewrites(C,D),     rewrites(map_select(E,F),H),     unobs(G),     rewrites(H,I).

