% Generated from Funcons/bound_value#1.csf

sigdec(bound_value,computes(bindable),[id]).

onestep(bound_value(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(bound_value(E),F).

onestep(bound_value(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(bound_value(E),F).

onestep(bound_value(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(bound_value(E),F).

sigdec(bound_value,computes(bindable),[computes(id)]).

onestep(bound_value(A),B,N,run) :-     rewrites(A,G),     rewrites(E,D),     eq_label(B,[env=C|I]),     rewrites(C,D),     rewrites(E,F),     runcheck(F,env),     checktag(F,env,J),     rewrites(G,H),     runcheck(H,id),     checktag(H,id,K),     unobs(I),     rewrites(J,L),     rewrites(K,M),     rewrites(map_select(L,M),N).

onestep(bound_value(A),D,map_select(C,B),inhabit) :-     rewrites(A,B),     rewrites(C,F),     eq_label(D,[env=E|G]),     rewrites(E,F),     unobs(G).

