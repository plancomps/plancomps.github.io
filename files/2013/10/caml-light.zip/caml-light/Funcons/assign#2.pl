% Generated from Funcons/assign#2.csf

sigdec(assign,comm,[variable,storable]).

onestep(assign(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(assign(G,H),I).

onestep(assign(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(assign(G,H),I).

onestep(assign(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(assign(J,K),L).

onestep(assign(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(assign(J,K),L).

sigdec(assign,comm,[computes(variable),computes(storable)]).

onestep(assign(A,B),O,K,run) :-     rewrites(A,H),     rewrites(B,F),     rewrites(L,D),     eq_label(O,[store=C|E]),     rewrites(C,D),     eq_label(E,[store+=_|J]),     rewrites(contains_key(L,H),true),     rewrites(F,G),     runcheck(G,storable),     checktag(G,storable,N),     rewrites(H,I),     runcheck(I,variable),     checktag(I,variable,M),     unobs(J),     rewrites(skip,K),     rewrites(map_update(L,M,N),P),     eq_label(O,[store+=P|_]).

onestep(assign(A,B),M,skip,inhabit) :-     rewrites(A,C),     rewrites(B,H),     pre_comp(M,K),     pre_comp(K,F),     rewrites(C,D),     inhabit(D,F,E) ->     mid_comp(F,G),     subtype(E,G,variable(J)),     post_comp(F,G,K),     mid_comp(K,L),     rewrites(H,I),     inhabit(I,L,J) ->     post_comp(K,L,M). 

