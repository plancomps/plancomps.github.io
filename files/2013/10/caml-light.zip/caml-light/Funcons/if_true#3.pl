% Generated from Funcons/if_true#3.csf

sigdec(if_true,A,[boolean,A,A]).

onestep(if_true(A,B,C),E,L,run) :-     rewrites(A,D),     rewrites(B,G),     rewrites(C,H),     runstep(D,E,F) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(if_true(I,J,K),L).

onestep(if_true(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(if_true(O,P,Q),R).

onestep(if_true(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(if_true(O,P,Q),R).

sigdec(if_true,A,[computes(boolean),A,A]).

rewrite(if_true(A,B,C),E) :-     rewrites(A,true),     rewrites(B,D),     rewrites(C,_),     rewrites(D,E).

rewrite(if_true(A,B,C),E) :-     rewrites(A,false),     rewrites(B,_),     rewrites(C,D),     rewrites(D,E).

onestep(if_true(A,B,C),O,J,inhabit) :-     rewrites(A,D),     rewrites(B,F),     rewrites(C,H),     pre_comp(O,M),     rewrites(D,E),     inhabit(E,M,boolean) ->     mid_comp(M,N),     pre_comp(N,K),     rewrites(F,G),     inhabit(G,K,J) ->     mid_comp(K,L),     rewrites(H,I),     inhabit(I,L,J) ->     post_comp(K,L,N),     post_comp(M,N,O).

