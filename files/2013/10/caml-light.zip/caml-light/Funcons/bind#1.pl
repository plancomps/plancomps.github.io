% Generated from Funcons/bind#1.csf

sigdec(bind,patt,[id]).

onestep(bind(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(bind(E),F).

onestep(bind(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(bind(E),F).

onestep(bind(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(bind(E),F).

sigdec(bind,computes(patt),[computes(id)]).

rewrite(bind(A),G) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,id),     checktag(C,id,D),     rewrites(D,E),     rewrites(bind_decl(E),F),     rewrites(abs(F),G).

onestep(bind(B),D,depends(A,map1(C,A)),inhabit) :-     rewrites(B,C),     unobs(D).

onestep(bind_decl(A),D,map_update(map_empty,B,C),inhabit) :-     rewrites(A,B),     rewrites(C,F),     eq_label(D,[given=E|G]),     rewrites(E,F),     unobs(G).

onestep(bind_decl(A),B,M,run) :-     rewrites(A,E),     rewrites(I,D),     eq_label(B,[given=C|G]),     rewrites(C,D),     rewrites(E,F),     runcheck(F,id),     checktag(F,id,H),     unobs(G),     rewrites(map_empty,J),     rewrites(H,K),     rewrites(I,L),     rewrites(map_update(J,K,L),M).

