% Generated from Funcons/recursive_typed#2.csf

sigdec(recursive_typed,decl,[map(id,type),decl]).

onestep(recursive_typed(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(recursive_typed(G,H),I).

onestep(recursive_typed(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(recursive_typed(J,K),L).

onestep(recursive_typed(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(recursive_typed(J,K),L).

sigdec(recursive_typed,decl,[computes(map(id,type)),decl]).

onestep(recursive_typed(A,B),C,I,run) :-     rewrites(A,D),     rewrites(B,F),     unobs(C),     rewrites(D,E),     rewrites(map_domain(E),G),     rewrites(F,H),     rewrites(recursive(G,H),I).

onestep(recursive_typed(A,B),C,O,inhabit) :-     rewrites(A,G),     rewrites(B,K),     rewrites(I,E),     eq_label(C,[env=D|R]),     rewrites(D,E),     pre_comp(R,P),     rewrites(I,F),     H=[env=F|P],     typeval(typeval_all(G),H,N) ->     mid_comp(P,Q),     rewrites(map_over(N,I),J),     M=[env=J|Q],     rewrites(K,L),     inhabit(L,M,O) ->     rewrites(map_subset(N,O),true),     post_comp(P,Q,R).

onestep(typeval_all(A),B,C,typeval) :-     rewrites(A,map_empty),     unobs(B),     rewrites(map_empty,C).

onestep(typeval_all(A),I,P,typeval) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,J),     rewrites(C,E),     rewrites(D,F),     pre_comp(I,G),     typeval(E,G,K) ->     mid_comp(G,H),     typeval(typeval_all(F),H,L) ->     post_comp(G,H,I),     rewrites(J,M),     rewrites(K,N),     rewrites(L,O),     rewrites(map_prefix(M,N,O),P).

