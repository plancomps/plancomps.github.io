% Generated from Funcons/fold#1.csf

sigdec(fold,A,[A]).

onestep(fold(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(fold(E),F).

onestep(fold(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(fold(E),F).

onestep(fold(A),B,rectype(F,L),inhabit) :-     rewrites(A,I),     rewrites(E,D),     eq_label(B,[env=C|H]),     rewrites(C,D),     rewrites(map_update(E,F,rectype(F,L)),G),     K=[env=G|H],     rewrites(I,J),     inhabit(J,K,L).

onestep(fold(A),B,D,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D).

sigdec(fold_poly,A,[A]).

onestep(fold_poly(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(fold_poly(E),F).

onestep(fold_poly(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(fold_poly(E),F).

onestep(fold_poly(A),B,instantiate_type(rectype(G,H),E),inhabit) :-     rewrites(A,K),     rewrites(F,D),     eq_label(B,[env=C|J]),     rewrites(C,D),     rewrites(instantiate_type(H,E),N),     rewrites(map_update(F,G,rectype(G,H)),I),     M=[env=I|J],     rewrites(K,L),     inhabit(L,M,N).

onestep(fold_poly(A),B,rectype(F,L),inhabit) :-     rewrites(A,I),     rewrites(E,D),     eq_label(B,[env=C|H]),     rewrites(C,D),     rewrites(map_update(E,F,rectype(F,L)),G),     K=[env=G|H],     rewrites(I,J),     inhabit(J,K,L).

onestep(fold_poly(A),B,D,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D).

