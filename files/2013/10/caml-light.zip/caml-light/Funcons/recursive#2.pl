% Generated from Funcons/recursive#2.csf

sigdec(recursive,decl,[list(id),decl]).

onestep(recursive(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(recursive(G,H),I).

onestep(recursive(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(recursive(J,K),L).

onestep(recursive(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(recursive(J,K),L).

sigdec(recursive,decl,[computes(list(id)),decl]).

onestep(recursive(A,B),C,I,run) :-     rewrites(A,D),     rewrites(B,F),     unobs(C),     rewrites(D,E),     rewrites(fresh_forwards(E),G),     rewrites(F,H),     rewrites(reclose(G,H),I).

sigdec(reclose,decl,[map(id,fwd),decl]).

onestep(reclose(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(reclose(G,H),I).

onestep(reclose(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(reclose(J,K),L).

onestep(reclose(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(reclose(J,K),L).

sigdec(reclose,decl,[computes(map(id,fwd)),decl]).

rewrite(reclose(A,B),O) :-     rewrites(A,H),     rewrites(B,E),     rewrites(forward_env(H),C),     rewrites(C,D),     runcheck(D,env),     checktag(D,env,J),     rewrites(J,F),     rewrites(E,G),     rewrites(scope(F,G),M),     rewrites(H,I),     rewrites(set_forwards(I),K),     rewrites(J,L),     rewrites(seq(K,L),N),     rewrites(accum(M,N),O).

sigdec(forward_env,env,[map(id,fwd)]).

onestep(forward_env(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(forward_env(E),F).

onestep(forward_env(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(forward_env(E),F).

onestep(forward_env(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(forward_env(E),F).

sigdec(forward_env,computes(env),[computes(map(id,fwd))]).

rewrite(forward_env(A),B) :-     rewrites(A,map_empty),     rewrites(map_empty,B).

rewrite(forward_env(A),Q) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,E),     rewrites(C,G),     rewrites(D,L),     rewrites(E,F),     runcheck(F,id),     checktag(F,id,I),     rewrites(G,H),     runcheck(H,fwd),     checktag(H,fwd,J),     rewrites(I,N),     rewrites(J,K),     rewrites(forward(K),O),     rewrites(L,M),     rewrites(forward_env(M),P),     rewrites(map_prefix(N,O,P),Q).

sigdec(set_forwards,comm,[map(id,fwd)]).

onestep(set_forwards(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(set_forwards(E),F).

onestep(set_forwards(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(set_forwards(E),F).

onestep(set_forwards(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(set_forwards(E),F).

sigdec(set_forwards,comm,[computes(map(id,fwd))]).

rewrite(set_forwards(A),B) :-     rewrites(A,map_empty),     rewrites(skip,B).

onestep(set_forwards(A),Y,T,run) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,M),     rewrites(C,O),     rewrites(D,R),     rewrites(K,F),     eq_label(Y,[env=E|G]),     rewrites(E,F),     rewrites(U,I),     eq_label(G,[forwards=H|J]),     rewrites(H,I),     eq_label(J,[forwards+=_|Q]),     rewrites(K,L),     runcheck(L,env),     checktag(L,env,W),     rewrites(M,N),     runcheck(N,id),     checktag(N,id,X),     rewrites(O,P),     runcheck(P,fwd),     checktag(P,fwd,V),     unobs(Q),     rewrites(R,S),     rewrites(set_forwards(S),T),     rewrites(map_update(U,V,map_select(W,X)),Z),     eq_label(Y,[forwards+=Z|_]).

