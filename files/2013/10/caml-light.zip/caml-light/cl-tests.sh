echo -e "Generating Prolog..."

./gen-pl.sh

#For the CSF tests to work, need to add 'Staging' to the list of
#funcon directories in csf_pl.pl
#echo -e "Running CSF tests..."
#swipl -s Prolog/csf_test -g "tests,halt."

echo -e "Test Append:"

cd Languages/Caml-Light
../../gen-fct.sh -m CL-Translation -f CL-Tests/OL-Test/append.ml -o CL-Tests/OL-Test/append.fct

cd ../..
./run-fct.sh -f Languages/Caml-Light/CL-Tests/OL-Test/append.fct

for i in $(seq 1 23)
do

  echo "Test $i:"

  cd Languages/Caml-Light
  ../../gen-fct.sh -n -m CL-Translation -f CL-Tests/OL-Test/OL-Test$i.ml -o CL-Tests/OL-Test/OL-Test$i.fct

  echo "Running..."

  cd ../..
  ./run-fct.sh -f Languages/Caml-Light/CL-Tests/OL-Test/OL-Test$i.fct

  echo -e "\n\n"

done

cd Languages/Caml-Light
../../gen-fct.sh -n -m CL-Translation -f CL-Tests/OL-Test/vr.ml -o CL-Tests/OL-Test/vr.fct

cd ../..
./run-fct.sh -f Languages/Caml-Light/CL-Tests/OL-Test/vr.fct

#For the CSF tests to work, need to add 'Staging' to the list of
#funcon directories in csf_pl.pl
#echo -e "Running OL sorting tests..."
#swipl -s OL-sortcheck -g "oltests,halt."

# rm OcamlLight/Tests/*.fct OcamlLight/*.eqs OcamlLight/*.tbl


