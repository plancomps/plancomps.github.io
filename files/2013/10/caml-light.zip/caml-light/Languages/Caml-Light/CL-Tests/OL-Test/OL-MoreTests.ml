(* CHARS *)

'a';;
(* - : char = 'a' *)

(* FLOATS *)

let pi = 4.0 *. atan 1.0;;
(* val pi : float = 3.14159265358979312 *)

let square x = x *. x;;
(* val square : float -> float = <fun> *)

square(sin pi) +. square(cos pi);;
(* - : float = 1. *)

1.0 * 2;;
(* Error: This expression has type float 
   but an expression was expected of type int *)

(* STRINGS *)

"Hello world";;
(* - : string = "Hello world" *)

let l = ["is"; "a"; "tale"; "told"; "etc."];;
(* val l : string list = ["is"; "a"; "tale"; "told"; "etc."] *)

"Life" :: l;;
(* - : string list = ["Life"; "is"; "a"; "tale"; "told"; "etc."] *)

(* MORE FLOATS *)

sort [3.14; 2.718];;
(* - : float list = [2.718; 3.14] *)

let deriv f dx = function x -> (f(x +. dx) -. f(x)) /. dx;;
(* val deriv : (float -> float) -> float -> float -> float = <fun> *)

let sin' = deriv sin 1e-6;;
(* val sin' : float -> float = <fun> *)

sin' pi;;
(* - : float = -1.00000000013961143 *)
