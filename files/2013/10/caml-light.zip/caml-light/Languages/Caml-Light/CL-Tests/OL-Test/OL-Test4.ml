let rec (sort : 'a list -> 'a list) = fun (lst : 'a list) -> (
  match lst with
    [] -> []
  | head :: tail -> insert head (sort tail)
  : 'a list)
and (insert : 'a -> 'a list -> 'a list) = fun elt (lst : 'a list) -> (
  match lst with
    [] -> [elt]
  | head :: tail -> 
       if elt <= head then elt :: lst else head :: insert elt tail
: 'a list);;
(* val sort : 'a list -> 'a list = <fun>
   val insert : 'a -> 'a list -> 'a list = <fun> 
*)

sort [6;2;5;3];;
(* - : int list = [2; 3; 5; 6] *)

sort [3.14; 2.718];;
(* - : float list = [2.718; 3.14] *)
