(* value restriction test *)

let pair = ((fun x -> x), (fun y -> y));;
