type 'a ref = { mutable contents: 'a };;
(* type 'a ref = { mutable contents : 'a; } *)

let prefix ! r = r.contents;;
(* val ( ! ) : 'a ref -> 'a = <fun> *)

let prefix := r newval = r.contents <- newval;;
(* val ( := ) : 'a ref -> 'a -> unit = <fun> *)

let ref a = { contents = a };;

let current_rand = ref 0;;
(* val current_rand : int ref = {contents = 0} *)

let random () =
  current_rand := !current_rand * 25713 + 1345;
  !current_rand;;
(* val random : unit -> int = <fun> *)

random ();;
random ();;
random ();;
random ();;
random ();;