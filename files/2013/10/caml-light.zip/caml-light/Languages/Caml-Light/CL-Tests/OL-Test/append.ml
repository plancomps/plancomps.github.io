let rec (append : 'a list -> 'a list -> 'a list) =
  fun (xs : 'a list) (ys : 'a list) ->
  match xs with
  | [] -> ys
  | x::xs -> x::(append xs ys);;

append [1;2] [4;5];;
