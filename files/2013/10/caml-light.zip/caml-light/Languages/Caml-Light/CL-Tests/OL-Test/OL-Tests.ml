(* All the examples from Chapter 1 of the OCaml 4.0 User Manual *)
  
1+2*3;;
(* - : int = 7 *)

let pi = 4.0 *. atan 1.0;;
(* val pi : float = 3.14159265358979312 *)

let square x = x *. x;;
(* val square : float -> float = <fun> *)

square(sin pi) +. square(cos pi);;
(* - : float = 1. *)

1.0 * 2;;
(* Error: This expression has type float 
   but an expression was expected of type int *)

let rec fib n =
  if n < 2 then n else fib(n-1) + fib(n-2);;
(* val fib : int -> int = <fun> *)

fib 10;;
(* - : int = 55 *)

(1 < 2) = false;;
(* - : bool = false *)

'a';;
(* - : char = 'a' *)

"Hello world";;
(* - : string = "Hello world" *)

let l = ["is"; "a"; "tale"; "told"; "etc."];;
(* val l : string list = ["is"; "a"; "tale"; "told"; "etc."] *)

"Life" :: l;;
(* - : string list = ["Life"; "is"; "a"; "tale"; "told"; "etc."] *)

let rec sort lst =
  match lst with
    [] -> []
  | head :: tail -> insert head (sort tail)
and insert elt lst =
  match lst with
    [] -> [elt]
  | head :: tail -> 
       if elt <= head then elt :: lst else head :: insert elt tail
;;
(* val sort : 'a list -> 'a list = <fun>
   val insert : 'a -> 'a list -> 'a list = <fun> 
*)

sort l;;
(* - : string list = ["a"; "etc."; "is"; "tale"; "told"] *)

sort [6;2;5;3];;
(* - : int list = [2; 3; 5; 6] *)

sort [3.14; 2.718];;
(* - : float list = [2.718; 3.14] *)

let deriv f dx = function x -> (f(x +. dx) -. f(x)) /. dx;;
(* val deriv : (float -> float) -> float -> float -> float = <fun> *)

let sin' = deriv sin 1e-6;;
(* val sin' : float -> float = <fun> *)

sin' pi;;
(* - : float = -1.00000000013961143 *)

let compose f g = function x -> f(g(x));;
(* val compose : ('a -> 'b) -> ('c -> 'a) -> 'c -> 'b = <fun> *)

let cos2 = compose square cos;;
(* val cos2 : float -> float = <fun> *)

List.map (function n -> n * 2 + 1) [0;1;2;3;4];;
(* - : int list = [1; 3; 5; 7; 9] *)

let rec map f l =
  match l with
    [] -> []
  | hd :: tl -> f hd :: map f tl;;
(* val map : ('a -> 'b) -> 'a list -> 'b list = <fun> *)

type ratio = {num: int; denom: int};;
(* type ratio = { num : int; denom : int; } *)

let add_ratio r1 r2 =
  {num = r1.num * r2.denom + r2.num * r1.denom;
   denom = r1.denom * r2.denom};;
(* val add_ratio : ratio -> ratio -> ratio = <fun> *)

add_ratio {num=1; denom=3} {num=2; denom=5};;
(* - : ratio = {num = 11; denom = 15} *)

type number = Int of int | Float of float | Error;;
(* type number = Int of int | Float of float | Error *)

type sign = Positive | Negative;;
(* type sign = Positive | Negative *)

let sign_int n = if n >= 0 then Positive else Negative;;
(* val sign_int : int -> sign = <fun> *)

let add_num n1 n2 =
  match (n1, n2) with
    (Int i1, Int i2) ->
      (* Check for map_overflow of integer addition *)
      if sign_int i1 = sign_int i2 && sign_int(i1 + i2) <> sign_int i1
      then Float(float i1 +. float i2)
      else Int(i1 + i2)
  | (Int i1, Float f2) -> Float(float i1 +. f2)
  | (Float f1, Int i2) -> Float(f1 +. float i2)
  | (Float f1, Float f2) -> Float(f1 +. f2)
  | (Error, _) -> Error
  | (_, Error) -> Error;;
(* val add_num : number -> number -> number = <fun> *)

add_num (Int 123) (Float 3.14159);;
(* - : number = Float 126.14159 *)

type 'a btree = Empty | Node of 'a * 'a btree * 'a btree;;
(* type 'a btree = Empty | Node of 'a * 'a btree * 'a btree *)

let rec member x btree =
  match btree with
    Empty -> false
  | Node(y, left, right) ->
      if x = y then true else
      if x < y then member x left else member x right;;
(* val member : 'a -> 'a btree -> bool = <fun> *)

let rec insert x btree =
  match btree with
    Empty -> Node(x, Empty, Empty)
  | Node(y, left, right) ->
      if x <= y then Node(y, insert x left, right)
                else Node(y, left, insert x right);;
(* val insert : 'a -> 'a btree -> 'a btree = <fun> *)
