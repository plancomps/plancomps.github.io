type idref = { mutable id: 'a -> 'a };;
(* type idref = { mutable id : 'a -> 'a; } *)

let r = {id = fun x -> x};;
(* val r : idref = {id = <fun>} *)

let g s = (s.id 1, s.id true);;
(* val g : idref -> int * bool = <fun> *)

r.id <- (fun x -> print_string "called id\n"; x);;
(* - : unit = () *)

g r;;
(* called id
   called id
   - : int * bool = (1, true) 
*)

