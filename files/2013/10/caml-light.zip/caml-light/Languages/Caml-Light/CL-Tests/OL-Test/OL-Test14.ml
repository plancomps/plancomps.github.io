let add_vect v1 v2 =
  let len = min (array_length v1) (array_length v2) in
  let res = array_create len 0.0 in
  for i = 0 to len - 1 do
    res.(i) <- v1.(i) +. v2.(i)
  done;
  res;;
(* val add_vect : float array -> float array -> float array = <fun> *)

add_vect [| 1.0; 2.0 |] [| 3.0; 4.0 |];;
(* - : float array = [|4.; 6.|] *)

