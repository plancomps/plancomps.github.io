(* $Id: asl.ml,v 1.3 1994/11/10 09:57:19 xleroy Exp $ *)

let init_env =  ["+";"-";"*";"/";"="];;
