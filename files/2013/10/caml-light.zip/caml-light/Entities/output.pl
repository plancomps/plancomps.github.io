% Generated from Entities/output.csf

writeable(output).

default(output,list_empty).

rewrite(monop(A,B,C),H) :-     rewrites(A,output),     rewrites(B,D),     rewrites(C,E),     rewrites(D,F),     rewrites(E,G),     rewrites(list_append(F,G),H).

