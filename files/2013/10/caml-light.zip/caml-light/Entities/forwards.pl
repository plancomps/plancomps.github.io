% Generated from Entities/forwards.csf

readable(forwards).

writeable(forwards).

default(forwards,map_empty).

sigdec(forwards,type,[]).

onestep(forwards,A,B,resolve) :-     unobs(A),     rewrites(forwards,B).

onestep(forwards,A,B,typeval) :-     unobs(A),     rewrites(forwards,B).

typedef(forwards,map(fwd,computes(bindable))).

sigdec(typforwards,type,[]).

onestep(typforwards,A,B,resolve) :-     unobs(A),     rewrites(typforwards,B).

onestep(typforwards,A,B,typeval) :-     unobs(A),     rewrites(typforwards,B).

typedef(typforwards,map(fwd,type)).

sigdec(forwards_fresh,fwd,[forwards]).

onestep(forwards_fresh(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(forwards_fresh(E),F).

onestep(forwards_fresh(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(forwards_fresh(E),F).

rewrite(forwards_fresh(A),I) :-     rewrites(A,B),     rewrites(B,map_prefix(C,_,_)),     rewrites(largest_key(B),E),     rewrites(C,D),     runcheck(D,fwd),     checktag(D,fwd,_),     rewrites(E,F),     runcheck(F,fwd),     checktag(F,fwd,G),     rewrites(G,H),     rewrites(fwd_next(H),I).

rewrite(forwards_fresh(A),B) :-     rewrites(A,map_empty),     rewrites(fwd_first,B).

