% Generated from Entities/given.csf

readable(given).

default(given,null).

