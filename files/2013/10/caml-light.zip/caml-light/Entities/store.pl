% Generated from Entities/store.csf

readable(store).

writeable(store).

default(store,map_empty).

sigdec(store,type,[]).

onestep(store,A,B,resolve) :-     unobs(A),     rewrites(store,B).

onestep(store,A,B,typeval) :-     unobs(A),     rewrites(store,B).

typedef(store,map(variable,storable)).

sigdec(typstore,type,[]).

onestep(typstore,A,B,resolve) :-     unobs(A),     rewrites(typstore,B).

onestep(typstore,A,B,typeval) :-     unobs(A),     rewrites(typstore,B).

typedef(typstore,map(variable,type)).

sigdec(store_freshvar,variable,[map(variable,_)]).

onestep(store_freshvar(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(store_freshvar(E),F).

onestep(store_freshvar(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(store_freshvar(E),F).

onestep(store_freshvar(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(store_freshvar(E),F).

sigdec(store_freshvar,computes(variable),[computes(map(variable,_))]).

rewrite(store_freshvar(A),K) :-     rewrites(A,B),     rewrites(B,map_prefix(C,E,_)),     rewrites(largest_key(B),G),     rewrites(C,D),     runcheck(D,variable),     checktag(D,variable,_),     rewrites(E,F),     runcheck(F,storable),     checktag(F,storable,_),     rewrites(G,H),     runcheck(H,variable),     checktag(H,variable,I),     rewrites(I,J),     rewrites(variable_next(J),K).

rewrite(store_freshvar(A),B) :-     rewrites(A,map_empty),     rewrites(variable_first,B).

