% Generated from Entities/exception.csf

writeable(exception).

default(exception,none).

rewrite(monop(A,B,C),E) :-     rewrites(A,exception),     rewrites(B,none),     rewrites(C,D),     rewrites(D,E).

rewrite(monop(A,B,C),E) :-     rewrites(A,exception),     rewrites(B,D),     rewrites(C,none),     rewrites(D,E).

rewrite(monop(A,B,D),H) :-     rewrites(A,exception),     rewrites(B,some(C)),     rewrites(C,F),     rewrites(D,some(E)),     rewrites(E,F),     rewrites(F,G),     rewrites(some(G),H).

