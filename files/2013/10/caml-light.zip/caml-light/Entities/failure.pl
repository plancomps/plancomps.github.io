% Generated from Entities/failure.csf

writeable(failure).

default(failure,false).

