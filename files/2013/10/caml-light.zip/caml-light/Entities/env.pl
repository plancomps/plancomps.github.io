% Generated from Entities/env.csf

readable(env).

default(env,map_empty).

sigdec(env,type,[]).

onestep(env,A,B,resolve) :-     unobs(A),     rewrites(env,B).

onestep(env,A,B,typeval) :-     unobs(A),     rewrites(env,B).

typedef(env,map(id,computes(bindable))).

valsort(env).

sigdec(typenv,type,[]).

onestep(typenv,A,B,resolve) :-     unobs(A),     rewrites(typenv,B).

onestep(typenv,A,B,typeval) :-     unobs(A),     rewrites(typenv,B).

typedef(typenv,map(id,type)).

valsort(typenv).

