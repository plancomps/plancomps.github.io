% Generated from Sorts/proc.csf

sigdec(proc,type,[]).

onestep(proc,A,B,resolve) :-     unobs(A),     rewrites(proc,B).

onestep(proc,A,B,typeval) :-     unobs(A),     rewrites(proc,B).

typedef(proc,depends(expressible,skip)).

