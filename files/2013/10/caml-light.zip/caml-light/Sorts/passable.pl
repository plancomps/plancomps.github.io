% Generated from Sorts/passable.csf

sigdec(passable,type,[]).

onestep(passable,A,B,resolve) :-     unobs(A),     rewrites(passable,B).

onestep(passable,A,B,typeval) :-     unobs(A),     rewrites(passable,B).

valsort(passable).

