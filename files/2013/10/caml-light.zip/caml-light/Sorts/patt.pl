% Generated from Sorts/patt.csf

sigdec(patt,type,[]).

onestep(patt,A,B,resolve) :-     unobs(A),     rewrites(patt,B).

onestep(patt,A,B,typeval) :-     unobs(A),     rewrites(patt,B).

typedef(patt,depends(expressible,env)).

