% Generated from Sorts/throwable.csf

sigdec(throwable,type,[]).

onestep(throwable,A,B,resolve) :-     unobs(A),     rewrites(throwable,B).

onestep(throwable,A,B,typeval) :-     unobs(A),     rewrites(throwable,B).

valsort(throwable).

