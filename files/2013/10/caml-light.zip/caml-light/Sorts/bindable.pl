% Generated from Sorts/bindable.csf

sigdec(bindable,type,[]).

onestep(bindable,A,B,resolve) :-     unobs(A),     rewrites(bindable,B).

onestep(bindable,A,B,typeval) :-     unobs(A),     rewrites(bindable,B).

valsort(bindable).

