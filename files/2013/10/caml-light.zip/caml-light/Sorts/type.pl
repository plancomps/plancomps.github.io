% Generated from Sorts/type.csf

sigdec(type,type,[]).

onestep(type,A,B,resolve) :-     unobs(A),     rewrites(type,B).

onestep(type,A,B,typeval) :-     unobs(A),     rewrites(type,B).

sigdec(unknown_type,type,[]).

onestep(unknown_type,A,B,resolve) :-     unobs(A),     rewrites(unknown_type,B).

onestep(unknown_type,A,B,typeval) :-     unobs(A),     rewrites(unknown_type,B).

