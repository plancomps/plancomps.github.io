% Generated from Sorts/expr.csf

sigdec(expr,type,[]).

onestep(expr,A,B,resolve) :-     unobs(A),     rewrites(expr,B).

onestep(expr,A,B,typeval) :-     unobs(A),     rewrites(expr,B).

typedef(expr,computes(expressible)).

