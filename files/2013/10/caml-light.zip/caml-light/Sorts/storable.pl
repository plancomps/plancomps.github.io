% Generated from Sorts/storable.csf

sigdec(storable,type,[]).

onestep(storable,A,B,resolve) :-     unobs(A),     rewrites(storable,B).

onestep(storable,A,B,typeval) :-     unobs(A),     rewrites(storable,B).

valsort(storable).

