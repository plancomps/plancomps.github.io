% Generated from Sorts/abs.csf

sigdec(abs,type,[]).

onestep(abs,A,type,inhabit) :-     unobs(A).

onestep(abs,A,B,resolve) :-     unobs(A),     rewrites(abs,B).

onestep(abs,A,B,typeval) :-     unobs(A),     rewrites(abs,B).

typedef(abs,depends(passable,expressible)).

