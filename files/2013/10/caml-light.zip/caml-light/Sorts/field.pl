% Generated from Sorts/field.csf

sigdec(field,type,[]).

onestep(field,A,B,resolve) :-     unobs(A),     rewrites(field,B).

onestep(field,A,B,typeval) :-     unobs(A),     rewrites(field,B).

typedef(field,atom).

valsort(field).

