% Generated from Sorts/decl.csf

sigdec(decl,type,[]).

onestep(decl,A,B,resolve) :-     unobs(A),     rewrites(decl,B).

onestep(decl,A,B,typeval) :-     unobs(A),     rewrites(decl,B).

typedef(decl,computes(env)).

