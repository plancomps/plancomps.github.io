% Generated from Sorts/expressible.csf

sigdec(expressible,type,[]).

onestep(expressible,A,B,resolve) :-     unobs(A),     rewrites(expressible,B).

onestep(expressible,A,B,typeval) :-     unobs(A),     rewrites(expressible,B).

valsort(expressible).

