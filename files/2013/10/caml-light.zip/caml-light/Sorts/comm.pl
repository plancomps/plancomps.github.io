% Generated from Sorts/comm.csf

sigdec(comm,type,[]).

onestep(comm,A,B,resolve) :-     unobs(A),     rewrites(comm,B).

onestep(comm,A,B,typeval) :-     unobs(A),     rewrites(comm,B).

typedef(comm,computes(skip)).

