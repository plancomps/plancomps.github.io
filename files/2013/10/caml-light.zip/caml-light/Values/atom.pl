% Generated from Values/atom.csf

sigdec(atom,type,[]).

onestep(atom,A,B,resolve) :-     unobs(A),     rewrites(atom,B).

onestep(atom,A,B,typeval) :-     unobs(A),     rewrites(atom,B).

valsort(atom).

