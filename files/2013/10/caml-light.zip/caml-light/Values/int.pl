% Generated from Values/int.csf

sigdec(int,type,[]).

onestep(int,A,B,resolve) :-     unobs(A),     rewrites(int,B).

onestep(int,A,B,typeval) :-     unobs(A),     rewrites(int,B).

valsort(int).

sigdec(int_plus,int,[int,int]).

onestep(int_plus(A,B),I,int,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,int) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,int) ->     post_comp(G,H,I). 

onestep(int_plus(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_plus(G,H),I).

onestep(int_plus(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_plus(G,H),I).

onestep(int_plus(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_plus(J,K),L).

onestep(int_plus(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_plus(J,K),L).

sigdec(int_plus,computes(int),[computes(int),computes(int)]).

sigdec(int_minus,int,[int,int]).

onestep(int_minus(A,B),I,int,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,int) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,int) ->     post_comp(G,H,I). 

onestep(int_minus(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_minus(G,H),I).

onestep(int_minus(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_minus(G,H),I).

onestep(int_minus(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_minus(J,K),L).

onestep(int_minus(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_minus(J,K),L).

sigdec(int_minus,computes(int),[computes(int),computes(int)]).

sigdec(int_times,int,[int,int]).

onestep(int_times(A,B),I,int,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,int) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,int) ->     post_comp(G,H,I). 

onestep(int_times(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_times(G,H),I).

onestep(int_times(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_times(G,H),I).

onestep(int_times(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_times(J,K),L).

onestep(int_times(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_times(J,K),L).

sigdec(int_times,computes(int),[computes(int),computes(int)]).

sigdec(int_divide,int,[int,int]).

onestep(int_divide(A,B),I,int,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,int) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,int) ->     post_comp(G,H,I). 

onestep(int_divide(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_divide(G,H),I).

onestep(int_divide(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_divide(G,H),I).

onestep(int_divide(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_divide(J,K),L).

onestep(int_divide(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_divide(J,K),L).

sigdec(int_divide,computes(int),[computes(int),computes(int)]).

sigdec(int_less,boolean,[int,int]).

onestep(int_less(A,B),I,boolean,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,int) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,int) ->     post_comp(G,H,I). 

onestep(int_less(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_less(G,H),I).

onestep(int_less(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_less(G,H),I).

onestep(int_less(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_less(J,K),L).

onestep(int_less(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_less(J,K),L).

sigdec(int_less,computes(boolean),[computes(int),computes(int)]).

sigdec(int_less_equal,boolean,[int,int]).

onestep(int_less_equal(A,B),I,boolean,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,int) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,int) ->     post_comp(G,H,I). 

onestep(int_less_equal(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_less_equal(G,H),I).

onestep(int_less_equal(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_less_equal(G,H),I).

onestep(int_less_equal(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_less_equal(J,K),L).

onestep(int_less_equal(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_less_equal(J,K),L).

sigdec(int_less_equal,computes(boolean),[computes(int),computes(int)]).

sigdec(int_greater,boolean,[int,int]).

onestep(int_greater(A,B),I,boolean,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,int) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,int) ->     post_comp(G,H,I). 

onestep(int_greater(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_greater(G,H),I).

onestep(int_greater(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_greater(G,H),I).

onestep(int_greater(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_greater(J,K),L).

onestep(int_greater(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_greater(J,K),L).

sigdec(int_greater,computes(boolean),[computes(int),computes(int)]).

sigdec(int_greater_equal,boolean,[int,int]).

onestep(int_greater_equal(A,B),I,boolean,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,int) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,int) ->     post_comp(G,H,I). 

onestep(int_greater_equal(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_greater_equal(G,H),I).

onestep(int_greater_equal(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_greater_equal(G,H),I).

onestep(int_greater_equal(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_greater_equal(J,K),L).

onestep(int_greater_equal(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_greater_equal(J,K),L).

sigdec(int_greater_equal,computes(boolean),[computes(int),computes(int)]).

sigdec(int_closed_interval,list(int),[int,int]).

onestep(int_closed_interval(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_closed_interval(G,H),I).

onestep(int_closed_interval(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_closed_interval(G,H),I).

onestep(int_closed_interval(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_closed_interval(J,K),L).

onestep(int_closed_interval(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_closed_interval(J,K),L).

sigdec(int_closed_interval,computes(list(int)),[computes(int),computes(int)]).

rewrite(int_closed_interval(A,B),H) :-     rewrites(A,C),     rewrites(B,C),     rewrites(C,D),     runcheck(D,int),     checktag(D,int,E),     rewrites(E,F),     rewrites(list_empty,G),     rewrites(list_prefix(F,G),H).

rewrite(int_closed_interval(A,B),O) :-     rewrites(A,C),     rewrites(B,E),     rewrites(int_less(C,E),true),     rewrites(C,D),     runcheck(D,int),     checktag(D,int,G),     rewrites(E,F),     runcheck(F,int),     checktag(F,int,J),     rewrites(G,M),     rewrites(G,H),     rewrites(q(1),I),     rewrites(int_plus(H,I),K),     rewrites(J,L),     rewrites(int_closed_interval(K,L),N),     rewrites(list_prefix(M,N),O).

onestep(int_closed_interval(A,B),I,list(int),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,int) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,int) ->     post_comp(G,H,I). 

sigdec(int_min,int,[int,int]).

onestep(int_min(A,B),I,int,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,int) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,int) ->     post_comp(G,H,I). 

onestep(int_min(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_min(G,H),I).

onestep(int_min(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(int_min(G,H),I).

onestep(int_min(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_min(J,K),L).

onestep(int_min(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(int_min(J,K),L).

sigdec(int_min,computes(int),[computes(int),computes(int)]).

rewrite(int_min(A,B),H) :-     rewrites(A,C),     rewrites(B,E),     rewrites(int_greater(C,E),true),     rewrites(C,D),     runcheck(D,int),     checktag(D,int,_),     rewrites(E,F),     runcheck(F,int),     checktag(F,int,G),     rewrites(G,H).

rewrite(int_min(A,B),H) :-     rewrites(A,C),     rewrites(B,E),     rewrites(int_less_equal(C,E),true),     rewrites(C,D),     runcheck(D,int),     checktag(D,int,G),     rewrites(E,F),     runcheck(F,int),     checktag(F,int,_),     rewrites(G,H).

