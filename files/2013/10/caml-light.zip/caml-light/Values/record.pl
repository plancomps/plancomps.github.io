% Generated from Values/record.csf

sigdec(record,record(A),[map(field,A)]).

onestep(record(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(record(E),F).

onestep(record(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(record(E),F).

onestep(record(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(record(E),F).

sigdec(record,computes(record(A)),[computes(map(field,A))]).

valcons(record).

sigdec(record(_),type,[]).

onestep(record(A),B,E,resolve) :-     rewrites(A,C),     unobs(B),     rewrites(C,D),     rewrites(record(D),E).

onestep(record(A),B,E,typeval) :-     rewrites(A,C),     unobs(B),     rewrites(C,D),     rewrites(record(D),E).

valsort(record(_)).

onestep(record(A),D,record(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

sigdec(record_over,record(A),[record(A),record(A)]).

onestep(record_over(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_over(G,H),I).

onestep(record_over(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_over(G,H),I).

onestep(record_over(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_over(J,K),L).

onestep(record_over(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_over(J,K),L).

sigdec(record_over,computes(record(A)),[computes(record(A)),computes(record(A))]).

rewrite(record_over(A,C),I) :-     rewrites(A,record(B)),     rewrites(B,E),     rewrites(C,record(D)),     rewrites(D,F),     rewrites(map_over(E,F),G),     rewrites(G,H),     rewrites(record(H),I).

sigdec(record_union,record(A),[record(A),record(A)]).

onestep(record_union(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_union(G,H),I).

onestep(record_union(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_union(G,H),I).

onestep(record_union(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_union(J,K),L).

onestep(record_union(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_union(J,K),L).

sigdec(record_union,computes(record(A)),[computes(record(A)),computes(record(A))]).

rewrite(record_union(A,C),I) :-     rewrites(A,record(B)),     rewrites(B,E),     rewrites(C,record(D)),     rewrites(D,F),     rewrites(map_union(E,F),G),     rewrites(G,H),     rewrites(record(H),I).

onestep(record_union(A,B),L,record(I),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(L,J),     rewrites(C,D),     inhabit(D,J,record(G)) ->     mid_comp(J,K),     rewrites(E,F),     inhabit(F,K,record(H)) ->     rewrites(map_union(G,H),I),     post_comp(J,K,L).

sigdec(record_select,A,[record(A),field]).

onestep(record_select(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_select(G,H),I).

onestep(record_select(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record_select(G,H),I).

onestep(record_select(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_select(J,K),L).

onestep(record_select(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record_select(J,K),L).

sigdec(record_select,A,[computes(record(A)),computes(field)]).

rewrite(record_select(A,C),J) :-     rewrites(A,record(B)),     rewrites(B,F),     rewrites(C,D),     rewrites(D,E),     runcheck(E,field),     checktag(E,field,G),     rewrites(F,H),     rewrites(G,I),     rewrites(map_select(H,I),J).

onestep(record_select(A,B),F,map_select(G,C),inhabit) :-     rewrites(A,D),     rewrites(B,C),     rewrites(D,E),     inhabit(E,F,record(G)).

sigdec(record1,record(A),[field,A]).

onestep(record1(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record1(G,H),I).

onestep(record1(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(record1(G,H),I).

onestep(record1(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record1(J,K),L).

onestep(record1(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(record1(J,K),L).

sigdec(record1,computes(record(A)),[computes(field),A]).

sigdec(record2,record(A),[field,A,field,A]).

onestep(record2(A,B,C,D),F,O,run) :-     rewrites(A,G),     rewrites(B,H),     rewrites(C,I),     rewrites(D,E),     runstep(E,F,J) ->     rewrites(G,K),     rewrites(H,L),     rewrites(I,M),     rewrites(J,N),     rewrites(record2(K,L,M,N),O).

onestep(record2(A,B,C,D),F,O,run) :-     rewrites(A,G),     rewrites(B,H),     rewrites(C,E),     rewrites(D,J),     runstep(E,F,I) ->     rewrites(G,K),     rewrites(H,L),     rewrites(I,M),     rewrites(J,N),     rewrites(record2(K,L,M,N),O).

onestep(record2(A,B,C,D),F,O,run) :-     rewrites(A,G),     rewrites(B,E),     rewrites(C,I),     rewrites(D,J),     runstep(E,F,H) ->     rewrites(G,K),     rewrites(H,L),     rewrites(I,M),     rewrites(J,N),     rewrites(record2(K,L,M,N),O).

onestep(record2(A,B,C,D),F,O,run) :-     rewrites(A,E),     rewrites(B,H),     rewrites(C,I),     rewrites(D,J),     runstep(E,F,G) ->     rewrites(G,K),     rewrites(H,L),     rewrites(I,M),     rewrites(J,N),     rewrites(record2(K,L,M,N),O).

onestep(record2(A,B,C,D),O,X,resolve) :-     rewrites(A,E),     rewrites(B,F),     rewrites(C,G),     rewrites(D,H),     pre_comp(O,M),     onestep(E,M,P,resolve) ->     mid_comp(M,N),     pre_comp(N,K),     onestep(F,K,Q,resolve) ->     mid_comp(K,L),     pre_comp(L,I),     onestep(G,I,R,resolve) ->     mid_comp(I,J),     onestep(H,J,S,resolve) ->     post_comp(I,J,L),     post_comp(K,L,N),     post_comp(M,N,O),     rewrites(P,T),     rewrites(Q,U),     rewrites(R,V),     rewrites(S,W),     rewrites(record2(T,U,V,W),X).

onestep(record2(A,B,C,D),O,X,typeval) :-     rewrites(A,E),     rewrites(B,F),     rewrites(C,G),     rewrites(D,H),     pre_comp(O,M),     typeval(E,M,P) ->     mid_comp(M,N),     pre_comp(N,K),     typeval(F,K,Q) ->     mid_comp(K,L),     pre_comp(L,I),     typeval(G,I,R) ->     mid_comp(I,J),     typeval(H,J,S) ->     post_comp(I,J,L),     post_comp(K,L,N),     post_comp(M,N,O),     rewrites(P,T),     rewrites(Q,U),     rewrites(R,V),     rewrites(S,W),     rewrites(record2(T,U,V,W),X).

sigdec(record2,computes(record(A)),[computes(field),A,computes(field),A]).

rewrite(record1(A,B),M) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,field),     checktag(D,field,G),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,H),     rewrites(map_empty,I),     rewrites(G,J),     rewrites(H,K),     rewrites(map_update(I,J,K),L),     rewrites(record(L),M).

rewrite(record2(A,B,C,D),X) :-     rewrites(A,E),     rewrites(B,G),     rewrites(C,I),     rewrites(D,K),     rewrites(E,F),     runcheck(F,field),     checktag(F,field,M),     rewrites(G,H),     runcheck(H,val),     checktag(H,val,N),     rewrites(I,J),     runcheck(J,field),     checktag(J,field,R),     rewrites(K,L),     runcheck(L,val),     checktag(L,val,S),     rewrites(map_empty,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(map_update(O,P,Q),T),     rewrites(R,U),     rewrites(S,V),     rewrites(map_update(T,U,V),W),     rewrites(record(W),X).

onestep(record1(A,B),F,G,inhabit) :-     rewrites(A,C),     rewrites(B,D),     rewrites(record(map_update(map_empty,C,D)),E),     inhabit(E,F,G).

