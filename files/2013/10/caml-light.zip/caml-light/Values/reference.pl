% Generated from Values/reference.csf

sigdec(null,reference,[]).

onestep(null,A,reference,inhabit) :-     unobs(A).

onestep(null,A,B,resolve) :-     unobs(A),     rewrites(null,B).

onestep(null,A,B,typeval) :-     unobs(A),     rewrites(null,B).

valcons(null).

sigdec(ref,reference,[variable]).

onestep(ref(A),D,reference(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

onestep(ref(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(ref(E),F).

onestep(ref(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(ref(E),F).

onestep(ref(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(ref(E),F).

sigdec(ref,computes(reference),[computes(variable)]).

valcons(ref).

sigdec(reference,type,[]).

onestep(reference,A,B,resolve) :-     unobs(A),     rewrites(reference,B).

onestep(reference,A,B,typeval) :-     unobs(A),     rewrites(reference,B).

valsort(reference).

sigdec(deref,variable,[reference]).

onestep(deref(A),D,variable,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,reference).

onestep(deref(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(deref(E),F).

onestep(deref(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(deref(E),F).

onestep(deref(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(deref(E),F).

sigdec(deref,computes(variable),[computes(reference)]).

rewrite(deref(A),F) :-     rewrites(A,ref(B)),     rewrites(B,C),     rewrites(C,D),     runcheck(D,variable),     checktag(D,variable,E),     rewrites(E,F).

