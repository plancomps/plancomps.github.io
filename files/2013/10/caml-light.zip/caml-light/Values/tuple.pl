% Generated from Values/tuple.csf

sigdec(tuple_empty,tuple,[]).

onestep(tuple_empty,A,B,resolve) :-     unobs(A),     rewrites(tuple_empty,B).

onestep(tuple_empty,A,B,typeval) :-     unobs(A),     rewrites(tuple_empty,B).

valcons(tuple_empty).

sigdec(tuple_prefix,tuple,[expressible,tuple]).

onestep(tuple_prefix(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(tuple_prefix(G,H),I).

onestep(tuple_prefix(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(tuple_prefix(G,H),I).

onestep(tuple_prefix(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(tuple_prefix(J,K),L).

onestep(tuple_prefix(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(tuple_prefix(J,K),L).

sigdec(tuple_prefix,computes(tuple),[computes(expressible),computes(tuple)]).

valcons(tuple_prefix).

sigdec(tuple,type,[]).

onestep(tuple,A,B,resolve) :-     unobs(A),     rewrites(tuple,B).

onestep(tuple,A,B,typeval) :-     unobs(A),     rewrites(tuple,B).

valsort(tuple).

sigdec(unit,tuple,[]).

onestep(unit,A,B,resolve) :-     unobs(A),     rewrites(unit,B).

onestep(unit,A,B,typeval) :-     unobs(A),     rewrites(unit,B).

sigdec(tuple2,tuple,[expressible,expressible]).

onestep(tuple2(A,B),I,tuple,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,expressible) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,expressible) ->     post_comp(G,H,I). 

onestep(tuple2(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(tuple2(G,H),I).

onestep(tuple2(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(tuple2(G,H),I).

onestep(tuple2(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(tuple2(J,K),L).

onestep(tuple2(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(tuple2(J,K),L).

sigdec(tuple2,computes(tuple),[computes(expressible),computes(expressible)]).

sigdec(tuple3,tuple,[expressible,expressible,expressible]).

onestep(tuple3(A,B,C),N,tuple,inhabit) :-     rewrites(A,D),     rewrites(B,F),     rewrites(C,H),     pre_comp(N,L),     rewrites(D,E),     inhabit(E,L,expressible) ->     mid_comp(L,M),     pre_comp(M,J),     rewrites(F,G),     inhabit(G,J,expressible) ->     mid_comp(J,K),     rewrites(H,I),     inhabit(I,K,expressible) ->     post_comp(J,K,M),     post_comp(L,M,N).

onestep(tuple3(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,G),     rewrites(C,D),     runstep(D,E,H) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(tuple3(I,J,K),L).

onestep(tuple3(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,D),     rewrites(C,H),     runstep(D,E,G) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(tuple3(I,J,K),L).

onestep(tuple3(A,B,C),E,L,run) :-     rewrites(A,D),     rewrites(B,G),     rewrites(C,H),     runstep(D,E,F) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(tuple3(I,J,K),L).

onestep(tuple3(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(tuple3(O,P,Q),R).

onestep(tuple3(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(tuple3(O,P,Q),R).

sigdec(tuple3,computes(tuple),[computes(expressible),computes(expressible),computes(expressible)]).

onestep(tuple_prefix(A,B),K,tuple_prefix(E,H),inhabit) :-     rewrites(A,C),     rewrites(B,F),     pre_comp(K,I),     rewrites(C,D),     inhabit(D,I,E) ->     mid_comp(I,J),     rewrites(F,G),     inhabit(G,J,H) ->     post_comp(I,J,K). 

onestep(tuple_empty,A,tuple_empty,inhabit) :-     unobs(A).

rewrite(unit,A) :-     rewrites(tuple_empty,A).

onestep(unit,A,tuple_empty,inhabit) :-     unobs(A).

rewrite(tuple2(A,B),I) :-     rewrites(A,C),     rewrites(B,D),     rewrites(C,G),     rewrites(D,E),     rewrites(tuple_empty,F),     rewrites(tuple_prefix(E,F),H),     rewrites(tuple_prefix(G,H),I).

rewrite(tuple3(A,B,C),M) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     rewrites(D,K),     rewrites(E,I),     rewrites(F,G),     rewrites(tuple_empty,H),     rewrites(tuple_prefix(G,H),J),     rewrites(tuple_prefix(I,J),L),     rewrites(tuple_prefix(K,L),M).

sigdec(project,expressible,[int,tuple]).

onestep(project(A,B),I,expressible,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,int) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,tuple) ->     post_comp(G,H,I). 

onestep(project(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(project(G,H),I).

onestep(project(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(project(G,H),I).

onestep(project(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(project(J,K),L).

onestep(project(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(project(J,K),L).

sigdec(project,computes(expressible),[computes(int),computes(tuple)]).

rewrite(project(A,B),H) :-     rewrites(A,q(1)),     rewrites(B,tuple_prefix(C,D)),     rewrites(C,E),     rewrites(D,_),     rewrites(E,F),     runcheck(F,expressible),     checktag(F,expressible,G),     rewrites(G,H).

rewrite(project(A,B),Q) :-     rewrites(A,I),     rewrites(B,tuple_prefix(C,D)),     rewrites(C,E),     rewrites(D,G),     rewrites(int_greater(I,q(1)),true),     rewrites(E,F),     runcheck(F,expressible),     checktag(F,expressible,_),     rewrites(G,H),     runcheck(H,tuple),     checktag(H,tuple,N),     rewrites(I,J),     runcheck(J,int),     checktag(J,int,K),     rewrites(K,L),     rewrites(q(1),M),     rewrites(int_minus(L,M),O),     rewrites(N,P),     rewrites(project(O,P),Q).

sigdec(project1,expressible,[tuple]).

onestep(project1(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(project1(E),F).

onestep(project1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(project1(E),F).

onestep(project1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(project1(E),F).

sigdec(project1,computes(expressible),[computes(tuple)]).

sigdec(project2,expressible,[tuple]).

onestep(project2(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(project2(E),F).

onestep(project2(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(project2(E),F).

onestep(project2(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(project2(E),F).

sigdec(project2,computes(expressible),[computes(tuple)]).

onestep(project1(A),D,E,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,tuple2(E,_)).

onestep(project2(A),D,E,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,tuple2(_,E)).

rewrite(project1(A),G) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,tuple),     checktag(C,tuple,D),     rewrites(q(1),E),     rewrites(D,F),     rewrites(project(E,F),G).

rewrite(project2(A),G) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,tuple),     checktag(C,tuple,D),     rewrites(q(2),E),     rewrites(D,F),     rewrites(project(E,F),G).

