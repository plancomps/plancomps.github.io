% Generated from Values/nat.csf

sigdec(o,nat,[]).

onestep(o,A,nat,inhabit) :-     unobs(A).

onestep(o,A,B,resolve) :-     unobs(A),     rewrites(o,B).

onestep(o,A,B,typeval) :-     unobs(A),     rewrites(o,B).

valcons(o).

sigdec(s,nat,[nat]).

onestep(s(A),D,nat(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

onestep(s(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(s(E),F).

onestep(s(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(s(E),F).

onestep(s(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(s(E),F).

sigdec(s,computes(nat),[computes(nat)]).

valcons(s).

sigdec(nat,type,[]).

onestep(nat,A,B,resolve) :-     unobs(A),     rewrites(nat,B).

onestep(nat,A,B,typeval) :-     unobs(A),     rewrites(nat,B).

valsort(nat).

