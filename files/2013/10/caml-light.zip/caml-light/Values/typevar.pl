% Generated from Values/typevar.csf

sigdec(typevar,typevar,[atom]).

onestep(typevar(A),D,typevar(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

onestep(typevar(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(typevar(E),F).

onestep(typevar(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(typevar(E),F).

onestep(typevar(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(typevar(E),F).

sigdec(typevar,computes(typevar),[computes(atom)]).

valcons(typevar).

sigdec(typevar,type,[]).

onestep(typevar,A,type,inhabit) :-     unobs(A).

onestep(typevar,A,B,resolve) :-     unobs(A),     rewrites(typevar,B).

onestep(typevar,A,B,typeval) :-     unobs(A),     rewrites(typevar,B).

valsort(typevar).

