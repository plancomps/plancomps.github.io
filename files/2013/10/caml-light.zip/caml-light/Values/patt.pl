% Generated from Values/patt.csf

sigdec(patt,type,[]).

onestep(patt,A,B,resolve) :-     unobs(A),     rewrites(patt,B).

onestep(patt,A,B,typeval) :-     unobs(A),     rewrites(patt,B).

typedef(patt,abs(expressible,env)).

valsort(patt).

