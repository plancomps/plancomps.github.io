% Generated from Values/id.csf

sigdec(id,id,[atom]).

onestep(id(A),D,id(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

onestep(id(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(id(E),F).

onestep(id(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(id(E),F).

onestep(id(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(id(E),F).

sigdec(id,computes(id),[computes(atom)]).

valcons(id).

sigdec(id,type,[]).

onestep(id,A,type,inhabit) :-     unobs(A).

onestep(id,A,B,resolve) :-     unobs(A),     rewrites(id,B).

onestep(id,A,B,typeval) :-     unobs(A),     rewrites(id,B).

valsort(id).

