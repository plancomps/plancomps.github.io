% Generated from Values/float.csf

sigdec(float,type,[]).

onestep(float,A,B,resolve) :-     unobs(A),     rewrites(float,B).

onestep(float,A,B,typeval) :-     unobs(A),     rewrites(float,B).

valsort(float).

sigdec(float_plus,float,[float,float]).

onestep(float_plus(A,B),I,float,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,float) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,float) ->     post_comp(G,H,I). 

onestep(float_plus(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_plus(G,H),I).

onestep(float_plus(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_plus(G,H),I).

onestep(float_plus(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_plus(J,K),L).

onestep(float_plus(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_plus(J,K),L).

sigdec(float_plus,computes(float),[computes(float),computes(float)]).

sigdec(float_minus,float,[float,float]).

onestep(float_minus(A,B),I,float,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,float) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,float) ->     post_comp(G,H,I). 

onestep(float_minus(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_minus(G,H),I).

onestep(float_minus(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_minus(G,H),I).

onestep(float_minus(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_minus(J,K),L).

onestep(float_minus(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_minus(J,K),L).

sigdec(float_minus,computes(float),[computes(float),computes(float)]).

sigdec(float_times,float,[float,float]).

onestep(float_times(A,B),I,float,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,float) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,float) ->     post_comp(G,H,I). 

onestep(float_times(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_times(G,H),I).

onestep(float_times(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_times(G,H),I).

onestep(float_times(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_times(J,K),L).

onestep(float_times(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_times(J,K),L).

sigdec(float_times,computes(float),[computes(float),computes(float)]).

sigdec(float_divide,float,[float,float]).

onestep(float_divide(A,B),I,float,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,float) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,float) ->     post_comp(G,H,I). 

onestep(float_divide(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_divide(G,H),I).

onestep(float_divide(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_divide(G,H),I).

onestep(float_divide(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_divide(J,K),L).

onestep(float_divide(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_divide(J,K),L).

sigdec(float_divide,computes(float),[computes(float),computes(float)]).

sigdec(float_exp,float,[float,float]).

onestep(float_exp(A,B),I,float,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,float) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,float) ->     post_comp(G,H,I). 

onestep(float_exp(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_exp(G,H),I).

onestep(float_exp(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(float_exp(G,H),I).

onestep(float_exp(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_exp(J,K),L).

onestep(float_exp(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(float_exp(J,K),L).

sigdec(float_exp,computes(float),[computes(float),computes(float)]).

sigdec(float_pi,float,[]).

onestep(float_pi,A,float,inhabit) :-     unobs(A).

onestep(float_pi,A,B,resolve) :-     unobs(A),     rewrites(float_pi,B).

onestep(float_pi,A,B,typeval) :-     unobs(A),     rewrites(float_pi,B).

sigdec(float_sin,float,[float]).

onestep(float_sin(A),D,float,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,float).

onestep(float_sin(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_sin(E),F).

onestep(float_sin(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_sin(E),F).

onestep(float_sin(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_sin(E),F).

sigdec(float_sin,computes(float),[computes(float)]).

sigdec(float_to_int,int,[float]).

onestep(float_to_int(A),D,int,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,float).

onestep(float_to_int(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(float_to_int(E),F).

onestep(float_to_int(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(float_to_int(E),F).

onestep(float_to_int(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(float_to_int(E),F).

sigdec(float_to_int,computes(int),[computes(float)]).

sigdec(int_to_float,float,[int]).

onestep(int_to_float(A),D,float,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,int).

onestep(int_to_float(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(int_to_float(E),F).

onestep(int_to_float(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(int_to_float(E),F).

onestep(int_to_float(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(int_to_float(E),F).

sigdec(int_to_float,computes(float),[computes(int)]).

