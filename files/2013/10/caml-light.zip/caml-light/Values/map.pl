% Generated from Values/map.csf

sigdec(map_empty,map(_,_),[]).

onestep(map_empty,A,B,resolve) :-     unobs(A),     rewrites(map_empty,B).

onestep(map_empty,A,B,typeval) :-     unobs(A),     rewrites(map_empty,B).

valcons(map_empty).

sigdec(map_prefix,map(A,B),[A,B,map(A,B)]).

onestep(map_prefix(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,G),     rewrites(C,D),     runstep(D,E,H) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(map_prefix(I,J,K),L).

onestep(map_prefix(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(map_prefix(O,P,Q),R).

onestep(map_prefix(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(map_prefix(O,P,Q),R).

sigdec(map_prefix,computes(map(A,B)),[A,B,computes(map(A,B))]).

valcons(map_prefix).

sigdec(map(_,_),type,[]).

onestep(map(A,B),C,H,resolve) :-     rewrites(A,D),     rewrites(B,E),     unobs(C),     rewrites(D,F),     rewrites(E,G),     rewrites(map(F,G),H).

onestep(map(A,B),C,H,typeval) :-     rewrites(A,D),     rewrites(B,E),     unobs(C),     rewrites(D,F),     rewrites(E,G),     rewrites(map(F,G),H).

valsort(map(_,_)).

onestep(map_empty,A,map_empty,inhabit) :-     unobs(A).

onestep(map_prefix(A,C,D),M,map_prefix(B,G,J),inhabit) :-     rewrites(A,B),     rewrites(C,E),     rewrites(D,H),     pre_comp(M,K),     rewrites(E,F),     inhabit(F,K,G) ->     mid_comp(K,L),     rewrites(H,I),     inhabit(I,L,J) ->     post_comp(K,L,M). 

sigdec(map_select,A,[map(B,A),B]).

onestep(map_select(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_select(G,H),I).

onestep(map_select(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_select(J,K),L).

onestep(map_select(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_select(J,K),L).

sigdec(map_select,A,[computes(map(B,A)),B]).

rewrite(map_select(A,E),H) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,F),     rewrites(C,G),     rewrites(D,_),     rewrites(E,F),     rewrites(G,H).

rewrite(map_select(A,E),N) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,H),     rewrites(C,_),     rewrites(D,J),     rewrites(E,I),     rewrites(H,F),     runcheck(F,ground),     checktag(F,ground,_),     rewrites(I,G),     runcheck(G,ground),     checktag(G,ground,K),     \+rewrites(H,I),     rewrites(J,L),     rewrites(K,M),     rewrites(map_select(L,M),N).

sigdec(map_update,map(A,B),[map(A,B),A,B]).

onestep(map_update(A,B,C),E,L,run) :-     rewrites(A,D),     rewrites(B,G),     rewrites(C,H),     runstep(D,E,F) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(map_update(I,J,K),L).

onestep(map_update(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(map_update(O,P,Q),R).

onestep(map_update(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(map_update(O,P,Q),R).

sigdec(map_update,computes(map(A,B)),[computes(map(A,B)),A,B]).

rewrite(map_update(A,E,F),M) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,G),     rewrites(C,_),     rewrites(D,I),     rewrites(E,G),     rewrites(F,H),     rewrites(G,J),     rewrites(H,K),     rewrites(I,L),     rewrites(map_prefix(J,K,L),M).

rewrite(map_update(A,B,C),I) :-     rewrites(A,map_empty),     rewrites(B,D),     rewrites(C,E),     rewrites(D,F),     rewrites(E,G),     rewrites(map_empty,H),     rewrites(map_prefix(F,G,H),I).

rewrite(map_update(A,E,F),S) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,I),     rewrites(C,N),     rewrites(D,J),     rewrites(E,K),     rewrites(F,L),     rewrites(I,G),     runcheck(G,ground),     checktag(G,ground,M),     rewrites(K,H),     runcheck(H,ground),     checktag(H,ground,_),     lessthan(I,K),     rewrites(map_update(J,K,L),O),     rewrites(M,P),     rewrites(N,Q),     rewrites(O,R),     rewrites(map_prefix(P,Q,R),S).

rewrite(map_update(A,E,F),V) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,J),     rewrites(C,N),     rewrites(D,O),     rewrites(E,I),     rewrites(F,L),     rewrites(J,G),     runcheck(G,ground),     checktag(G,ground,M),     rewrites(I,H),     runcheck(H,ground),     checktag(H,ground,K),     lessthan(I,J),     rewrites(K,S),     rewrites(L,T),     rewrites(M,P),     rewrites(N,Q),     rewrites(O,R),     rewrites(map_prefix(P,Q,R),U),     rewrites(map_prefix(S,T,U),V).

sigdec(map_over,map(A,B),[map(A,B),map(A,B)]).

onestep(map_over(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_over(G,H),I).

onestep(map_over(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_over(G,H),I).

onestep(map_over(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_over(J,K),L).

onestep(map_over(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_over(J,K),L).

sigdec(map_over,computes(map(A,B)),[computes(map(A,B)),computes(map(A,B))]).

rewrite(map_over(A,B),D) :-     rewrites(A,map_empty),     rewrites(B,C),     rewrites(C,D).

rewrite(map_over(A,E),N) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,I),     rewrites(C,J),     rewrites(D,F),     rewrites(E,G),     rewrites(map_over(F,G),H),     rewrites(H,K),     rewrites(I,L),     rewrites(J,M),     rewrites(map_update(K,L,M),N).

onestep(map_over(A,B),K,map_over(E,H),inhabit) :-     rewrites(A,C),     rewrites(B,F),     pre_comp(K,I),     rewrites(C,D),     inhabit(D,I,E) ->     mid_comp(I,J),     rewrites(F,G),     inhabit(G,J,H) ->     post_comp(I,J,K). 

sigdec(map_union,map(A,B),[map(A,B),map(A,B)]).

onestep(map_union(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_union(G,H),I).

onestep(map_union(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_union(G,H),I).

onestep(map_union(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_union(J,K),L).

onestep(map_union(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_union(J,K),L).

sigdec(map_union,computes(map(A,B)),[computes(map(A,B)),computes(map(A,B))]).

rewrite(map_union(A,B),D) :-     rewrites(A,map_empty),     rewrites(B,C),     rewrites(C,D).

rewrite(map_union(A,E),N) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,I),     rewrites(C,J),     rewrites(D,F),     rewrites(E,G),     rewrites(contains_key(G,I),false),     rewrites(map_union(F,G),H),     rewrites(H,K),     rewrites(I,L),     rewrites(J,M),     rewrites(map_update(K,L,M),N).

onestep(map_union(A,B),L,I,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(L,J),     rewrites(C,D),     inhabit(D,J,G) ->     mid_comp(J,K),     rewrites(E,F),     inhabit(F,K,H) ->     rewrites(map_union(G,H),I),     post_comp(J,K,L).

sigdec(contains_key,boolean,[map(A,_),A]).

onestep(contains_key(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(contains_key(G,H),I).

onestep(contains_key(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(contains_key(J,K),L).

onestep(contains_key(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(contains_key(J,K),L).

sigdec(contains_key,computes(boolean),[computes(map(A,_)),A]).

rewrite(contains_key(A,B),C) :-     rewrites(A,map_empty),     rewrites(B,_),     rewrites(false,C).

rewrite(contains_key(A,E),G) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,F),     rewrites(C,_),     rewrites(D,_),     rewrites(E,F),     rewrites(true,G).

rewrite(contains_key(A,E),N) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,H),     rewrites(C,_),     rewrites(D,J),     rewrites(E,I),     rewrites(H,F),     runcheck(F,ground),     checktag(F,ground,_),     rewrites(I,G),     runcheck(G,ground),     checktag(G,ground,K),     \+rewrites(H,I),     rewrites(J,L),     rewrites(K,M),     rewrites(contains_key(L,M),N).

sigdec(largest_key,A,[map(A,_)]).

onestep(largest_key(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(largest_key(E),F).

onestep(largest_key(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(largest_key(E),F).

onestep(largest_key(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(largest_key(E),F).

sigdec(largest_key,A,[computes(map(A,_))]).

rewrite(largest_key(A),F) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,E),     rewrites(C,_),     rewrites(D,map_empty),     rewrites(E,F).

rewrite(largest_key(A),O) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,_),     rewrites(C,_),     rewrites(D,map_prefix(E,F,G)),     rewrites(E,H),     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(I,L),     rewrites(J,M),     rewrites(map_prefix(K,L,M),N),     rewrites(largest_key(N),O).

sigdec(map_eval,computes(map(A,B)),[map(A,computes(B))]).

onestep(map_eval(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(map_eval(E),F).

onestep(map_eval(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(map_eval(E),F).

onestep(map_eval(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(map_eval(E),F).

sigdec(map_eval,computes(map(A,B)),[computes(map(A,computes(B)))]).

onestep(map_eval(A),B,C,run) :-     rewrites(A,map_empty),     unobs(B),     rewrites(map_empty,C).

onestep(map_eval(A),F,N,run) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,G),     rewrites(C,E),     rewrites(D,I),     runstep(E,F,H) ->     rewrites(G,J),     rewrites(H,K),     rewrites(I,L),     rewrites(map_prefix(J,K,L),M),     rewrites(map_eval(M),N).

onestep(map_eval(A),F,N,run) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,G),     rewrites(C,H),     rewrites(D,E),     runstep(map_eval(E),F,map_eval(I)) ->     rewrites(G,J),     rewrites(H,K),     rewrites(I,L),     rewrites(map_prefix(J,K,L),M),     rewrites(map_eval(M),N).

onestep(map_eval(A),F,N,run) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,I),     rewrites(C,G),     rewrites(D,E),     runstep(map_eval(E),F,map_empty) ->     rewrites(G,H),     runcheck(H,val),     checktag(H,val,J),     rewrites(I,K),     rewrites(J,L),     rewrites(map_empty,M),     rewrites(map_prefix(K,L,M),N).

onestep(map_eval(A),F,T,run) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,I),     rewrites(C,G),     rewrites(D,E),     runstep(map_eval(E),F,map_prefix(K,L,M)) ->     rewrites(G,H),     runcheck(H,val),     checktag(H,val,J),     rewrites(I,Q),     rewrites(J,R),     rewrites(K,N),     rewrites(L,O),     rewrites(M,P),     rewrites(map_prefix(N,O,P),S),     rewrites(map_prefix(Q,R,S),T).

sigdec(map1,map(A,B),[A,B]).

onestep(map1(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map1(J,K),L).

onestep(map1(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map1(J,K),L).

rewrite(map1(A,B),H) :-     rewrites(A,C),     rewrites(B,D),     rewrites(map_empty,E),     rewrites(C,F),     rewrites(D,G),     rewrites(map_update(E,F,G),H).

sigdec(map2,map(A,B),[A,B,A,B]).

onestep(map2(A,B,C,D),O,X,resolve) :-     rewrites(A,E),     rewrites(B,F),     rewrites(C,G),     rewrites(D,H),     pre_comp(O,M),     onestep(E,M,P,resolve) ->     mid_comp(M,N),     pre_comp(N,K),     onestep(F,K,Q,resolve) ->     mid_comp(K,L),     pre_comp(L,I),     onestep(G,I,R,resolve) ->     mid_comp(I,J),     onestep(H,J,S,resolve) ->     post_comp(I,J,L),     post_comp(K,L,N),     post_comp(M,N,O),     rewrites(P,T),     rewrites(Q,U),     rewrites(R,V),     rewrites(S,W),     rewrites(map2(T,U,V,W),X).

onestep(map2(A,B,C,D),O,X,typeval) :-     rewrites(A,E),     rewrites(B,F),     rewrites(C,G),     rewrites(D,H),     pre_comp(O,M),     typeval(E,M,P) ->     mid_comp(M,N),     pre_comp(N,K),     typeval(F,K,Q) ->     mid_comp(K,L),     pre_comp(L,I),     typeval(G,I,R) ->     mid_comp(I,J),     typeval(H,J,S) ->     post_comp(I,J,L),     post_comp(K,L,N),     post_comp(M,N,O),     rewrites(P,T),     rewrites(Q,U),     rewrites(R,V),     rewrites(S,W),     rewrites(map2(T,U,V,W),X).

rewrite(map2(A,B,C,D),N) :-     rewrites(A,E),     rewrites(B,F),     rewrites(C,I),     rewrites(D,J),     rewrites(E,G),     rewrites(F,H),     rewrites(map1(G,H),K),     rewrites(I,L),     rewrites(J,M),     rewrites(map_update(K,L,M),N).

sigdec(map_domain,list(A),[map(A,_)]).

onestep(map_domain(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(map_domain(E),F).

onestep(map_domain(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(map_domain(E),F).

onestep(map_domain(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(map_domain(E),F).

sigdec(map_domain,computes(list(A)),[computes(map(A,_))]).

rewrite(map_domain(A),B) :-     rewrites(A,map_empty),     rewrites(list_empty,B).

rewrite(map_domain(A),J) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,E),     rewrites(C,_),     rewrites(D,F),     rewrites(E,H),     rewrites(F,G),     rewrites(map_domain(G),I),     rewrites(list_prefix(H,I),J).

sigdec(map_subset,boolean,[map(A,B),map(A,B)]).

onestep(map_subset(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_subset(G,H),I).

onestep(map_subset(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_subset(G,H),I).

onestep(map_subset(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_subset(J,K),L).

onestep(map_subset(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_subset(J,K),L).

sigdec(map_subset,computes(boolean),[computes(map(A,B)),computes(map(A,B))]).

rewrite(map_subset(A,B),C) :-     rewrites(A,map_empty),     rewrites(B,_),     rewrites(true,C).

rewrite(map_subset(A,E),Q) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,F),     rewrites(C,G),     rewrites(D,K),     rewrites(E,L),     rewrites(L,H),     rewrites(F,I),     rewrites(G,J),     rewrites(contains(H,I,J),O),     rewrites(K,M),     rewrites(L,N),     rewrites(map_subset(M,N),P),     rewrites(and(O,P),Q).

sigdec(contains,boolean,[map(A,B),A,B]).

onestep(contains(A,B,C),E,L,run) :-     rewrites(A,D),     rewrites(B,G),     rewrites(C,H),     runstep(D,E,F) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(contains(I,J,K),L).

onestep(contains(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(contains(O,P,Q),R).

onestep(contains(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(contains(O,P,Q),R).

sigdec(contains,computes(boolean),[computes(map(A,B)),A,B]).

rewrite(contains(A,B,C),D) :-     rewrites(A,map_empty),     rewrites(B,_),     rewrites(C,_),     rewrites(false,D).

rewrite(contains(A,E,G),I) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,F),     rewrites(C,H),     rewrites(D,_),     rewrites(E,F),     rewrites(G,H),     rewrites(true,I).

rewrite(contains(A,E,F),Q) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,I),     rewrites(C,M),     rewrites(D,K),     rewrites(E,J),     rewrites(F,M),     rewrites(I,G),     runcheck(G,ground),     checktag(G,ground,_),     rewrites(J,H),     runcheck(H,ground),     checktag(H,ground,L),     \+rewrites(I,J),     rewrites(K,N),     rewrites(L,O),     rewrites(M,P),     rewrites(contains(N,O,P),Q).

rewrite(contains(A,E,F),R) :-     rewrites(A,map_prefix(B,C,D)),     rewrites(B,G),     rewrites(C,K),     rewrites(D,L),     rewrites(E,I),     rewrites(F,N),     rewrites(G,H),     runcheck(H,ground),     checktag(H,ground,_),     rewrites(I,J),     runcheck(J,ground),     checktag(J,ground,M),     \+rewrites(K,N),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(contains(O,P,Q),R).

sigdec(map_zip,map(A,B),[list(A),list(B)]).

onestep(map_zip(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_zip(G,H),I).

onestep(map_zip(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(map_zip(G,H),I).

onestep(map_zip(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_zip(J,K),L).

onestep(map_zip(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(map_zip(J,K),L).

sigdec(map_zip,computes(map(A,B)),[computes(list(A)),computes(list(B))]).

rewrite(map_zip(A,B),C) :-     rewrites(A,list_empty),     rewrites(B,list_empty),     rewrites(map_empty,C).

rewrite(map_zip(A,D),P) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,K),     rewrites(C,G),     rewrites(D,list_prefix(E,F)),     rewrites(E,L),     rewrites(F,H),     rewrites(G,I),     rewrites(H,J),     rewrites(map_zip(I,J),M),     rewrites(K,N),     rewrites(L,O),     rewrites(map_update(M,N,O),P).

