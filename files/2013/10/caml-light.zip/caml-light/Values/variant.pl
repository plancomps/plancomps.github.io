% Generated from Values/variant.csf

sigdec(variant,variant,[atom,expressible]).

onestep(variant(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(variant(G,H),I).

onestep(variant(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(variant(G,H),I).

onestep(variant(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(variant(J,K),L).

onestep(variant(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(variant(J,K),L).

sigdec(variant,computes(variant),[computes(atom),computes(expressible)]).

valcons(variant).

sigdec(variant,type,[]).

onestep(variant,A,B,resolve) :-     unobs(A),     rewrites(variant,B).

onestep(variant,A,B,typeval) :-     unobs(A),     rewrites(variant,B).

valsort(variant).

sigdec(variant,type,[map(atom,type)]).

onestep(variant(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(variant(E),F).

onestep(variant(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(variant(E),F).

onestep(variant(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(variant(E),F).

sigdec(variant,type,[computes(map(atom,type))]).

onestep(variant(A,B),E,variant(F),inhabit) :-     rewrites(A,G),     rewrites(B,C),     rewrites(C,D),     inhabit(D,E,map_select(F,G)).

sigdec(variant_type_extend,type,[type,map(atom,type)]).

onestep(variant_type_extend(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(variant_type_extend(G,H),I).

onestep(variant_type_extend(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(variant_type_extend(J,K),L).

onestep(variant_type_extend(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(variant_type_extend(J,K),L).

sigdec(variant_type_extend,type,[type,computes(map(atom,type))]).

rewrite(variant_type_extend(A,E),O) :-     rewrites(A,rectype(B,C)),     rewrites(B,H),     rewrites(C,variant(D)),     rewrites(D,G),     rewrites(E,F),     rewrites(map_over(F,G),K),     rewrites(H,I),     runcheck(I,typevar),     checktag(I,typevar,J),     rewrites(J,M),     rewrites(K,L),     rewrites(variant(L),N),     rewrites(rectype(M,N),O).

sigdec(variant_select,patt,[atom,patt]).

onestep(variant_select(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(variant_select(G,H),I).

onestep(variant_select(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(variant_select(G,H),I).

onestep(variant_select(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(variant_select(J,K),L).

onestep(variant_select(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(variant_select(J,K),L).

sigdec(variant_select,computes(patt),[computes(atom),computes(patt)]).

onestep(variant_select(A,B),E,L,run) :-     rewrites(A,F),     rewrites(B,C),     rewrites(C,D),     runcheck(D,patt),     checktag(D,patt,H),     unobs(E),     rewrites(variant,I),     rewrites(F,G),     rewrites(only(G),J),     rewrites(H,K),     rewrites(invert_1(I,J,K),L).

onestep(variant_select(A,B),G,depends(variant(C),I),inhabit) :-     rewrites(A,D),     rewrites(B,E),     rewrites(map_select(C,D),H),     rewrites(E,F),     inhabit(F,G,depends(H,I)).

