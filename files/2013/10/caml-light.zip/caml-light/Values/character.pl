% Generated from Values/character.csf

sigdec(character,type,[]).

onestep(character,A,B,resolve) :-     unobs(A),     rewrites(character,B).

onestep(character,A,B,typeval) :-     unobs(A),     rewrites(character,B).

valsort(character).

