% Generated from Values/option.csf

sigdec(none,option(_),[]).

onestep(none,A,option,inhabit) :-     unobs(A).

onestep(none,A,B,resolve) :-     unobs(A),     rewrites(none,B).

onestep(none,A,B,typeval) :-     unobs(A),     rewrites(none,B).

valcons(none).

sigdec(some,option(A),[A]).

onestep(some(A),D,option(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

onestep(some(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(some(E),F).

onestep(some(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(some(E),F).

valcons(some).

sigdec(option(_),type,[]).

onestep(option(A),B,E,resolve) :-     rewrites(A,C),     unobs(B),     rewrites(C,D),     rewrites(option(D),E).

onestep(option(A),B,E,typeval) :-     rewrites(A,C),     unobs(B),     rewrites(C,D),     rewrites(option(D),E).

valsort(option(_)).

