% Generated from Values/abs.csf

sigdec(abs,abs(_,A),[computes(A)]).

onestep(abs(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(abs(E),F).

onestep(abs(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(abs(E),F).

valcons(abs).

sigdec(abs(_,_),type,[]).

onestep(abs(A,B),C,H,resolve) :-     rewrites(A,D),     rewrites(B,E),     unobs(C),     rewrites(D,F),     rewrites(E,G),     rewrites(abs(F,G),H).

onestep(abs(A,B),C,H,typeval) :-     rewrites(A,D),     rewrites(B,E),     unobs(C),     rewrites(D,F),     rewrites(E,G),     rewrites(abs(F,G),H).

valsort(abs(_,_)).

sigdec(abs,type,[]).

onestep(abs,A,B,resolve) :-     unobs(A),     rewrites(abs,B).

onestep(abs,A,B,typeval) :-     unobs(A),     rewrites(abs,B).

typedef(abs,abs(expressible,expressible)).

valsort(abs).

onestep(abs(A),D,depends(B,H),inhabit) :-     rewrites(A,E),     rewrites(B,C),     G=[given=C|D],     rewrites(E,F),     inhabit(F,G,H).

