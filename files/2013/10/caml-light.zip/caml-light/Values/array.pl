% Generated from Values/array.csf

sigdec(array_empty,array(_),[]).

onestep(array_empty,A,B,resolve) :-     unobs(A),     rewrites(array_empty,B).

onestep(array_empty,A,B,typeval) :-     unobs(A),     rewrites(array_empty,B).

sigdec(array_empty,computes(array(_)),[]).

valcons(array_empty).

sigdec(array_prefix,array(A),[A,array(A)]).

onestep(array_prefix(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(array_prefix(G,H),I).

onestep(array_prefix(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(array_prefix(G,H),I).

onestep(array_prefix(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(array_prefix(J,K),L).

onestep(array_prefix(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(array_prefix(J,K),L).

sigdec(array_prefix,computes(array(A)),[A,computes(array(A))]).

valcons(array_prefix).

sigdec(array(_),type,[]).

onestep(array(A),B,E,resolve) :-     rewrites(A,C),     unobs(B),     rewrites(C,D),     rewrites(array(D),E).

onestep(array(A),B,E,typeval) :-     rewrites(A,C),     unobs(B),     rewrites(C,D),     rewrites(array(D),E).

valsort(array(_)).

sigdec(array,type,[type]).

onestep(array(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(array(E),F).

onestep(array(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(array(E),F).

sigdec(array1,computes(array(A)),[A]).

onestep(array1(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(array1(E),F).

onestep(array1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(array1(E),F).

onestep(array1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(array1(E),F).

sigdec(array1,computes(array(A)),[A]).

sigdec(array_append,array(A),[array(A),array(A)]).

onestep(array_append(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(array_append(G,H),I).

onestep(array_append(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(array_append(G,H),I).

onestep(array_append(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(array_append(J,K),L).

onestep(array_append(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(array_append(J,K),L).

sigdec(array_append,computes(array(A)),[computes(array(A)),computes(array(A))]).

rewrite(array1(A),E) :-     rewrites(A,B),     rewrites(B,C),     rewrites(array_empty,D),     rewrites(array_prefix(C,D),E).

rewrite(array_append(A,B),D) :-     rewrites(A,array_empty),     rewrites(B,C),     rewrites(C,D).

rewrite(array_append(A,D),L) :-     rewrites(A,array_prefix(B,C)),     rewrites(B,E),     rewrites(C,F),     rewrites(D,G),     rewrites(E,J),     rewrites(F,H),     rewrites(G,I),     rewrites(array_append(H,I),K),     rewrites(array_prefix(J,K),L).

onestep(array_append(A,B),J,array(G),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,array(G)) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,array(G)) ->     post_comp(H,I,J). 

onestep(array_empty,A,array(_),inhabit) :-     unobs(A).

onestep(array_prefix(A,B),J,array(G),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,variable(G)) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,array(G)) ->     post_comp(H,I,J). 

sigdec(array_select,A,[array(A),int]).

onestep(array_select(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(array_select(G,H),I).

onestep(array_select(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(array_select(G,H),I).

onestep(array_select(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(array_select(J,K),L).

onestep(array_select(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(array_select(J,K),L).

sigdec(array_select,A,[computes(array(A)),computes(int)]).

rewrite(array_select(A,D),F) :-     rewrites(A,array_prefix(B,C)),     rewrites(B,E),     rewrites(C,_),     rewrites(D,q(0)),     rewrites(E,F).

rewrite(array_select(A,D),M) :-     rewrites(A,array_prefix(B,C)),     rewrites(B,_),     rewrites(C,I),     rewrites(D,E),     rewrites(int_greater(E,q(0)),true),     rewrites(int_minus(E,q(1)),G),     rewrites(E,F),     runcheck(F,int),     checktag(F,int,_),     rewrites(G,H),     runcheck(H,int),     checktag(H,int,J),     rewrites(I,K),     rewrites(J,L),     rewrites(array_select(K,L),M).

onestep(array_select(A,B),J,variable(G),inhabit) :-     rewrites(A,E),     rewrites(B,C),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,int) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,array(G)) ->     post_comp(H,I,J). 

sigdec(array_create,array(A),[int,A]).

onestep(array_create(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(array_create(G,H),I).

onestep(array_create(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(array_create(J,K),L).

onestep(array_create(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(array_create(J,K),L).

sigdec(array_create,computes(array(A)),[computes(int),A]).

rewrite(array_create(A,B),F) :-     rewrites(A,q(1)),     rewrites(B,C),     rewrites(C,D),     rewrites(alloc(D),E),     rewrites(array1(E),F).

rewrite(array_create(A,B),N) :-     rewrites(A,C),     rewrites(B,I),     rewrites(int_greater(C,q(1)),true),     rewrites(C,D),     runcheck(D,int),     checktag(D,int,F),     rewrites(I,E),     rewrites(alloc(E),L),     rewrites(F,G),     rewrites(q(1),H),     rewrites(int_minus(G,H),J),     rewrites(I,K),     rewrites(array_create(J,K),M),     rewrites(array_prefix(L,M),N).

onestep(array_create(A,B),J,array(G),inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(J,H),     rewrites(C,D),     inhabit(D,H,int) ->     mid_comp(H,I),     rewrites(E,F),     inhabit(F,I,G) ->     post_comp(H,I,J). 

sigdec(array_length,int,[array(_)]).

onestep(array_length(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(array_length(E),F).

onestep(array_length(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(array_length(E),F).

onestep(array_length(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(array_length(E),F).

sigdec(array_length,computes(int),[computes(array(_))]).

rewrite(array_length(A),q(0)) :-     rewrites(A,array_empty).

rewrite(array_length(A),H) :-     rewrites(A,array_prefix(B,C)),     rewrites(B,_),     rewrites(C,D),     rewrites(D,E),     rewrites(array_length(E),F),     rewrites(q(1),G),     rewrites(int_plus(F,G),H).

onestep(array_length(A),D,int,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,array(_)).

sigdec(array_pattern,patt,[lazylist(pattern)]).

onestep(array_pattern(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(array_pattern(E),F).

onestep(array_pattern(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(array_pattern(E),F).

onestep(array_pattern(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(array_pattern(E),F).

sigdec(array_pattern,computes(patt),[computes(lazylist(pattern))]).

onestep(array_pattern(A),B,F,run) :-     rewrites(A,lazylist_empty),     rewrites(array_empty,D),     eq_label(B,[given=C|E]),     rewrites(C,D),     unobs(E),     rewrites(map_empty,F).

onestep(array_pattern(A),D,X,run) :-     rewrites(A,lazylist_prefix(B,C)),     rewrites(B,I),     rewrites(C,R),     rewrites(array_prefix(G,Q),F),     eq_label(D,[given=E|K]),     rewrites(E,F),     rewrites(G,H),     runcheck(H,variable),     checktag(H,variable,L),     rewrites(I,J),     runcheck(J,patt),     checktag(J,patt,N),     unobs(K),     rewrites(L,M),     rewrites(assigned_value(M),O),     rewrites(N,P),     rewrites(match(O,P),V),     rewrites(Q,T),     rewrites(R,S),     rewrites(array_pattern(S),U),     rewrites(match(T,U),W),     rewrites(accum(V,W),X).

