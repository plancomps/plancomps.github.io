% Generated from Values/fwd.csf

sigdec(fwd,fwd,[int]).

onestep(fwd(A),D,fwd(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

onestep(fwd(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(fwd(E),F).

onestep(fwd(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(fwd(E),F).

onestep(fwd(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(fwd(E),F).

sigdec(fwd,computes(fwd),[computes(int)]).

valcons(fwd).

sigdec(fwd,type,[]).

onestep(fwd,A,type,inhabit) :-     unobs(A).

onestep(fwd,A,B,resolve) :-     unobs(A),     rewrites(fwd,B).

onestep(fwd,A,B,typeval) :-     unobs(A),     rewrites(fwd,B).

valsort(fwd).

sigdec(fwd_next,fwd,[fwd]).

onestep(fwd_next(A),D,fwd,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,fwd).

onestep(fwd_next(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(fwd_next(E),F).

onestep(fwd_next(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(fwd_next(E),F).

onestep(fwd_next(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(fwd_next(E),F).

sigdec(fwd_next,computes(fwd),[computes(fwd)]).

rewrite(fwd_next(A),I) :-     rewrites(A,fwd(B)),     rewrites(B,C),     rewrites(C,D),     runcheck(D,int),     checktag(D,int,E),     rewrites(E,F),     rewrites(q(1),G),     rewrites(int_plus(F,G),H),     rewrites(fwd(H),I).

sigdec(fwd_first,fwd,[]).

onestep(fwd_first,A,fwd,inhabit) :-     unobs(A).

onestep(fwd_first,A,B,resolve) :-     unobs(A),     rewrites(fwd_first,B).

onestep(fwd_first,A,B,typeval) :-     unobs(A),     rewrites(fwd_first,B).

rewrite(fwd_first,B) :-     rewrites(q(0),A),     rewrites(fwd(A),B).

rewrite(fwd1,B) :-     rewrites(q(1),A),     rewrites(fwd(A),B).

rewrite(fwd2,B) :-     rewrites(q(2),A),     rewrites(fwd(A),B).

rewrite(fwd3,B) :-     rewrites(q(3),A),     rewrites(fwd(A),B).

