% Generated from Values/boolean.csf

sigdec(true,boolean,[]).

onestep(true,A,boolean,inhabit) :-     unobs(A).

onestep(true,A,B,resolve) :-     unobs(A),     rewrites(true,B).

onestep(true,A,B,typeval) :-     unobs(A),     rewrites(true,B).

valcons(true).

sigdec(false,boolean,[]).

onestep(false,A,boolean,inhabit) :-     unobs(A).

onestep(false,A,B,resolve) :-     unobs(A),     rewrites(false,B).

onestep(false,A,B,typeval) :-     unobs(A),     rewrites(false,B).

valcons(false).

sigdec(boolean,type,[]).

onestep(boolean,A,B,resolve) :-     unobs(A),     rewrites(boolean,B).

onestep(boolean,A,B,typeval) :-     unobs(A),     rewrites(boolean,B).

valsort(boolean).

sigdec(not,boolean,[boolean]).

onestep(not(A),D,boolean,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,boolean).

onestep(not(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(not(E),F).

onestep(not(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(not(E),F).

onestep(not(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(not(E),F).

sigdec(not,computes(boolean),[computes(boolean)]).

rewrite(not(A),B) :-     rewrites(A,false),     rewrites(true,B).

rewrite(not(A),B) :-     rewrites(A,true),     rewrites(false,B).

sigdec(and,boolean,[boolean,boolean]).

onestep(and(A,B),I,boolean,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,boolean) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,boolean) ->     post_comp(G,H,I). 

onestep(and(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(and(G,H),I).

onestep(and(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(and(G,H),I).

onestep(and(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(and(J,K),L).

onestep(and(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(and(J,K),L).

sigdec(and,computes(boolean),[computes(boolean),computes(boolean)]).

rewrite(and(A,B),C) :-     rewrites(A,true),     rewrites(B,true),     rewrites(true,C).

rewrite(and(A,B),C) :-     rewrites(A,true),     rewrites(B,false),     rewrites(false,C).

rewrite(and(A,B),C) :-     rewrites(A,false),     rewrites(B,true),     rewrites(false,C).

rewrite(and(A,B),C) :-     rewrites(A,false),     rewrites(B,false),     rewrites(false,C).

sigdec(or,boolean,[boolean,boolean]).

onestep(or(A,B),I,boolean,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,boolean) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,boolean) ->     post_comp(G,H,I). 

onestep(or(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(or(G,H),I).

onestep(or(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(or(G,H),I).

onestep(or(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(or(J,K),L).

onestep(or(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(or(J,K),L).

sigdec(or,computes(boolean),[computes(boolean),computes(boolean)]).

rewrite(or(A,B),C) :-     rewrites(A,true),     rewrites(B,true),     rewrites(true,C).

rewrite(or(A,B),C) :-     rewrites(A,true),     rewrites(B,false),     rewrites(true,C).

rewrite(or(A,B),C) :-     rewrites(A,false),     rewrites(B,false),     rewrites(false,C).

rewrite(or(A,B),C) :-     rewrites(A,false),     rewrites(B,true),     rewrites(true,C).

