% Generated from Values/list.csf

sigdec(list_empty,list(_),[]).

onestep(list_empty,A,B,resolve) :-     unobs(A),     rewrites(list_empty,B).

onestep(list_empty,A,B,typeval) :-     unobs(A),     rewrites(list_empty,B).

sigdec(list_empty,computes(list(_)),[]).

valcons(list_empty).

sigdec(list_prefix,list(A),[A,list(A)]).

onestep(list_prefix(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_prefix(G,H),I).

onestep(list_prefix(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_prefix(G,H),I).

onestep(list_prefix(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_prefix(J,K),L).

onestep(list_prefix(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_prefix(J,K),L).

sigdec(list_prefix,computes(list(A)),[A,computes(list(A))]).

valcons(list_prefix).

sigdec(list(_),type,[]).

onestep(list(A),B,E,resolve) :-     rewrites(A,C),     unobs(B),     rewrites(C,D),     rewrites(list(D),E).

onestep(list(A),B,E,typeval) :-     rewrites(A,C),     unobs(B),     rewrites(C,D),     rewrites(list(D),E).

valsort(list(_)).

sigdec(list_append1,list(A),[list(A),A]).

onestep(list_append1(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_append1(G,H),I).

onestep(list_append1(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_append1(J,K),L).

onestep(list_append1(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_append1(J,K),L).

sigdec(list_append1,computes(list(A)),[computes(list(A)),A]).

rewrite(list_append1(A,B),F) :-     rewrites(A,list_empty),     rewrites(B,C),     rewrites(C,D),     rewrites(list_empty,E),     rewrites(list_prefix(D,E),F).

rewrite(list_append1(A,D),L) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,F),     rewrites(D,G),     rewrites(E,J),     rewrites(F,H),     rewrites(G,I),     rewrites(list_append1(H,I),K),     rewrites(list_prefix(J,K),L).

sigdec(list_reverse,list(A),[list(A)]).

onestep(list_reverse(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(list_reverse(E),F).

onestep(list_reverse(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(list_reverse(E),F).

onestep(list_reverse(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(list_reverse(E),F).

sigdec(list_reverse,computes(list(A)),[computes(list(A))]).

rewrite(list_reverse(A),B) :-     rewrites(A,list_empty),     rewrites(list_empty,B).

rewrite(list_reverse(A),H) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,D),     rewrites(D,F),     rewrites(E,G),     rewrites(list_append1(F,G),H).

sigdec(list_append,list(A),[list(A),list(A)]).

onestep(list_append(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_append(G,H),I).

onestep(list_append(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_append(G,H),I).

onestep(list_append(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_append(J,K),L).

onestep(list_append(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_append(J,K),L).

sigdec(list_append,computes(list(A)),[computes(list(A)),computes(list(A))]).

rewrite(list_append(A,B),D) :-     rewrites(A,list_empty),     rewrites(B,C),     rewrites(C,D).

rewrite(list_append(A,D),L) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,F),     rewrites(D,G),     rewrites(E,J),     rewrites(F,H),     rewrites(G,I),     rewrites(list_append(H,I),K),     rewrites(list_prefix(J,K),L).

sigdec(list1,list(A),[A]).

onestep(list1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(list1(E),F).

onestep(list1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(list1(E),F).

rewrite(list1(A),E) :-     rewrites(A,B),     rewrites(B,C),     rewrites(list_empty,D),     rewrites(list_prefix(C,D),E).

sigdec(lazylist_empty,lazylist(_),[]).

onestep(lazylist_empty,A,lazylist,inhabit) :-     unobs(A).

onestep(lazylist_empty,A,B,resolve) :-     unobs(A),     rewrites(lazylist_empty,B).

onestep(lazylist_empty,A,B,typeval) :-     unobs(A),     rewrites(lazylist_empty,B).

valcons(lazylist_empty).

sigdec(lazylist_prefix,lazylist(A),[A,lazylist(A)]).

onestep(lazylist_prefix(A,B),K,lazylist(E,H),inhabit) :-     rewrites(A,C),     rewrites(B,F),     pre_comp(K,I),     rewrites(C,D),     inhabit(D,I,E) ->     mid_comp(I,J),     rewrites(F,G),     inhabit(G,J,H) ->     post_comp(I,J,K). 

onestep(lazylist_prefix(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(lazylist_prefix(G,H),I).

onestep(lazylist_prefix(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(lazylist_prefix(J,K),L).

onestep(lazylist_prefix(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(lazylist_prefix(J,K),L).

sigdec(lazylist_prefix,computes(lazylist(A)),[A,computes(lazylist(A))]).

valcons(lazylist_prefix).

sigdec(lazylist(_),type,[]).

onestep(lazylist(A),B,E,resolve) :-     rewrites(A,C),     unobs(B),     rewrites(C,D),     rewrites(lazylist(D),E).

onestep(lazylist(A),B,E,typeval) :-     rewrites(A,C),     unobs(B),     rewrites(C,D),     rewrites(lazylist(D),E).

valsort(lazylist(_)).

sigdec(list_select,A,[list(A),int]).

onestep(list_select(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_select(G,H),I).

onestep(list_select(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_select(G,H),I).

onestep(list_select(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_select(J,K),L).

onestep(list_select(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_select(J,K),L).

sigdec(list_select,A,[computes(list(A)),computes(int)]).

rewrite(list_select(A,D),F) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,_),     rewrites(D,q(0)),     rewrites(E,F).

rewrite(list_select(A,D),M) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,_),     rewrites(C,I),     rewrites(D,E),     rewrites(int_greater(E,q(0)),true),     rewrites(int_minus(E,q(1)),G),     rewrites(E,F),     runcheck(F,int),     checktag(F,int,_),     rewrites(G,H),     runcheck(H,int),     checktag(H,int,J),     rewrites(I,K),     rewrites(J,L),     rewrites(list_select(K,L),M).

sigdec(list_length,int,[list(_)]).

onestep(list_length(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(list_length(E),F).

onestep(list_length(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(list_length(E),F).

onestep(list_length(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(list_length(E),F).

sigdec(list_length,computes(int),[computes(list(_))]).

rewrite(list_length(A),q(0)) :-     rewrites(A,list_empty).

rewrite(list_length(A),H) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,_),     rewrites(C,D),     rewrites(D,E),     rewrites(list_length(E),F),     rewrites(q(1),G),     rewrites(int_plus(F,G),H).

sigdec(list_union,list(A),[list(A),list(A)]).

onestep(list_union(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_union(G,H),I).

onestep(list_union(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_union(G,H),I).

onestep(list_union(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_union(J,K),L).

onestep(list_union(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_union(J,K),L).

sigdec(list_union,computes(list(A)),[computes(list(A)),computes(list(A))]).

rewrite(list_union(A,B),D) :-     rewrites(A,list_empty),     rewrites(B,C),     rewrites(C,D).

rewrite(list_union(A,D),L) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,F),     rewrites(D,G),     rewrites(list_contains(G,E),false),     rewrites(E,J),     rewrites(F,H),     rewrites(G,I),     rewrites(list_union(H,I),K),     rewrites(list_prefix(J,K),L).

rewrite(list_union(A,D),J) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,F),     rewrites(D,G),     rewrites(list_contains(G,E),true),     rewrites(F,H),     rewrites(G,I),     rewrites(list_union(H,I),J).

sigdec(list_contains,boolean,[list(A),A]).

onestep(list_contains(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_contains(G,H),I).

onestep(list_contains(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_contains(J,K),L).

onestep(list_contains(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_contains(J,K),L).

sigdec(list_contains,computes(boolean),[computes(list(A)),A]).

rewrite(list_contains(A,B),C) :-     rewrites(A,list_empty),     rewrites(B,_),     rewrites(false,C).

rewrite(list_contains(A,D),F) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,_),     rewrites(D,E),     rewrites(true,F).

rewrite(list_contains(A,D),J) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,F),     rewrites(D,G),     \+rewrites(E,G),     rewrites(F,H),     rewrites(G,I),     rewrites(list_contains(H,I),J).

sigdec(list_remove,list(A),[list(A),A]).

onestep(list_remove(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_remove(G,H),I).

onestep(list_remove(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_remove(J,K),L).

onestep(list_remove(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_remove(J,K),L).

sigdec(list_remove,computes(list(A)),[computes(list(A)),A]).

rewrite(list_remove(A,B),C) :-     rewrites(A,list_empty),     rewrites(B,_),     rewrites(list_empty,C).

rewrite(list_remove(A,D),I) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,F),     rewrites(C,E),     rewrites(D,F),     rewrites(E,G),     rewrites(F,H),     rewrites(list_remove(G,H),I).

rewrite(list_remove(A,D),L) :-     rewrites(A,list_prefix(B,C)),     rewrites(B,E),     rewrites(C,F),     rewrites(D,G),     \+rewrites(E,G),     rewrites(E,J),     rewrites(F,H),     rewrites(G,I),     rewrites(list_remove(H,I),K),     rewrites(list_prefix(J,K),L).

sigdec(list_removes,list(A),[list(A),list(A)]).

onestep(list_removes(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_removes(G,H),I).

onestep(list_removes(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(list_removes(G,H),I).

onestep(list_removes(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_removes(J,K),L).

onestep(list_removes(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(list_removes(J,K),L).

sigdec(list_removes,computes(list(A)),[computes(list(A)),computes(list(A))]).

rewrite(list_removes(A,B),D) :-     rewrites(A,C),     rewrites(B,list_empty),     rewrites(C,D).

rewrite(list_removes(A,B),L) :-     rewrites(A,E),     rewrites(B,list_prefix(C,D)),     rewrites(C,I),     rewrites(D,F),     rewrites(E,G),     rewrites(F,H),     rewrites(list_removes(G,H),J),     rewrites(I,K),     rewrites(list_remove(J,K),L).

