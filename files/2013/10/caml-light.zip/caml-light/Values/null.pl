% Generated from Values/null.csf

sigdec(null,null,[]).

onestep(null,A,null,inhabit) :-     unobs(A).

onestep(null,A,B,resolve) :-     unobs(A),     rewrites(null,B).

onestep(null,A,B,typeval) :-     unobs(A),     rewrites(null,B).

valcons(null).

sigdec(null,type,[]).

onestep(null,A,type,inhabit) :-     unobs(A).

onestep(null,A,B,resolve) :-     unobs(A),     rewrites(null,B).

onestep(null,A,B,typeval) :-     unobs(A),     rewrites(null,B).

valsort(null).

