% Generated from Values/typeid.csf

sigdec(typeid,typeid,[atom]).

onestep(typeid(A),D,typeid(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

onestep(typeid(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(typeid(E),F).

onestep(typeid(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(typeid(E),F).

onestep(typeid(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(typeid(E),F).

sigdec(typeid,computes(typeid),[computes(atom)]).

valcons(typeid).

sigdec(typeid,type,[]).

onestep(typeid,A,type,inhabit) :-     unobs(A).

onestep(typeid,A,B,resolve) :-     unobs(A),     rewrites(typeid,B).

onestep(typeid,A,B,typeval) :-     unobs(A),     rewrites(typeid,B).

valsort(typeid).

subsort(typeid,id).

