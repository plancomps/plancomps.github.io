% Generated from Values/skip.csf

sigdec(skip,skip,[]).

onestep(skip,A,skip,inhabit) :-     unobs(A).

onestep(skip,A,B,resolve) :-     unobs(A),     rewrites(skip,B).

onestep(skip,A,B,typeval) :-     unobs(A),     rewrites(skip,B).

valcons(skip).

sigdec(skip,type,[]).

onestep(skip,A,type,inhabit) :-     unobs(A).

onestep(skip,A,B,resolve) :-     unobs(A),     rewrites(skip,B).

onestep(skip,A,B,typeval) :-     unobs(A),     rewrites(skip,B).

valsort(skip).

