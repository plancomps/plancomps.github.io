% Generated from Values/variable.csf

sigdec(var,variable,[int]).

onestep(var(A),D,variable(E),inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,E).

onestep(var(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(var(E),F).

onestep(var(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(var(E),F).

onestep(var(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(var(E),F).

sigdec(var,computes(variable),[computes(int)]).

valcons(var).

sigdec(variable,type,[]).

onestep(variable,A,B,resolve) :-     unobs(A),     rewrites(variable,B).

onestep(variable,A,B,typeval) :-     unobs(A),     rewrites(variable,B).

valsort(variable).

sigdec(variable,type,[type]).

onestep(variable(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(variable(E),F).

onestep(variable(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(variable(E),F).

sigdec(variable_next,variable,[variable]).

onestep(variable_next(A),D,variable,inhabit) :-     rewrites(A,B),     rewrites(B,C),     inhabit(C,D,variable).

onestep(variable_next(A),C,F,run) :-     rewrites(A,B),     runstep(B,C,D) ->     rewrites(D,E),     rewrites(variable_next(E),F).

onestep(variable_next(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(variable_next(E),F).

onestep(variable_next(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(variable_next(E),F).

sigdec(variable_next,computes(variable),[computes(variable)]).

rewrite(variable_next(A),I) :-     rewrites(A,var(B)),     rewrites(B,C),     rewrites(C,D),     runcheck(D,int),     checktag(D,int,E),     rewrites(E,F),     rewrites(q(1),G),     rewrites(int_plus(F,G),H),     rewrites(var(H),I).

sigdec(variable_first,variable,[]).

onestep(variable_first,A,variable,inhabit) :-     unobs(A).

onestep(variable_first,A,B,resolve) :-     unobs(A),     rewrites(variable_first,B).

onestep(variable_first,A,B,typeval) :-     unobs(A),     rewrites(variable_first,B).

rewrite(variable_first,B) :-     rewrites(q(0),A),     rewrites(var(A),B).

rewrite(var1,B) :-     rewrites(q(1),A),     rewrites(var(A),B).

rewrite(var2,B) :-     rewrites(q(2),A),     rewrites(var(A),B).

rewrite(var3,B) :-     rewrites(q(3),A),     rewrites(var(A),B).

