% Generated from Values/equal#2.csf

sigdec(equal,boolean,[A,A]).

onestep(equal(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(equal(G,H),I).

onestep(equal(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(equal(G,H),I).

onestep(equal(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(equal(J,K),L).

onestep(equal(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(equal(J,K),L).

sigdec(equal,computes(boolean),[A,A]).

rewrite(equal(A,B),F) :-     rewrites(A,D),     rewrites(B,D),     rewrites(D,C),     runcheck(C,ground),     checktag(C,ground,_),     rewrites(D,E),     runcheck(E,val),     checktag(E,val,_),     rewrites(true,F).

rewrite(equal(A,B),I) :-     rewrites(A,E),     rewrites(B,G),     rewrites(E,C),     runcheck(C,ground),     checktag(C,ground,_),     rewrites(G,D),     runcheck(D,ground),     checktag(D,ground,_),     \+rewrites(E,G),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,_),     rewrites(G,H),     runcheck(H,val),     checktag(H,val,_),     rewrites(false,I).

sigdec(less,boolean,[A,A]).

onestep(less(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(less(G,H),I).

onestep(less(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(less(G,H),I).

onestep(less(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(less(J,K),L).

onestep(less(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(less(J,K),L).

sigdec(less,computes(boolean),[A,A]).

rewrite(less(A,B),I) :-     rewrites(A,E),     rewrites(B,G),     rewrites(E,C),     runcheck(C,ground),     checktag(C,ground,_),     rewrites(G,D),     runcheck(D,ground),     checktag(D,ground,_),     lessthan(E,G),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,_),     rewrites(G,H),     runcheck(H,val),     checktag(H,val,_),     rewrites(true,I).

rewrite(less(A,B),I) :-     rewrites(A,E),     rewrites(B,G),     rewrites(E,C),     runcheck(C,ground),     checktag(C,ground,_),     rewrites(G,D),     runcheck(D,ground),     checktag(D,ground,_),     \+lessthan(E,G),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,_),     rewrites(G,H),     runcheck(H,val),     checktag(H,val,_),     rewrites(false,I).

sigdec(greater,boolean,[A,A]).

onestep(greater(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(greater(G,H),I).

onestep(greater(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(greater(G,H),I).

onestep(greater(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(greater(J,K),L).

onestep(greater(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(greater(J,K),L).

sigdec(greater,computes(boolean),[A,A]).

rewrite(greater(A,B),I) :-     rewrites(A,G),     rewrites(B,E),     rewrites(G,C),     runcheck(C,ground),     checktag(C,ground,_),     rewrites(E,D),     runcheck(D,ground),     checktag(D,ground,_),     lessthan(E,G),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,_),     rewrites(G,H),     runcheck(H,val),     checktag(H,val,_),     rewrites(true,I).

rewrite(greater(A,B),I) :-     rewrites(A,G),     rewrites(B,E),     rewrites(G,C),     runcheck(C,ground),     checktag(C,ground,_),     rewrites(E,D),     runcheck(D,ground),     checktag(D,ground,_),     \+lessthan(E,G),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,_),     rewrites(G,H),     runcheck(H,val),     checktag(H,val,_),     rewrites(false,I).

sigdec(less_equal,boolean,[A,A]).

onestep(less_equal(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(less_equal(G,H),I).

onestep(less_equal(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(less_equal(G,H),I).

onestep(less_equal(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(less_equal(J,K),L).

onestep(less_equal(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(less_equal(J,K),L).

sigdec(less_equal,computes(boolean),[A,A]).

sigdec(greater_equal,boolean,[A,A]).

onestep(greater_equal(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(greater_equal(G,H),I).

onestep(greater_equal(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(greater_equal(G,H),I).

onestep(greater_equal(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(greater_equal(J,K),L).

onestep(greater_equal(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(greater_equal(J,K),L).

sigdec(greater_equal,computes(boolean),[A,A]).

rewrite(less_equal(A,B),O) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,I),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,J),     rewrites(I,G),     rewrites(J,H),     rewrites(less(G,H),M),     rewrites(I,K),     rewrites(J,L),     rewrites(equal(K,L),N),     rewrites(or(M,N),O).

rewrite(greater_equal(A,B),O) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,val),     checktag(D,val,I),     rewrites(E,F),     runcheck(F,val),     checktag(F,val,J),     rewrites(I,G),     rewrites(J,H),     rewrites(greater(G,H),M),     rewrites(I,K),     rewrites(J,L),     rewrites(equal(K,L),N),     rewrites(or(M,N),O).

