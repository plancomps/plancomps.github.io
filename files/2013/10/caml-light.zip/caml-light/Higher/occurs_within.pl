% Generated from Higher/occurs_within.csf

sigdec(occurs_within_1,boolean,[A,val]) :-     sigdec(A,B,[_]),     subsort_rt(B,val).

onestep(occurs_within_1(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(occurs_within_1(G,H),I).

onestep(occurs_within_1(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(occurs_within_1(J,K),L).

onestep(occurs_within_1(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(occurs_within_1(J,K),L).

sigdec(occurs_within_1,computes(boolean),[A,computes(val)]) :-     sigdec(A,B,[_]),     subsort_rt(B,val).

rewrite(occurs_within_1(A,B),E) :-     rewrites(A,_),     rewrites(B,C),     rewrites(C,D),     runcheck(D,constant),     checktag(D,constant,_),     rewrites(false,E).

rewrite(occurs_within_1(A,B),F) :-     rewrites(A,D),     decompose(C,D,[E]),     rewrites(B,C),     decompose(C,D,[E]),     rewrites(E,_),     rewrites(true,F).

rewrite(occurs_within_1(A,B),O) :-     rewrites(A,K),     decompose(C,H,[D]),     rewrites(B,C),     decompose(C,H,[D]),     rewrites(D,L),     decompose(E,H,[L]),     rewrites(E,F),     decompose(E,H,[L]),     runcheck(F,val),     checktag(F,val,_),     decompose(G,H,[L]),     decompose(I,K,[J]),     \+rewrites(G,I),     decompose(G,H,[L]),     decompose(I,K,[J]),     rewrites(K,M),     rewrites(L,N),     rewrites(occurs_within_1(M,N),O).

rewrite(occurs_within_1(A,B),R) :-     rewrites(A,L),     decompose(C,G,[D,E]),     rewrites(B,C),     decompose(C,G,[D,E]),     rewrites(D,I),     rewrites(E,M),     decompose(F,G,[I,M]),     rewrites(F,H),     decompose(F,G,[I,M]),     runcheck(H,val),     checktag(H,val,_),     rewrites(L,J),     rewrites(I,K),     rewrites(occurs_within_1(J,K),P),     rewrites(L,N),     rewrites(M,O),     rewrites(occurs_within_1(N,O),Q),     rewrites(or(P,Q),R).

rewrite(occurs_within_1(A,B),X) :-     rewrites(A,R),     decompose(C,H,[D,E,F]),     rewrites(B,C),     decompose(C,H,[D,E,F]),     rewrites(D,J),     rewrites(E,M),     rewrites(F,S),     decompose(G,H,[J,M,S]),     rewrites(G,I),     decompose(G,H,[J,M,S]),     runcheck(I,val),     checktag(I,val,_),     rewrites(R,K),     rewrites(J,L),     rewrites(occurs_within_1(K,L),P),     rewrites(R,N),     rewrites(M,O),     rewrites(occurs_within_1(N,O),Q),     rewrites(or(P,Q),V),     rewrites(R,T),     rewrites(S,U),     rewrites(occurs_within_1(T,U),W),     rewrites(or(V,W),X).

