% Generated from Higher/abs.csf

sigdec(abs_1,abs,[A]) :-     sigdec(A,B,[_]),     subsort_rt(B,expressible).

onestep(abs_1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(abs_1(E),F).

onestep(abs_1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(abs_1(E),F).

sigdec(abs_1,abs,[A]) :-     sigdec(A,B,[_,_]),     subsort_rt(B,expressible).

onestep(abs_1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(abs_1(E),F).

onestep(abs_1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(abs_1(E),F).

rewrite(abs_1(A),F) :-     rewrites(A,C),     sigdec(C,_,[_]),     rewrites(given,D),     decompose(B,C,[D]),     rewrites(B,E),     decompose(B,C,[D]),     rewrites(abs(E),F).

rewrite(abs_1(A),I) :-     rewrites(A,E),     sigdec(E,_,[_,_]),     rewrites(given,B),     rewrites(project1(B),F),     rewrites(given,C),     rewrites(project2(C),G),     decompose(D,E,[F,G]),     rewrites(D,H),     decompose(D,E,[F,G]),     rewrites(abs(H),I).

onestep(abs_1(A),E,depends(D,C),inhabit) :-     rewrites(A,B),     sigdec(B,C,[D]),     unobs(E).

onestep(abs_1(A),F,depends(tuple2(D,E),C),inhabit) :-     rewrites(A,B),     sigdec(B,C,[D,E]),     unobs(F).

