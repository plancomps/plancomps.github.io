% Generated from Higher/loose.csf

sigdec(loose_1,patt,[A,map(B,patt)]) :-     sigdec(A,C,[map(B,expressible)]),     subsort_rt(C,expressible).

onestep(loose_1(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(loose_1(G,H),I).

onestep(loose_1(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(loose_1(J,K),L).

onestep(loose_1(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(loose_1(J,K),L).

sigdec(loose_1,computes(patt),[A,computes(map(B,patt))]) :-     sigdec(A,C,[map(B,expressible)]),     subsort_rt(C,expressible).

rewrite(loose_1(A,B),H) :-     rewrites(A,C),     rewrites(B,D),     rewrites(C,E),     rewrites(D,F),     rewrites(loose_decl_1(E,F),G),     rewrites(abs(G),H).

onestep(loose_1(A,B),G,depends(C,map_empty),inhabit) :-     rewrites(A,E),     rewrites(B,map_empty),     decompose(D,E,[F]),     rewrites(C,D),     decompose(D,E,[F]),     unobs(G).

onestep(loose_1(A,B),U,depends(M,map_union(L,H)),inhabit) :-     rewrites(A,O),     rewrites(B,map_prefix(C,D,E)),     rewrites(C,P),     rewrites(D,J),     rewrites(E,F),     pre_comp(U,S),     rewrites(loose_1(O,F),G),     decompose(I,O,[R]),     inhabit(G,S,depends(I,H)),     decompose(I,O,[R]) ->     mid_comp(S,T),     rewrites(J,K),     inhabit(K,T,depends(Q,L)) ->     decompose(N,O,[map_prefix(P,Q,R)]),     rewrites(M,N),     decompose(N,O,[map_prefix(P,Q,R)]),     post_comp(S,T,U).

onestep(loose_decl_1(A,B),F,J,run) :-     rewrites(A,D),     rewrites(B,map_empty),     decompose(C,D,[E]),     rewrites(C,H),     decompose(C,D,[E]),     eq_label(F,[given=G|I]),     rewrites(G,H),     unobs(I),     rewrites(map_empty,J).

onestep(loose_decl_1(A,B),C,map_empty,inhabit) :-     rewrites(A,H),     rewrites(B,map_empty),     rewrites(F,E),     eq_label(C,[given=D|J]),     rewrites(D,E),     decompose(G,H,[I]),     rewrites(F,G),     decompose(G,H,[I]),     unobs(J).

onestep(loose_decl_1(A,B),F,map_union(O,K),inhabit) :-     rewrites(A,R),     rewrites(B,map_prefix(C,D,E)),     rewrites(C,S),     rewrites(D,M),     rewrites(E,I),     rewrites(P,H),     eq_label(F,[given=G|X]),     rewrites(G,H),     pre_comp(X,V),     rewrites(loose_1(R,I),J),     decompose(L,R,[U]),     inhabit(J,V,depends(L,K)),     decompose(L,R,[U]) ->     mid_comp(V,W),     rewrites(M,N),     inhabit(N,W,depends(T,O)) ->     decompose(Q,R,[map_prefix(S,T,U)]),     rewrites(P,Q),     decompose(Q,R,[map_prefix(S,T,U)]),     post_comp(V,W,X).

onestep(loose_decl_1(A,B),H,U,run) :-     rewrites(A,G),     rewrites(B,map_prefix(C,D,E)),     rewrites(C,L),     rewrites(D,R),     rewrites(E,map_empty),     decompose(F,G,[K]),     rewrites(F,J),     decompose(F,G,[K]),     eq_label(H,[given=I|P]),     rewrites(I,J),     rewrites(contains_key(K,L),true),     rewrites(map_select(K,L),N),     rewrites(L,M),     runcheck(M,field),     checktag(M,field,_),     rewrites(N,O),     runcheck(O,expressible),     checktag(O,expressible,Q),     unobs(P),     rewrites(Q,S),     rewrites(R,T),     rewrites(match(S,T),U).

onestep(loose_decl_1(A,B),P,O,run) :-     rewrites(A,G),     rewrites(B,map_prefix(C,D,E)),     rewrites(C,L),     rewrites(D,_),     rewrites(E,map_empty),     decompose(F,G,[K]),     rewrites(F,I),     decompose(F,G,[K]),     eq_label(P,[given=H|J]),     rewrites(H,I),     eq_label(J,[failure+=_|N]),     rewrites(contains_key(K,L),false),     rewrites(L,M),     runcheck(M,field),     checktag(M,field,_),     unobs(N),     rewrites(stuck,O),     rewrites(true,Q),     eq_label(P,[failure+=Q|_]).

onestep(loose_decl_1(A,B),G,ZH,run) :-     rewrites(A,Z),     rewrites(B,map_prefix(C,D,E)),     rewrites(C,J),     rewrites(D,P),     rewrites(E,ZA),     decompose(F,Z,[W]),     rewrites(F,I),     decompose(F,Z,[W]),     eq_label(G,[given=H|L]),     rewrites(H,I),     \+rewrites(ZA,map_empty),     rewrites(J,K),     runcheck(K,field),     checktag(K,field,O),     unobs(L),     rewrites(W,N),     decompose(M,Z,[N]),     rewrites(M,U),     decompose(M,Z,[N]),     rewrites(Z,S),     rewrites(O,Q),     rewrites(P,R),     rewrites(map1(Q,R),T),     rewrites(loose_1(S,T),V),     rewrites(match(U,V),ZF),     rewrites(W,Y),     decompose(X,Z,[Y]),     rewrites(X,ZD),     decompose(X,Z,[Y]),     rewrites(Z,ZB),     rewrites(ZA,ZC),     rewrites(loose_1(ZB,ZC),ZE),     rewrites(match(ZD,ZE),ZG),     rewrites(accum(ZF,ZG),ZH).

onestep(loose_decl_1(A,B),M,L,run) :-     rewrites(A,G),     rewrites(B,_),     rewrites(I,D),     eq_label(M,[given=C|E]),     rewrites(C,D),     eq_label(E,[failure+=_|K]),     decompose(F,G,[H]),     \+rewrites(I,F),     decompose(F,G,[H]),     rewrites(I,J),     runcheck(J,expressible),     checktag(J,expressible,_),     unobs(K),     rewrites(stuck,L),     rewrites(true,N),     eq_label(M,[failure+=N|_]).

