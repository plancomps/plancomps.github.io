% Generated from Higher/type_vars#2.csf

sigdec(type_vars,list(typevar),[type]).

onestep(type_vars(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(type_vars(E),F).

onestep(type_vars(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(type_vars(E),F).

rewrite(type_vars(A),D) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,nullary),     checktag(C,nullary,_),     rewrites(list_empty,D).

rewrite(type_vars(A),G) :-     rewrites(A,B),     different(B,typevar(_)),     decompose(C,D,[E]),     rewrites(B,C),     decompose(C,D,[E]),     rewrites(E,F),     rewrites(type_vars(F),G).

rewrite(type_vars(A),G) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,typevar),     checktag(C,typevar,D),     rewrites(D,E),     rewrites(list_empty,F),     rewrites(list_prefix(E,F),G).

rewrite(type_vars(A),L) :-     decompose(B,C,[D,E]),     rewrites(A,B),     decompose(B,C,[D,E]),     rewrites(D,F),     rewrites(E,H),     rewrites(F,G),     rewrites(type_vars(G),J),     rewrites(H,I),     rewrites(type_vars(I),K),     rewrites(list_union(J,K),L).

rewrite(type_vars(A),Q) :-     decompose(B,C,[D,E,F]),     rewrites(A,B),     decompose(B,C,[D,E,F]),     rewrites(D,G),     rewrites(E,I),     rewrites(F,M),     rewrites(G,H),     rewrites(type_vars(H),K),     rewrites(I,J),     rewrites(type_vars(J),L),     rewrites(list_append(K,L),O),     rewrites(M,N),     rewrites(type_vars(N),P),     rewrites(list_union(O,P),Q).

sigdec(free_vars,list(typevar),[type]).

onestep(free_vars(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(free_vars(E),F).

onestep(free_vars(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(free_vars(E),F).

rewrite(free_vars(A),D) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,nullary),     checktag(C,nullary,_),     rewrites(list_empty,D).

rewrite(free_vars(A),G) :-     rewrites(A,B),     different(B,typevar(_)),     decompose(C,D,[E]),     rewrites(B,C),     decompose(C,D,[E]),     rewrites(E,F),     rewrites(free_vars(F),G).

rewrite(free_vars(A),G) :-     rewrites(A,B),     rewrites(B,C),     runcheck(C,typevar),     checktag(C,typevar,D),     rewrites(D,E),     rewrites(list_empty,F),     rewrites(list_prefix(E,F),G).

rewrite(free_vars(A),I) :-     rewrites(A,type_abs(B,C)),     rewrites(B,F),     rewrites(C,D),     rewrites(D,E),     rewrites(free_vars(E),G),     rewrites(F,H),     rewrites(list_removes(G,H),I).

rewrite(free_vars(A),M) :-     decompose(B,F,[C,D]),     rewrites(A,B),     decompose(B,F,[C,D]),     rewrites(C,G),     rewrites(D,I),     decompose(E,F,[G,I]),     \+rewrites(E,type_abs(_,_)),     decompose(E,F,[G,I]),     rewrites(G,H),     rewrites(free_vars(H),K),     rewrites(I,J),     rewrites(free_vars(J),L),     rewrites(list_union(K,L),M).

rewrite(free_vars(A),Q) :-     decompose(B,C,[D,E,F]),     rewrites(A,B),     decompose(B,C,[D,E,F]),     rewrites(D,G),     rewrites(E,I),     rewrites(F,M),     rewrites(G,H),     rewrites(free_vars(H),K),     rewrites(I,J),     rewrites(free_vars(J),L),     rewrites(list_append(K,L),O),     rewrites(M,N),     rewrites(free_vars(N),P),     rewrites(list_union(O,P),Q).

