% Generated from Higher/subst#2.csf

sigdec(subst,type,[type,typevar,type]).

onestep(subst(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,D),     rewrites(C,H),     runstep(D,E,G) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(subst(I,J,K),L).

onestep(subst(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(subst(O,P,Q),R).

onestep(subst(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(subst(O,P,Q),R).

sigdec(subst,type,[type,computes(typevar),type]).

rewrite(subst(A,B,C),I) :-     rewrites(A,F),     rewrites(B,D),     rewrites(C,_),     rewrites(D,E),     runcheck(E,typevar),     checktag(E,typevar,_),     rewrites(F,G),     runcheck(G,nullary),     checktag(G,nullary,H),     rewrites(H,I).

rewrite(subst(A,B,C),N) :-     rewrites(A,D),     rewrites(B,F),     rewrites(C,J),     different(D,F),     decompose(E,P,[H]),     rewrites(D,E),     decompose(E,P,[H]),     rewrites(F,G),     runcheck(G,typevar),     checktag(G,typevar,I),     rewrites(H,K),     rewrites(I,L),     rewrites(J,M),     rewrites(subst(K,L,M),Q),     decompose(O,P,[Q]),     rewrites(O,N),     decompose(O,P,[Q]).

rewrite(subst(A,B,C),G) :-     rewrites(A,D),     rewrites(B,D),     rewrites(C,F),     rewrites(D,E),     runcheck(E,typevar),     checktag(E,typevar,_),     rewrites(F,G).

rewrite(subst(A,D,E),L) :-     rewrites(A,type_abs(B,C)),     rewrites(B,H),     rewrites(C,I),     rewrites(D,F),     rewrites(E,_),     rewrites(list_contains(H,F),true),     rewrites(F,G),     runcheck(G,typevar),     checktag(G,typevar,_),     rewrites(H,J),     rewrites(I,K),     rewrites(type_abs(J,K),L).

rewrite(subst(A,D,E),Q) :-     rewrites(A,type_abs(B,C)),     rewrites(B,H),     rewrites(C,I),     rewrites(D,F),     rewrites(E,K),     rewrites(list_contains(H,F),false),     rewrites(F,G),     runcheck(G,typevar),     checktag(G,typevar,J),     rewrites(H,O),     rewrites(I,L),     rewrites(J,M),     rewrites(K,N),     rewrites(subst(L,M,N),P),     rewrites(type_abs(O,P),Q).

rewrite(subst(A,E,F),T) :-     decompose(B,V,[C,D]),     rewrites(A,B),     decompose(B,V,[C,D]),     rewrites(C,J),     rewrites(D,N),     rewrites(E,H),     rewrites(F,P),     decompose(G,V,[J,N]),     \+rewrites(G,type_abs(_,_)),     decompose(G,V,[J,N]),     rewrites(H,I),     runcheck(I,typevar),     checktag(I,typevar,O),     rewrites(J,K),     rewrites(O,L),     rewrites(P,M),     rewrites(subst(K,L,M),W),     rewrites(N,Q),     rewrites(O,R),     rewrites(P,S),     rewrites(subst(Q,R,S),X),     decompose(U,V,[W,X]),     rewrites(U,T),     decompose(U,V,[W,X]).

rewrite(subst(A,F,G),X) :-     decompose(B,Z,[C,D,E]),     rewrites(A,B),     decompose(B,Z,[C,D,E]),     rewrites(C,J),     rewrites(D,N),     rewrites(E,R),     rewrites(F,H),     rewrites(G,T),     rewrites(H,I),     runcheck(I,typevar),     checktag(I,typevar,S),     rewrites(J,K),     rewrites(S,L),     rewrites(T,M),     rewrites(subst(K,L,M),ZA),     rewrites(N,O),     rewrites(S,P),     rewrites(T,Q),     rewrites(subst(O,P,Q),ZB),     rewrites(R,U),     rewrites(S,V),     rewrites(T,W),     rewrites(subst(U,V,W),ZC),     decompose(Y,Z,[ZA,ZB,ZC]),     rewrites(Y,X),     decompose(Y,Z,[ZA,ZB,ZC]).

sigdec(subst,type,[type,map(id,type)]).

onestep(subst(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(subst(G,H),I).

onestep(subst(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(subst(J,K),L).

onestep(subst(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(subst(J,K),L).

sigdec(subst,type,[type,computes(map(id,type))]).

rewrite(subst(A,B),D) :-     rewrites(A,C),     rewrites(B,map_empty),     rewrites(C,D).

rewrite(subst(A,B),Q) :-     rewrites(A,H),     rewrites(B,map_prefix(C,D,E)),     rewrites(C,F),     rewrites(D,M),     rewrites(E,I),     rewrites(F,G),     runcheck(G,typevar),     checktag(G,typevar,L),     rewrites(H,J),     rewrites(I,K),     rewrites(subst(J,K),N),     rewrites(L,O),     rewrites(M,P),     rewrites(subst(N,O,P),Q).

