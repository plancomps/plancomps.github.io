% Generated from Higher/struct_eq#2.csf

sigdec(struct_eq,boolean,[val,val]).

onestep(struct_eq(A,B),I,boolean,inhabit) :-     rewrites(A,C),     rewrites(B,E),     pre_comp(I,G),     rewrites(C,D),     inhabit(D,G,val) ->     mid_comp(G,H),     rewrites(E,F),     inhabit(F,H,val) ->     post_comp(G,H,I). 

onestep(struct_eq(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(struct_eq(G,H),I).

onestep(struct_eq(A,B),D,I,run) :-     rewrites(A,C),     rewrites(B,F),     runstep(C,D,E) ->     rewrites(E,G),     rewrites(F,H),     rewrites(struct_eq(G,H),I).

onestep(struct_eq(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(struct_eq(J,K),L).

onestep(struct_eq(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(struct_eq(J,K),L).

sigdec(struct_eq,computes(boolean),[computes(val),computes(val)]).

rewrite(struct_eq(A,B),E) :-     rewrites(A,C),     rewrites(B,C),     rewrites(C,D),     runcheck(D,constant),     checktag(D,constant,_),     rewrites(true,E).

rewrite(struct_eq(A,B),G) :-     rewrites(A,C),     rewrites(B,E),     \+rewrites(C,E),     rewrites(C,D),     runcheck(D,constant),     checktag(D,constant,_),     rewrites(E,F),     runcheck(F,constant),     checktag(F,constant,_),     rewrites(false,G).

rewrite(struct_eq(A,B),M) :-     rewrites(A,C),     rewrites(B,E),     rewrites(C,D),     runcheck(D,variable),     checktag(D,variable,G),     rewrites(E,F),     runcheck(F,variable),     checktag(F,variable,I),     rewrites(G,H),     rewrites(assigned_value(H),K),     rewrites(I,J),     rewrites(assigned_value(J),L),     rewrites(struct_eq(K,L),M).

rewrite(struct_eq(A,D),Q) :-     decompose(B,L,[C]),     rewrites(A,B),     decompose(B,L,[C]),     rewrites(C,M),     decompose(E,L,[F]),     rewrites(D,E),     decompose(E,L,[F]),     rewrites(F,N),     decompose(G,L,[M]),     rewrites(G,H),     decompose(G,L,[M]),     runcheck(H,val),     checktag(H,val,_),     decompose(I,L,[N]),     rewrites(I,J),     decompose(I,L,[N]),     runcheck(J,val),     checktag(J,val,_),     decompose(K,L,[M]),     \+rewrites(K,var(_)),     decompose(K,L,[M]),     rewrites(M,O),     rewrites(N,P),     rewrites(struct_eq(O,P),Q).

rewrite(struct_eq(A,D),M) :-     decompose(B,K,[C]),     rewrites(A,B),     decompose(B,K,[C]),     rewrites(C,F),     rewrites(D,I),     decompose(E,K,[F]),     rewrites(E,G),     decompose(E,K,[F]),     runcheck(G,val),     checktag(G,val,_),     rewrites(I,H),     runcheck(H,val),     checktag(H,val,_),     decompose(J,K,[L]),     \+rewrites(I,J),     decompose(J,K,[L]),     rewrites(false,M).

rewrite(struct_eq(A,E),X) :-     decompose(B,L,[C,D]),     rewrites(A,B),     decompose(B,L,[C,D]),     rewrites(C,N),     rewrites(D,R),     decompose(F,L,[G,H]),     rewrites(E,F),     decompose(F,L,[G,H]),     rewrites(G,O),     rewrites(H,S),     decompose(I,L,[N,R]),     rewrites(I,J),     decompose(I,L,[N,R]),     runcheck(J,val),     checktag(J,val,_),     decompose(K,L,[O,S]),     rewrites(K,M),     decompose(K,L,[O,S]),     runcheck(M,val),     checktag(M,val,_),     rewrites(N,P),     rewrites(O,Q),     rewrites(struct_eq(P,Q),V),     rewrites(R,T),     rewrites(S,U),     rewrites(struct_eq(T,U),W),     rewrites(and(V,W),X).

rewrite(struct_eq(A,E),P) :-     decompose(B,M,[C,D]),     rewrites(A,B),     decompose(B,M,[C,D]),     rewrites(C,G),     rewrites(D,H),     rewrites(E,K),     decompose(F,M,[G,H]),     rewrites(F,I),     decompose(F,M,[G,H]),     runcheck(I,val),     checktag(I,val,_),     rewrites(K,J),     runcheck(J,val),     checktag(J,val,_),     decompose(L,M,[N,O]),     \+rewrites(K,L),     decompose(L,M,[N,O]),     rewrites(false,P).

rewrite(struct_eq(A,F),ZF) :-     decompose(B,N,[C,D,E]),     rewrites(A,B),     decompose(B,N,[C,D,E]),     rewrites(C,P),     rewrites(D,T),     rewrites(E,Z),     decompose(G,N,[H,I,J]),     rewrites(F,G),     decompose(G,N,[H,I,J]),     rewrites(H,Q),     rewrites(I,U),     rewrites(J,ZA),     decompose(K,N,[P,T,Z]),     rewrites(K,L),     decompose(K,N,[P,T,Z]),     runcheck(L,val),     checktag(L,val,_),     decompose(M,N,[Q,U,ZA]),     rewrites(M,O),     decompose(M,N,[Q,U,ZA]),     runcheck(O,val),     checktag(O,val,_),     rewrites(P,R),     rewrites(Q,S),     rewrites(struct_eq(R,S),X),     rewrites(T,V),     rewrites(U,W),     rewrites(struct_eq(V,W),Y),     rewrites(and(X,Y),ZD),     rewrites(Z,ZB),     rewrites(ZA,ZC),     rewrites(struct_eq(ZB,ZC),ZE),     rewrites(and(ZD,ZE),ZF).

rewrite(struct_eq(A,F),S) :-     decompose(B,O,[C,D,E]),     rewrites(A,B),     decompose(B,O,[C,D,E]),     rewrites(C,H),     rewrites(D,I),     rewrites(E,J),     rewrites(F,M),     decompose(G,O,[H,I,J]),     rewrites(G,K),     decompose(G,O,[H,I,J]),     runcheck(K,val),     checktag(K,val,_),     rewrites(M,L),     runcheck(L,val),     checktag(L,val,_),     decompose(N,O,[P,Q,R]),     \+rewrites(M,N),     decompose(N,O,[P,Q,R]),     rewrites(false,S).

