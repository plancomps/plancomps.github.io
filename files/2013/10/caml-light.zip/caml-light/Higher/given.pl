% Generated from Higher/given.csf

sigdec(given_1,computes(B),[A]) :-     sigdec(A,C,[B]),     subsort_rt(C,value).

onestep(given_1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(given_1(E),F).

onestep(given_1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(given_1(E),F).

sigdec(given1_1,computes(B),[A]) :-     sigdec(A,C,[B,_]),     subsort_rt(C,value).

onestep(given1_1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(given1_1(E),F).

onestep(given1_1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(given1_1(E),F).

sigdec(given2_1,computes(B),[A]) :-     sigdec(A,C,[_,B]),     subsort_rt(C,value).

onestep(given2_1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(given2_1(E),F).

onestep(given2_1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(given2_1(E),F).

sigdec(given1_1,computes(B),[A]) :-     sigdec(A,C,[B,_,_]),     subsort_rt(C,value).

onestep(given1_1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(given1_1(E),F).

onestep(given1_1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(given1_1(E),F).

sigdec(given2_1,computes(B),[A]) :-     sigdec(A,C,[_,B,_]),     subsort_rt(C,value).

onestep(given2_1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(given2_1(E),F).

onestep(given2_1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(given2_1(E),F).

sigdec(given3_1,computes(B),[A]) :-     sigdec(A,C,[_,_,B]),     subsort_rt(C,value).

onestep(given3_1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(given3_1(E),F).

onestep(given3_1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(given3_1(E),F).

onestep(given_1(A),C,I,run) :-     rewrites(A,F),     decompose(B,F,[H]),     rewrites(B,E),     decompose(B,F,[H]),     eq_label(C,[given=D|G]),     rewrites(D,E),     sigdec(F,_,[_]),     unobs(G),     rewrites(H,I).

onestep(given_1(A),L,K,run) :-     rewrites(A,F),     rewrites(H,C),     eq_label(L,[given=B|D]),     rewrites(B,C),     eq_label(D,[failure+=_|J]),     sigdec(F,_,[_]),     decompose(E,F,[G]),     \+rewrites(H,E),     decompose(E,F,[G]),     rewrites(H,I),     runcheck(I,passable),     checktag(I,passable,_),     unobs(J),     rewrites(stuck,K),     rewrites(true,M),     eq_label(L,[failure+=M|_]).

onestep(given_1(A),C,H,inhabit) :-     rewrites(A,G),     decompose(B,G,[H]),     rewrites(B,E),     decompose(B,G,[H]),     eq_label(C,[given=D|I]),     rewrites(D,E),     decompose(F,G,[H]),     rewrites(_,F),     decompose(F,G,[H]),     unobs(I).

onestep(given1_1(A),D,J,run) :-     rewrites(A,G),     decompose(B,G,[I,C]),     rewrites(B,F),     decompose(B,G,[I,C]),     eq_label(D,[given=E|H]),     rewrites(E,F),     sigdec(G,_,[_,_]),     unobs(H),     rewrites(I,J).

onestep(given1_1(A),M,L,run) :-     rewrites(A,F),     rewrites(I,C),     eq_label(M,[given=B|D]),     rewrites(B,C),     eq_label(D,[failure+=_|K]),     sigdec(F,_,[_,_]),     decompose(E,F,[G,H]),     \+rewrites(I,E),     decompose(E,F,[G,H]),     rewrites(I,J),     runcheck(J,passable),     checktag(J,passable,_),     unobs(K),     rewrites(stuck,L),     rewrites(true,N),     eq_label(M,[failure+=N|_]).

onestep(given2_1(A),D,J,run) :-     rewrites(A,G),     decompose(B,G,[C,I]),     rewrites(B,F),     decompose(B,G,[C,I]),     eq_label(D,[given=E|H]),     rewrites(E,F),     sigdec(G,_,[_,_]),     unobs(H),     rewrites(I,J).

onestep(given2_1(A),M,L,run) :-     rewrites(A,F),     rewrites(I,C),     eq_label(M,[given=B|D]),     rewrites(B,C),     eq_label(D,[failure+=_|K]),     sigdec(F,_,[_,_]),     decompose(E,F,[G,H]),     \+rewrites(I,E),     decompose(E,F,[G,H]),     rewrites(I,J),     runcheck(J,passable),     checktag(J,passable,_),     unobs(K),     rewrites(stuck,L),     rewrites(true,N),     eq_label(M,[failure+=N|_]).

onestep(given1_1(A),B,H,inhabit) :-     rewrites(A,G),     rewrites(E,D),     eq_label(B,[given=C|J]),     rewrites(C,D),     sigdec(G,_,[_,_]),     decompose(F,G,[H,I]),     rewrites(E,F),     decompose(F,G,[H,I]),     unobs(J).

onestep(given2_1(A),B,I,inhabit) :-     rewrites(A,G),     rewrites(E,D),     eq_label(B,[given=C|J]),     rewrites(C,D),     sigdec(G,_,[_,_]),     decompose(F,G,[H,I]),     rewrites(E,F),     decompose(F,G,[H,I]),     unobs(J).

onestep(given1_1(A),E,K,run) :-     rewrites(A,H),     decompose(B,H,[J,C,D]),     rewrites(B,G),     decompose(B,H,[J,C,D]),     eq_label(E,[given=F|I]),     rewrites(F,G),     sigdec(H,_,[_,_,_]),     unobs(I),     rewrites(J,K).

onestep(given1_1(A),N,M,run) :-     rewrites(A,F),     rewrites(J,C),     eq_label(N,[given=B|D]),     rewrites(B,C),     eq_label(D,[failure+=_|L]),     sigdec(F,_,[_,_,_]),     decompose(E,F,[G,H,I]),     \+rewrites(J,E),     decompose(E,F,[G,H,I]),     rewrites(J,K),     runcheck(K,passable),     checktag(K,passable,_),     unobs(L),     rewrites(stuck,M),     rewrites(true,O),     eq_label(N,[failure+=O|_]).

onestep(given2_1(A),E,K,run) :-     rewrites(A,H),     decompose(B,H,[C,J,D]),     rewrites(B,G),     decompose(B,H,[C,J,D]),     eq_label(E,[given=F|I]),     rewrites(F,G),     sigdec(H,_,[_,_,_]),     unobs(I),     rewrites(J,K).

onestep(given2_1(A),N,M,run) :-     rewrites(A,F),     rewrites(J,C),     eq_label(N,[given=B|D]),     rewrites(B,C),     eq_label(D,[failure+=_|L]),     sigdec(F,_,[_,_,_]),     decompose(E,F,[G,H,I]),     \+rewrites(J,E),     decompose(E,F,[G,H,I]),     rewrites(J,K),     runcheck(K,passable),     checktag(K,passable,_),     unobs(L),     rewrites(stuck,M),     rewrites(true,O),     eq_label(N,[failure+=O|_]).

onestep(given3_1(A),E,K,run) :-     rewrites(A,H),     decompose(B,H,[C,D,J]),     rewrites(B,G),     decompose(B,H,[C,D,J]),     eq_label(E,[given=F|I]),     rewrites(F,G),     sigdec(H,_,[_,_,_]),     unobs(I),     rewrites(J,K).

onestep(given3_1(A),N,M,run) :-     rewrites(A,F),     rewrites(J,C),     eq_label(N,[given=B|D]),     rewrites(B,C),     eq_label(D,[failure+=_|L]),     sigdec(F,_,[_,_,_]),     decompose(E,F,[G,H,I]),     \+rewrites(J,E),     decompose(E,F,[G,H,I]),     rewrites(J,K),     runcheck(K,passable),     checktag(K,passable,_),     unobs(L),     rewrites(stuck,M),     rewrites(true,O),     eq_label(N,[failure+=O|_]).

onestep(given1_1(A),B,H,inhabit) :-     rewrites(A,G),     rewrites(E,D),     eq_label(B,[given=C|K]),     rewrites(C,D),     sigdec(G,_,[_,_,_]),     decompose(F,G,[H,I,J]),     rewrites(E,F),     decompose(F,G,[H,I,J]),     unobs(K).

onestep(given2_1(A),B,I,inhabit) :-     rewrites(A,G),     rewrites(E,D),     eq_label(B,[given=C|K]),     rewrites(C,D),     sigdec(G,_,[_,_,_]),     decompose(F,G,[H,I,J]),     rewrites(E,F),     decompose(F,G,[H,I,J]),     unobs(K).

onestep(given3_1(A),B,J,inhabit) :-     rewrites(A,G),     rewrites(E,D),     eq_label(B,[given=C|K]),     rewrites(C,D),     sigdec(G,_,[_,_,_]),     decompose(F,G,[H,I,J]),     rewrites(E,F),     decompose(F,G,[H,I,J]),     unobs(K).

