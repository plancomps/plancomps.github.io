% Generated from Higher/invert.csf

sigdec(invert_1,patt,[A,patt,patt]) :-     sigdec(A,B,[_,_]),     subsort_rt(B,passable).

onestep(invert_1(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,G),     rewrites(C,D),     runstep(D,E,H) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(invert_1(I,J,K),L).

onestep(invert_1(A,B,C),E,L,run) :-     rewrites(A,F),     rewrites(B,D),     rewrites(C,H),     runstep(D,E,G) ->     rewrites(F,I),     rewrites(G,J),     rewrites(H,K),     rewrites(invert_1(I,J,K),L).

onestep(invert_1(A,B,C),K,R,resolve) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     onestep(D,I,L,resolve) ->     mid_comp(I,J),     pre_comp(J,G),     onestep(E,G,M,resolve) ->     mid_comp(G,H),     onestep(F,H,N,resolve) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(invert_1(O,P,Q),R).

onestep(invert_1(A,B,C),K,R,typeval) :-     rewrites(A,D),     rewrites(B,E),     rewrites(C,F),     pre_comp(K,I),     typeval(D,I,L) ->     mid_comp(I,J),     pre_comp(J,G),     typeval(E,G,M) ->     mid_comp(G,H),     typeval(F,H,N) ->     post_comp(G,H,J),     post_comp(I,J,K),     rewrites(L,O),     rewrites(M,P),     rewrites(N,Q),     rewrites(invert_1(O,P,Q),R).

sigdec(invert_1,computes(patt),[A,computes(patt),computes(patt)]) :-     sigdec(A,B,[_,_]),     subsort_rt(B,passable).

sigdec(invert_1,patt,[A,patt]) :-     sigdec(A,B,[_]),     subsort_rt(B,passable).

onestep(invert_1(A,B),D,I,run) :-     rewrites(A,E),     rewrites(B,C),     runstep(C,D,F) ->     rewrites(E,G),     rewrites(F,H),     rewrites(invert_1(G,H),I).

onestep(invert_1(A,B),G,L,resolve) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     onestep(C,E,H,resolve) ->     mid_comp(E,F),     onestep(D,F,I,resolve) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(invert_1(J,K),L).

onestep(invert_1(A,B),G,L,typeval) :-     rewrites(A,C),     rewrites(B,D),     pre_comp(G,E),     typeval(C,E,H) ->     mid_comp(E,F),     typeval(D,F,I) ->     post_comp(E,F,G),     rewrites(H,J),     rewrites(I,K),     rewrites(invert_1(J,K),L).

sigdec(invert_1,computes(patt),[A,computes(patt)]) :-     sigdec(A,B,[_]),     subsort_rt(B,passable).

sigdec(invert_1,patt,[A]) :-     sigdec(A,B,[]),     subsort_rt(B,passable).

onestep(invert_1(A),C,F,resolve) :-     rewrites(A,B),     onestep(B,C,D,resolve) ->     rewrites(D,E),     rewrites(invert_1(E),F).

onestep(invert_1(A),C,F,typeval) :-     rewrites(A,B),     typeval(B,C,D) ->     rewrites(D,E),     rewrites(invert_1(E),F).

onestep(invert_1(A),B,E,run) :-     rewrites(A,C),     unobs(B),     rewrites(C,D),     rewrites(only(D),E).

onestep(invert_1(A,B),E,L,run) :-     rewrites(A,F),     rewrites(B,C),     rewrites(C,D),     runcheck(D,patt),     checktag(D,patt,H),     unobs(E),     rewrites(F,G),     rewrites(given_1(G),I),     rewrites(H,J),     rewrites(match(I,J),K),     rewrites(abs(K),L).

onestep(invert_1(A,B,C),H,U,run) :-     rewrites(A,M),     rewrites(B,D),     rewrites(C,F),     rewrites(D,E),     runcheck(E,patt),     checktag(E,patt,J),     rewrites(F,G),     runcheck(G,patt),     checktag(G,patt,O),     unobs(H),     rewrites(M,I),     rewrites(given1_1(I),K),     rewrites(J,L),     rewrites(match(K,L),R),     rewrites(M,N),     rewrites(given2_1(N),P),     rewrites(O,Q),     rewrites(match(P,Q),S),     rewrites(map_union(R,S),T),     rewrites(abs(T),U).

onestep(invert_1(A),D,B,inhabit) :-     rewrites(A,C),     rewrites(B,depends(C,map_empty)),     unobs(D).

onestep(invert_1(A,B),H,C,inhabit) :-     rewrites(A,E),     rewrites(B,F),     decompose(D,E,[I]),     rewrites(C,depends(D,J)),     decompose(D,E,[I]),     rewrites(F,G),     inhabit(G,H,depends(I,J)).

onestep(invert_1(A,B,C),R,D,inhabit) :-     rewrites(A,F),     rewrites(B,G),     rewrites(C,J),     decompose(E,F,[I,L]),     rewrites(D,depends(E,M)),     decompose(E,F,[I,L]),     pre_comp(R,P),     rewrites(G,H),     inhabit(H,P,depends(I,N)) ->     mid_comp(P,Q),     rewrites(J,K),     inhabit(K,Q,depends(L,O)) ->     rewrites(M,map_union(N,O)),     post_comp(P,Q,R).

