let rec map f l =
  match l with
    [] -> []
  | hd :: tl -> f hd :: map f tl;;
(* val map : ('a -> 'b) -> 'a list -> 'b list = <fun> *)

map (function n -> n * 2 + 1) [0;1;2;3;4];;
(* - : int list = [1; 3; 5; 7; 9] *)
