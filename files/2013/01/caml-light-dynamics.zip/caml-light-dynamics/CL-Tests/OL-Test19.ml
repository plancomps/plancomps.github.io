exception Empty_list;;
(* exception Empty_list *)

let head l =
  match l with
    [] -> raise Empty_list
  | hd :: tl -> hd;;
(* val head : 'a list -> 'a = <fun> *)

head [1;2];;
(* - : int = 1 *)

let rec assoc x l =
   match l with
   | [] -> raise Not_found
   | (y,z)::yzs -> if x = y then z else assoc x yzs;;

assoc 1 [(0, "zero"); (1, "one")];;
(* - : string = "one" *)

assoc 2 [(0, "zero"); (1, "one")];;
(* Exception: Not_found. *)

head [];;
(* Exception: Empty_list. *)

