(1 < 2) = false;;
(* - : bool = false *)
