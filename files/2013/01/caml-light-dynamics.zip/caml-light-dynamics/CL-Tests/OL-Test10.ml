let square x = x *. x;;
(* val square : float -> float = <fun> *)

square 2.5;;