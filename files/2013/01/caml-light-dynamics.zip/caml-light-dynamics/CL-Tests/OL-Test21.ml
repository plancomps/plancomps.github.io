let temporarily_set_reference ref newval funct =
  let oldval = !ref in
  try
    ref := newval;
    let res = funct () in
    ref := oldval;
    res
  with x ->
    ref := oldval;
    raise x;;
(* val temporarily_set_reference : 'a ref -> 'a -> (unit -> 'b) -> 'b = <fun> *)

let x = ref 0;;

let y = fun u -> x := ! x + 1; !x;;

!x;;
temporarily_set_reference x 2 y;;
!x;;
