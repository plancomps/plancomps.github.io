type expression =
    Const of float
  | Var of string
  | Sum of expression * expression    (* e1 + e2 *)
  | Diff of expression * expression   (* e1 - e2 *)
  | Prod of expression * expression   (* e1 * e2 *)
  | Quot of expression * expression   (* e1 / e2 *)
;;
(* type expression =
      Const of float
    | Var of string
    | Sum of expression * expression
    | Diff of expression * expression
    | Prod of expression * expression
    | Quot of expression * expression
*)

let rec assoc x l =
   match l with
   | [] -> raise Not_found
   | (y,z)::yzs -> if x = y then z else assoc x yzs;;

exception Unbound_variable of string;;
(* exception Unbound_variable of string *)

let rec eval env exp =
  match exp with
    Const c -> c
  | Var v ->
      (try assoc v env with Not_found -> raise(Unbound_variable v))
  | Sum(f, g) -> eval env f +. eval env g
  | Diff(f, g) -> eval env f -. eval env g
  | Prod(f, g) -> eval env f *. eval env g
  | Quot(f, g) -> eval env f /. eval env g;;
(* val eval : (string * float) list -> expression -> float = <fun> *)

let rec deriv exp dv =
  match exp with
    Const c -> Const 0.0
  | Var v -> if v = dv then Const 1.0 else Const 0.0
  | Sum(f, g) -> Sum(deriv f dv, deriv g dv)
  | Diff(f, g) -> Diff(deriv f dv, deriv g dv)
  | Prod(f, g) -> Sum(Prod(f, deriv g dv), Prod(deriv f dv, g))
  | Quot(f, g) -> Quot(Diff(Prod(deriv f dv, g), Prod(f, deriv g dv)),
                       Prod(g, g))
;;
(* val deriv : expression -> string -> expression = <fun> *)

let print_expr exp =
  (* Local function definitions *)
  let open_paren prec op_prec =
    if prec > op_prec then print_string "(" in
  let close_paren prec op_prec =
    if prec > op_prec then print_string ")" in
  let rec print prec exp =     (* prec is the current precedence *)
    match exp with
      Const c -> print_float c
    | Var v -> print_string v
    | Sum(f, g) ->
        open_paren prec 0;
        print 0 f; print_string " + "; print 0 g;
        close_paren prec 0
    | Diff(f, g) ->
        open_paren prec 0;
        print 0 f; print_string " - "; print 1 g;
        close_paren prec 0
    | Prod(f, g) ->
        open_paren prec 2;
        print 2 f; print_string " * "; print 2 g;
        close_paren prec 2
    | Quot(f, g) ->
        open_paren prec 2;
        print 2 f; print_string " / "; print 3 g;
        close_paren prec 2
  in print 0 exp;;
(* val print_expr : expression -> unit = <fun> *)

let e = Sum(Prod(Const 2.0, Var "x"), Const 1.0);;
(* val e : expression = Sum (Prod (Const 2., Var "x"), Const 1.) *)

eval [("x", 1.0); ("y", 3.14)] (Prod(Sum(Var "x", Const 2.0), Var "y"));;
(* - : float = 9.42 *)

deriv (Quot(Const 1.0, Var "x")) "x";;
(* - : expression =
  Quot (Diff (Prod (Const 0., Var "x"), Prod (Const 1., Const 1.)),
   Prod (Var "x", Var "x"))
*)

print_expr e; print_newline();;
(* 2. * x + 1.
   - : unit = () *)

print_expr (deriv e "x"); print_newline();;
(* 2. * 1. + 0. * x + 0.
   - : unit = () *)

