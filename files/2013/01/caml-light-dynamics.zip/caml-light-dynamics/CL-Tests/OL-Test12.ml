let deriv f dx = function x -> (f(x +. dx) -. f(x)) /. dx;;
(* val deriv : (float -> float) -> float -> float -> float = <fun> *)

let cos = deriv sin 0.0000000000001;;
(* val sin' : float -> float = <fun> *)

cos pi;;
(* - : float = -1.00000000013961143 *)
