let rec assoc x l =
   match l with
   | [] -> raise Not_found
   | (y,z)::yzs -> if x = y then z else assoc x yzs;;

let rec name_of_binary_digit digit =
  try
    assoc digit [0, "zero"; 1, "one"]
  with Not_found ->
    "not a binary digit";;
(* val name_of_binary_digit : int -> string = <fun> *)

name_of_binary_digit 0;;
(* - : string = "zero" *)

name_of_binary_digit (-1);;
(* - : string = "not a binary digit" *)

