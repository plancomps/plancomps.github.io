#/usr/bash

# to do : options -d trace -t time -f file

TRACE=false
TIME=false

while getopts dtf: OPTION
do
  case "$OPTION" in
    d) TRACE=true;;
    t) TIME=true;;
    f) FILE="$OPTARG";;
  esac
done

if $TRACE; then
  START="assert(tracing),startf('"$FILE"'),halt."
else
  START="startf_nt('"$FILE"'),halt."
fi

# echo $START

if $TIME; then
  swipl -s Prolog/run_fct.pl -g $START
else
  swipl -s Prolog/run_fct.pl -q -g $START
fi
