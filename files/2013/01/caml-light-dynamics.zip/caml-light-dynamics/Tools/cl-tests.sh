echo -e "Generating Prolog..."

./gen-pl.sh

echo -e "Test Append:"

cd ../CL-Translation
../Tools/gen-fct.sh -m CL-Translation -f ../CL-Tests/append.ml -o ../CL-Tests/append.fct

cd ../Tools
./run-fct.sh -f ../CL-Tests/append.fct

for i in $(seq 1 23)
do

  echo "Test $i:"

  cd ../CL-Translation
  ../Tools/gen-fct.sh -n -m CL-Translation -f ../CL-Tests/OL-Test$i.ml -o ../CL-Tests/OL-Test$i.fct

  echo "Running..."

  cd ../Tools
  ./run-fct.sh -f ../CL-Tests/OL-Test$i.fct

  echo -e "\n\n"

done



