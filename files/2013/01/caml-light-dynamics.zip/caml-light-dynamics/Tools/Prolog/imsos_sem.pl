:- ensure_loaded(imsos_syn).

% PROLOG GENERATION
% -----------------

/* SEMANTICS OF CSF RULES
    via Prolog translation

  Prolog code Head :- Conditions just as list [Head|Conditions]
  will "pretty print" to Prolog code later. */

term2pl(Term,Term).

% In seq(skip,C) = C we can't just match the premise against skip, but rather
% against seq(A,B) and see if A normalises (rewrites) to skip

% subterms2vars_r(Term,Term1,Code) replaces subexpressions that aren't variables
% in Term to varaibles in Term1, and Code is the rewrites FROM those variables
% TO the desired form. For similar things in the target we must rewrite FROM the
% desired form TO a variable and make a similar replacement.

subterm2vars_r(Term,Term1,[rewrites(Term1,Term)]) :- myvar(Term), !.
subterm2vars_r(q(Xs),q(Xs),[]) :- !.
subterm2vars_r(Term,Term1,Code) :- nonvar(Term), Term =.. [F|Xs],
   subterms2vars_r(Xs,Ys,Code), Term1 =.. [F|Ys].

subterms2vars_r([],[],[]).
subterms2vars_r([X|Xs],[X1|Ys],Code1) :- myvar(X), !, 
   subterms2vars_r(Xs,Ys,Code),
   Code1 = [rewrites(X1,X)|Code].
subterms2vars_r([X|Xs],[Y|Ys],Code) :- nonvar(X),
   Code1 = [rewrites(Y,X1)],
   subterm2vars_r(X,X1,Code2),
   subterms2vars_r(Xs,Ys,Code3),
   append([Code1,Code2,Code3],Code).

subterm2vars_w(Term,Term1,[rewrites(Term,Term1)]) :- myvar(Term), !.
subterm2vars_w(q(Xs),q(Xs),[]) :- !.
subterm2vars_w(Term,Z,Code) :- nonvar(Term), Term =.. [F|Xs],
   subterms2vars_w(Xs,Ys,Code1),
   Term1 =.. [F|Ys],
   Code2 = [rewrites(Term1,Z)],
   append(Code1,Code2,Code).

subterms2vars_w([],[],[]).
subterms2vars_w([X|Xs],[X1|Ys],Code1) :- myvar(X), !,
   subterms2vars_w(Xs,Ys,Code),
   Code1 = [rewrites(X,X1)|Code].
subterms2vars_w([X|Xs],[Y|Ys],Code) :- nonvar(X),
   subterm2vars_w1(X,X1,Code1),
   Code2 = [rewrites(X1,Y)],
   subterms2vars_w(Xs,Ys,Code3),
   append([Code1,Code2,Code3],Code).

myvar(X) :- var(X).
myvar(X) :- atom(X), name(X,[Y|_]), upper(_,[Y],[]).

subterm2vars_w1(Term,Term,[]) :- myvar(Term), !.
subterm2vars_w1(q(Xs),q(Xs),[]) :- !.
subterm2vars_w1(Term,Term1,Code) :- nonvar(Term), Term =.. [F|Xs],
   subterms2vars_w(Xs,Ys,Code), Term1 =.. [F|Ys].

% Premise to list of prolog conditions.
% prem2pl(formula,inner label,generated code,subst)
% The "inner label" is (a variable for) the rest of the label after named
% components have been extracted.
% subst is substitution: built up and used in premises, used in conclusion
% for use if X : value is a premise (must reduce X to normal form, new var X')

prem2pl(imsos_termeq(Source,Target),_,Conds,Subst,Subst) :-
    term2pl(Source,SourcePl), term2pl(Target,TargetPl),
    Conds = [rewrites(SourcePl,TargetPl)].
prem2pl(imsos_termlt(Source,Target),_,Conds,Subst,Subst) :-
    term2pl(Source,SourcePl), term2pl(Target,TargetPl),
    Conds = [lessthan(SourcePl,TargetPl)].
prem2pl(imsos_onestep(Source,Eqns,Target,intype),Var,Conds,Subst,Subst1) :- !,
    NewPrems = [imsos_onestep(Source,Eqns,NewVar,inhabit),
                imsos_onestep(NewVar,Eqns,Target,subtype)],
    prems2pl(NewPrems,Var,Conds,Subst,Subst1).
prem2pl(imsos_onestep(Source,Eqns,Target,inhabit),Var,Conds,Subst,Subst1) :- !,
    term2pl(Source,SourcePl), term2pl(Target,TargetPl),
    prem_readables(Eqns,Code1,Label,Var,Subst),
    Code2 = [rewrites(SourcePl,SourcePl1),inhabit(SourcePl1,Label,TargetPl)],
    prem_writeables(Eqns,Code3,Label,_),
    Subst1 = [SourcePl=SourcePl1|Subst],
    append([Code1,Code2,Code3],Conds).
prem2pl(imsos_runcheck(Source,Target),_,Code,Subst,Subst1) :- !,
    term2pl(Source,SourcePl), term2pl(Target,TargetPl),
    Code = [rewrites(SourcePl,SourcePl1),runcheck(SourcePl1,TargetPl),checktag(SourcePl1,TargetPl,SourcePl2)],
    Subst1 = [SourcePl=SourcePl2|Subst].
prem2pl(imsos_onestep(Source,Eqns,Target,subtype),Var,Conds,Subst,Subst) :- !,
    term2pl(Source,SourcePl), term2pl(Target,TargetPl),
    prem_readables(Eqns,Code1,Label,Var,Subst),
    Code2 = [subtype(SourcePl,Label,TargetPl)],
    prem_writeables(Eqns,Code3,Label,_),
    append([Code1,Code2,Code3],Conds).
prem2pl(imsos_onestep(Source,Eqns,Target,run),Var,Conds,Subst,Subst) :-
    term2pl(Source,SourcePl), term2pl(Target,TargetPl),
    apply_subst(SourcePl,Subst,SourcePl1),
    prem_readables(Eqns,Code1,Label,Var,Subst),
    Code2 = [runstep(SourcePl1,Label,TargetPl), ifcut],
    prem_writeables(Eqns,Code3,Label,_),
    append([Code1,Code2,Code3],Conds).
prem2pl(imsos_onestep(Source,Eqns,Target,resolve),Var,Conds,Subst,Subst) :-
    term2pl(Source,SourcePl), term2pl(Target,TargetPl),
    apply_subst(SourcePl,Subst,SourcePl1),
    prem_readables(Eqns,Code1,Label,Var,Subst),
    Code2 = [onestep(SourcePl1,Label,TargetPl,resolve)],
    prem_writeables(Eqns,Code3,Label,_),
    append([Code1,Code2,Code3],Conds).
prem2pl(imsos_neg(Form),Var,Conds1,Subst,Subst1) :-
    prem2pl(Form,Var,Conds,Subst,Subst1),
    (Conds = [] -> Conds1 = [] ; list2tuple(Conds,Conds2), Conds1 = [ \+ Conds2 ] ).
prem2pl(imsos_neg(Form),Var,Conds1,Subst,Subst1) :-
    prem2pl(Form,Var,[Cond,Cond1],Subst,Subst1),
    Conds1 = [ \+ (Cond, Cond1) ].
prem2pl(imsos_sigdec(F,Out,Ins),_,[sigdec(F,Out,Ins)],Subst,Subst).
prem2pl(imsos_valsort(F),_,[valsort(F)],Subst,Subst).
prem2pl(imsos_subsort(F,G),_,[subsort_rt(F,G)],Subst,Subst).

list2tuple([X],X).
list2tuple([X|Xs],(X,Xs1)) :- list2tuple(Xs,Xs1).

% translate named components in a premise to code (extracting label components
%  and rewriting to normal form)

prem_writeable(C+=V,Code,L,L1) :-
    Code = [rewrites(V,V1),
            eq_label(L,[C+=Term|L1]),
            rewrites(Term,V1)].
prem_writeable(_=_,[],L,L).

prem_writeables([],[],L,L).
prem_writeables([Eqn|Eqns],Code,L,L2) :-
    prem_writeable(Eqn,Code1,L,L1) ,
    prem_writeables(Eqns,Code2,L1,L2),
    append(Code1,Code2,Code).

prem_readable(C=Term,Code,L,L1,Subst) :-
    apply_subst(Term,Subst,Term1),
    Code = [rewrites(Term1,V), L = [C=V|L1] ].
prem_readable(C+=_,Code,L,L1,_) :-
    Code = [L = [C+=_|L1]].

prem_readables([],[],L,L,_).
prem_readables([Eqn|Eqns],Code,L,L2,Subst) :-
    prem_readable(Eqn,Code1,L,L1,Subst) ,
    prem_readables(Eqns,Code2,L1,L2,Subst),
    append(Code1,Code2,Code).

% Premises to list of prolog conditions.
% prems2pl(list of formulas, inner label variable, generated conditions)
% Might involve composition of arrows.

prems2pl([],_,[],Subst,Subst).
prems2pl([Form],Var,Conds,Subst,Subst1) :- prem2pl(Form,Var,Conds,Subst,Subst1).
prems2pl([Form|Forms],Var,Conds,Subst,Subst2) :- \+ haslabel(Form),
      prem2pl(Form,_,Conds1,Subst,Subst1),
      prems2pl(Forms,Var,Conds2,Subst1,Subst2),
      append(Conds1,Conds2,Conds).
prems2pl([Form|Forms],ILab,Conds,Subst,Subst2) :- haslabel(Form),
      \+ maplist(nolabel,Forms),
      prem2pl(Form,ILab1,Conds1,Subst,Subst1),
      prems2pl(Forms,ILab2,Conds2,Subst1,Subst2),
      append([[pre_comp(ILab,ILab1)],
              Conds1,
              [mid_comp(ILab1,ILab2)],
              Conds2,
              [post_comp(ILab1,ILab2,ILab)]], Conds).
prems2pl([Form|Forms],ILab,Conds,Subst,Subst2) :- haslabel(Form),
      maplist(nolabel,Forms),
      prem2pl(Form,ILab,Conds1,Subst,Subst1),
      prems2pl(Forms,_,Conds2,Subst1,Subst2),
      append(Conds1,Conds2,Conds).

% Substitutions -- a substitution is a list of equations

strict_member(Term,[Term1=Value|_],Value) :- Term == Term1, !.
strict_member(Term,[_|Terms],Value) :- strict_member(Term,Terms,Value).

apply_subst(Term,Subst,NewTerm) :- strict_member(Term,Subst,NT), NewTerm = NT, !.
apply_subst(Term,_,Term) :- var(Term), !.
apply_subst(Term,_,Term) :- Term = q(_), !.
apply_subst(Term,Subst,NewTerm) :- Term =.. [F|Xs], list_substs(Xs,Subst,Ys),
  NewTerm =.. [F|Ys].

list_substs([],_,[]).
list_substs([X|Xs],Subst,[Y|Ys]) :- apply_subst(X,Subst,Y),
   list_substs(Xs,Subst,Ys).

% Conclusion to Prolog head and list of Prolog conditions.
% Var is underlying label variable.

conc2pl(imsos_termeq(Source,Target),_,Head,Conds1,Conds2,Subst) :-
    term2pl(Source,SourcePl),
    apply_subst(Target,Subst,Target1),
    term2pl(Target1,TargetPl),
    subterm2vars_r(SourcePl,SourcePl1,Conds1),
    subterm2vars_w(TargetPl,TargetPl1,Conds2),
    Head = rewrite(SourcePl1,TargetPl1).
conc2pl(imsos_onestep(Source,Eqns,Target,Kind),Var,Head,Conds1,Conds2,Subst) :-
    term2pl(Source,SourcePl),
    apply_subst(Target,Subst,Target1),
    subterm2vars_r(SourcePl,SourcePl1,Conds1A),
    term2pl(Target1,TargetPl),
    (member(Kind,[inhabit,subtype]) -> TargetPl1 = TargetPl, Conds2A = [];
                      subterm2vars_w(TargetPl,TargetPl1,Conds2A)),
    Head = onestep(SourcePl1,Label,TargetPl1,Kind),
    conc_readables(Eqns,Conds1B,Label,Var),
    conc_writeables(Eqns,Conds2B,Label,_,Subst),
    append(Conds1A,Conds1B,Conds1),
    append(Conds2A,Conds2B,Conds2).
conc2pl(imsos_sigdec(F,Out,Ins),_,sigdec(F,Out,Ins),[],[],_).
conc2pl(imsos_valsort(F),_,valsort(F),[],[],_).
conc2pl(imsos_subsort(F,G),_,subsort(F,G),[],[],_).


conc_writeable(C+=Term,Code,L,L1,Subst) :-
    apply_subst(Term,Subst,Term1),
    Code = [rewrites(Term1,V),
            eq_label(L,[C+=V|L1])].
conc_writeable(_=_,[],L,L,_).

conc_writeables([],[],L,L,_).
conc_writeables([Eqn|Eqns],Code,L,L2,Subst) :-
    conc_writeable(Eqn,Code1,L,L1,Subst) ,
    conc_writeables(Eqns,Code2,L1,L2,Subst),
    append(Code1,Code2,Code).

conc_readable(C=V,Code,L,L1) :-
    Code = [rewrites(V,V1),
            eq_label(L,[C=Term|L1]),
            rewrites(Term,V1)].
conc_readable(C+=_,Code,L,L1) :-
    Code = [eq_label(L,[C+=_|L1])].

conc_readables([],[],L,L).
conc_readables([Eqn|Eqns],Code,L,L2) :-
    conc_readable(Eqn,Code1,L,L1) ,
    conc_readables(Eqns,Code2,L1,L2),
    append(Code1,Code2,Code).

% Rules to Prolog, translated as above.

item2pl(imsos_rule(Prem,Conc),[Head|Conds]) :-
    maplist(nolabel,Prem), haslabel(Conc), !, 
    prems2pl(Prem,ILab,Conds2,[],Subst),
    conc2pl(Conc,ILab,Head,Conds1,Conds3,Subst),
    append([Conds1,Conds2,[unobs(ILab)],Conds3],Conds).
item2pl(imsos_rule(Prem,Conc),[Head|Conds]) :-
    nolabel(Conc), !, 
    prems2pl(Prem,[inhabit_mode = run],Conds2,[],Subst),
    conc2pl(Conc,[],Head,Conds1,Conds3,Subst),
    append([Conds1,Conds2,Conds3],Conds).
item2pl(imsos_rule(Prem,Conc),[Head|Conds]) :- 
    prems2pl(Prem,ILab,Conds2,[],Subst),
    conc2pl(Conc,ILab,Head,Conds1,Conds3,Subst),
    append([Conds1,Conds2,Conds3],Conds).
item2pl(imsos_entity(Name,Default),[default(Name,Default)]).
item2pl(imsos_typeeq(Sort1,Sort2),[typedef(Sort1,Sort2)]).
item2pl(imsos_valsort(Type),[valsort(Type)]).
item2pl(imsos_sigdec(F,Out,Ins),[sigdec(F,Out,Ins)]).
item2pl(imsos_valcons(F),[valcons(F)]).
item2pl(imsos_subsort(F,G),[subsort(F,G)]).
item2pl(imsos_writeable(F),[writeable(F)]).
item2pl(imsos_readable(F),[readable(F)]).

haslabel(imsos_onestep(_,_,_,_)).
nolabel(A) :- \+ haslabel(A).

% Auxiliary entity extraction
%   so that the readable,writeable predicates are added automatically based on
%   the position entities are found within rules

% extracts label declarations required by a formula
rwdecl(A=_,readable(A)).
rwdecl(A+=_,writeable(A)).

extract_rw_form(imsos_onestep(_,Eqns,_,_),Decls) :- maplist(rwdecl,Eqns,Decls).
extract_rw_form(_,[]). % anything else

% extracts label declarations required by a rule
extract_rw_item(imsos_rule(Prem,Conc),Aux1) :- !,
   maplist(extract_rw_form,[Conc|Prem],Aux), append(Aux,Aux1).
extract_rw_item(_,[]). % anything else

% extracts label declarations required by a file
extract_rw_file(imsos_file(Items),DeclsB) :- maplist(extract_rw_item,Items,Decls),
   append(Decls,DeclsA), sort(DeclsA,DeclsB). %sort removes duplicates

% PROLOG RENDERING
% ----------------

% Our idealised representation of Prolog allows terms like F(a,b), where F
% quantifies over all functors. This is not allowed in actual Prolog.
% But we can translate this as follows: F(a,b) becomes X with extra premise
% X =.. [F,a,b].

% term2premises(input term, ouput term, supporting =.. equations)
term2premises(Term,Term,[]) :- myvar(Term), !.
term2premises(Term,Term,[]) :- atom(Term), !.
term2premises(Term,Term1,Eqns) :- is_list(Term), !, terms2premises(Term,Term1,Eqns).
term2premises(Term,NewVar,[decompose(NewVar,Func,NewTs)|Eqns]) :- Term =.. [Func|Ts],
     name(Func,Name), syms_up(_,Name,[]), !, terms2premises(Ts,NewTs,Eqns).
term2premises(Term,NewTerm,Eqns) :- Term =.. [Func|Ts],
     terms2premises(Ts,NewTs,Eqns),  NewTerm =.. [Func|NewTs].

% terms2premises(input term list, ouput term list, supporting =.. equations)
terms2premises([],[],[]).
terms2premises([Term|Terms],[NewTerm|NewTerms],Eqns) :-
  term2premises(Term,NewTerm,Eqns1), terms2premises(Terms,NewTerms,Eqns2),
  append(Eqns1,Eqns2,Eqns).

% tail_ho(conditions,code) replaces each condition for the processed condition
% and the new =.. equations

tail_ho([],[]).
tail_ho([Source|Sources],Code) :-
   term2premises(Source,NewSource,Eqns),
   tail_ho(Sources,Code1),
   append([Eqns,[NewSource],Eqns,Code1],Code).

% This is the main predicate that does this transformation on a Prolog rule
% rule(old rule, processed rule)
rule_ho([Head|Tail],Code) :- term2premises(Head,HeadCode,Code1),
    tail_ho(Tail,Code2), append([Code1,[HeadCode],Code1,Code2],Code).

/* Now for actual Prolog rendering... */

% replace a list of atoms for a single atom, seperated by comma and ended by .
collate_atoms([],[]).
collate_atoms([C],D) :- concat_atom([C , '.'],D).
collate_atoms([A,'ifcut',B|Bs],D) :- collate_atoms(Bs,D1), concat_atom([A , ' -> ', B , ', ' , D1],D).
collate_atoms([C|Cs],D) :- collate_atoms(Cs,D1), concat_atom([C , ', ', D1],D).

% remove quotes from a string (variables could be quoted in internal repn. to
%    prevent premature alpha-conversion)
removequote1([],[]).
removequote1([39|Rest],Rest1) :- !, removequote(Rest,Rest1). % [39] = "'".
removequote1([Head|Rest],[Head|Rest1]) :- removequote1(Rest,Rest1).

removequote([],[]).
removequote([40,113,40,39|Xs],[40,113,40,39|Ys]) :- !, removequote2(Xs,Ys). %(q('
removequote([44,113,40,39|Xs],[44,113,40,39|Ys]) :- !, removequote2(Xs,Ys). %,q('
removequote([32,113,40,39|Xs],[32,113,40,39|Ys]) :- !, removequote2(Xs,Ys). % q('
removequote([39,R|Est],Rest1) :- char_type(R,upper), !, removequote1([R|Est],Rest1). % [39] = "'".
removequote([39,95|Est],Rest1) :- !, removequote1([95|Est],Rest1). % [95] = "_".
removequote([Head|Rest],[Head|Rest1]) :- removequote(Rest,Rest1).

removequote2([],[]).
removequote2([39|Rest],[39|Rest1]) :- !, removequote(Rest,Rest1). % [39] = "'".
removequote2([Head|Rest],[Head|Rest1]) :- removequote2(Rest,Rest1).

% VARIABLE RENAMING

% Tests for strict membership in a list (variables are not unified, but
%  they are checked to see if they are the same variable)
strict_elem(Term,[Term1|_]) :- Term == Term1, !.
strict_elem(Term,[_|Terms]) :- strict_elem(Term,Terms).

% Removing an element (strictly) from a list
strict_remove(_,[],[]).
strict_remove(Term,[Term1|Terms],Terms1) :- Term == Term1, !, strict_remove(Term,Terms,Terms1).
strict_remove(Term,[Term1|Terms],[Term1|Terms1]) :- strict_remove(Term,Terms,Terms1).

% get_vars(Term,[],Vars) -- Vars are the variables appearing in the Term
get_vars(Term,SingsIn,SingsOut) :- myvar(Term), append(SingsIn,[Term],SingsOut).
get_vars(Term,SingsIn,SingsOut) :- is_list(Term),
   get_vars_pl(Term,SingsIn,SingsOut).
get_vars(Term,SingsIn,SingsOut) :- \+ myvar(Term),
   Term =.. [_|Xs], get_vars_pl(Xs,SingsIn,SingsOut).

% get_vars(Terms,[],Vars) -- Vars are the variables appearing in the Terms
get_vars_pl([],Sings,Sings).
get_vars_pl([X|Xs],SingsIn,SingsOut) :- get_vars(X,SingsIn,SingsMid),
   get_vars_pl(Xs,SingsMid,SingsOut).

% get_sings(Term,Sings) --- Sings are the variables that appear exactly once
% in the term
rem_dups([],[]).
rem_dups([Term|Terms], Terms2) :- strict_elem(Term,Terms), !, strict_remove(Term,Terms,Terms1),
   rem_dups(Terms1,Terms2).
rem_dups([Term|Terms], [Term|Terms2]) :- rem_dups(Terms,Terms2).

get_sings(Term,Sings) :- get_vars_pl(Term,[],Vars), rem_dups(Vars,Sings).

% converts a list of singletons to a substitution mapping each to _
sing_to_subst([],[]).
sing_to_subst([Sing|Sings],[Sing='_'|Sings1]) :- sing_to_subst(Sings,Sings1).

% replaces singleton variables in Prolog code for _
erase_sings(Code,Code1) :- get_sings(Code,Sings), sing_to_subst(Sings,Subst),
     apply_subst(Code,Subst,Code1).

% rename_vars(Code,Code1) replaces the variables in Code for normalised
% version A,B,C,...
nextvar(L,NewL) :- "Z" = [Z], append(Most,[Last],L), Last < Z,
  NewLast is Last + 1, append(Most,[NewLast],NewL).
nextvar(L,NewL) :- "Z" = [Z], append(_,[Last],L), Last = Z,
    append(L,"A",NewL).

vars_to_subst([],_,[]).
vars_to_subst([Var|Vars],L,[Var=Atom|Subst]) :- name(Atom,L),
   nextvar(L,NewL), vars_to_subst(Vars,NewL,Subst).

rem_rep([],[]).
rem_rep([Term|Terms], Terms2) :- strict_elem(Term,Terms), !, rem_rep(Terms,Terms2).
rem_rep([Term|Terms], [Term|Terms2]) :- rem_rep(Terms,Terms2).

rename_vars(Code,Code1) :- get_vars_pl(Code,[],Vars), rem_rep(Vars,Vars1),
   vars_to_subst(Vars1,"A",Subst), apply_subst(Code,Subst,Code1).

% PROLOG RENDERING

% convert internal prolog representation of a rule to code string
code2string(Code,Str) :-
       rule_ho(Code,CodeHo),
       erase_sings(CodeHo,CodeSings),
       rename_vars(CodeSings,CodeVars),
       CodeVars = [Head|Conds],
       maplist(term_to_atom,Conds,CondAtms), % convert each tail term to an atom
       collate_atoms(CondAtms,CondAtm), % combine the atoms into a single atom
       term_to_atom(Head,HeadAtm), % convert the head of the clause to atom
       (CondAtm = [] -> concat_atom([HeadAtm, '.'], LongAtom) ;  % concat head
         concat_atom([HeadAtm, ' :- ', CondAtm],LongAtom)),      % and tail
       name(LongAtom,Str1), % convert to string
       removequote(Str1,Str). % remove quotes around variables

% FILE IO
% -------

% writes series of Prolog code lines to file
writelines([],_).
writelines([Line|More],Stream) :- name(Atom,Line), write(Stream,Atom),
   nl(Stream), nl(Stream), writelines(More,Stream).

% Convert CSF file to Prolog file
rule2str(Rule,Code) :- item2pl(Rule,Code1), code2string(Code1,Code).
decl2str(Decl,Code1) :- term_to_atom(Decl,DeclA), name(DeclA,Code),
  append(Code,".",Code1).

% imsos2pl_abs(imsos AST,'test.pl').
imsos2pl_abs(CFile,FileOut) :-
    %extract_rw_file(CFile,Labels), maplist(decl2str,Labels,Code1), % labeldecs
    CFile = imsos_file(Rules), maplist(rule2str,Rules,Code), % rules
    %append(Code1,Code2,CodeList), % combine
    open(FileOut,write,Stream1), writelines(Code,Stream1), % write
    close(Stream1). % close

% imsos2pl('test.imsos','test.pl')
imsos2pl(FileIn,FileOut) :-
    open(FileIn,read,Stream), read_entire_file(Stream,String), % read
    ifile(CFile,String,[]), % parse
    imsos2pl_abs(CFile,FileOut),
    close(Stream).

