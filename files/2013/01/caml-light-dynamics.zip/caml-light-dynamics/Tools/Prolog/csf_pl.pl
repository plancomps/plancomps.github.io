:- ensure_loaded(imsos_sem).
:- ensure_loaded(csf_sem).
:- ensure_loaded(imsos_lib).

dirs(['../Operational Rules/Funcons','../Operational Rules/Sorts','../Operational Rules/Entities','../Operational Rules/Values', '../CL-Translation', '../Operational Rules/Higher']).

dir_csf(Dir,NewFiles) :- directory_files(Dir,Files), csf_files(Files,Files1), atom_concat(Dir,'/',Dir1), maplist(atom_concat(Dir1),Files1,NewFiles).

all_csf(NewFiles) :- dirs(Xs), maplist(dir_csf,Xs,Files), append(Files,NewFiles).

csf2pl :- all_csf(NewFiles), csfs_parse(NewFiles,CFiles), csf2imsos(CFiles,IFile), imsos2pl_abs(IFile,'Prolog/repos.pl'), repos, !.

repos :- reconsult('Prolog/repos').
