:- ensure_loaded(imsos_syn).

/*

A csf_file is a list of csf_items.

Imports some syntactic elements from IMSOS, e.g. for terms, rules...

A csf_item is either:

   csf_datadec(iterm type, iterm list constructors, polymorphic constraints) -- declaration of data types
   csf_typedec(iterm type, valsort yes or no) -- declaration of a sort
   csf_typedef(iterm type, iterm type, valsort yes or no) -- definition of a sort via an equality
   csf_subtypedec(iterm type, iterm suptype, valsort yes or no) -- subsort inclusion
   csf_valsortdec(iterm type) -- declaring a sort is a value sort
   csf_opcondec(iterm outputtype, iterm name with type args, poly constraints) -- declaration of an operation or funcon
   csf_rules(imsos_rule list) -- list of rules
   csf_relation(Entity,R,Default) -- relation declaration, where R is readable/writeable/changeable
   csf_opglossary( text ) -- glossary text
 
*/

:- discontiguous citem/3.

citem(csf_datadec(Type,Cstrs,Sideconds)) --> "Data", m, iterm(Type), m, "=", m, cdatacons(Cstrs), csidecons(Sideconds).
%citem(csf_datadec(Type,Cstrs,Sideconds)) --> "Data", m, iterm(Type), m, "=", m, cdatacons(Cstrs), m, "{" , m, csidecons(Sideconds), m, "}".

cdatacons([Term]) --> iterm(Term).
cdatacons([Term|Terms]) --> iterm(Term), m, "|", m, cdatacons(Terms).

csidecons([]) --> "".
csidecons(Xs) --> m, "{", m, csidecons1(Xs), m, "}".

%csidecons1([]) --> "comp(", m, iterm(_), m, ")".
%csidecons1([Xs]) --> "comp(", m, iterm(_), m, ")", m, ",", m, csidecons1(Xs).
csidecons1([X]) --> csidecon(X).
csidecons1([X|Xs]) --> csidecon(X), m, ",", m, csidecons1(Xs).

csidecon(val(X)) --> "val(", m, iterm(X), m, ")".
csidecon(sig(F,Out,Ins)) --> iterm(S), m, ":", m, iterm(Out), { S =.. [F|Ins] }.
csidecon(comp(X)) --> "comp(", m, iterm(X), m, ")".

% Not yet properly implemented / working

citem(csf_typedec(Term,nonval)) --> "Sort", m, iterm(Term).
citem(csf_typedec(Term,value)) --> "Value Sort", m, iterm(Term).

% Types defined by syntax 'Value'? Type ... are assumed to be "nominal" in the sense that
% all inhabitants are inhabitants of the declared supertype T. So when checking x : T,
% we don't bother checking if x is a member of this type. For example, to see if a term
% is a Function in dynamic semantics, we don't want to include checking that it's a Function(A,B)
% for every possible A,B. Possibly not ideal concrete syntax, but don't have time to change right now.
% Feel free to do so (but then would need to also change the CSF files). See abs.csf for example.

citem(csf_subtypedec(Subtype,Type,nonval)) --> "Subtype", m, iterm(Subtype), m, "<", m, iterm(Type).
citem(csf_subtypedec(Subtype,Type,nonval)) --> "Sort", m, iterm(Subtype), m, "<", m, iterm(Type).
citem(csf_subtypedec(Subtype,Type,value)) --> "Value Sort", m, iterm(Subtype), m, "<", m, iterm(Type).

%citem(csf_opcondec(Type,TermType,[])) --> "Operation", m, iterm(TermType), m, ":", m, iterm(Type), m, csidecons(Sidecon
%citem(csf_opcondec(Type,TermType,[])) --> "Funcon", m, iterm(TermType), m, ":", m, iterm(Type).
citem(csf_opcondec(Type,TermType,Sideconds)) --> "Operation", m, iterm(TermType), m, ":", m, iterm(Type), csidecons(Sideconds).
citem(csf_opcondec(Type,TermType,Sideconds)) --> "Funcon", m, iterm(TermType), m, ":", m, iterm(Type), csidecons(Sideconds).

citem(csf_typedef(Type,EqType,nonval)) --> "Sort", m, iterm(Type), m, "=", m, iterm(EqType).
citem(csf_typedef(Type,EqType,value)) --> "Value Sort", m, iterm(Type), m, "=", m, iterm(EqType).

citem(csf_rules(Rules)) --> "Rules:", moptblanklines, cfrulelist(Rules).

cfrulelist([imsos_rule(Prem,Conc)|Rules]) --> iitem(imsos_rule(Prem,Conc)), moptblanklines, cfrulelist(Rules).
cfrulelist([imsos_rule(Prem,Conc)]) --> iitem(imsos_rule(Prem,Conc)).

citem(csf_glossary(Text)) --> "Glossary:", moptblanklines, text(Text).
citem(csf_opglossary(Text)) --> "Operation Glossary:", moptblanklines, text(Text).

% Allowed, but does nothing for now...
citem(csf_glossary("")) --> "Uses:", text(_).
citem(csf_glossary("")) --> "Requires:", text(_).

citem(R) --> "Relation:", m, crelation(R).
crelation(csf_relation(Entity,writeable,Default)) --> "_", m, "--", m, cauxent(Entity), m, iterm(_), m, "=" , m, iterm(Default), m, "-->", m, "_". 
crelation(csf_relation(Entity,readable,Default)) --> cauxent(Entity), m, iterm(_), m, "=" , m, iterm(Default), m, "|-", m, "_", m, "-->", m, "_". 
crelation(csf_relation(Entity,changeable,Default)) --> "(", m, "_", m, ",", m, cauxent(Entity), m, iterm(T1), m, "=" , m, iterm(Default), m, ")", m,
                                                        "-->", m, "(", m, "_", m, ",", m, cauxent(Entity), m, iterm(T1), m, ")".  


text([],[X|Xs],[X|Xs]) :- char_type(X, end_of_line).
text([X|Text],[X|Xs],Ys) :- \+ char_type(X, end_of_line), text(Text,Xs,Ys).

cfile(csf_file(CSF)) --> moptblanklines, cfile1(CSF), moptblanklines.

cfile1([Item|Items]) --> citem(Item), mblanklines, cfile1(Items).
cfile1([Item]) --> citem(Item).
cfile1([]) --> "".

csf_parse(File,CFile) :- open(File,read,Stream), read_entire_file(Stream,String),
    cfile(CFile,String,[]), close(Stream), !.
csf_parse(File,_) :- print('Failed to parse: '), print(File), fail.

csfs_parse(Files,csf_files(CFiles)) :- maplist(csf_parse,Files,CFiles).

csf_direct(Dir,csf_files(CFileList)) :- directory_files(Dir,Files), working_directory(OldDir,Dir),
    csf_files(Files,Files1),
    maplist(csf_parse,Files1,CFileList), working_directory(_,OldDir).

csf_files([],[]).
csf_files([X|Xs],[X|Ys]) :- file_name_extension(_,'csf',X), !, csf_files(Xs,Ys).
csf_files([_|Xs],Ys) :- csf_files(Xs,Ys).

