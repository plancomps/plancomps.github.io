sigdec(q(_),atom,[]).

valcons(q(_)).

onestep(q(M),L,int,inhabit) :- integer(M), unobs(L).

sigdec(q(M),int,[]) :- integer(M).

rewrite(int_plus(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), Z is M1 + N1.

rewrite(int_minus(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), Z is M1 - N1.

rewrite(int_times(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), Z is M1 * N1.

rewrite(int_divide(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), Z is M1 / N1.

rewrite(int_less(M,N),Z) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), ( M1 < N1 -> Z = true ; Z = false).

rewrite(int_less_equal(M,N),Z) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), ( M1 =< N1 -> Z = true ; Z = false).

rewrite(int_greater(M,N),Z) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), ( M1 > N1 -> Z = true ; Z = false).

rewrite(int_greater_equal(M,N),Z) :- rewrites(M,q(M1)), rewrites(N,q(N1)), integer(M1), integer(N1), ( M1 >= N1 -> Z = true ; Z = false).

onestep(q(M),L,float,inhabit) :- float(M), unobs(L).

sigdec(q(M),float,[]) :- float(M).

rewrite(float_plus(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), float(M1), float(N1), Z is M1 + N1.

rewrite(float_minus(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), float(M1), float(N1), Z is M1 - N1.

rewrite(float_times(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), float(M1), float(N1), Z is M1 * N1.

rewrite(float_divide(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), float(M1), float(N1), Z is M1 / N1.

rewrite(float_exp(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), float(M1), float(N1), Z is M1 ** N1.

rewrite(float_sin(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is sin(M1).

rewrite(float_to_int(M),q(Z)) :- rewrites(M,q(M1)), float(M1), Z is round(M1).

rewrite(int_to_float(M),q(Z)) :- rewrites(M,q(M1)), integer(M1), Z is float(M1).

rewrite(float_pi,q(Z)) :- Z is pi.

onestep(q(M),L,string,inhabit) :- atom(M), name(M,_), unobs(L).

sigdec(q(M),string,[]) :- atom(M), name(M,_).

rewrite(string_append(M,N),q(Z)) :- rewrites(M,q(M1)), rewrites(N,q(N1)), name(M1,M1n), name(N1,N1n),
           append(["\"",M1ncore,"\""],M1n), append(["\"",N1ncore,"\""], N1n), 
           append(M1ncore,N1ncore,Zncore), append(["\"",Zncore,"\""],Zn), name(Z,Zn).

onestep(q(M),L,character,inhabit) :- atom(M), name(M,[_]), unobs(L).

sigdec(q(M),character,[]) :- atom(M), name(M,[_]).

% Builtins

subsort(Type,computes(Type)) :- valsort(Type).
subsort(computes(Type1),computes(Type2)) :- valsort(Type1), subsort(Type1,Type2), valsort(Type2).
typedef(computes(X),computes(Y)) :- valsort(X), typedef(X,Y).

subsort(computes(Y),depends(_,Y)) :- valsort(Y).
typedef(depends(Z,X),depends(Z,Y)) :- valsort(X), typedef(X,Y).
typedef(depends(X,Z),depends(Y,Z)) :- valsort(X), typedef(X,Y).
subsort(depends(Z,Type1),depends(Z,Type2)) :- valsort(Type1), subsort(Type1,Type2), valsort(Type2).
%subsort(depends(Type1,Z),depends(Type2,Z)) :- valsort(Type1), subsort(Type1,Type2), valsort(Type2).

subsort(list(X),list(Y)) :- \+ var(X), subsort(X,Y).
subsort(map(X,Y),map(X,Z)) :- \+ var(X), \+ var(Y), subsort(Y,Z).
typedef(map(Z,X),map(Z,Y)) :- \+ var(X), typedef(X,Y).
typedef(map(X,Z),map(Y,Z)) :- \+ var(X), typedef(X,Y).

valsort(val).
valsort(ground).

onestep(q(A),L,q(A),resolve) :- unobs(L).
onestep(computes(A),L,computes(B),resolve) :- onestep(A,L,B,resolve).
onestep(depends(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(depends(J,K),L).

valsort(constant).

