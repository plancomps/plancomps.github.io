:- ensure_loaded(csf_syn).
:- ensure_loaded(imsos_syn).
:- ensure_loaded(imsos_sem).

% Semantics of CSF, via translation to IMSOS

% Generation of Additional Premises
% ---------------------------------

% lex_term_type(Term,Type) occurs if Term is syntactically written to be a variable ranging over Type.

lex_term_type(T,T3) :- T =.. [F|Xs], name(F,F1), uptound(F1,F2), name(F3,F2), maplist(lex_term_type,Xs,Ys), T3 =.. [F3|Ys].

uptound([T],Ts) :- char_type(T,upper), !, append([T],"Type",Ts). % variables
uptound([T|Ts],Out) :- char_type(T,upper), !, Tl is T + 32, uptound(Ts,Out1), Out = [Tl|Out1].
uptound([T|Ts],[T|Out]) :- uptound(Ts,Out).
uptound([],[]).

% Formula to Rule
% Extra premises generated for ranging over value sets
% only in dynamic transitions ( --> and = ) - tagged by extra first premise

extra_prem(dyn,Term,[imsos_runcheck(Term,Type)]) :- atom(Term), name(Term,[X|Xs]), char_type(X,upper), 
    letters(TypeName,[X|Xs],_), name(Type1,TypeName), lex_term_type(Type1,Type), valsort_csf(Type), !.
extra_prem(_,Term,List) :- atom(Term), !, List = [].
extra_prem(_,Term,[]) :- var(Term), !.
extra_prem(Kind,Term,Types) :- Term =.. [_|Xs], maplist(extra_prem(Kind),Xs,Ys), append(Ys,Types).

extra_prem_labels(_,[],[]).
extra_prem_labels(Kind,[_=T|Xs],Zs) :- extra_prem_labels(Kind,Xs,Ys), extra_prem(Kind,T,Ws), append(Ys,Ws,Zs).
extra_prem_labels(Kind,[_+=T|Xs],Zs) :- extra_prem_labels(Kind,Xs,Ys), extra_prem(Kind,T,Ws), append(Ys,Ws,Zs).

% Tanslation of formula from CSF to IMSOS (generating extra premises depending on context)
% Kind parameter is static or dynamic depending on the kind of rule we're in
% Second parameter is generated set of premises, Third is replacement formula

% If premise is of kind F(X,..):Y, change to signature check rather than type check
form2imsos(imsos_onestep(Source,Label,Target,Rel),Prems,imsos_onestep(Source,Label,Target,Rel),dyn) :- !,
    extra_prem(Kind,Source,Prems1), extra_prem(Kind,Target,Prems2), extra_prem_labels(Kind,Label,Prems3), 
    append([Prems3,Prems2,Prems1],Prems).
form2imsos(imsos_onestep(Source,Label,Target,Rel),[],imsos_onestep(Source,Label,Target,Rel),_).
form2imsos(imsos_termeq(Term1,Term2),Prems,imsos_termeq(Term1,Term2),Kind) :-
    extra_prem(Kind,Term1,Prems1), extra_prem(Kind,Term2,Prems2), append(Prems1,Prems2,Prems).
form2imsos(imsos_termlt(Term1,Term2),Prems,imsos_termlt(Term1,Term2),Kind) :-
    extra_prem(Kind,Term1,Prems1), extra_prem(Kind,Term2,Prems2), append(Prems1,Prems2,Prems).
form2imsos(imsos_neg(Form),Prems,imsos_neg(Out),Kind) :- form2imsos(Form,Prems,Out,Kind).
form2imsos(imsos_runcheck(Term,Type),Prems,imsos_runcheck(Term,Type),Kind) :- extra_prem(Kind,Term,Prems).
form2imsos(imsos_sigdec(Term,Type,Args),[],imsos_sigdec(Term,Type,Args),_).

% CSF Rules to IMSOS
% ------------------

rule2imsos(imsos_rule(Prems,Conc),imsos_rule(NewPrems,Conc1)) :-
     (member(Conc,[imsos_termeq(_,_),imsos_onestep(_,_,_,run)]) -> Kind = dyn ;
      Kind = static),
     form2imsos(Conc,NewPrems1,Conc1,Kind), prems2imsos(Prems,NewPrems2,Prems1,Kind),
     append(NewPrems1,NewPrems2,NewPrems3), set(NewPrems3,NewPrems4),
     append([Prems1,NewPrems4],NewPrems).

prems2imsos([],[],[],_).
prems2imsos([Prem|Prems],NewPrems,[Prem1|Prems1],Kind) :-
    form2imsos(Prem,NewPrems1,Prem1,Kind), prems2imsos(Prems,NewPrems2,Prems1,Kind),
    append(NewPrems1,NewPrems2,NewPrems).

% CSF files to IMSOS
% ------------------

% item2imsos(Declared,CSFItem,List of IMSOS items)
% Declared is a list of the kind inhabit(Foo), subtype(Foo), run(Foo) or resolve(Foo)
% An element inhabit(cons) is in the list if cons has a declared typing rule in that
% file, etc.

:- discontiguous item2imsos/3.

item2imsos(_,csf_datadec(Type,Cstrs,Sideconds),Imsos1) :- datacons2imsos(Type,Cstrs,Sideconds,Imsos),
  append(Imsos,[imsos_sigdec(Type,type,[]),imsos_valsort(Type)],Imsos1).
 
datacon2imsos(Type,Term,Sideconds,Imsos) :- item2imsos(_,csf_opcondec(Type,Term,Sideconds),Imsos1),
      Term =.. [F|_], append(Imsos1,[imsos_valcons(F)],Imsos).
		
sideconds2prems(val(X),[imsos_valsort(X)]).
sideconds2prems(sig(F,Out,Ins), [imsos_sigdec(F,Out1,Ins), imsos_subsort(Out1,Out)]).

datacons2imsos(Type,[Term],Sideconds,Imsos) :- !,
      datacon2imsos(Type,Term,Sideconds,Imsos).
datacons2imsos(Type,[Term|Terms],Sideconds,Imsos) :-
      datacon2imsos(Type,Term,Sideconds,Imsos1),
      datacons2imsos(Type,Terms,Sideconds,Imsos2),
      append(Imsos1,Imsos2,Imsos).

item2imsos(_,csf_typedec(Type,value),[imsos_sigdec(Type,type,[]),imsos_valsort(Type)]) :- !.
item2imsos(_,csf_typedec(Type,_),[imsos_sigdec(Type,type,[])]).

item2imsos(_,csf_subtypedec(Subtype,Type,X),Imsos) :-
    Imsos1 = [imsos_subsort(Subtype,Type)],
    (X = value -> Imsos2 = [imsos_valsort(Subtype)] ; Imsos2 = []),
    append([Imsos1,Imsos2],Imsos).

item2imsos(_,csf_opcondec(Type,Term,Sideconds),[Imsos]) :-
	 Term =.. [F|Types], maplist(sideconds2prems,Sideconds,Premss), append(Premss,Prems),
	 Conc = imsos_sigdec(F,Type,Types),
	 Imsos = imsos_rule(Prems,Conc).
	
item2imsos(_,csf_rules(Rules),Imsos) :- rulelist2imsos(Rules,Imsos).

rulelist2imsos([],[]).
rulelist2imsos([Rule|Rules], [Imsos|Imsoses]) :- rule2imsos(Rule,Imsos),
   rulelist2imsos(Rules,Imsoses).

item2imsos(_,csf_glossary(_),[]).
item2imsos(_,csf_opglossary(_),[]).

item2imsos(_,csf_relation(Entity,readable,Default),[imsos_readable(Entity),imsos_entity(Entity,Default)]).
item2imsos(_,csf_relation(Entity,writeable,Default),[imsos_writeable(Entity),imsos_entity(Entity,Default)]).
item2imsos(_,csf_relation(Entity,changeable,Default),[imsos_readable(Entity),imsos_writeable(Entity),imsos_entity(Entity,Default)]).

item2imsos(_,csf_entitydefault(Entity,Default),[imsos_entity(Entity,Default)]).

item2imsos(_,csf_typedef(X,Y,value),[imsos_sigdec(X,type,[]),imsos_typeeq(X,Y),imsos_valsort(X)]) :- !.
item2imsos(_,csf_typedef(X,Y,_),[imsos_sigdec(X,type,[]),imsos_typeeq(X,Y)]).

mymember(X,[X|_]) :- !.
mymember(X,[_|T]) :- mymember(X,T).

set([],[]).
set([H|T],[H|Out]) :- \+ mymember(H,T), set(T,Out).
set([H|T],Out) :- mymember(H,T), set(T,Out).

% Autogenerated Rules
% -------------------

% Adding liftings
% foo_addition(X,Y) says that if X is given original rule, Y is a valid extra
% rule from lifting. later results will be collected.

% 1. Patience Rules

dynamic_addition(imsos_sigdec(F,Type,Args),NewRule) :-
	dynamic_addition(imsos_rule([],imsos_sigdec(F,Type,Args)),NewRule).
dynamic_addition(imsos_rule(Prem,imsos_sigdec(F,_,Xs)),NewRule) :-
     append([Xs1,[X],Xs2],Xs),
     (valsort_csf(X) ; member(imsos_valsort(X),Prem)),
     length(Xs1,N1), length(Sources1,N1),
     length(Xs2,N2), length(Sources2,N2),
     append([Sources1,['X'],Sources2],Sources),
     Term1 =.. [F|Sources],
     append([Sources1,['X1'],Sources2],Targets),
     Term2 =.. [F|Targets],
     NewRule = imsos_rule([imsos_onestep('X',[],'X1',run)],imsos_onestep(Term1,[],Term2,run)).

sig_addition(imsos_rule(Prems,InSigDec),imsos_rule(Prems1,NewRule)) :-
     InSigDec = imsos_sigdec(_,_,Args),
     (hasval(Args) ; hasvalhyp(Prems)),
     remvals(Prems,Prems1),
     sig_addition1(InSigDec,NewRule).
sig_addition(InSigDec,OutSigDec) :- InSigDec = imsos_sigdec(_,_,Args), hasval(Args), sig_addition1(InSigDec,OutSigDec).
 
hasval([X|_]) :- valsort_csf(X), !.
hasval([_|Xs]) :- hasval(Xs).

remvals([],[]).
remvals([imsos_valsort(_)|Xs],Ys) :- !, remvals(Xs,Ys).
remvals([X|Xs],[X|Ys]) :- !, remvals(Xs,Ys).

hasvalhyp([imsos_valsort(_)|_]) :- !.
hasvalhyp([_|Xs]) :- hasvalhyp(Xs).

myvar1(X) :- myvar(X).
myvar1(X) :- atom(X), name(X,[95|_]).

sig_addition1(imsos_sigdec(F,Type,Args),imsos_sigdec(F,Type1,Args1)) :- maplist(add_dep(Y),Args,Args1), add_dep(Y,Type,Type1).
sig_addition1(imsos_sigdec(F,Type,Args),imsos_sigdec(F,Type1,Args1)) :- maplist(add_comp,Args,Args1), add_comp(Type,Type1).

add_comp(Type,computes(Type)) :- valsort_csf(Type), !.
add_comp(X,X).

add_dep(Y,Type,depends(Y,Type)) :- valsort_csf(Type).
add_dep(Y,depends(Y,Type),depends(Y,Type)).
add_dep(Y,computes(Type),depends(Y,Type)).
 
% 2. Autogenerated Typing Rules

% for value constructors of monomorphic types.

% if f is an n-ary data constructor of monomorphic sort S we get:
%
%    x1 : A1, ..., xn : An
% --------------------------- f is a value constructor
% f(x1,...,xn) : S(A1,...,An)

type_addition(D,imsos_rule([],imsos_sigdec(F,Type,Args)),NewRule) :-
	type_addition(D,imsos_sigdec(F,Type,Args),NewRule).
type_addition(_,imsos_sigdec(F,Type,Args),NewRule) :-
	 valcons_csf(F),
	 %valsort_csf(Type),
	 %maplist(valsort_csf,Args),
     length(Args,N),
     length(Terms,N),
     length(Types,N),
     prems_zip(inhabit,Terms,Types,Prems),
     Term1 =.. [F|Terms],
     atom(Type),
     Type2 =.. [Type|Types],
     NewRule = imsos_rule(Prems,imsos_onestep(Term1,[],Type2,inhabit)).
     
% if F(S1,...,SN) : T where S1,...,SN,T are value sorts then generate rule
%    only if no other typing rule is present
%
%  x1 : S1 , ... , xn : SN
%  -----------------------
%   F(x1,...,sn) : T

type_addition(Declared,imsos_sigdec(F,Type,Args),NewRule) :-
	 \+ valcons_csf(F),
	 valsort_csf(Type),
	 maplist(valsort_csf,Args),
     atom(Type),
     \+ member(inhabit(F),Declared),
     maplist(atom,Args),
     length(Args,N),
     length(Terms,N),
     prems_zip(inhabit,Terms,Args,Prems),
     Term1 =.. [F|Terms],
     NewRule = imsos_rule(Prems,imsos_onestep(Term1,[],Type,inhabit)).

% issue: ocaml_light_library : env
% don't auto generate if there is something already there?
% explicit typing for ocaml_light_library

prems_zip(_,[],[],[]).
prems_zip(Rel,[Source|Sources],[Target|Targets],[Type|Types]) :-
    Type = imsos_onestep(Source,[],Target,Rel), prems_zip(Rel,Sources,Targets,Types).

% if an operation has value types as arguments and conclusion, get corresponding typing rule

% 3. Autogenerated Resolve Rules

resolve_addition(D,imsos_rule(_,imsos_sigdec(F,Type,Args)),NewRule) :-
	resolve_addition(D,imsos_sigdec(F,Type,Args),NewRule).
resolve_addition(Declared,imsos_sigdec(F,_,Args),NewRule) :-
     \+ member(resolve(F),Declared),
     length(Args,N),
     length(Sources,N),
     length(Targets,N),
     prems_zip(resolve,Sources,Targets,Prems),
     Term1 =.. [F|Sources],
     Term2 =.. [F|Targets],
     NewRule = imsos_rule(Prems,imsos_onestep(Term1,[],Term2,resolve)).


% Declaration to rule

% Converts a declaration (TermWithTypeArgs, Type) to a typing rule
% TODO this should really be in the rule generation section.

%convert_decl(Term,Type,Sideconds,SortOnly,imsos_rule(Prems2,imsos_onestep(NewTerm,List,Type,inhabit))) :-
%    Term =.. [F|Types],
%    (atom_concat(_,'_1',F) -> Types = [Con|Types1], construct_prems(1,Types1,Prems,Vars1), Vars = [Con|Vars1] ;
%      construct_prems(1,Types,Prems,Vars) ),
%    NewTerm =.. [F|Vars],
%    (SortOnly = true -> List = [inhabit_mode = sort] ; List = []),
%    maplist(sideconds2prem,Sideconds,Prems1),
%    append(Prems,Prems1,Prems2). 

%construct_prems(_,[],[],[]).
%construct_prems(N,[Type|Types],[Prem|Prems],[Var|Vars]) :-
%    atom_number(Atom,N),
%    atom_concat('Var',Atom,Var),
%    Prem = imsos_onestep(Var,[],Type,inhabit),
%    M is N + 1,
%    construct_prems(M,Types,Prems,Vars).

/*inhabit_addition(imsos_rule(Prem,Conc), imsos_rule(Prem1,Conc1)) :-
   Conc = imsos_onestep(_,_,_,inhabit), add_computes(Conc,Conc1),
   maplist(add_computes,Prem,Prem1), \+ Prem = Prem1.
inhabit_addition(imsos_rule(Prem,Conc), imsos_rule(Prem1,Conc1)) :-
   Conc = imsos_onestep(_,_,_,inhabit), add_depends(V,Conc,Conc1),
   maplist(add_depends(V),Prem,Prem1), \+ Prem = Prem1.

add_computes(imsos_onestep(Term,Label,Type,inhabit), imsos_onestep(Term,Label,computes(Type),inhabit)) :- valsort_csf(Type), !.
add_computes(X,X).

add_depends(V,imsos_onestep(Term,Label,Type,inhabit), imsos_onestep(Term,Label,depends(V,Type),inhabit)) :- valsort_csf(Type), !.
add_depends(_,X,X).

resolve_addition(Declared,imsos_rule(_,imsos_onestep(Term,_,_,inhabit)),NewRule) :-
     Term =.. [F|Xs],
     \+ member(resolve(F),Declared),
     length(Xs,N),
     length(Sources,N),
     length(Targets,N),
     Term1 =.. [F|Sources],
     Term2 =.. [F|Targets],
     resolve_zip(Sources,Targets,Prems),
     NewRule = imsos_rule(Prems,imsos_onestep(Term1,[],Term2,resolve)).

resolve_zip([],[],[]).
resolve_zip([Source|Sources],[Target|Targets],[Resolve|Resolves]) :-
    Resolve = imsos_onestep(Source,[],Target,resolve),
    resolve_zip(Sources,Targets,Resolves).
*/

liftings(Declared,Rule,Rules) :- findall(Rule1,type_addition(Declared,Rule,Rule1),Rules1), sort(Rules1,Rules1a),
                        findall(Rule1,dynamic_addition(Rule,Rule1),Rules2), sort(Rules2,Rules2a),
                        findall(Rule1,resolve_addition(Declared,Rule,Rule1),Rules3), sort(Rules3,Rules3a),
                        findall(Rule1,sig_addition(Rule,Rule1),Rules4), sort(Rules4,Rules4a),
                        append([[Rule],Rules1a,Rules2a,Rules3a,Rules4a],Rules).

% Constructing the Declared list... find_decl(CSF rules list, Declared list).

find_decl([csf_rules(RuleList)|Rest],List) :- !, find_decl_rules(RuleList,Some),
    find_decl(Rest,List1), append(Some,List1,List).
find_decl([_|Rest],List) :- find_decl(Rest,List).
find_decl([],[]).

find_decl_rules([],[]).
find_decl_rules([imsos_rule(_,imsos_onestep(Term,_,_,Kind))|Rest],[Token|Out]) :- !,
    Term =.. [F|_], Token =.. [Kind,F],
    find_decl_rules(Rest,Out).
find_decl_rules([_|Rest],Out) :- find_decl_rules(Rest,Out).

file2imsos(csf_file(CItems),IMSOS1) :- find_decl(CItems,Declared),
     maplist(item2imsos(Declared),CItems,IMSOSS), append(IMSOSS,IMSOS),
     maplist(liftings(Declared),IMSOS,IMSOSS1), append(IMSOSS1, IMSOS1).

files2imsos(csf_files(CFiles),imsos_file(IMSOS)) :- maplist(file2imsos,CFiles,IMSOSS), append(IMSOSS,IMSOS).

% Goes through a file and finds the value types, asserting that they are value types (used later in liftings).

:- dynamic valsort_csf/1, valcons_csf/1.

variablise(Term,_) :- atom(Term), name(Term,[X|_]), char_type(X,upper).
variablise(Term,Term1) :- Term =.. [F|Xs], maplist(variablise,Xs,Ys), Term1 =.. [F|Ys].

make_assertions(csf_files(CFiles)) :- maplist(make_assertions,CFiles), !.
make_assertions(csf_file(CItems)) :- maplist(make_assertions,CItems), !.
make_assertions(csf_subtypedec(Subtype,_,value)) :- assert(valsort_csf(Subtype)), !.
make_assertions(csf_typedec(Type,value)) :- assert(valsort_csf(Type)), !.
make_assertions(csf_typedef(Type,_,value)) :- assert(valsort_csf(Type)), !.
make_assertions(csf_datadec(Type,Constructors,_)) :- variablise(Type,Type2), assert(valsort_csf(Type2)), maplist(valcons_assert,Constructors), !.
make_assertions(_).

valcons_assert(Term) :- Term =.. [F|_], assert(valcons_csf(F)).


% valsort_csf(X) should hold precisely if generated prolog code declares valsort(X),
% there's a test for this in csf_test.pl
valsort_csf(val).
valsort_csf(ground).
valsort_csf(constant).
% otherwise generated from make_assertions

% CSF repository directory to IMSOS

csf2imsos(CFile,Imsos) :- make_assertions(CFile), files2imsos(CFile,Imsos).


