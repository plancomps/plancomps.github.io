:- cd('~/workspace/PLCS').
:- [csf_pl].
:- [csf_test].