sigdec(deref,computes(storable),[variable]).

onestep(deref(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(deref(E),F).

onestep(deref(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(deref(E),F).

sigdec(deref,computes(storable),[computes(variable)]).

sigdec(deref,depends(A,storable),[depends(A,variable)]).

onestep(deref(A),M,K,run) :- rewrites(A,E), rewrites(L,C), eq_label(M,[store=B|D]), rewrites(B,C), eq_label(D,[store+=_|G]), rewrites(E,F), runcheck(F,variable), checktag(F,variable,H), unobs(G), rewrites(L,I), rewrites(H,J), rewrites(map_select(I,J),K), rewrites(L,N), eq_label(M,[store+=N|_]).

sigdec(alloc,computes(variable),[storable]).

onestep(alloc(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(alloc(E),F).

onestep(alloc(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(alloc(E),F).

sigdec(alloc,computes(variable),[computes(storable)]).

sigdec(alloc,depends(A,variable),[depends(A,storable)]).

onestep(alloc(A),L,H,run) :- rewrites(A,E), rewrites(I,C), eq_label(L,[store=B|D]), rewrites(B,C), eq_label(D,[store+=_|G]), rewrites(store_freshvar(I),J), rewrites(E,F), runcheck(F,val), checktag(F,val,K), unobs(G), rewrites(J,H), rewrites(map_update(I,J,K),M), eq_label(L,[store+=M|_]).

sigdec(match,decl,[value,patt]).

onestep(match(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(match(G,H),I).

onestep(match(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(match(J,K),L).

sigdec(match,decl,[computes(value),patt]).

onestep(match(A,B),C,P,run) :- rewrites(A,J), rewrites(B,H), rewrites(_,E), eq_label(C,[given=D|G]), rewrites(D,E), rewrites(J,F), I=[given=F|G], runstep(H,I,M) -> rewrites(J,K), runcheck(K,value), checktag(K,value,L), rewrites(L,N), rewrites(M,O), rewrites(match(N,O),P).

rewrite(match(A,B),H) :- rewrites(A,C), rewrites(B,E), rewrites(C,D), runcheck(D,value), checktag(D,value,_), rewrites(E,F), runcheck(F,env), checktag(F,env,G), rewrites(G,H).

sigdec(stuck,computes(_),[]).

onestep(stuck,A,B,resolve) :- unobs(A), rewrites(stuck,B).

onestep(stuck,A,_,inhabit) :- unobs(A).

sigdec(prefer_over,depends(A,B),[depends(A,B),depends(A,B)]).

onestep(prefer_over(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(prefer_over(J,K),L).

onestep(prefer_over(A,B),M,L,run) :- rewrites(A,D), rewrites(B,I), eq_label(M,[not_in_domain+=_|C]), E=[not_in_domain+=_|C], runstep(D,E,H) -> rewrites(false,G), eq_label(E,[not_in_domain+=F|_]), rewrites(F,G), rewrites(H,J), rewrites(I,K), rewrites(prefer_over(J,K),L), rewrites(false,N), eq_label(M,[not_in_domain+=N|_]).

onestep(prefer_over(A,B),J,I,run) :- rewrites(A,D), rewrites(B,H), eq_label(J,[not_in_domain+=_|C]), E=[not_in_domain+=_|C], runstep(D,E,_) -> rewrites(true,G), eq_label(E,[not_in_domain+=F|_]), rewrites(F,G), rewrites(H,I), rewrites(false,K), eq_label(J,[not_in_domain+=K|_]).

rewrite(prefer_over(A,B),F) :- rewrites(A,C), rewrites(B,_), rewrites(C,D), runcheck(D,val), checktag(D,val,E), rewrites(E,F).

sigdec(only,patt,[value]).

onestep(only(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(only(E),F).

onestep(only(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(only(E),F).

sigdec(only,patt,[computes(value)]).

onestep(only(A),B,I,run) :- rewrites(A,F), rewrites(F,D), eq_label(B,[given=C|H]), rewrites(C,D), rewrites(F,E), runcheck(E,ground), checktag(E,ground,_), rewrites(F,G), runcheck(G,value), checktag(G,value,_), unobs(H), rewrites(map_empty,I).

onestep(only(A),M,L,run) :- rewrites(A,I), rewrites(G,C), eq_label(M,[given=B|D]), rewrites(B,C), eq_label(D,[not_in_domain+=_|K]), rewrites(G,E), runcheck(E,ground), checktag(E,ground,_), rewrites(I,F), runcheck(F,ground), checktag(F,ground,_), \+rewrites(G,I), rewrites(G,H), runcheck(H,value), checktag(H,value,_), rewrites(I,J), runcheck(J,value), checktag(J,value,_), unobs(K), rewrites(stuck,L), rewrites(true,N), eq_label(M,[not_in_domain+=N|_]).

sigdec(catch,expr,[expr,abs]).

onestep(catch(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(catch(J,K),L).

onestep(catch(A,B),M,L,run) :- rewrites(A,D), rewrites(B,I), eq_label(M,[exception+=_|C]), E=[exception+=_|C], runstep(D,E,H) -> rewrites(none,G), eq_label(E,[exception+=F|_]), rewrites(F,G), rewrites(H,J), rewrites(I,K), rewrites(catch(J,K),L), rewrites(none,N), eq_label(M,[exception+=N|_]).

onestep(catch(A,B),O,N,run) :- rewrites(A,D), rewrites(B,J), eq_label(O,[exception+=_|C]), E=[exception+=_|C], runstep(D,E,_) -> rewrites(some(H),G), eq_label(E,[exception+=F|_]), rewrites(F,G), rewrites(H,I), runcheck(I,throwable), checktag(I,throwable,K), rewrites(J,L), rewrites(K,M), rewrites(apply(L,M),N), rewrites(none,P), eq_label(O,[exception+=P|_]).

rewrite(catch(A,B),F) :- rewrites(A,C), rewrites(B,_), rewrites(C,D), runcheck(D,value), checktag(D,value,E), rewrites(E,F).

sigdec(accum,decl,[env,decl]).

onestep(accum(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(accum(G,H),I).

onestep(accum(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(accum(J,K),L).

sigdec(accum,decl,[computes(env),decl]).

rewrite(accum(A,B),K) :- rewrites(A,C), rewrites(B,E), rewrites(C,D), runcheck(D,env), checktag(D,env,F), rewrites(F,I), rewrites(E,G), rewrites(F,H), rewrites(map_over(G,H),J), rewrites(scope(I,J),K).

sigdec(partial_app,abs,[abs,value]).

onestep(partial_app(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(partial_app(G,H),I).

onestep(partial_app(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(partial_app(J,K),L).

sigdec(partial_app,abs,[abs,computes(value)]).

onestep(partial_app(A,B),C,R,run) :- rewrites(A,H), rewrites(B,J), rewrites(L,E), eq_label(C,[given=D|G]), rewrites(D,E), rewrites(tuple2(J,L),F), I=[given=F|G], runstep(H,I,N) -> rewrites(J,K), runcheck(K,value), checktag(K,value,O), rewrites(L,M), runcheck(M,value), checktag(M,value,_), rewrites(N,P), rewrites(O,Q), rewrites(partial_app(P,Q),R).

rewrite(partial_app(A,B),H) :- rewrites(A,E), rewrites(B,C), rewrites(C,D), runcheck(D,value), checktag(D,value,_), rewrites(E,F), runcheck(F,value), checktag(F,value,G), rewrites(G,H).

sigdec(effect,comm,[_]).

onestep(effect(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(effect(E),F).

onestep(effect(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(effect(E),F).

rewrite(effect(A),D) :- rewrites(A,B), rewrites(B,C), runcheck(C,val), checktag(C,val,_), rewrites(skip,D).

sigdec(closure,A,[A,env]).

onestep(closure(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(closure(G,H),I).

onestep(closure(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(closure(J,K),L).

sigdec(closure,A,[A,computes(env)]).

onestep(closure(A,B),C,P,run) :- rewrites(A,H), rewrites(B,J), rewrites(_,E), eq_label(C,[env=D|G]), rewrites(D,E), rewrites(J,F), I=[env=F|G], runstep(H,I,L) -> rewrites(J,K), runcheck(K,env), checktag(K,env,M), rewrites(L,N), rewrites(M,O), rewrites(closure(N,O),P).

rewrite(closure(A,B),H) :- rewrites(A,E), rewrites(B,C), rewrites(C,D), runcheck(D,env), checktag(D,env,_), rewrites(E,F), runcheck(F,val), checktag(F,val,G), rewrites(G,H).

sigdec(scope,A,[env,A]).

onestep(scope(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(scope(G,H),I).

onestep(scope(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(scope(J,K),L).

sigdec(scope,A,[computes(env),A]).

onestep(scope(A,B),C,R,run) :- rewrites(A,J), rewrites(B,H), rewrites(L,E), eq_label(C,[env=D|G]), rewrites(D,E), rewrites(map_over(J,L),F), I=[env=F|G], runstep(H,I,O) -> rewrites(J,K), runcheck(K,env), checktag(K,env,N), rewrites(L,M), runcheck(M,env), checktag(M,env,_), rewrites(N,P), rewrites(O,Q), rewrites(scope(P,Q),R).

rewrite(scope(A,B),H) :- rewrites(A,C), rewrites(B,E), rewrites(C,D), runcheck(D,env), checktag(D,env,_), rewrites(E,F), runcheck(F,val), checktag(F,val,G), rewrites(G,H).

sigdec(if_true,A,[boolean,A,A]).

onestep(if_true(A,B,C),E,L,run) :- rewrites(A,D), rewrites(B,G), rewrites(C,H), runstep(D,E,F) -> rewrites(F,I), rewrites(G,J), rewrites(H,K), rewrites(if_true(I,J,K),L).

onestep(if_true(A,B,C),K,R,resolve) :- rewrites(A,D), rewrites(B,E), rewrites(C,F), pre_comp(K,I), onestep(D,I,L,resolve), mid_comp(I,J), pre_comp(J,G), onestep(E,G,M,resolve), mid_comp(G,H), onestep(F,H,N,resolve), post_comp(G,H,J), post_comp(I,J,K), rewrites(L,O), rewrites(M,P), rewrites(N,Q), rewrites(if_true(O,P,Q),R).

sigdec(if_true,A,[computes(boolean),A,A]).

rewrite(if_true(A,B,C),E) :- rewrites(A,true), rewrites(B,D), rewrites(C,_), rewrites(D,E).

rewrite(if_true(A,B,C),E) :- rewrites(A,false), rewrites(B,_), rewrites(C,D), rewrites(D,E).

sigdec(abs,abs,[patt,expr]).

onestep(abs(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(abs(J,K),L).

onestep(abs(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(abs(G,H),I).

rewrite(abs(A,B),I) :- rewrites(A,C), rewrites(B,F), rewrites(C,D), runcheck(D,env), checktag(D,env,E), rewrites(E,G), rewrites(F,H), rewrites(scope(G,H),I).

sigdec(bind_value,decl,[id,passable]).

onestep(bind_value(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(bind_value(G,H),I).

onestep(bind_value(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(bind_value(G,H),I).

onestep(bind_value(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(bind_value(J,K),L).

sigdec(bind_value,decl,[computes(id),computes(passable)]).

rewrite(bind_value(A,B),L) :- rewrites(A,C), rewrites(B,E), rewrites(C,D), runcheck(D,id), checktag(D,id,G), rewrites(E,F), runcheck(F,passable), checktag(F,passable,H), rewrites(map_empty,I), rewrites(G,J), rewrites(H,K), rewrites(map_update(I,J,K),L).

sigdec(assign,comm,[variable,storable]).

onestep(assign(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(assign(G,H),I).

onestep(assign(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(assign(G,H),I).

onestep(assign(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(assign(J,K),L).

sigdec(assign,comm,[computes(variable),computes(storable)]).

onestep(assign(A,B),O,K,run) :- rewrites(A,H), rewrites(B,F), rewrites(L,D), eq_label(O,[store=C|E]), rewrites(C,D), eq_label(E,[store+=_|J]), rewrites(contains_key(L,H),true), rewrites(F,G), runcheck(G,storable), checktag(G,storable,N), rewrites(H,I), runcheck(I,variable), checktag(I,variable,M), unobs(J), rewrites(skip,K), rewrites(map_update(L,M,N),P), eq_label(O,[store+=P|_]).

sigdec(apply_to_each,comm,[abs,list(value)]).

onestep(apply_to_each(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(apply_to_each(G,H),I).

onestep(apply_to_each(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(apply_to_each(J,K),L).

sigdec(apply_to_each,comm,[abs,computes(list(value))]).

rewrite(apply_to_each(A,B),C) :- rewrites(A,_), rewrites(B,list_empty), rewrites(skip,C).

rewrite(apply_to_each(A,B),N) :- rewrites(A,H), rewrites(B,list_prefix(C,D)), rewrites(C,E), rewrites(D,I), rewrites(H,F), rewrites(E,G), rewrites(apply(F,G),L), rewrites(H,J), rewrites(I,K), rewrites(apply_to_each(J,K),M), rewrites(seq(L,M),N).

sigdec(bound_value,computes(bindable),[id]).

onestep(bound_value(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(bound_value(E),F).

onestep(bound_value(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(bound_value(E),F).

sigdec(bound_value,computes(bindable),[computes(id)]).

sigdec(bound_value,depends(A,bindable),[depends(A,id)]).

onestep(bound_value(A),B,N,run) :- rewrites(A,G), rewrites(E,D), eq_label(B,[env=C|I]), rewrites(C,D), rewrites(E,F), runcheck(F,env), checktag(F,env,J), rewrites(G,H), runcheck(H,id), checktag(H,id,K), unobs(I), rewrites(J,L), rewrites(K,M), rewrites(map_select(L,M),N).

sigdec(throw,computes(_),[throwable]).

onestep(throw(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(throw(E),F).

onestep(throw(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(throw(E),F).

sigdec(throw,computes(_),[computes(throwable)]).

sigdec(throw,depends(A,_),[depends(A,throwable)]).

onestep(throw(A),G,E,run) :- rewrites(A,B), eq_label(G,[exception+=_|D]), rewrites(B,C), runcheck(C,throwable), checktag(C,throwable,F), unobs(D), rewrites(stuck,E), rewrites(some(F),H), eq_label(G,[exception+=H|_]).

sigdec(bind,patt,[id]).

onestep(bind(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(bind(E),F).

onestep(bind(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(bind(E),F).

sigdec(bind,patt,[computes(id)]).

onestep(bind(A),B,O,run) :- rewrites(A,G), rewrites(E,D), eq_label(B,[given=C|I]), rewrites(C,D), rewrites(E,F), runcheck(F,val), checktag(F,val,K), rewrites(G,H), runcheck(H,id), checktag(H,id,J), unobs(I), rewrites(map_empty,L), rewrites(J,M), rewrites(K,N), rewrites(map_update(L,M,N),O).

sigdec(apply,computes(B),[depends(A,B),A]) :- valsort(A), valsort(B).

onestep(apply(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(apply(G,H),I).

onestep(apply(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(apply(J,K),L).

sigdec(apply,computes(A),[depends(B,A),B]).

onestep(apply(A,B),C,P,run) :- rewrites(A,H), rewrites(B,J), rewrites(_,E), eq_label(C,[given=D|G]), rewrites(D,E), rewrites(J,F), I=[given=F|G], runstep(H,I,L) -> rewrites(J,K), runcheck(K,val), checktag(K,val,M), rewrites(L,N), rewrites(M,O), rewrites(apply(N,O),P).

rewrite(apply(A,B),F) :- rewrites(A,C), rewrites(B,_), rewrites(C,D), runcheck(D,val), checktag(D,val,E), rewrites(E,F).

sigdec(compose,depends(B,A),[depends(C,A),depends(B,C)]).

onestep(compose(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(compose(J,K),L).

onestep(compose(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(compose(G,H),I).

onestep(compose(A,B),C,P,run) :- rewrites(A,H), rewrites(B,J), rewrites(_,E), eq_label(C,[given=D|G]), rewrites(D,E), rewrites(J,F), I=[given=F|G], runstep(H,I,L) -> rewrites(J,K), runcheck(K,val), checktag(K,val,M), rewrites(L,N), rewrites(M,O), rewrites(compose(N,O),P).

rewrite(compose(A,B),H) :- rewrites(A,E), rewrites(B,C), rewrites(C,D), runcheck(D,val), checktag(D,val,_), rewrites(E,F), runcheck(F,val), checktag(F,val,G), rewrites(G,H).

sigdec(forward,computes(bindable),[fwd]).

onestep(forward(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(forward(E),F).

onestep(forward(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(forward(E),F).

sigdec(forward,computes(bindable),[computes(fwd)]).

sigdec(forward,depends(A,bindable),[depends(A,fwd)]).

onestep(forward(A),M,K,run) :- rewrites(A,E), rewrites(L,C), eq_label(M,[forwards=B|D]), rewrites(B,C), eq_label(D,[forwards+=_|G]), rewrites(E,F), runcheck(F,fwd), checktag(F,fwd,H), unobs(G), rewrites(L,I), rewrites(H,J), rewrites(map_select(I,J),K), rewrites(L,N), eq_label(M,[forwards+=N|_]).

sigdec(given,depends(A,A),[]).

onestep(given,A,B,resolve) :- unobs(A), rewrites(given,B).

onestep(given,A,H,run) :- rewrites(D,C), eq_label(A,[given=B|F]), rewrites(B,C), rewrites(D,E), runcheck(E,val), checktag(E,val,G), unobs(F), rewrites(G,H).

sigdec(seq,A,[comm,A]).

onestep(seq(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(seq(J,K),L).

onestep(seq(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(seq(G,H),I).

rewrite(seq(A,B),D) :- rewrites(A,skip), rewrites(B,C), rewrites(C,D).

sigdec(recursive,decl,[list(id),decl]).

onestep(recursive(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(recursive(G,H),I).

onestep(recursive(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(recursive(J,K),L).

sigdec(recursive,decl,[computes(list(id)),decl]).

onestep(recursive(A,B),C,I,run) :- rewrites(A,D), rewrites(B,F), unobs(C), rewrites(D,E), rewrites(fresh_forwards(E),G), rewrites(F,H), rewrites(reclose(G,H),I).

sigdec(reclose,decl,[map(id,fwd),decl]).

onestep(reclose(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(reclose(G,H),I).

onestep(reclose(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(reclose(J,K),L).

sigdec(reclose,decl,[computes(map(id,fwd)),decl]).

rewrite(reclose(A,B),O) :- rewrites(A,H), rewrites(B,E), rewrites(forward_env(H),C), rewrites(C,D), runcheck(D,env), checktag(D,env,J), rewrites(J,F), rewrites(E,G), rewrites(scope(F,G),M), rewrites(H,I), rewrites(set_forwards(I),K), rewrites(J,L), rewrites(seq(K,L),N), rewrites(accum(M,N),O).

sigdec(forward_env,env,[map(id,fwd)]).

onestep(forward_env(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(forward_env(E),F).

onestep(forward_env(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(forward_env(E),F).

sigdec(forward_env,computes(env),[computes(map(id,fwd))]).

sigdec(forward_env,depends(A,env),[depends(A,map(id,fwd))]).

rewrite(forward_env(A),B) :- rewrites(A,map_empty), rewrites(map_empty,B).

rewrite(forward_env(A),Q) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,E), rewrites(C,G), rewrites(D,L), rewrites(E,F), runcheck(F,id), checktag(F,id,I), rewrites(G,H), runcheck(H,fwd), checktag(H,fwd,J), rewrites(I,N), rewrites(J,K), rewrites(forward(K),O), rewrites(L,M), rewrites(forward_env(M),P), rewrites(map_prefix(N,O,P),Q).

sigdec(set_forwards,comm,[map(id,fwd)]).

onestep(set_forwards(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(set_forwards(E),F).

onestep(set_forwards(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(set_forwards(E),F).

sigdec(set_forwards,comm,[computes(map(id,fwd))]).

rewrite(set_forwards(A),B) :- rewrites(A,map_empty), rewrites(skip,B).

onestep(set_forwards(A),Y,T,run) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,M), rewrites(C,O), rewrites(D,R), rewrites(K,F), eq_label(Y,[env=E|G]), rewrites(E,F), rewrites(U,I), eq_label(G,[forwards=H|J]), rewrites(H,I), eq_label(J,[forwards+=_|Q]), rewrites(K,L), runcheck(L,env), checktag(L,env,W), rewrites(M,N), runcheck(N,id), checktag(N,id,X), rewrites(O,P), runcheck(P,fwd), checktag(P,fwd,V), unobs(Q), rewrites(R,S), rewrites(set_forwards(S),T), rewrites(map_update(U,V,map_select(W,X)),Z), eq_label(Y,[forwards+=Z|_]).

sigdec(any,patt,[]).

onestep(any,A,B,resolve) :- unobs(A), rewrites(any,B).

onestep(any,A,E,run) :- rewrites(_,C), eq_label(A,[given=B|D]), rewrites(B,C), unobs(D), rewrites(map_empty,E).

sigdec(print,comm,[value]).

onestep(print(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(print(E),F).

onestep(print(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(print(E),F).

sigdec(print,comm,[computes(value)]).

onestep(print(A),G,E,run) :- rewrites(A,B), eq_label(G,[output+=_|D]), rewrites(B,C), runcheck(C,value), checktag(C,value,F), unobs(D), rewrites(skip,E), rewrites(list_prefix(F,list_empty),H), eq_label(G,[output+=H|_]).

sigdec(while_true,comm,[computes(boolean),comm]).

onestep(while_true(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(while_true(J,K),L).

onestep(while_true(A,B),C,M,run) :- rewrites(A,D), rewrites(B,E), unobs(C), rewrites(D,J), rewrites(E,H), rewrites(D,F), rewrites(E,G), rewrites(while_true(F,G),I), rewrites(seq(H,I),K), rewrites(skip,L), rewrites(if_true(J,K,L),M).

sigdec(fresh_forwards,computes(map(A,fwd)),[list(A)]).

onestep(fresh_forwards(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(fresh_forwards(E),F).

onestep(fresh_forwards(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(fresh_forwards(E),F).

sigdec(fresh_forwards,computes(map(A,fwd)),[computes(list(A))]).

sigdec(fresh_forwards,depends(A,map(B,fwd)),[depends(A,list(B))]).

rewrite(fresh_forwards(A),B) :- rewrites(A,list_empty), rewrites(map_empty,B).

onestep(fresh_forwards(A),S,P,run) :- rewrites(A,list_prefix(B,C)), rewrites(B,J), rewrites(C,K), rewrites(Q,E), eq_label(S,[forwards=D|F]), rewrites(D,E), eq_label(F,[forwards+=_|I]), rewrites(forwards_fresh(Q),G), rewrites(G,H), runcheck(H,fwd), checktag(H,fwd,R), unobs(I), rewrites(J,M), rewrites(R,N), rewrites(K,L), rewrites(fresh_forwards(L),O), rewrites(map_prefix(M,N,O),P), rewrites(map_update(Q,R,undefined),T), eq_label(S,[forwards+=T|_]).

sigdec(abs,type,[]).

onestep(abs,A,B,resolve) :- unobs(A), rewrites(abs,B).

typedef(abs,depends(passable,value)).

sigdec(proc,type,[]).

onestep(proc,A,B,resolve) :- unobs(A), rewrites(proc,B).

typedef(proc,depends(value,skip)).

sigdec(expr,type,[]).

onestep(expr,A,B,resolve) :- unobs(A), rewrites(expr,B).

typedef(expr,computes(value)).

sigdec(value,type,[]).

onestep(value,A,B,resolve) :- unobs(A), rewrites(value,B).

valsort(value).

sigdec(decl,type,[]).

onestep(decl,A,B,resolve) :- unobs(A), rewrites(decl,B).

typedef(decl,computes(env)).

sigdec(storable,type,[]).

onestep(storable,A,B,resolve) :- unobs(A), rewrites(storable,B).

valsort(storable).

sigdec(comm,type,[]).

onestep(comm,A,B,resolve) :- unobs(A), rewrites(comm,B).

typedef(comm,computes(skip)).

sigdec(field,type,[]).

onestep(field,A,B,resolve) :- unobs(A), rewrites(field,B).

typedef(field,atom).

valsort(field).

sigdec(passable,type,[]).

onestep(passable,A,B,resolve) :- unobs(A), rewrites(passable,B).

valsort(passable).

sigdec(throwable,type,[]).

onestep(throwable,A,B,resolve) :- unobs(A), rewrites(throwable,B).

valsort(throwable).

sigdec(bindable,type,[]).

onestep(bindable,A,B,resolve) :- unobs(A), rewrites(bindable,B).

valsort(bindable).

sigdec(patt,type,[]).

onestep(patt,A,B,resolve) :- unobs(A), rewrites(patt,B).

typedef(patt,depends(value,env)).

readable(store).

writeable(store).

default(store,map_empty).

sigdec(store,type,[]).

onestep(store,A,B,resolve) :- unobs(A), rewrites(store,B).

typedef(store,map(variable,storable)).

sigdec(store_freshvar,variable,[map(variable,_)]).

onestep(store_freshvar(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(store_freshvar(E),F).

onestep(store_freshvar(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(store_freshvar(E),F).

sigdec(store_freshvar,computes(variable),[computes(map(variable,_))]).

sigdec(store_freshvar,depends(A,variable),[depends(A,map(variable,_))]).

rewrite(store_freshvar(A),K) :- rewrites(A,B), rewrites(B,map_prefix(C,E,_)), rewrites(largest_key(B),G), rewrites(C,D), runcheck(D,variable), checktag(D,variable,_), rewrites(E,F), runcheck(F,storable), checktag(F,storable,_), rewrites(G,H), runcheck(H,variable), checktag(H,variable,I), rewrites(I,J), rewrites(variable_next(J),K).

rewrite(store_freshvar(A),B) :- rewrites(A,map_empty), rewrites(variable_first,B).

readable(forwards).

writeable(forwards).

default(forwards,map_empty).

sigdec(forwards,type,[]).

onestep(forwards,A,B,resolve) :- unobs(A), rewrites(forwards,B).

typedef(forwards,map(fwd,computes(bindable))).

sigdec(forwards_fresh,fwd,[forwards]).

onestep(forwards_fresh(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(forwards_fresh(E),F).

rewrite(forwards_fresh(A),I) :- rewrites(A,B), rewrites(B,map_prefix(C,_,_)), rewrites(largest_key(B),E), rewrites(C,D), runcheck(D,fwd), checktag(D,fwd,_), rewrites(E,F), runcheck(F,fwd), checktag(F,fwd,G), rewrites(G,H), rewrites(fwd_next(H),I).

rewrite(forwards_fresh(A),B) :- rewrites(A,map_empty), rewrites(fwd_first,B).

readable(given).

default(given,null).

readable(env).

default(env,map_empty).

sigdec(env,type,[]).

onestep(env,A,B,resolve) :- unobs(A), rewrites(env,B).

typedef(env,map(id,computes(bindable))).

valsort(env).

writeable(output).

default(output,list_empty).

rewrite(monop(A,B,C),H) :- rewrites(A,output), rewrites(B,D), rewrites(C,E), rewrites(D,F), rewrites(E,G), rewrites(list_append(F,G),H).

writeable(not_in_domain).

default(not_in_domain,false).

writeable(exception).

default(exception,none).

rewrite(monop(A,B,C),E) :- rewrites(A,exception), rewrites(B,none), rewrites(C,D), rewrites(D,E).

rewrite(monop(A,B,C),E) :- rewrites(A,exception), rewrites(B,D), rewrites(C,none), rewrites(D,E).

rewrite(monop(A,B,D),H) :- rewrites(A,exception), rewrites(B,some(C)), rewrites(C,F), rewrites(D,some(E)), rewrites(E,F), rewrites(F,G), rewrites(some(G),H).

sigdec(record,record,[map(field,value)]).

onestep(record(A),D,record(E),inhabit) :- rewrites(A,B), rewrites(B,C), inhabit(C,D,E).

onestep(record(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(record(E),F).

onestep(record(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(record(E),F).

sigdec(record,computes(record),[computes(map(field,value))]).

sigdec(record,depends(A,record),[depends(A,map(field,value))]).

valcons(record).

sigdec(record,type,[]).

onestep(record,A,type,inhabit) :- unobs(A).

onestep(record,A,B,resolve) :- unobs(A), rewrites(record,B).

valsort(record).

sigdec(record_over,record,[record,record]).

onestep(record_over(A,B),I,record,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,record), mid_comp(G,H), rewrites(E,F), inhabit(F,H,record), post_comp(G,H,I).

onestep(record_over(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(record_over(G,H),I).

onestep(record_over(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(record_over(G,H),I).

onestep(record_over(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(record_over(J,K),L).

sigdec(record_over,computes(record),[computes(record),computes(record)]).

sigdec(record_over,depends(A,record),[depends(A,record),depends(A,record)]).

rewrite(record_over(A,C),I) :- rewrites(A,record(B)), rewrites(B,E), rewrites(C,record(D)), rewrites(D,F), rewrites(map_over(E,F),G), rewrites(G,H), rewrites(record(H),I).

sigdec(record_union,record,[record,record]).

onestep(record_union(A,B),I,record,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,record), mid_comp(G,H), rewrites(E,F), inhabit(F,H,record), post_comp(G,H,I).

onestep(record_union(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(record_union(G,H),I).

onestep(record_union(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(record_union(G,H),I).

onestep(record_union(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(record_union(J,K),L).

sigdec(record_union,computes(record),[computes(record),computes(record)]).

sigdec(record_union,depends(A,record),[depends(A,record),depends(A,record)]).

rewrite(record_union(A,C),I) :- rewrites(A,record(B)), rewrites(B,E), rewrites(C,record(D)), rewrites(D,F), rewrites(map_union(E,F),G), rewrites(G,H), rewrites(record(H),I).

sigdec(record_select,value,[record,field]).

onestep(record_select(A,B),I,value,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,record), mid_comp(G,H), rewrites(E,F), inhabit(F,H,field), post_comp(G,H,I).

onestep(record_select(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(record_select(G,H),I).

onestep(record_select(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(record_select(G,H),I).

onestep(record_select(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(record_select(J,K),L).

sigdec(record_select,computes(value),[computes(record),computes(field)]).

sigdec(record_select,depends(A,value),[depends(A,record),depends(A,field)]).

rewrite(record_select(A,C),J) :- rewrites(A,record(B)), rewrites(B,F), rewrites(C,D), rewrites(D,E), runcheck(E,field), checktag(E,field,G), rewrites(F,H), rewrites(G,I), rewrites(map_select(H,I),J).

sigdec(record1,record,[field,value]).

onestep(record1(A,B),I,record,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,field), mid_comp(G,H), rewrites(E,F), inhabit(F,H,value), post_comp(G,H,I).

onestep(record1(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(record1(G,H),I).

onestep(record1(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(record1(G,H),I).

onestep(record1(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(record1(J,K),L).

sigdec(record1,computes(record),[computes(field),computes(value)]).

sigdec(record1,depends(A,record),[depends(A,field),depends(A,value)]).

sigdec(record2,record,[field,value,field,value]).

onestep(record2(A,B,C,D),S,record,inhabit) :- rewrites(A,E), rewrites(B,G), rewrites(C,I), rewrites(D,K), pre_comp(S,Q), rewrites(E,F), inhabit(F,Q,field), mid_comp(Q,R), pre_comp(R,O), rewrites(G,H), inhabit(H,O,value), mid_comp(O,P), pre_comp(P,M), rewrites(I,J), inhabit(J,M,field), mid_comp(M,N), rewrites(K,L), inhabit(L,N,value), post_comp(M,N,P), post_comp(O,P,R), post_comp(Q,R,S).

onestep(record2(A,B,C,D),F,O,run) :- rewrites(A,G), rewrites(B,H), rewrites(C,I), rewrites(D,E), runstep(E,F,J) -> rewrites(G,K), rewrites(H,L), rewrites(I,M), rewrites(J,N), rewrites(record2(K,L,M,N),O).

onestep(record2(A,B,C,D),F,O,run) :- rewrites(A,G), rewrites(B,H), rewrites(C,E), rewrites(D,J), runstep(E,F,I) -> rewrites(G,K), rewrites(H,L), rewrites(I,M), rewrites(J,N), rewrites(record2(K,L,M,N),O).

onestep(record2(A,B,C,D),F,O,run) :- rewrites(A,G), rewrites(B,E), rewrites(C,I), rewrites(D,J), runstep(E,F,H) -> rewrites(G,K), rewrites(H,L), rewrites(I,M), rewrites(J,N), rewrites(record2(K,L,M,N),O).

onestep(record2(A,B,C,D),F,O,run) :- rewrites(A,E), rewrites(B,H), rewrites(C,I), rewrites(D,J), runstep(E,F,G) -> rewrites(G,K), rewrites(H,L), rewrites(I,M), rewrites(J,N), rewrites(record2(K,L,M,N),O).

onestep(record2(A,B,C,D),O,X,resolve) :- rewrites(A,E), rewrites(B,F), rewrites(C,G), rewrites(D,H), pre_comp(O,M), onestep(E,M,P,resolve), mid_comp(M,N), pre_comp(N,K), onestep(F,K,Q,resolve), mid_comp(K,L), pre_comp(L,I), onestep(G,I,R,resolve), mid_comp(I,J), onestep(H,J,S,resolve), post_comp(I,J,L), post_comp(K,L,N), post_comp(M,N,O), rewrites(P,T), rewrites(Q,U), rewrites(R,V), rewrites(S,W), rewrites(record2(T,U,V,W),X).

sigdec(record2,computes(record),[computes(field),computes(value),computes(field),computes(value)]).

sigdec(record2,depends(A,record),[depends(A,field),depends(A,value),depends(A,field),depends(A,value)]).

rewrite(record1(A,B),M) :- rewrites(A,C), rewrites(B,E), rewrites(C,D), runcheck(D,field), checktag(D,field,G), rewrites(E,F), runcheck(F,value), checktag(F,value,H), rewrites(map_empty,I), rewrites(G,J), rewrites(H,K), rewrites(map_update(I,J,K),L), rewrites(record(L),M).

rewrite(record2(A,B,C,D),X) :- rewrites(A,E), rewrites(B,G), rewrites(C,I), rewrites(D,K), rewrites(E,F), runcheck(F,field), checktag(F,field,M), rewrites(G,H), runcheck(H,value), checktag(H,value,N), rewrites(I,J), runcheck(J,field), checktag(J,field,R), rewrites(K,L), runcheck(L,value), checktag(L,value,S), rewrites(map_empty,O), rewrites(M,P), rewrites(N,Q), rewrites(map_update(O,P,Q),T), rewrites(R,U), rewrites(S,V), rewrites(map_update(T,U,V),W), rewrites(record(W),X).

sigdec(map_empty,map(_,_),[]).

onestep(map_empty,A,B,resolve) :- unobs(A), rewrites(map_empty,B).

valcons(map_empty).

sigdec(map_prefix,map(A,B),[A,B,map(A,B)]).

onestep(map_prefix(A,B,C),E,L,run) :- rewrites(A,F), rewrites(B,G), rewrites(C,D), runstep(D,E,H) -> rewrites(F,I), rewrites(G,J), rewrites(H,K), rewrites(map_prefix(I,J,K),L).

onestep(map_prefix(A,B,C),K,R,resolve) :- rewrites(A,D), rewrites(B,E), rewrites(C,F), pre_comp(K,I), onestep(D,I,L,resolve), mid_comp(I,J), pre_comp(J,G), onestep(E,G,M,resolve), mid_comp(G,H), onestep(F,H,N,resolve), post_comp(G,H,J), post_comp(I,J,K), rewrites(L,O), rewrites(M,P), rewrites(N,Q), rewrites(map_prefix(O,P,Q),R).

sigdec(map_prefix,computes(map(A,B)),[A,B,computes(map(A,B))]).

valcons(map_prefix).

sigdec(map(_,_),type,[]).

onestep(map(A,B),C,H,resolve) :- rewrites(A,D), rewrites(B,E), unobs(C), rewrites(D,F), rewrites(E,G), rewrites(map(F,G),H).

valsort(map(_,_)).

sigdec(map_select,A,[map(B,A),B]).

onestep(map_select(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(map_select(G,H),I).

onestep(map_select(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(map_select(J,K),L).

sigdec(map_select,A,[computes(map(B,A)),B]).

rewrite(map_select(A,E),H) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,F), rewrites(C,G), rewrites(D,_), rewrites(E,F), rewrites(G,H).

rewrite(map_select(A,E),N) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,H), rewrites(C,_), rewrites(D,J), rewrites(E,I), rewrites(H,F), runcheck(F,ground), checktag(F,ground,_), rewrites(I,G), runcheck(G,ground), checktag(G,ground,K), \+rewrites(H,I), rewrites(J,L), rewrites(K,M), rewrites(map_select(L,M),N).

sigdec(map_update,map(A,B),[map(A,B),A,B]).

onestep(map_update(A,B,C),E,L,run) :- rewrites(A,D), rewrites(B,G), rewrites(C,H), runstep(D,E,F) -> rewrites(F,I), rewrites(G,J), rewrites(H,K), rewrites(map_update(I,J,K),L).

onestep(map_update(A,B,C),K,R,resolve) :- rewrites(A,D), rewrites(B,E), rewrites(C,F), pre_comp(K,I), onestep(D,I,L,resolve), mid_comp(I,J), pre_comp(J,G), onestep(E,G,M,resolve), mid_comp(G,H), onestep(F,H,N,resolve), post_comp(G,H,J), post_comp(I,J,K), rewrites(L,O), rewrites(M,P), rewrites(N,Q), rewrites(map_update(O,P,Q),R).

sigdec(map_update,computes(map(A,B)),[computes(map(A,B)),A,B]).

rewrite(map_update(A,E,F),M) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,G), rewrites(C,_), rewrites(D,I), rewrites(E,G), rewrites(F,H), rewrites(G,J), rewrites(H,K), rewrites(I,L), rewrites(map_prefix(J,K,L),M).

rewrite(map_update(A,B,C),I) :- rewrites(A,map_empty), rewrites(B,D), rewrites(C,E), rewrites(D,F), rewrites(E,G), rewrites(map_empty,H), rewrites(map_prefix(F,G,H),I).

rewrite(map_update(A,E,F),S) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,I), rewrites(C,N), rewrites(D,J), rewrites(E,K), rewrites(F,L), rewrites(I,G), runcheck(G,ground), checktag(G,ground,M), rewrites(K,H), runcheck(H,ground), checktag(H,ground,_), lessthan(I,K), rewrites(map_update(J,K,L),O), rewrites(M,P), rewrites(N,Q), rewrites(O,R), rewrites(map_prefix(P,Q,R),S).

rewrite(map_update(A,E,F),V) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,J), rewrites(C,N), rewrites(D,O), rewrites(E,I), rewrites(F,L), rewrites(J,G), runcheck(G,ground), checktag(G,ground,M), rewrites(I,H), runcheck(H,ground), checktag(H,ground,K), lessthan(I,J), rewrites(K,S), rewrites(L,T), rewrites(M,P), rewrites(N,Q), rewrites(O,R), rewrites(map_prefix(P,Q,R),U), rewrites(map_prefix(S,T,U),V).

sigdec(map_over,map(A,B),[map(A,B),map(A,B)]).

onestep(map_over(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(map_over(G,H),I).

onestep(map_over(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(map_over(G,H),I).

onestep(map_over(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(map_over(J,K),L).

sigdec(map_over,computes(map(A,B)),[computes(map(A,B)),computes(map(A,B))]).

sigdec(map_over,depends(A,map(B,C)),[depends(A,map(B,C)),depends(A,map(B,C))]).

rewrite(map_over(A,B),D) :- rewrites(A,map_empty), rewrites(B,C), rewrites(C,D).

rewrite(map_over(A,E),N) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,I), rewrites(C,J), rewrites(D,F), rewrites(E,G), rewrites(map_over(F,G),H), rewrites(H,K), rewrites(I,L), rewrites(J,M), rewrites(map_update(K,L,M),N).

sigdec(map_union,map(A,B),[map(A,B),map(A,B)]).

onestep(map_union(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(map_union(G,H),I).

onestep(map_union(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(map_union(G,H),I).

onestep(map_union(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(map_union(J,K),L).

sigdec(map_union,computes(map(A,B)),[computes(map(A,B)),computes(map(A,B))]).

sigdec(map_union,depends(A,map(B,C)),[depends(A,map(B,C)),depends(A,map(B,C))]).

rewrite(map_union(A,B),D) :- rewrites(A,map_empty), rewrites(B,C), rewrites(C,D).

rewrite(map_union(A,E),N) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,I), rewrites(C,J), rewrites(D,F), rewrites(E,G), rewrites(contains_key(G,I),false), rewrites(map_union(F,G),H), rewrites(H,K), rewrites(I,L), rewrites(J,M), rewrites(map_update(K,L,M),N).

sigdec(contains_key,boolean,[map(A,_),A]).

onestep(contains_key(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(contains_key(G,H),I).

onestep(contains_key(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(contains_key(J,K),L).

sigdec(contains_key,computes(boolean),[computes(map(A,_)),A]).

rewrite(contains_key(A,B),C) :- rewrites(A,map_empty), rewrites(B,_), rewrites(false,C).

rewrite(contains_key(A,E),G) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,F), rewrites(C,_), rewrites(D,_), rewrites(E,F), rewrites(true,G).

rewrite(contains_key(A,E),N) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,H), rewrites(C,_), rewrites(D,J), rewrites(E,I), rewrites(H,F), runcheck(F,ground), checktag(F,ground,_), rewrites(I,G), runcheck(G,ground), checktag(G,ground,K), \+rewrites(H,I), rewrites(J,L), rewrites(K,M), rewrites(contains_key(L,M),N).

sigdec(largest_key,A,[map(A,_)]).

onestep(largest_key(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(largest_key(E),F).

onestep(largest_key(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(largest_key(E),F).

sigdec(largest_key,A,[computes(map(A,_))]).

rewrite(largest_key(A),F) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,E), rewrites(C,_), rewrites(D,map_empty), rewrites(E,F).

rewrite(largest_key(A),O) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,_), rewrites(C,_), rewrites(D,map_prefix(E,F,G)), rewrites(E,H), rewrites(F,I), rewrites(G,J), rewrites(H,K), rewrites(I,L), rewrites(J,M), rewrites(map_prefix(K,L,M),N), rewrites(largest_key(N),O).

sigdec(map_eval,computes(map(A,B)),[map(A,computes(B))]).

onestep(map_eval(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(map_eval(E),F).

onestep(map_eval(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(map_eval(E),F).

sigdec(map_eval,computes(map(A,B)),[computes(map(A,computes(B)))]).

sigdec(map_eval,depends(A,map(B,C)),[depends(A,map(B,computes(C)))]).

onestep(map_eval(A),B,C,run) :- rewrites(A,map_empty), unobs(B), rewrites(map_empty,C).

onestep(map_eval(A),F,N,run) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,G), rewrites(C,E), rewrites(D,I), runstep(E,F,H) -> rewrites(G,J), rewrites(H,K), rewrites(I,L), rewrites(map_prefix(J,K,L),M), rewrites(map_eval(M),N).

onestep(map_eval(A),F,N,run) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,G), rewrites(C,H), rewrites(D,E), runstep(map_eval(E),F,map_eval(I)) -> rewrites(G,J), rewrites(H,K), rewrites(I,L), rewrites(map_prefix(J,K,L),M), rewrites(map_eval(M),N).

onestep(map_eval(A),F,N,run) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,I), rewrites(C,G), rewrites(D,E), runstep(map_eval(E),F,map_empty) -> rewrites(G,H), runcheck(H,val), checktag(H,val,J), rewrites(I,K), rewrites(J,L), rewrites(map_empty,M), rewrites(map_prefix(K,L,M),N).

onestep(map_eval(A),F,T,run) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,I), rewrites(C,G), rewrites(D,E), runstep(map_eval(E),F,map_prefix(K,L,M)) -> rewrites(G,H), runcheck(H,val), checktag(H,val,J), rewrites(I,Q), rewrites(J,R), rewrites(K,N), rewrites(L,O), rewrites(M,P), rewrites(map_prefix(N,O,P),S), rewrites(map_prefix(Q,R,S),T).

sigdec(map1,map(A,B),[A,B]).

onestep(map1(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(map1(J,K),L).

rewrite(map1(A,B),H) :- rewrites(A,C), rewrites(B,D), rewrites(map_empty,E), rewrites(C,F), rewrites(D,G), rewrites(map_update(E,F,G),H).

sigdec(map_domain,list(A),[map(A,_)]).

onestep(map_domain(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(map_domain(E),F).

onestep(map_domain(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(map_domain(E),F).

sigdec(map_domain,computes(list(A)),[computes(map(A,_))]).

sigdec(map_domain,depends(A,list(B)),[depends(A,map(B,_))]).

rewrite(map_domain(A),B) :- rewrites(A,map_empty), rewrites(list_empty,B).

rewrite(map_domain(A),J) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,E), rewrites(C,_), rewrites(D,F), rewrites(E,H), rewrites(F,G), rewrites(map_domain(G),I), rewrites(list_prefix(H,I),J).

sigdec(map_subset,boolean,[map(A,B),map(A,B)]).

onestep(map_subset(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(map_subset(G,H),I).

onestep(map_subset(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(map_subset(G,H),I).

onestep(map_subset(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(map_subset(J,K),L).

sigdec(map_subset,computes(boolean),[computes(map(A,B)),computes(map(A,B))]).

sigdec(map_subset,depends(A,boolean),[depends(A,map(B,C)),depends(A,map(B,C))]).

rewrite(map_subset(A,B),C) :- rewrites(A,map_empty), rewrites(B,_), rewrites(true,C).

rewrite(map_subset(A,E),Q) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,F), rewrites(C,G), rewrites(D,K), rewrites(E,L), rewrites(L,H), rewrites(F,I), rewrites(G,J), rewrites(contains(H,I,J),O), rewrites(K,M), rewrites(L,N), rewrites(map_subset(M,N),P), rewrites(and(O,P),Q).

sigdec(contains,boolean,[map(A,B),A,B]).

onestep(contains(A,B,C),E,L,run) :- rewrites(A,D), rewrites(B,G), rewrites(C,H), runstep(D,E,F) -> rewrites(F,I), rewrites(G,J), rewrites(H,K), rewrites(contains(I,J,K),L).

onestep(contains(A,B,C),K,R,resolve) :- rewrites(A,D), rewrites(B,E), rewrites(C,F), pre_comp(K,I), onestep(D,I,L,resolve), mid_comp(I,J), pre_comp(J,G), onestep(E,G,M,resolve), mid_comp(G,H), onestep(F,H,N,resolve), post_comp(G,H,J), post_comp(I,J,K), rewrites(L,O), rewrites(M,P), rewrites(N,Q), rewrites(contains(O,P,Q),R).

sigdec(contains,computes(boolean),[computes(map(A,B)),A,B]).

rewrite(contains(A,B,C),D) :- rewrites(A,map_empty), rewrites(B,_), rewrites(C,_), rewrites(false,D).

rewrite(contains(A,E,G),I) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,F), rewrites(C,H), rewrites(D,_), rewrites(E,F), rewrites(G,H), rewrites(true,I).

rewrite(contains(A,E,F),Q) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,I), rewrites(C,M), rewrites(D,K), rewrites(E,J), rewrites(F,M), rewrites(I,G), runcheck(G,ground), checktag(G,ground,_), rewrites(J,H), runcheck(H,ground), checktag(H,ground,L), \+rewrites(I,J), rewrites(K,N), rewrites(L,O), rewrites(M,P), rewrites(contains(N,O,P),Q).

rewrite(contains(A,E,F),R) :- rewrites(A,map_prefix(B,C,D)), rewrites(B,G), rewrites(C,K), rewrites(D,L), rewrites(E,I), rewrites(F,N), rewrites(G,H), runcheck(H,ground), checktag(H,ground,_), rewrites(I,J), runcheck(J,ground), checktag(J,ground,M), \+rewrites(K,N), rewrites(L,O), rewrites(M,P), rewrites(N,Q), rewrites(contains(O,P,Q),R).

sigdec(map_zip,map(A,B),[list(A),list(B)]).

onestep(map_zip(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(map_zip(G,H),I).

onestep(map_zip(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(map_zip(G,H),I).

onestep(map_zip(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(map_zip(J,K),L).

sigdec(map_zip,computes(map(A,B)),[computes(list(A)),computes(list(B))]).

sigdec(map_zip,depends(B,map(A,C)),[depends(B,list(A)),depends(B,list(C))]).

rewrite(map_zip(A,B),C) :- rewrites(A,list_empty), rewrites(B,list_empty), rewrites(map_empty,C).

rewrite(map_zip(A,D),P) :- rewrites(A,list_prefix(B,C)), rewrites(B,K), rewrites(C,G), rewrites(D,list_prefix(E,F)), rewrites(E,L), rewrites(F,H), rewrites(G,I), rewrites(H,J), rewrites(map_zip(I,J),M), rewrites(K,N), rewrites(L,O), rewrites(map_update(M,N,O),P).

sigdec(var,variable,[int]).

onestep(var(A),D,variable(E),inhabit) :- rewrites(A,B), rewrites(B,C), inhabit(C,D,E).

onestep(var(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(var(E),F).

onestep(var(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(var(E),F).

sigdec(var,computes(variable),[computes(int)]).

sigdec(var,depends(A,variable),[depends(A,int)]).

valcons(var).

sigdec(variable,type,[]).

onestep(variable,A,B,resolve) :- unobs(A), rewrites(variable,B).

valsort(variable).

sigdec(variable,type,[type]).

onestep(variable(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(variable(E),F).

sigdec(variable_next,variable,[variable]).

onestep(variable_next(A),D,variable,inhabit) :- rewrites(A,B), rewrites(B,C), inhabit(C,D,variable).

onestep(variable_next(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(variable_next(E),F).

onestep(variable_next(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(variable_next(E),F).

sigdec(variable_next,computes(variable),[computes(variable)]).

sigdec(variable_next,depends(A,variable),[depends(A,variable)]).

rewrite(variable_next(A),I) :- rewrites(A,var(B)), rewrites(B,C), rewrites(C,D), runcheck(D,int), checktag(D,int,E), rewrites(E,F), rewrites(q(1),G), rewrites(int_plus(F,G),H), rewrites(var(H),I).

sigdec(variable_first,variable,[]).

onestep(variable_first,A,variable,inhabit) :- unobs(A).

onestep(variable_first,A,B,resolve) :- unobs(A), rewrites(variable_first,B).

rewrite(variable_first,B) :- rewrites(q(0),A), rewrites(var(A),B).

rewrite(var1,B) :- rewrites(q(1),A), rewrites(var(A),B).

rewrite(var2,B) :- rewrites(q(2),A), rewrites(var(A),B).

rewrite(var3,B) :- rewrites(q(3),A), rewrites(var(A),B).

sigdec(o,nat,[]).

onestep(o,A,nat,inhabit) :- unobs(A).

onestep(o,A,B,resolve) :- unobs(A), rewrites(o,B).

valcons(o).

sigdec(s,nat,[nat]).

onestep(s(A),D,nat(E),inhabit) :- rewrites(A,B), rewrites(B,C), inhabit(C,D,E).

onestep(s(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(s(E),F).

onestep(s(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(s(E),F).

sigdec(s,computes(nat),[computes(nat)]).

sigdec(s,depends(A,nat),[depends(A,nat)]).

valcons(s).

sigdec(nat,type,[]).

onestep(nat,A,B,resolve) :- unobs(A), rewrites(nat,B).

valsort(nat).

sigdec(list_empty,list(A),[]) :- valsort(A).

onestep(list_empty,A,B,resolve) :- unobs(A), rewrites(list_empty,B).

sigdec(list_empty,computes(list(_)),[]).

sigdec(list_empty,depends(_,list(_)),[]).

valcons(list_empty).

sigdec(list_prefix,list(A),[A,list(A)]) :- valsort(A).

onestep(list_prefix(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(list_prefix(G,H),I).

onestep(list_prefix(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(list_prefix(G,H),I).

onestep(list_prefix(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(list_prefix(J,K),L).

sigdec(list_prefix,computes(list(A)),[A,computes(list(A))]).

valcons(list_prefix).

sigdec(list(_),type,[]).

onestep(list(A),B,E,resolve) :- rewrites(A,C), unobs(B), rewrites(C,D), rewrites(list(D),E).

valsort(list(_)).

sigdec(list_append1,list(A),[list(A),A]).

onestep(list_append1(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(list_append1(G,H),I).

onestep(list_append1(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(list_append1(J,K),L).

sigdec(list_append1,computes(list(A)),[computes(list(A)),A]).

rewrite(list_append1(A,B),F) :- rewrites(A,list_empty), rewrites(B,C), rewrites(C,D), rewrites(list_empty,E), rewrites(list_prefix(D,E),F).

rewrite(list_append1(A,D),L) :- rewrites(A,list_prefix(B,C)), rewrites(B,E), rewrites(C,F), rewrites(D,G), rewrites(E,J), rewrites(F,H), rewrites(G,I), rewrites(list_append1(H,I),K), rewrites(list_prefix(J,K),L).

sigdec(list_reverse,list(A),[list(A)]).

onestep(list_reverse(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(list_reverse(E),F).

onestep(list_reverse(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(list_reverse(E),F).

sigdec(list_reverse,computes(list(A)),[computes(list(A))]).

sigdec(list_reverse,depends(A,list(B)),[depends(A,list(B))]).

rewrite(list_reverse(A),B) :- rewrites(A,list_empty), rewrites(list_empty,B).

rewrite(list_reverse(A),H) :- rewrites(A,list_prefix(B,C)), rewrites(B,E), rewrites(C,D), rewrites(D,F), rewrites(E,G), rewrites(list_append1(F,G),H).

sigdec(list_append,list(A),[list(A),list(A)]).

onestep(list_append(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(list_append(G,H),I).

onestep(list_append(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(list_append(G,H),I).

onestep(list_append(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(list_append(J,K),L).

sigdec(list_append,computes(list(A)),[computes(list(A)),computes(list(A))]).

sigdec(list_append,depends(A,list(B)),[depends(A,list(B)),depends(A,list(B))]).

rewrite(list_append(A,B),D) :- rewrites(A,list_empty), rewrites(B,C), rewrites(C,D).

rewrite(list_append(A,D),L) :- rewrites(A,list_prefix(B,C)), rewrites(B,E), rewrites(C,F), rewrites(D,G), rewrites(E,J), rewrites(F,H), rewrites(G,I), rewrites(list_append(H,I),K), rewrites(list_prefix(J,K),L).

sigdec(list1,list(A),[A]).

onestep(list1(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(list1(E),F).

rewrite(list1(A),E) :- rewrites(A,B), rewrites(B,C), rewrites(list_empty,D), rewrites(list_prefix(C,D),E).

sigdec(list_select,A,[list(A),int]).

onestep(list_select(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(list_select(G,H),I).

onestep(list_select(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(list_select(G,H),I).

onestep(list_select(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(list_select(J,K),L).

sigdec(list_select,A,[computes(list(A)),computes(int)]).

rewrite(list_select(A,D),F) :- rewrites(A,list_prefix(B,C)), rewrites(B,E), rewrites(C,_), rewrites(D,q(0)), rewrites(E,F).

rewrite(list_select(A,D),M) :- rewrites(A,list_prefix(B,C)), rewrites(B,_), rewrites(C,I), rewrites(D,E), rewrites(int_greater(E,q(0)),true), rewrites(int_minus(E,q(1)),G), rewrites(E,F), runcheck(F,int), checktag(F,int,_), rewrites(G,H), runcheck(H,int), checktag(H,int,J), rewrites(I,K), rewrites(J,L), rewrites(list_select(K,L),M).

sigdec(list_length,int,[list(_)]).

onestep(list_length(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(list_length(E),F).

onestep(list_length(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(list_length(E),F).

sigdec(list_length,computes(int),[computes(list(_))]).

sigdec(list_length,depends(A,int),[depends(A,list(_))]).

rewrite(list_length(A),q(0)) :- rewrites(A,list_empty).

rewrite(list_length(A),H) :- rewrites(A,list_prefix(B,C)), rewrites(B,_), rewrites(C,D), rewrites(D,E), rewrites(list_length(E),F), rewrites(q(1),G), rewrites(int_plus(F,G),H).

sigdec(int,type,[]).

onestep(int,A,B,resolve) :- unobs(A), rewrites(int,B).

valsort(int).

sigdec(int_plus,int,[int,int]).

onestep(int_plus(A,B),I,int,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,int), mid_comp(G,H), rewrites(E,F), inhabit(F,H,int), post_comp(G,H,I).

onestep(int_plus(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(int_plus(G,H),I).

onestep(int_plus(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(int_plus(G,H),I).

onestep(int_plus(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(int_plus(J,K),L).

sigdec(int_plus,computes(int),[computes(int),computes(int)]).

sigdec(int_plus,depends(A,int),[depends(A,int),depends(A,int)]).

sigdec(int_minus,int,[int,int]).

onestep(int_minus(A,B),I,int,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,int), mid_comp(G,H), rewrites(E,F), inhabit(F,H,int), post_comp(G,H,I).

onestep(int_minus(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(int_minus(G,H),I).

onestep(int_minus(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(int_minus(G,H),I).

onestep(int_minus(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(int_minus(J,K),L).

sigdec(int_minus,computes(int),[computes(int),computes(int)]).

sigdec(int_minus,depends(A,int),[depends(A,int),depends(A,int)]).

sigdec(int_times,int,[int,int]).

onestep(int_times(A,B),I,int,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,int), mid_comp(G,H), rewrites(E,F), inhabit(F,H,int), post_comp(G,H,I).

onestep(int_times(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(int_times(G,H),I).

onestep(int_times(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(int_times(G,H),I).

onestep(int_times(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(int_times(J,K),L).

sigdec(int_times,computes(int),[computes(int),computes(int)]).

sigdec(int_times,depends(A,int),[depends(A,int),depends(A,int)]).

sigdec(int_divide,int,[int,int]).

onestep(int_divide(A,B),I,int,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,int), mid_comp(G,H), rewrites(E,F), inhabit(F,H,int), post_comp(G,H,I).

onestep(int_divide(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(int_divide(G,H),I).

onestep(int_divide(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(int_divide(G,H),I).

onestep(int_divide(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(int_divide(J,K),L).

sigdec(int_divide,computes(int),[computes(int),computes(int)]).

sigdec(int_divide,depends(A,int),[depends(A,int),depends(A,int)]).

sigdec(int_less,boolean,[int,int]).

onestep(int_less(A,B),I,boolean,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,int), mid_comp(G,H), rewrites(E,F), inhabit(F,H,int), post_comp(G,H,I).

onestep(int_less(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(int_less(G,H),I).

onestep(int_less(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(int_less(G,H),I).

onestep(int_less(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(int_less(J,K),L).

sigdec(int_less,computes(boolean),[computes(int),computes(int)]).

sigdec(int_less,depends(A,boolean),[depends(A,int),depends(A,int)]).

sigdec(int_less_equal,boolean,[int,int]).

onestep(int_less_equal(A,B),I,boolean,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,int), mid_comp(G,H), rewrites(E,F), inhabit(F,H,int), post_comp(G,H,I).

onestep(int_less_equal(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(int_less_equal(G,H),I).

onestep(int_less_equal(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(int_less_equal(G,H),I).

onestep(int_less_equal(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(int_less_equal(J,K),L).

sigdec(int_less_equal,computes(boolean),[computes(int),computes(int)]).

sigdec(int_less_equal,depends(A,boolean),[depends(A,int),depends(A,int)]).

sigdec(int_greater,boolean,[int,int]).

onestep(int_greater(A,B),I,boolean,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,int), mid_comp(G,H), rewrites(E,F), inhabit(F,H,int), post_comp(G,H,I).

onestep(int_greater(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(int_greater(G,H),I).

onestep(int_greater(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(int_greater(G,H),I).

onestep(int_greater(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(int_greater(J,K),L).

sigdec(int_greater,computes(boolean),[computes(int),computes(int)]).

sigdec(int_greater,depends(A,boolean),[depends(A,int),depends(A,int)]).

sigdec(int_greater_equal,boolean,[int,int]).

onestep(int_greater_equal(A,B),I,boolean,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,int), mid_comp(G,H), rewrites(E,F), inhabit(F,H,int), post_comp(G,H,I).

onestep(int_greater_equal(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(int_greater_equal(G,H),I).

onestep(int_greater_equal(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(int_greater_equal(G,H),I).

onestep(int_greater_equal(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(int_greater_equal(J,K),L).

sigdec(int_greater_equal,computes(boolean),[computes(int),computes(int)]).

sigdec(int_greater_equal,depends(A,boolean),[depends(A,int),depends(A,int)]).

sigdec(int_closed_interval,list(int),[int,int]).

onestep(int_closed_interval(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(int_closed_interval(G,H),I).

onestep(int_closed_interval(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(int_closed_interval(G,H),I).

onestep(int_closed_interval(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(int_closed_interval(J,K),L).

sigdec(int_closed_interval,computes(list(int)),[computes(int),computes(int)]).

sigdec(int_closed_interval,depends(A,list(int)),[depends(A,int),depends(A,int)]).

rewrite(int_closed_interval(A,B),F) :- rewrites(A,C), rewrites(B,C), rewrites(C,D), rewrites(list_empty,E), rewrites(list_prefix(D,E),F).

rewrite(int_closed_interval(A,B),K) :- rewrites(A,C), rewrites(B,F), rewrites(int_less(C,F),true), rewrites(C,I), rewrites(C,D), rewrites(q(1),E), rewrites(int_plus(D,E),G), rewrites(F,H), rewrites(int_closed_interval(G,H),J), rewrites(list_prefix(I,J),K).

sigdec(int_min,int,[int,int]).

onestep(int_min(A,B),I,int,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,int), mid_comp(G,H), rewrites(E,F), inhabit(F,H,int), post_comp(G,H,I).

onestep(int_min(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(int_min(G,H),I).

onestep(int_min(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(int_min(G,H),I).

onestep(int_min(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(int_min(J,K),L).

sigdec(int_min,computes(int),[computes(int),computes(int)]).

sigdec(int_min,depends(A,int),[depends(A,int),depends(A,int)]).

rewrite(int_min(A,B),H) :- rewrites(A,C), rewrites(B,E), rewrites(int_greater(C,E),true), rewrites(C,D), runcheck(D,int), checktag(D,int,_), rewrites(E,F), runcheck(F,int), checktag(F,int,G), rewrites(G,H).

rewrite(int_min(A,B),H) :- rewrites(A,C), rewrites(B,E), rewrites(int_less_equal(C,E),true), rewrites(C,D), runcheck(D,int), checktag(D,int,G), rewrites(E,F), runcheck(F,int), checktag(F,int,_), rewrites(G,H).

sigdec(string,type,[]).

onestep(string,A,B,resolve) :- unobs(A), rewrites(string,B).

valsort(string).

sigdec(string_append,string,[string,string]).

onestep(string_append(A,B),I,string,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,string), mid_comp(G,H), rewrites(E,F), inhabit(F,H,string), post_comp(G,H,I).

onestep(string_append(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(string_append(G,H),I).

onestep(string_append(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(string_append(G,H),I).

onestep(string_append(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(string_append(J,K),L).

sigdec(string_append,computes(string),[computes(string),computes(string)]).

sigdec(string_append,depends(A,string),[depends(A,string),depends(A,string)]).

sigdec(float,type,[]).

onestep(float,A,B,resolve) :- unobs(A), rewrites(float,B).

valsort(float).

sigdec(float_plus,float,[float,float]).

onestep(float_plus(A,B),I,float,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,float), mid_comp(G,H), rewrites(E,F), inhabit(F,H,float), post_comp(G,H,I).

onestep(float_plus(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(float_plus(G,H),I).

onestep(float_plus(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(float_plus(G,H),I).

onestep(float_plus(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(float_plus(J,K),L).

sigdec(float_plus,computes(float),[computes(float),computes(float)]).

sigdec(float_plus,depends(A,float),[depends(A,float),depends(A,float)]).

sigdec(float_minus,float,[float,float]).

onestep(float_minus(A,B),I,float,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,float), mid_comp(G,H), rewrites(E,F), inhabit(F,H,float), post_comp(G,H,I).

onestep(float_minus(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(float_minus(G,H),I).

onestep(float_minus(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(float_minus(G,H),I).

onestep(float_minus(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(float_minus(J,K),L).

sigdec(float_minus,computes(float),[computes(float),computes(float)]).

sigdec(float_minus,depends(A,float),[depends(A,float),depends(A,float)]).

sigdec(float_times,float,[float,float]).

onestep(float_times(A,B),I,float,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,float), mid_comp(G,H), rewrites(E,F), inhabit(F,H,float), post_comp(G,H,I).

onestep(float_times(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(float_times(G,H),I).

onestep(float_times(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(float_times(G,H),I).

onestep(float_times(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(float_times(J,K),L).

sigdec(float_times,computes(float),[computes(float),computes(float)]).

sigdec(float_times,depends(A,float),[depends(A,float),depends(A,float)]).

sigdec(float_divide,float,[float,float]).

onestep(float_divide(A,B),I,float,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,float), mid_comp(G,H), rewrites(E,F), inhabit(F,H,float), post_comp(G,H,I).

onestep(float_divide(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(float_divide(G,H),I).

onestep(float_divide(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(float_divide(G,H),I).

onestep(float_divide(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(float_divide(J,K),L).

sigdec(float_divide,computes(float),[computes(float),computes(float)]).

sigdec(float_divide,depends(A,float),[depends(A,float),depends(A,float)]).

sigdec(float_exp,float,[float,float]).

onestep(float_exp(A,B),I,float,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,float), mid_comp(G,H), rewrites(E,F), inhabit(F,H,float), post_comp(G,H,I).

onestep(float_exp(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(float_exp(G,H),I).

onestep(float_exp(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(float_exp(G,H),I).

onestep(float_exp(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(float_exp(J,K),L).

sigdec(float_exp,computes(float),[computes(float),computes(float)]).

sigdec(float_exp,depends(A,float),[depends(A,float),depends(A,float)]).

sigdec(float_pi,float,[]).

onestep(float_pi,A,float,inhabit) :- unobs(A).

onestep(float_pi,A,B,resolve) :- unobs(A), rewrites(float_pi,B).

sigdec(float_sin,float,[float]).

onestep(float_sin(A),D,float,inhabit) :- rewrites(A,B), rewrites(B,C), inhabit(C,D,float).

onestep(float_sin(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(float_sin(E),F).

onestep(float_sin(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(float_sin(E),F).

sigdec(float_sin,computes(float),[computes(float)]).

sigdec(float_sin,depends(A,float),[depends(A,float)]).

sigdec(float_to_int,int,[float]).

onestep(float_to_int(A),D,int,inhabit) :- rewrites(A,B), rewrites(B,C), inhabit(C,D,float).

onestep(float_to_int(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(float_to_int(E),F).

onestep(float_to_int(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(float_to_int(E),F).

sigdec(float_to_int,computes(int),[computes(float)]).

sigdec(float_to_int,depends(A,int),[depends(A,float)]).

sigdec(int_to_float,float,[int]).

onestep(int_to_float(A),D,float,inhabit) :- rewrites(A,B), rewrites(B,C), inhabit(C,D,int).

onestep(int_to_float(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(int_to_float(E),F).

onestep(int_to_float(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(int_to_float(E),F).

sigdec(int_to_float,computes(float),[computes(int)]).

sigdec(int_to_float,depends(A,float),[depends(A,int)]).

sigdec(tuple_empty,tuple,[]).

onestep(tuple_empty,A,tuple,inhabit) :- unobs(A).

onestep(tuple_empty,A,B,resolve) :- unobs(A), rewrites(tuple_empty,B).

valcons(tuple_empty).

sigdec(tuple_prefix,tuple,[value,tuple]).

onestep(tuple_prefix(A,B),K,tuple(E,H),inhabit) :- rewrites(A,C), rewrites(B,F), pre_comp(K,I), rewrites(C,D), inhabit(D,I,E), mid_comp(I,J), rewrites(F,G), inhabit(G,J,H), post_comp(I,J,K).

onestep(tuple_prefix(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(tuple_prefix(G,H),I).

onestep(tuple_prefix(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(tuple_prefix(G,H),I).

onestep(tuple_prefix(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(tuple_prefix(J,K),L).

sigdec(tuple_prefix,computes(tuple),[computes(value),computes(tuple)]).

sigdec(tuple_prefix,depends(A,tuple),[depends(A,value),depends(A,tuple)]).

valcons(tuple_prefix).

sigdec(tuple,type,[]).

onestep(tuple,A,B,resolve) :- unobs(A), rewrites(tuple,B).

valsort(tuple).

sigdec(unit,tuple,[]).

onestep(unit,A,tuple,inhabit) :- unobs(A).

onestep(unit,A,B,resolve) :- unobs(A), rewrites(unit,B).

sigdec(tuple2,tuple,[value,value]).

onestep(tuple2(A,B),I,tuple,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,value), mid_comp(G,H), rewrites(E,F), inhabit(F,H,value), post_comp(G,H,I).

onestep(tuple2(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(tuple2(G,H),I).

onestep(tuple2(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(tuple2(G,H),I).

onestep(tuple2(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(tuple2(J,K),L).

sigdec(tuple2,computes(tuple),[computes(value),computes(value)]).

sigdec(tuple2,depends(A,tuple),[depends(A,value),depends(A,value)]).

rewrite(unit,A) :- rewrites(tuple_empty,A).

rewrite(tuple2(A,B),M) :- rewrites(A,C), rewrites(B,E), rewrites(C,D), runcheck(D,value), checktag(D,value,G), rewrites(E,F), runcheck(F,value), checktag(F,value,H), rewrites(G,K), rewrites(H,I), rewrites(tuple_empty,J), rewrites(tuple_prefix(I,J),L), rewrites(tuple_prefix(K,L),M).

sigdec(project,value,[int,tuple]).

onestep(project(A,B),I,value,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,int), mid_comp(G,H), rewrites(E,F), inhabit(F,H,tuple), post_comp(G,H,I).

onestep(project(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(project(G,H),I).

onestep(project(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(project(G,H),I).

onestep(project(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(project(J,K),L).

sigdec(project,computes(value),[computes(int),computes(tuple)]).

sigdec(project,depends(A,value),[depends(A,int),depends(A,tuple)]).

rewrite(project(A,B),H) :- rewrites(A,q(1)), rewrites(B,tuple_prefix(C,D)), rewrites(C,E), rewrites(D,_), rewrites(E,F), runcheck(F,value), checktag(F,value,G), rewrites(G,H).

rewrite(project(A,B),Q) :- rewrites(A,I), rewrites(B,tuple_prefix(C,D)), rewrites(C,E), rewrites(D,G), rewrites(int_greater(I,q(1)),true), rewrites(E,F), runcheck(F,value), checktag(F,value,_), rewrites(G,H), runcheck(H,tuple), checktag(H,tuple,N), rewrites(I,J), runcheck(J,int), checktag(J,int,K), rewrites(K,L), rewrites(q(1),M), rewrites(int_minus(L,M),O), rewrites(N,P), rewrites(project(O,P),Q).

sigdec(project1,value,[tuple]).

onestep(project1(A),D,value,inhabit) :- rewrites(A,B), rewrites(B,C), inhabit(C,D,tuple).

onestep(project1(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(project1(E),F).

onestep(project1(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(project1(E),F).

sigdec(project1,computes(value),[computes(tuple)]).

sigdec(project1,depends(A,value),[depends(A,tuple)]).

sigdec(project2,value,[tuple]).

onestep(project2(A),D,value,inhabit) :- rewrites(A,B), rewrites(B,C), inhabit(C,D,tuple).

onestep(project2(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(project2(E),F).

onestep(project2(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(project2(E),F).

sigdec(project2,computes(value),[computes(tuple)]).

sigdec(project2,depends(A,value),[depends(A,tuple)]).

rewrite(project1(A),G) :- rewrites(A,B), rewrites(B,C), runcheck(C,tuple), checktag(C,tuple,D), rewrites(q(1),E), rewrites(D,F), rewrites(project(E,F),G).

rewrite(project2(A),G) :- rewrites(A,B), rewrites(B,C), runcheck(C,tuple), checktag(C,tuple,D), rewrites(q(2),E), rewrites(D,F), rewrites(project(E,F),G).

sigdec(equal,boolean,[A,A]) :- valsort(A).

onestep(equal(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(equal(G,H),I).

onestep(equal(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(equal(G,H),I).

onestep(equal(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(equal(J,K),L).

sigdec(equal,computes(boolean),[A,A]).

rewrite(equal(A,B),F) :- rewrites(A,D), rewrites(B,D), rewrites(D,C), runcheck(C,ground), checktag(C,ground,_), rewrites(D,E), runcheck(E,val), checktag(E,val,_), rewrites(true,F).

rewrite(equal(A,B),I) :- rewrites(A,E), rewrites(B,G), rewrites(E,C), runcheck(C,ground), checktag(C,ground,_), rewrites(G,D), runcheck(D,ground), checktag(D,ground,_), \+rewrites(E,G), rewrites(E,F), runcheck(F,val), checktag(F,val,_), rewrites(G,H), runcheck(H,val), checktag(H,val,_), rewrites(false,I).

sigdec(less,boolean,[A,A]) :- valsort(A).

onestep(less(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(less(G,H),I).

onestep(less(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(less(G,H),I).

onestep(less(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(less(J,K),L).

sigdec(less,computes(boolean),[A,A]).

rewrite(less(A,B),I) :- rewrites(A,E), rewrites(B,G), rewrites(E,C), runcheck(C,ground), checktag(C,ground,_), rewrites(G,D), runcheck(D,ground), checktag(D,ground,_), lessthan(E,G), rewrites(E,F), runcheck(F,val), checktag(F,val,_), rewrites(G,H), runcheck(H,val), checktag(H,val,_), rewrites(true,I).

rewrite(less(A,B),I) :- rewrites(A,E), rewrites(B,G), rewrites(E,C), runcheck(C,ground), checktag(C,ground,_), rewrites(G,D), runcheck(D,ground), checktag(D,ground,_), \+lessthan(E,G), rewrites(E,F), runcheck(F,val), checktag(F,val,_), rewrites(G,H), runcheck(H,val), checktag(H,val,_), rewrites(false,I).

sigdec(greater,boolean,[A,A]) :- valsort(A).

onestep(greater(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(greater(G,H),I).

onestep(greater(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(greater(G,H),I).

onestep(greater(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(greater(J,K),L).

sigdec(greater,computes(boolean),[A,A]).

rewrite(greater(A,B),I) :- rewrites(A,G), rewrites(B,E), rewrites(G,C), runcheck(C,ground), checktag(C,ground,_), rewrites(E,D), runcheck(D,ground), checktag(D,ground,_), lessthan(E,G), rewrites(E,F), runcheck(F,val), checktag(F,val,_), rewrites(G,H), runcheck(H,val), checktag(H,val,_), rewrites(true,I).

rewrite(greater(A,B),I) :- rewrites(A,G), rewrites(B,E), rewrites(G,C), runcheck(C,ground), checktag(C,ground,_), rewrites(E,D), runcheck(D,ground), checktag(D,ground,_), \+lessthan(E,G), rewrites(E,F), runcheck(F,val), checktag(F,val,_), rewrites(G,H), runcheck(H,val), checktag(H,val,_), rewrites(false,I).

sigdec(less_equal,boolean,[A,A]) :- valsort(A).

onestep(less_equal(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(less_equal(G,H),I).

onestep(less_equal(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(less_equal(G,H),I).

onestep(less_equal(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(less_equal(J,K),L).

sigdec(less_equal,computes(boolean),[A,A]).

sigdec(greater_equal,boolean,[A,A]) :- valsort(A).

onestep(greater_equal(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(greater_equal(G,H),I).

onestep(greater_equal(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(greater_equal(G,H),I).

onestep(greater_equal(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(greater_equal(J,K),L).

sigdec(greater_equal,computes(boolean),[A,A]).

rewrite(less_equal(A,B),O) :- rewrites(A,C), rewrites(B,E), rewrites(C,D), runcheck(D,val), checktag(D,val,I), rewrites(E,F), runcheck(F,val), checktag(F,val,J), rewrites(I,G), rewrites(J,H), rewrites(less(G,H),M), rewrites(I,K), rewrites(J,L), rewrites(equal(K,L),N), rewrites(or(M,N),O).

rewrite(greater_equal(A,B),O) :- rewrites(A,C), rewrites(B,E), rewrites(C,D), runcheck(D,val), checktag(D,val,I), rewrites(E,F), runcheck(F,val), checktag(F,val,J), rewrites(I,G), rewrites(J,H), rewrites(greater(G,H),M), rewrites(I,K), rewrites(J,L), rewrites(equal(K,L),N), rewrites(or(M,N),O).

sigdec(skip,skip,[]).

onestep(skip,A,skip,inhabit) :- unobs(A).

onestep(skip,A,B,resolve) :- unobs(A), rewrites(skip,B).

valcons(skip).

sigdec(skip,type,[]).

onestep(skip,A,type,inhabit) :- unobs(A).

onestep(skip,A,B,resolve) :- unobs(A), rewrites(skip,B).

valsort(skip).

sigdec(variant,variant,[atom,value]).

onestep(variant(A,B),K,variant(E,H),inhabit) :- rewrites(A,C), rewrites(B,F), pre_comp(K,I), rewrites(C,D), inhabit(D,I,E), mid_comp(I,J), rewrites(F,G), inhabit(G,J,H), post_comp(I,J,K).

onestep(variant(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(variant(G,H),I).

onestep(variant(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(variant(G,H),I).

onestep(variant(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(variant(J,K),L).

sigdec(variant,computes(variant),[computes(atom),computes(value)]).

sigdec(variant,depends(A,variant),[depends(A,atom),depends(A,value)]).

valcons(variant).

sigdec(variant,type,[]).

onestep(variant,A,type,inhabit) :- unobs(A).

onestep(variant,A,B,resolve) :- unobs(A), rewrites(variant,B).

valsort(variant).

sigdec(null,null,[]).

onestep(null,A,null,inhabit) :- unobs(A).

onestep(null,A,B,resolve) :- unobs(A), rewrites(null,B).

valcons(null).

sigdec(null,type,[]).

onestep(null,A,type,inhabit) :- unobs(A).

onestep(null,A,B,resolve) :- unobs(A), rewrites(null,B).

valsort(null).

sigdec(function,function,[abs]).

onestep(function(A),D,function(E),inhabit) :- rewrites(A,B), rewrites(B,C), inhabit(C,D,E).

onestep(function(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(function(E),F).

valcons(function).

sigdec(function,type,[]).

onestep(function,A,type,inhabit) :- unobs(A).

onestep(function,A,B,resolve) :- unobs(A), rewrites(function,B).

valsort(function).

sigdec(atom,type,[]).

onestep(atom,A,B,resolve) :- unobs(A), rewrites(atom,B).

valsort(atom).

sigdec(character,type,[]).

onestep(character,A,B,resolve) :- unobs(A), rewrites(character,B).

valsort(character).

sigdec(fwd,fwd,[int]).

onestep(fwd(A),D,fwd(E),inhabit) :- rewrites(A,B), rewrites(B,C), inhabit(C,D,E).

onestep(fwd(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(fwd(E),F).

onestep(fwd(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(fwd(E),F).

sigdec(fwd,computes(fwd),[computes(int)]).

sigdec(fwd,depends(A,fwd),[depends(A,int)]).

valcons(fwd).

sigdec(fwd,type,[]).

onestep(fwd,A,type,inhabit) :- unobs(A).

onestep(fwd,A,B,resolve) :- unobs(A), rewrites(fwd,B).

valsort(fwd).

sigdec(fwd_next,fwd,[fwd]).

onestep(fwd_next(A),D,fwd,inhabit) :- rewrites(A,B), rewrites(B,C), inhabit(C,D,fwd).

onestep(fwd_next(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(fwd_next(E),F).

onestep(fwd_next(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(fwd_next(E),F).

sigdec(fwd_next,computes(fwd),[computes(fwd)]).

sigdec(fwd_next,depends(A,fwd),[depends(A,fwd)]).

rewrite(fwd_next(A),I) :- rewrites(A,fwd(B)), rewrites(B,C), rewrites(C,D), runcheck(D,int), checktag(D,int,E), rewrites(E,F), rewrites(q(1),G), rewrites(int_plus(F,G),H), rewrites(fwd(H),I).

sigdec(fwd_first,fwd,[]).

onestep(fwd_first,A,fwd,inhabit) :- unobs(A).

onestep(fwd_first,A,B,resolve) :- unobs(A), rewrites(fwd_first,B).

rewrite(fwd_first,B) :- rewrites(q(0),A), rewrites(fwd(A),B).

rewrite(fwd1,B) :- rewrites(q(1),A), rewrites(fwd(A),B).

rewrite(fwd2,B) :- rewrites(q(2),A), rewrites(fwd(A),B).

rewrite(fwd3,B) :- rewrites(q(3),A), rewrites(fwd(A),B).

sigdec(true,boolean,[]).

onestep(true,A,boolean,inhabit) :- unobs(A).

onestep(true,A,B,resolve) :- unobs(A), rewrites(true,B).

valcons(true).

sigdec(false,boolean,[]).

onestep(false,A,boolean,inhabit) :- unobs(A).

onestep(false,A,B,resolve) :- unobs(A), rewrites(false,B).

valcons(false).

sigdec(boolean,type,[]).

onestep(boolean,A,B,resolve) :- unobs(A), rewrites(boolean,B).

valsort(boolean).

sigdec(not,boolean,[boolean]).

onestep(not(A),D,boolean,inhabit) :- rewrites(A,B), rewrites(B,C), inhabit(C,D,boolean).

onestep(not(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(not(E),F).

onestep(not(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(not(E),F).

sigdec(not,computes(boolean),[computes(boolean)]).

sigdec(not,depends(A,boolean),[depends(A,boolean)]).

rewrite(not(A),B) :- rewrites(A,false), rewrites(true,B).

rewrite(not(A),B) :- rewrites(A,true), rewrites(false,B).

sigdec(and,boolean,[boolean,boolean]).

onestep(and(A,B),I,boolean,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,boolean), mid_comp(G,H), rewrites(E,F), inhabit(F,H,boolean), post_comp(G,H,I).

onestep(and(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(and(G,H),I).

onestep(and(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(and(G,H),I).

onestep(and(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(and(J,K),L).

sigdec(and,computes(boolean),[computes(boolean),computes(boolean)]).

sigdec(and,depends(A,boolean),[depends(A,boolean),depends(A,boolean)]).

rewrite(and(A,B),C) :- rewrites(A,true), rewrites(B,true), rewrites(true,C).

rewrite(and(A,B),C) :- rewrites(A,true), rewrites(B,false), rewrites(false,C).

rewrite(and(A,B),C) :- rewrites(A,false), rewrites(B,true), rewrites(false,C).

rewrite(and(A,B),C) :- rewrites(A,false), rewrites(B,false), rewrites(false,C).

sigdec(or,boolean,[boolean,boolean]).

onestep(or(A,B),I,boolean,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,boolean), mid_comp(G,H), rewrites(E,F), inhabit(F,H,boolean), post_comp(G,H,I).

onestep(or(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(or(G,H),I).

onestep(or(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(or(G,H),I).

onestep(or(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(or(J,K),L).

sigdec(or,computes(boolean),[computes(boolean),computes(boolean)]).

sigdec(or,depends(A,boolean),[depends(A,boolean),depends(A,boolean)]).

rewrite(or(A,B),C) :- rewrites(A,true), rewrites(B,true), rewrites(true,C).

rewrite(or(A,B),C) :- rewrites(A,true), rewrites(B,false), rewrites(true,C).

rewrite(or(A,B),C) :- rewrites(A,false), rewrites(B,false), rewrites(false,C).

rewrite(or(A,B),C) :- rewrites(A,false), rewrites(B,true), rewrites(true,C).

sigdec(array_empty,array,[]).

onestep(array_empty,A,array,inhabit) :- unobs(A).

onestep(array_empty,A,B,resolve) :- unobs(A), rewrites(array_empty,B).

valcons(array_empty).

sigdec(array_prefix,array,[variable,array]).

onestep(array_prefix(A,B),K,array(E,H),inhabit) :- rewrites(A,C), rewrites(B,F), pre_comp(K,I), rewrites(C,D), inhabit(D,I,E), mid_comp(I,J), rewrites(F,G), inhabit(G,J,H), post_comp(I,J,K).

onestep(array_prefix(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(array_prefix(G,H),I).

onestep(array_prefix(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(array_prefix(G,H),I).

onestep(array_prefix(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(array_prefix(J,K),L).

sigdec(array_prefix,computes(array),[computes(variable),computes(array)]).

sigdec(array_prefix,depends(A,array),[depends(A,variable),depends(A,array)]).

valcons(array_prefix).

sigdec(array,type,[]).

onestep(array,A,B,resolve) :- unobs(A), rewrites(array,B).

valsort(array).

sigdec(array1,computes(array),[variable]).

onestep(array1(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(array1(E),F).

onestep(array1(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(array1(E),F).

sigdec(array1,computes(array),[computes(variable)]).

sigdec(array1,depends(A,array),[depends(A,variable)]).

sigdec(array_append,array,[array,array]).

onestep(array_append(A,B),I,array,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,array), mid_comp(G,H), rewrites(E,F), inhabit(F,H,array), post_comp(G,H,I).

onestep(array_append(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(array_append(G,H),I).

onestep(array_append(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(array_append(G,H),I).

onestep(array_append(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(array_append(J,K),L).

sigdec(array_append,computes(array),[computes(array),computes(array)]).

sigdec(array_append,depends(A,array),[depends(A,array),depends(A,array)]).

rewrite(array1(A),E) :- rewrites(A,B), rewrites(B,C), rewrites(array_empty,D), rewrites(array_prefix(C,D),E).

rewrite(array_append(A,B),F) :- rewrites(A,array_empty), rewrites(B,C), rewrites(C,D), runcheck(D,array), checktag(D,array,E), rewrites(E,F).

rewrite(array_append(A,D),R) :- rewrites(A,array_prefix(B,C)), rewrites(B,E), rewrites(C,G), rewrites(D,I), rewrites(E,F), runcheck(F,variable), checktag(F,variable,K), rewrites(G,H), runcheck(H,array), checktag(H,array,L), rewrites(I,J), runcheck(J,array), checktag(J,array,M), rewrites(K,P), rewrites(L,N), rewrites(M,O), rewrites(array_append(N,O),Q), rewrites(array_prefix(P,Q),R).

sigdec(array_select,variable,[array,int]).

onestep(array_select(A,B),I,variable,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,array), mid_comp(G,H), rewrites(E,F), inhabit(F,H,int), post_comp(G,H,I).

onestep(array_select(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(array_select(G,H),I).

onestep(array_select(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(array_select(G,H),I).

onestep(array_select(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(array_select(J,K),L).

sigdec(array_select,computes(variable),[computes(array),computes(int)]).

sigdec(array_select,depends(A,variable),[depends(A,array),depends(A,int)]).

rewrite(array_select(A,D),J) :- rewrites(A,array_prefix(B,C)), rewrites(B,G), rewrites(C,E), rewrites(D,q(0)), rewrites(E,F), runcheck(F,array), checktag(F,array,_), rewrites(G,H), runcheck(H,variable), checktag(H,variable,I), rewrites(I,J).

rewrite(array_select(A,D),Q) :- rewrites(A,array_prefix(B,C)), rewrites(B,E), rewrites(C,G), rewrites(D,I), rewrites(int_greater(I,q(0)),true), rewrites(int_minus(I,q(1)),K), rewrites(E,F), runcheck(F,variable), checktag(F,variable,_), rewrites(G,H), runcheck(H,array), checktag(H,array,M), rewrites(I,J), runcheck(J,int), checktag(J,int,_), rewrites(K,L), runcheck(L,int), checktag(L,int,N), rewrites(M,O), rewrites(N,P), rewrites(array_select(O,P),Q).

sigdec(array_create,array(A),[int,A]).

onestep(array_create(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(array_create(G,H),I).

onestep(array_create(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(array_create(J,K),L).

sigdec(array_create,array(A),[computes(int),A]).

rewrite(array_create(A,B),F) :- rewrites(A,q(1)), rewrites(B,C), rewrites(C,D), rewrites(alloc(D),E), rewrites(array1(E),F).

rewrite(array_create(A,B),N) :- rewrites(A,C), rewrites(B,I), rewrites(int_greater(C,q(1)),true), rewrites(C,D), runcheck(D,int), checktag(D,int,F), rewrites(I,E), rewrites(alloc(E),L), rewrites(F,G), rewrites(q(1),H), rewrites(int_minus(G,H),J), rewrites(I,K), rewrites(array_create(J,K),M), rewrites(array_prefix(L,M),N).

sigdec(array_length,int,[array]).

onestep(array_length(A),D,int,inhabit) :- rewrites(A,B), rewrites(B,C), inhabit(C,D,array).

onestep(array_length(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(array_length(E),F).

onestep(array_length(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(array_length(E),F).

sigdec(array_length,computes(int),[computes(array)]).

sigdec(array_length,depends(A,int),[depends(A,array)]).

rewrite(array_length(A),q(0)) :- rewrites(A,array_empty).

rewrite(array_length(A),J) :- rewrites(A,array_prefix(B,C)), rewrites(B,_), rewrites(C,D), rewrites(D,E), runcheck(E,array), checktag(E,array,F), rewrites(F,G), rewrites(array_length(G),H), rewrites(q(1),I), rewrites(int_plus(H,I),J).

sigdec(id,id,[atom]).

onestep(id(A),D,id(E),inhabit) :- rewrites(A,B), rewrites(B,C), inhabit(C,D,E).

onestep(id(A),C,F,run) :- rewrites(A,B), runstep(B,C,D) -> rewrites(D,E), rewrites(id(E),F).

onestep(id(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(id(E),F).

sigdec(id,computes(id),[computes(atom)]).

sigdec(id,depends(A,id),[depends(A,atom)]).

valcons(id).

sigdec(id,type,[]).

onestep(id,A,type,inhabit) :- unobs(A).

onestep(id,A,B,resolve) :- unobs(A), rewrites(id,B).

valsort(id).

sigdec(none,option(_),[]).

onestep(none,A,B,resolve) :- unobs(A), rewrites(none,B).

valcons(none).

sigdec(some,option(A),[A]).

onestep(some(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(some(E),F).

valcons(some).

sigdec(option(_),type,[]).

onestep(option(A),B,E,resolve) :- rewrites(A,C), unobs(B), rewrites(C,D), rewrites(option(D),E).

valsort(option(_)).

subsort(boolean,value).

subsort(int,value).

subsort(float,value).

subsort(string,value).

subsort(constructed,value).

subsort(record,value).

subsort(function,value).

subsort(variable,value).

subsort(skip,value).

sigdec(passable,type,[]).

onestep(passable,A,B,resolve) :- unobs(A), rewrites(passable,B).

typedef(passable,value).

sigdec(throwable,type,[]).

onestep(throwable,A,B,resolve) :- unobs(A), rewrites(throwable,B).

typedef(throwable,value).

sigdec(bindable,type,[]).

onestep(bindable,A,B,resolve) :- unobs(A), rewrites(bindable,B).

typedef(bindable,value).

sigdec(storable,type,[]).

onestep(storable,A,B,resolve) :- unobs(A), rewrites(storable,B).

typedef(storable,value).

subsort(array,value).

subsort(list(value),value).

subsort(variant,value).

subsort(atom,value).

subsort(tuple,value).

subsort(char,value).

sigdec(cl_append,value,[]).

onestep(cl_append,A,value,inhabit) :- unobs(A).

onestep(cl_append,A,B,resolve) :- unobs(A), rewrites(cl_append,B).

rewrite(cl_append,ZZZB) :- rewrites(function,ZZQ), rewrites(q(xs),A), rewrites(id(A),B), rewrites(bind(B),ZZI), rewrites(function,ZZG), rewrites(q(ys),C), rewrites(id(C),D), rewrites(bind(D),ZZ), rewrites(q([]),E), rewrites(only(E),H), rewrites(q(ys),F), rewrites(id(F),G), rewrites(bound_value(G),I), rewrites(abs(H,I),ZO), rewrites(variant,R), rewrites(q(::),J), rewrites(only(J),S), rewrites(tuple2,O), rewrites(q(x),K), rewrites(id(K),L), rewrites(bind(L),P), rewrites(q(xs),M), rewrites(id(M),N), rewrites(bind(N),Q), rewrites(invert_1(O,P,Q),T), rewrites(invert_1(R,S,T),ZM), rewrites(q(::),ZK), rewrites(q(x),U), rewrites(id(U),V), rewrites(bound_value(V),ZI), rewrites(function,ZF), rewrites(function,ZA), rewrites(q(append),W), rewrites(id(W),X), rewrites(bound_value(X),ZB), rewrites(q(xs),Y), rewrites(id(Y),Z), rewrites(bound_value(Z),ZC), rewrites(apply_1(ZA,ZB,ZC),ZG), rewrites(q(ys),ZD), rewrites(id(ZD),ZE), rewrites(bound_value(ZE),ZH), rewrites(apply_1(ZF,ZG,ZH),ZJ), rewrites(tuple2(ZI,ZJ),ZL), rewrites(variant(ZK,ZL),ZN), rewrites(abs(ZM,ZN),ZP), rewrites(prefer_over(ZO,ZP),ZT), rewrites(any,ZR), rewrites(q('Match_failure'),ZQ), rewrites(throw(ZQ),ZS), rewrites(abs(ZR,ZS),ZU), rewrites(prefer_over(ZT,ZU),ZX), rewrites(q(xs),ZV), rewrites(id(ZV),ZW), rewrites(bound_value(ZW),ZY), rewrites(apply(ZX,ZY),ZZA), rewrites(abs(ZZ,ZZA),ZZE), rewrites(any,ZZC), rewrites(q('Match_failure'),ZZB), rewrites(throw(ZZB),ZZD), rewrites(abs(ZZC,ZZD),ZZF), rewrites(prefer_over(ZZE,ZZF),ZZH), rewrites(close_1(ZZG,ZZH),ZZJ), rewrites(abs(ZZI,ZZJ),ZZO), rewrites(any,ZZM), rewrites(q('Match_failure'),ZZL), rewrites(throw(ZZL),ZZN), rewrites(abs(ZZM,ZZN),ZZP), rewrites(prefer_over(ZZO,ZZP),ZZR), rewrites(close_1(ZZQ,ZZR),ZZU), rewrites(q(append),ZZS), rewrites(id(ZZS),ZZT), rewrites(bind(ZZT),ZZV), rewrites(match(ZZU,ZZV),ZZW), rewrites(recursive(ZZW),ZZZ), rewrites(q(append),ZZX), rewrites(id(ZZX),ZZY), rewrites(bound_value(ZZY),ZZZA), rewrites(scope(ZZZ,ZZZA),ZZZB).

sigdec(caml_light_library,env,[]).

onestep(caml_light_library,A,env,inhabit) :- unobs(A).

onestep(caml_light_library,A,B,resolve) :- unobs(A), rewrites(caml_light_library,B).

onestep(caml_light_library,A,ZZZZZZZZZZZZZF,run) :- unobs(A), rewrites(map_empty,D), rewrites(q(min),B), rewrites(id(B),E), rewrites(int_min,C), rewrites(binary_function_1(C),F), rewrites(map_update(D,E,F),I), rewrites(q(array_create),G), rewrites(id(G),J), rewrites(array_create,H), rewrites(binary_function_1(H),K), rewrites(map_update(I,J,K),O), rewrites(q(array_length),L), rewrites(id(L),P), rewrites(array_length,M), rewrites(abs_1(M),N), rewrites(function(N),Q), rewrites(map_update(O,P,Q),ZZE), rewrites(q(vect_assign),R), rewrites(id(R),ZZF), rewrites(q(x),S), rewrites(id(S),T), rewrites(bind(T),ZZB), rewrites(function,ZZ), rewrites(q(y),U), rewrites(id(U),V), rewrites(bind(V),ZX), rewrites(function,ZV), rewrites(q(z),W), rewrites(id(W),X), rewrites(bind(X),ZT), rewrites(q(y),Y), rewrites(id(Y),Z), rewrites(bound_value(Z),ZD), rewrites(q(x),ZA), rewrites(id(ZA),ZB), rewrites(bound_value(ZB),ZC), rewrites(array_length(ZC),ZE), rewrites(int_less(ZD,ZE),ZQ), rewrites(q(x),ZF), rewrites(id(ZF),ZG), rewrites(bound_value(ZG),ZJ), rewrites(q(y),ZH), rewrites(id(ZH),ZI), rewrites(bound_value(ZI),ZK), rewrites(array_select(ZJ,ZK),ZN), rewrites(q(z),ZL), rewrites(id(ZL),ZM), rewrites(bound_value(ZM),ZO), rewrites(assign(ZN,ZO),ZR), rewrites(q('Invalid_argument'),ZP), rewrites(throw(ZP),ZS), rewrites(if_true(ZQ,ZR,ZS),ZU), rewrites(abs(ZT,ZU),ZW), rewrites(close_1(ZV,ZW),ZY), rewrites(abs(ZX,ZY),ZZA), rewrites(close_1(ZZ,ZZA),ZZC), rewrites(abs(ZZB,ZZC),ZZD), rewrites(function(ZZD),ZZG), rewrites(map_update(ZZE,ZZF,ZZG),ZZZL), rewrites(q(vect_item),ZZH), rewrites(id(ZZH),ZZZM), rewrites(q(x),ZZI), rewrites(id(ZZI),ZZJ), rewrites(bind(ZZJ),ZZZI), rewrites(function,ZZZG), rewrites(q(y),ZZK), rewrites(id(ZZK),ZZL), rewrites(bind(ZZL),ZZZE), rewrites(q(y),ZZM), rewrites(id(ZZM),ZZN), rewrites(bound_value(ZZN),ZZR), rewrites(q(x),ZZO), rewrites(id(ZZO),ZZP), rewrites(bound_value(ZZP),ZZQ), rewrites(array_length(ZZQ),ZZS), rewrites(int_less(ZZR,ZZS),ZZZB), rewrites(q(x),ZZT), rewrites(id(ZZT),ZZU), rewrites(bound_value(ZZU),ZZX), rewrites(q(y),ZZV), rewrites(id(ZZV),ZZW), rewrites(bound_value(ZZW),ZZY), rewrites(array_select(ZZX,ZZY),ZZZ), rewrites(deref(ZZZ),ZZZC), rewrites(q('Invalid_argument'),ZZZA), rewrites(throw(ZZZA),ZZZD), rewrites(if_true(ZZZB,ZZZC,ZZZD),ZZZF), rewrites(abs(ZZZE,ZZZF),ZZZH), rewrites(close_1(ZZZG,ZZZH),ZZZJ), rewrites(abs(ZZZI,ZZZJ),ZZZK), rewrites(function(ZZZK),ZZZN), rewrites(map_update(ZZZL,ZZZM,ZZZN),ZZZR), rewrites(q(raise),ZZZO), rewrites(id(ZZZO),ZZZS), rewrites(throw,ZZZP), rewrites(abs_1(ZZZP),ZZZQ), rewrites(function(ZZZQ),ZZZT), rewrites(map_update(ZZZR,ZZZS,ZZZT),ZZZX), rewrites(q(print_newline),ZZZU), rewrites(id(ZZZU),ZZZY), rewrites(q('"Newline!"'),ZZZV), rewrites(print(ZZZV),ZZZW), rewrites(function(ZZZW),ZZZZ), rewrites(map_update(ZZZX,ZZZY,ZZZZ),ZZZZD), rewrites(q(print_float),ZZZZA), rewrites(id(ZZZZA),ZZZZE), rewrites(print,ZZZZB), rewrites(abs_1(ZZZZB),ZZZZC), rewrites(function(ZZZZC),ZZZZF), rewrites(map_update(ZZZZD,ZZZZE,ZZZZF),ZZZZJ), rewrites(q(print_string),ZZZZG), rewrites(id(ZZZZG),ZZZZK), rewrites(print,ZZZZH), rewrites(abs_1(ZZZZH),ZZZZI), rewrites(function(ZZZZI),ZZZZL), rewrites(map_update(ZZZZJ,ZZZZK,ZZZZL),ZZZZP), rewrites(q(float),ZZZZM), rewrites(id(ZZZZM),ZZZZQ), rewrites(int_to_float,ZZZZN), rewrites(abs_1(ZZZZN),ZZZZO), rewrites(function(ZZZZO),ZZZZR), rewrites(map_update(ZZZZP,ZZZZQ,ZZZZR),ZZZZT), rewrites(q(pi),ZZZZS), rewrites(id(ZZZZS),ZZZZU), rewrites(float_pi,ZZZZV), rewrites(map_update(ZZZZT,ZZZZU,ZZZZV),ZZZZZ), rewrites(q(sin),ZZZZW), rewrites(id(ZZZZW),ZZZZZA), rewrites(float_sin,ZZZZX), rewrites(abs_1(ZZZZX),ZZZZY), rewrites(function(ZZZZY),ZZZZZB), rewrites(map_update(ZZZZZ,ZZZZZA,ZZZZZB),ZZZZZF), rewrites(q(ref),ZZZZZC), rewrites(id(ZZZZZC),ZZZZZG), rewrites(alloc,ZZZZZD), rewrites(abs_1(ZZZZZD),ZZZZZE), rewrites(function(ZZZZZE),ZZZZZH), rewrites(map_update(ZZZZZF,ZZZZZG,ZZZZZH),ZZZZZK), rewrites(q('prefix >=.'),ZZZZZI), rewrites(id(ZZZZZI),ZZZZZL), rewrites(greater_equal,ZZZZZJ), rewrites(binary_function_1(ZZZZZJ),ZZZZZM), rewrites(map_update(ZZZZZK,ZZZZZL,ZZZZZM),ZZZZZP), rewrites(q('prefix <=.'),ZZZZZN), rewrites(id(ZZZZZN),ZZZZZQ), rewrites(less_equal,ZZZZZO), rewrites(binary_function_1(ZZZZZO),ZZZZZR), rewrites(map_update(ZZZZZP,ZZZZZQ,ZZZZZR),ZZZZZU), rewrites(q('prefix >.'),ZZZZZS), rewrites(id(ZZZZZS),ZZZZZV), rewrites(greater,ZZZZZT), rewrites(binary_function_1(ZZZZZT),ZZZZZW), rewrites(map_update(ZZZZZU,ZZZZZV,ZZZZZW),ZZZZZZ), rewrites(q('prefix <.'),ZZZZZX), rewrites(id(ZZZZZX),ZZZZZZA), rewrites(less,ZZZZZY), rewrites(binary_function_1(ZZZZZY),ZZZZZZB), rewrites(map_update(ZZZZZZ,ZZZZZZA,ZZZZZZB),ZZZZZZE), rewrites(q('prefix >='),ZZZZZZC), rewrites(id(ZZZZZZC),ZZZZZZF), rewrites(greater_equal,ZZZZZZD), rewrites(binary_function_1(ZZZZZZD),ZZZZZZG), rewrites(map_update(ZZZZZZE,ZZZZZZF,ZZZZZZG),ZZZZZZJ), rewrites(q('prefix <='),ZZZZZZH), rewrites(id(ZZZZZZH),ZZZZZZK), rewrites(less_equal,ZZZZZZI), rewrites(binary_function_1(ZZZZZZI),ZZZZZZL), rewrites(map_update(ZZZZZZJ,ZZZZZZK,ZZZZZZL),ZZZZZZO), rewrites(q('prefix >'),ZZZZZZM), rewrites(id(ZZZZZZM),ZZZZZZP), rewrites(greater,ZZZZZZN), rewrites(binary_function_1(ZZZZZZN),ZZZZZZQ), rewrites(map_update(ZZZZZZO,ZZZZZZP,ZZZZZZQ),ZZZZZZT), rewrites(q('prefix <'),ZZZZZZR), rewrites(id(ZZZZZZR),ZZZZZZU), rewrites(less,ZZZZZZS), rewrites(binary_function_1(ZZZZZZS),ZZZZZZV), rewrites(map_update(ZZZZZZT,ZZZZZZU,ZZZZZZV),ZZZZZZZF), rewrites(q('prefix !='),ZZZZZZW), rewrites(id(ZZZZZZW),ZZZZZZZG), rewrites(function,ZZZZZZZC), rewrites(not,ZZZZZZX), rewrites(abs_1(ZZZZZZX),ZZZZZZZA), rewrites(q('prefix =='),ZZZZZZY), rewrites(id(ZZZZZZY),ZZZZZZZ), rewrites(bound_value(ZZZZZZZ),ZZZZZZZB), rewrites(compose(ZZZZZZZA,ZZZZZZZB),ZZZZZZZD), rewrites(curry_abs_1(ZZZZZZZC,ZZZZZZZD),ZZZZZZZE), rewrites(function(ZZZZZZZE),ZZZZZZZH), rewrites(map_update(ZZZZZZZF,ZZZZZZZG,ZZZZZZZH),ZZZZZZZZ), rewrites(q('prefix =='),ZZZZZZZI), rewrites(id(ZZZZZZZI),ZZZZZZZZA), rewrites(function,ZZZZZZZW), rewrites(function,ZZZZZZZK), rewrites(project1,ZZZZZZZJ), rewrites(abs_1(ZZZZZZZJ),ZZZZZZZL), rewrites(occurs_within_1(ZZZZZZZK,ZZZZZZZL),ZZZZZZZP), rewrites(function,ZZZZZZZN), rewrites(project2,ZZZZZZZM), rewrites(abs_1(ZZZZZZZM),ZZZZZZZO), rewrites(occurs_within_1(ZZZZZZZN,ZZZZZZZO),ZZZZZZZQ), rewrites(or(ZZZZZZZP,ZZZZZZZQ),ZZZZZZZT), rewrites(q('Invalid_argument'),ZZZZZZZR), rewrites(throw(ZZZZZZZR),ZZZZZZZU), rewrites(equal,ZZZZZZZS), rewrites(abs_1(ZZZZZZZS),ZZZZZZZV), rewrites(if_true(ZZZZZZZT,ZZZZZZZU,ZZZZZZZV),ZZZZZZZX), rewrites(curry_abs_1(ZZZZZZZW,ZZZZZZZX),ZZZZZZZY), rewrites(function(ZZZZZZZY),ZZZZZZZZB), rewrites(map_update(ZZZZZZZZ,ZZZZZZZZA,ZZZZZZZZB),ZZZZZZZZL), rewrites(q('prefix <>'),ZZZZZZZZC), rewrites(id(ZZZZZZZZC),ZZZZZZZZM), rewrites(function,ZZZZZZZZI), rewrites(not,ZZZZZZZZD), rewrites(abs_1(ZZZZZZZZD),ZZZZZZZZG), rewrites(q('prefix ='),ZZZZZZZZE), rewrites(id(ZZZZZZZZE),ZZZZZZZZF), rewrites(bound_value(ZZZZZZZZF),ZZZZZZZZH), rewrites(compose(ZZZZZZZZG,ZZZZZZZZH),ZZZZZZZZJ), rewrites(curry_abs_1(ZZZZZZZZI,ZZZZZZZZJ),ZZZZZZZZK), rewrites(function(ZZZZZZZZK),ZZZZZZZZN), rewrites(map_update(ZZZZZZZZL,ZZZZZZZZM,ZZZZZZZZN),ZZZZZZZZZG), rewrites(q('prefix ='),ZZZZZZZZO), rewrites(id(ZZZZZZZZO),ZZZZZZZZZH), rewrites(function,ZZZZZZZZZD), rewrites(function,ZZZZZZZZQ), rewrites(project1,ZZZZZZZZP), rewrites(abs_1(ZZZZZZZZP),ZZZZZZZZR), rewrites(occurs_within_1(ZZZZZZZZQ,ZZZZZZZZR),ZZZZZZZZV), rewrites(function,ZZZZZZZZT), rewrites(project2,ZZZZZZZZS), rewrites(abs_1(ZZZZZZZZS),ZZZZZZZZU), rewrites(occurs_within_1(ZZZZZZZZT,ZZZZZZZZU),ZZZZZZZZW), rewrites(or(ZZZZZZZZV,ZZZZZZZZW),ZZZZZZZZZA), rewrites(q('Invalid_argument'),ZZZZZZZZY), rewrites(throw(ZZZZZZZZY),ZZZZZZZZZB), rewrites(struct_eq,ZZZZZZZZZ), rewrites(abs_1(ZZZZZZZZZ),ZZZZZZZZZC), rewrites(if_true(ZZZZZZZZZA,ZZZZZZZZZB,ZZZZZZZZZC),ZZZZZZZZZE), rewrites(curry_abs_1(ZZZZZZZZZD,ZZZZZZZZZE),ZZZZZZZZZF), rewrites(function(ZZZZZZZZZF),ZZZZZZZZZI), rewrites(map_update(ZZZZZZZZZG,ZZZZZZZZZH,ZZZZZZZZZI),ZZZZZZZZZL), rewrites(q('prefix :='),ZZZZZZZZZJ), rewrites(id(ZZZZZZZZZJ),ZZZZZZZZZM), rewrites(assign,ZZZZZZZZZK), rewrites(binary_function_1(ZZZZZZZZZK),ZZZZZZZZZN), rewrites(map_update(ZZZZZZZZZL,ZZZZZZZZZM,ZZZZZZZZZN),ZZZZZZZZZR), rewrites(q('prefix !'),ZZZZZZZZZO), rewrites(id(ZZZZZZZZZO),ZZZZZZZZZS), rewrites(deref,ZZZZZZZZZP), rewrites(abs_1(ZZZZZZZZZP),ZZZZZZZZZQ), rewrites(function(ZZZZZZZZZQ),ZZZZZZZZZT), rewrites(map_update(ZZZZZZZZZR,ZZZZZZZZZS,ZZZZZZZZZT),ZZZZZZZZZW), rewrites(q('prefix ^'),ZZZZZZZZZU), rewrites(id(ZZZZZZZZZU),ZZZZZZZZZX), rewrites(string_append,ZZZZZZZZZV), rewrites(binary_function_1(ZZZZZZZZZV),ZZZZZZZZZY), rewrites(map_update(ZZZZZZZZZW,ZZZZZZZZZX,ZZZZZZZZZY),ZZZZZZZZZZA), rewrites(q('prefix @'),ZZZZZZZZZZ), rewrites(id(ZZZZZZZZZZ),ZZZZZZZZZZB), rewrites(cl_append,ZZZZZZZZZZC), rewrites(map_update(ZZZZZZZZZZA,ZZZZZZZZZZB,ZZZZZZZZZZC),ZZZZZZZZZZF), rewrites(q('prefix **'),ZZZZZZZZZZD), rewrites(id(ZZZZZZZZZZD),ZZZZZZZZZZG), rewrites(float_exp,ZZZZZZZZZZE), rewrites(binary_function_1(ZZZZZZZZZZE),ZZZZZZZZZZH), rewrites(map_update(ZZZZZZZZZZF,ZZZZZZZZZZG,ZZZZZZZZZZH),ZZZZZZZZZZK), rewrites(q('prefix /.'),ZZZZZZZZZZI), rewrites(id(ZZZZZZZZZZI),ZZZZZZZZZZL), rewrites(float_divide,ZZZZZZZZZZJ), rewrites(binary_function_1(ZZZZZZZZZZJ),ZZZZZZZZZZM), rewrites(map_update(ZZZZZZZZZZK,ZZZZZZZZZZL,ZZZZZZZZZZM),ZZZZZZZZZZP), rewrites(q('prefix *.'),ZZZZZZZZZZN), rewrites(id(ZZZZZZZZZZN),ZZZZZZZZZZQ), rewrites(float_times,ZZZZZZZZZZO), rewrites(binary_function_1(ZZZZZZZZZZO),ZZZZZZZZZZR), rewrites(map_update(ZZZZZZZZZZP,ZZZZZZZZZZQ,ZZZZZZZZZZR),ZZZZZZZZZZU), rewrites(q('prefix -.'),ZZZZZZZZZZS), rewrites(id(ZZZZZZZZZZS),ZZZZZZZZZZV), rewrites(float_minus,ZZZZZZZZZZT), rewrites(binary_function_1(ZZZZZZZZZZT),ZZZZZZZZZZW), rewrites(map_update(ZZZZZZZZZZU,ZZZZZZZZZZV,ZZZZZZZZZZW),ZZZZZZZZZZZ), rewrites(q('prefix +.'),ZZZZZZZZZZX), rewrites(id(ZZZZZZZZZZX),ZZZZZZZZZZZA), rewrites(float_plus,ZZZZZZZZZZY), rewrites(binary_function_1(ZZZZZZZZZZY),ZZZZZZZZZZZB), rewrites(map_update(ZZZZZZZZZZZ,ZZZZZZZZZZZA,ZZZZZZZZZZZB),ZZZZZZZZZZZE), rewrites(q('prefix asr'),ZZZZZZZZZZZC), rewrites(id(ZZZZZZZZZZZC),ZZZZZZZZZZZF), rewrites(int_arshift,ZZZZZZZZZZZD), rewrites(binary_function_1(ZZZZZZZZZZZD),ZZZZZZZZZZZG), rewrites(map_update(ZZZZZZZZZZZE,ZZZZZZZZZZZF,ZZZZZZZZZZZG),ZZZZZZZZZZZJ), rewrites(q('prefix lsr'),ZZZZZZZZZZZH), rewrites(id(ZZZZZZZZZZZH),ZZZZZZZZZZZK), rewrites(int_rshift,ZZZZZZZZZZZI), rewrites(binary_function_1(ZZZZZZZZZZZI),ZZZZZZZZZZZL), rewrites(map_update(ZZZZZZZZZZZJ,ZZZZZZZZZZZK,ZZZZZZZZZZZL),ZZZZZZZZZZZO), rewrites(q('prefix lsl'),ZZZZZZZZZZZM), rewrites(id(ZZZZZZZZZZZM),ZZZZZZZZZZZP), rewrites(int_lshift,ZZZZZZZZZZZN), rewrites(binary_function_1(ZZZZZZZZZZZN),ZZZZZZZZZZZQ), rewrites(map_update(ZZZZZZZZZZZO,ZZZZZZZZZZZP,ZZZZZZZZZZZQ),ZZZZZZZZZZZT), rewrites(q('prefix lxor'),ZZZZZZZZZZZR), rewrites(id(ZZZZZZZZZZZR),ZZZZZZZZZZZU), rewrites(int_xor,ZZZZZZZZZZZS), rewrites(binary_function_1(ZZZZZZZZZZZS),ZZZZZZZZZZZV), rewrites(map_update(ZZZZZZZZZZZT,ZZZZZZZZZZZU,ZZZZZZZZZZZV),ZZZZZZZZZZZY), rewrites(q('prefix lor'),ZZZZZZZZZZZW), rewrites(id(ZZZZZZZZZZZW),ZZZZZZZZZZZZ), rewrites(int_or,ZZZZZZZZZZZX), rewrites(binary_function_1(ZZZZZZZZZZZX),ZZZZZZZZZZZZA), rewrites(map_update(ZZZZZZZZZZZY,ZZZZZZZZZZZZ,ZZZZZZZZZZZZA),ZZZZZZZZZZZZD), rewrites(q('prefix land'),ZZZZZZZZZZZZB), rewrites(id(ZZZZZZZZZZZZB),ZZZZZZZZZZZZE), rewrites(int_and,ZZZZZZZZZZZZC), rewrites(binary_function_1(ZZZZZZZZZZZZC),ZZZZZZZZZZZZF), rewrites(map_update(ZZZZZZZZZZZZD,ZZZZZZZZZZZZE,ZZZZZZZZZZZZF),ZZZZZZZZZZZZI), rewrites(q('prefix mod'),ZZZZZZZZZZZZG), rewrites(id(ZZZZZZZZZZZZG),ZZZZZZZZZZZZJ), rewrites(int_modulo,ZZZZZZZZZZZZH), rewrites(binary_function_1(ZZZZZZZZZZZZH),ZZZZZZZZZZZZK), rewrites(map_update(ZZZZZZZZZZZZI,ZZZZZZZZZZZZJ,ZZZZZZZZZZZZK),ZZZZZZZZZZZZN), rewrites(q('prefix /'),ZZZZZZZZZZZZL), rewrites(id(ZZZZZZZZZZZZL),ZZZZZZZZZZZZO), rewrites(int_divide,ZZZZZZZZZZZZM), rewrites(binary_function_1(ZZZZZZZZZZZZM),ZZZZZZZZZZZZP), rewrites(map_update(ZZZZZZZZZZZZN,ZZZZZZZZZZZZO,ZZZZZZZZZZZZP),ZZZZZZZZZZZZS), rewrites(q('prefix *'),ZZZZZZZZZZZZQ), rewrites(id(ZZZZZZZZZZZZQ),ZZZZZZZZZZZZT), rewrites(int_times,ZZZZZZZZZZZZR), rewrites(binary_function_1(ZZZZZZZZZZZZR),ZZZZZZZZZZZZU), rewrites(map_update(ZZZZZZZZZZZZS,ZZZZZZZZZZZZT,ZZZZZZZZZZZZU),ZZZZZZZZZZZZX), rewrites(q('prefix -'),ZZZZZZZZZZZZV), rewrites(id(ZZZZZZZZZZZZV),ZZZZZZZZZZZZY), rewrites(int_minus,ZZZZZZZZZZZZW), rewrites(binary_function_1(ZZZZZZZZZZZZW),ZZZZZZZZZZZZZ), rewrites(map_update(ZZZZZZZZZZZZX,ZZZZZZZZZZZZY,ZZZZZZZZZZZZZ),ZZZZZZZZZZZZZC), rewrites(q('prefix +'),ZZZZZZZZZZZZZA), rewrites(id(ZZZZZZZZZZZZZA),ZZZZZZZZZZZZZD), rewrites(int_plus,ZZZZZZZZZZZZZB), rewrites(binary_function_1(ZZZZZZZZZZZZZB),ZZZZZZZZZZZZZE), rewrites(map_update(ZZZZZZZZZZZZZC,ZZZZZZZZZZZZZD,ZZZZZZZZZZZZZE),ZZZZZZZZZZZZZF).

sigdec(binary_function_1,value,[A]) :- sigdec(A,B,[_,_]), subsort_rt(B,value).

onestep(binary_function_1(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(binary_function_1(E),F).

rewrite(binary_function_1(A),G) :- rewrites(A,B), rewrites(function,D), rewrites(B,C), rewrites(abs_1(C),E), rewrites(curry_abs_1(D,E),F), rewrites(function(F),G).

sigdec(abs_1,abs,[A]) :- sigdec(A,B,[_]), subsort_rt(B,value).

onestep(abs_1(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(abs_1(E),F).

sigdec(abs_1,abs,[A]) :- sigdec(A,B,[_,_]), subsort_rt(B,value).

onestep(abs_1(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(abs_1(E),F).

onestep(abs_1(A),B,C,run) :- rewrites(A,E), sigdec(E,_,[_]), unobs(B), rewrites(given,F), decompose(D,E,[F]), rewrites(D,C), decompose(D,E,[F]).

onestep(abs_1(A),B,E,run) :- rewrites(A,G), sigdec(G,_,[_,_]), unobs(B), rewrites(project1,C), rewrites(abs_1(C),H), rewrites(project2,D), rewrites(abs_1(D),I), decompose(F,G,[H,I]), rewrites(F,E), decompose(F,G,[H,I]).

sigdec(struct_eq,boolean,[val,val]).

onestep(struct_eq(A,B),I,boolean,inhabit) :- rewrites(A,C), rewrites(B,E), pre_comp(I,G), rewrites(C,D), inhabit(D,G,val), mid_comp(G,H), rewrites(E,F), inhabit(F,H,val), post_comp(G,H,I).

onestep(struct_eq(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(struct_eq(G,H),I).

onestep(struct_eq(A,B),D,I,run) :- rewrites(A,C), rewrites(B,F), runstep(C,D,E) -> rewrites(E,G), rewrites(F,H), rewrites(struct_eq(G,H),I).

onestep(struct_eq(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(struct_eq(J,K),L).

sigdec(struct_eq,computes(boolean),[computes(val),computes(val)]).

sigdec(struct_eq,depends(A,boolean),[depends(A,val),depends(A,val)]).

rewrite(struct_eq(A,B),E) :- rewrites(A,C), rewrites(B,C), rewrites(C,D), runcheck(D,constant), checktag(D,constant,_), rewrites(true,E).

rewrite(struct_eq(A,B),G) :- rewrites(A,C), rewrites(B,E), \+rewrites(C,E), rewrites(C,D), runcheck(D,constant), checktag(D,constant,_), rewrites(E,F), runcheck(F,constant), checktag(F,constant,_), rewrites(false,G).

rewrite(struct_eq(A,B),M) :- rewrites(A,C), rewrites(B,E), rewrites(C,D), runcheck(D,variable), checktag(D,variable,G), rewrites(E,F), runcheck(F,variable), checktag(F,variable,I), rewrites(G,H), rewrites(deref(H),K), rewrites(I,J), rewrites(deref(J),L), rewrites(struct_eq(K,L),M).

rewrite(struct_eq(A,D),R) :- decompose(B,L,[C]), rewrites(A,B), decompose(B,L,[C]), rewrites(C,N), decompose(E,L,[F]), rewrites(D,E), decompose(E,L,[F]), rewrites(F,O), decompose(G,L,[N]), rewrites(G,H), decompose(G,L,[N]), runcheck(H,val), checktag(H,val,_), decompose(I,L,[O]), rewrites(I,J), decompose(I,L,[O]), runcheck(J,val), checktag(J,val,_), decompose(K,L,[M]), \+rewrites(K,var(_)), decompose(K,L,[M]), rewrites(N,P), rewrites(O,Q), rewrites(struct_eq(P,Q),R).

rewrite(struct_eq(A,D),M) :- decompose(B,K,[C]), rewrites(A,B), decompose(B,K,[C]), rewrites(C,F), rewrites(D,I), decompose(E,K,[F]), rewrites(E,G), decompose(E,K,[F]), runcheck(G,val), checktag(G,val,_), rewrites(I,H), runcheck(H,val), checktag(H,val,_), decompose(J,K,[L]), \+rewrites(I,J), decompose(J,K,[L]), rewrites(false,M).

rewrite(struct_eq(A,E),X) :- decompose(B,L,[C,D]), rewrites(A,B), decompose(B,L,[C,D]), rewrites(C,N), rewrites(D,R), decompose(F,L,[G,H]), rewrites(E,F), decompose(F,L,[G,H]), rewrites(G,O), rewrites(H,S), decompose(I,L,[N,R]), rewrites(I,J), decompose(I,L,[N,R]), runcheck(J,val), checktag(J,val,_), decompose(K,L,[O,S]), rewrites(K,M), decompose(K,L,[O,S]), runcheck(M,val), checktag(M,val,_), rewrites(N,P), rewrites(O,Q), rewrites(struct_eq(P,Q),V), rewrites(R,T), rewrites(S,U), rewrites(struct_eq(T,U),W), rewrites(and(V,W),X).

rewrite(struct_eq(A,E),P) :- decompose(B,M,[C,D]), rewrites(A,B), decompose(B,M,[C,D]), rewrites(C,G), rewrites(D,H), rewrites(E,K), decompose(F,M,[G,H]), rewrites(F,I), decompose(F,M,[G,H]), runcheck(I,val), checktag(I,val,_), rewrites(K,J), runcheck(J,val), checktag(J,val,_), decompose(L,M,[N,O]), \+rewrites(K,L), decompose(L,M,[N,O]), rewrites(false,P).

rewrite(struct_eq(A,F),ZF) :- decompose(B,N,[C,D,E]), rewrites(A,B), decompose(B,N,[C,D,E]), rewrites(C,P), rewrites(D,T), rewrites(E,Z), decompose(G,N,[H,I,J]), rewrites(F,G), decompose(G,N,[H,I,J]), rewrites(H,Q), rewrites(I,U), rewrites(J,ZA), decompose(K,N,[P,T,Z]), rewrites(K,L), decompose(K,N,[P,T,Z]), runcheck(L,val), checktag(L,val,_), decompose(M,N,[Q,U,ZA]), rewrites(M,O), decompose(M,N,[Q,U,ZA]), runcheck(O,val), checktag(O,val,_), rewrites(P,R), rewrites(Q,S), rewrites(struct_eq(R,S),X), rewrites(T,V), rewrites(U,W), rewrites(struct_eq(V,W),Y), rewrites(and(X,Y),ZD), rewrites(Z,ZB), rewrites(ZA,ZC), rewrites(struct_eq(ZB,ZC),ZE), rewrites(and(ZD,ZE),ZF).

rewrite(struct_eq(A,F),S) :- decompose(B,O,[C,D,E]), rewrites(A,B), decompose(B,O,[C,D,E]), rewrites(C,H), rewrites(D,I), rewrites(E,J), rewrites(F,M), decompose(G,O,[H,I,J]), rewrites(G,K), decompose(G,O,[H,I,J]), runcheck(K,val), checktag(K,val,_), rewrites(M,L), runcheck(L,val), checktag(L,val,_), decompose(N,O,[P,Q,R]), \+rewrites(M,N), decompose(N,O,[P,Q,R]), rewrites(false,S).

sigdec(apply_1,computes(B),[A,E,D]) :- sigdec(A,C,[depends(D,B)]), subsort_rt(C,E), valsort(D), valsort(E).

onestep(apply_1(A,B,C),E,L,run) :- rewrites(A,F), rewrites(B,G), rewrites(C,D), runstep(D,E,H) -> rewrites(F,I), rewrites(G,J), rewrites(H,K), rewrites(apply_1(I,J,K),L).

onestep(apply_1(A,B,C),E,L,run) :- rewrites(A,F), rewrites(B,D), rewrites(C,H), runstep(D,E,G) -> rewrites(F,I), rewrites(G,J), rewrites(H,K), rewrites(apply_1(I,J,K),L).

onestep(apply_1(A,B,C),K,R,resolve) :- rewrites(A,D), rewrites(B,E), rewrites(C,F), pre_comp(K,I), onestep(D,I,L,resolve), mid_comp(I,J), pre_comp(J,G), onestep(E,G,M,resolve), mid_comp(G,H), onestep(F,H,N,resolve), post_comp(G,H,J), post_comp(I,J,K), rewrites(L,O), rewrites(M,P), rewrites(N,Q), rewrites(apply_1(O,P,Q),R).

sigdec(apply_1,computes(C),[A,E,B]) :- sigdec(A,D,[depends(B,C)]), subsort_rt(D,E).

rewrite(apply_1(A,B,F),K) :- rewrites(A,D), decompose(C,D,[E]), rewrites(B,C), decompose(C,D,[E]), rewrites(E,G), rewrites(F,H), rewrites(G,I), rewrites(H,J), rewrites(apply(I,J),K).

sigdec(prefer_over_1,value,[A,value,value]) :- sigdec(A,B,[abs]), subsort_rt(B,value).

onestep(prefer_over_1(A,B,C),E,L,run) :- rewrites(A,F), rewrites(B,G), rewrites(C,D), runstep(D,E,H) -> rewrites(F,I), rewrites(G,J), rewrites(H,K), rewrites(prefer_over_1(I,J,K),L).

onestep(prefer_over_1(A,B,C),E,L,run) :- rewrites(A,F), rewrites(B,D), rewrites(C,H), runstep(D,E,G) -> rewrites(F,I), rewrites(G,J), rewrites(H,K), rewrites(prefer_over_1(I,J,K),L).

onestep(prefer_over_1(A,B,C),K,R,resolve) :- rewrites(A,D), rewrites(B,E), rewrites(C,F), pre_comp(K,I), onestep(D,I,L,resolve), mid_comp(I,J), pre_comp(J,G), onestep(E,G,M,resolve), mid_comp(G,H), onestep(F,H,N,resolve), post_comp(G,H,J), post_comp(I,J,K), rewrites(L,O), rewrites(M,P), rewrites(N,Q), rewrites(prefer_over_1(O,P,Q),R).

sigdec(prefer_over_1,computes(value),[A,computes(value),computes(value)]) :- sigdec(A,B,[abs]), subsort_rt(B,value).

rewrite(prefer_over_1(A,B,E),L) :- rewrites(A,N), decompose(C,N,[D]), rewrites(B,C), decompose(C,N,[D]), rewrites(D,H), decompose(F,N,[G]), rewrites(E,F), decompose(F,N,[G]), rewrites(G,I), rewrites(H,J), rewrites(I,K), rewrites(prefer_over(J,K),O), decompose(M,N,[O]), rewrites(M,L), decompose(M,N,[O]).

sigdec(loose_1,patt,[A,map(B,patt)]) :- sigdec(A,C,[map(B,value)]), subsort_rt(C,value).

onestep(loose_1(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(loose_1(G,H),I).

onestep(loose_1(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(loose_1(J,K),L).

sigdec(loose_1,patt,[A,computes(map(B,patt))]) :- sigdec(A,C,[map(B,value)]), subsort_rt(C,value).

onestep(loose_1(A,B),F,J,run) :- rewrites(A,D), rewrites(B,map_empty), decompose(C,D,[E]), rewrites(C,H), decompose(C,D,[E]), eq_label(F,[given=G|I]), rewrites(G,H), unobs(I), rewrites(map_empty,J).

onestep(loose_1(A,B),H,U,run) :- rewrites(A,G), rewrites(B,map_prefix(C,D,E)), rewrites(C,L), rewrites(D,R), rewrites(E,map_empty), decompose(F,G,[K]), rewrites(F,J), decompose(F,G,[K]), eq_label(H,[given=I|P]), rewrites(I,J), rewrites(contains_key(K,L),true), rewrites(map_select(K,L),N), rewrites(L,M), runcheck(M,field), checktag(M,field,_), rewrites(N,O), runcheck(O,value), checktag(O,value,Q), unobs(P), rewrites(Q,S), rewrites(R,T), rewrites(match(S,T),U).

onestep(loose_1(A,B),P,O,run) :- rewrites(A,G), rewrites(B,map_prefix(C,D,E)), rewrites(C,L), rewrites(D,_), rewrites(E,map_empty), decompose(F,G,[K]), rewrites(F,I), decompose(F,G,[K]), eq_label(P,[given=H|J]), rewrites(H,I), eq_label(J,[not_in_domain+=_|N]), rewrites(contains_key(K,L),false), rewrites(L,M), runcheck(M,field), checktag(M,field,_), unobs(N), rewrites(stuck,O), rewrites(true,Q), eq_label(P,[not_in_domain+=Q|_]).

onestep(loose_1(A,B),G,ZH,run) :- rewrites(A,Z), rewrites(B,map_prefix(C,D,E)), rewrites(C,J), rewrites(D,P), rewrites(E,ZA), decompose(F,Z,[W]), rewrites(F,I), decompose(F,Z,[W]), eq_label(G,[given=H|L]), rewrites(H,I), \+rewrites(ZA,map_empty), rewrites(J,K), runcheck(K,field), checktag(K,field,O), unobs(L), rewrites(W,N), decompose(M,Z,[N]), rewrites(M,U), decompose(M,Z,[N]), rewrites(Z,S), rewrites(O,Q), rewrites(P,R), rewrites(map1(Q,R),T), rewrites(loose_1(S,T),V), rewrites(match(U,V),ZF), rewrites(W,Y), decompose(X,Z,[Y]), rewrites(X,ZD), decompose(X,Z,[Y]), rewrites(Z,ZB), rewrites(ZA,ZC), rewrites(loose_1(ZB,ZC),ZE), rewrites(match(ZD,ZE),ZG), rewrites(accum(ZF,ZG),ZH).

onestep(loose_record(A),L,K,run) :- rewrites(A,_), rewrites(H,C), eq_label(L,[given=B|D]), rewrites(B,C), eq_label(D,[not_in_domain+=_|J]), decompose(E,F,[G]), \+rewrites(H,E), decompose(E,F,[G]), rewrites(H,I), runcheck(I,value), checktag(I,value,_), unobs(J), rewrites(stuck,K), rewrites(true,M), eq_label(L,[not_in_domain+=M|_]).

sigdec(curry_abs_1,abs,[A,abs]) :- sigdec(A,B,[abs]), subsort_rt(B,abs).

onestep(curry_abs_1(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(curry_abs_1(J,K),L).

sigdec(curry_1,value,[A,value]) :- sigdec(A,B,[abs]), subsort_rt(B,value).

onestep(curry_1(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(curry_1(G,H),I).

onestep(curry_1(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(curry_1(J,K),L).

sigdec(curry_1,computes(value),[A,computes(value)]) :- sigdec(A,B,[abs]), subsort_rt(B,value).

onestep(curry_abs_1(A,B),C,M,run) :- rewrites(A,O), rewrites(B,I), rewrites(F,E), eq_label(C,[given=D|H]), rewrites(D,E), rewrites(F,G), runcheck(G,val), checktag(G,val,J), unobs(H), rewrites(I,K), rewrites(J,L), rewrites(partial_app(K,L),P), decompose(N,O,[P]), rewrites(N,M), decompose(N,O,[P]).

rewrite(curry_1(A,B),H) :- rewrites(A,J), decompose(C,J,[D]), rewrites(B,C), decompose(C,J,[D]), rewrites(D,E), rewrites(J,F), rewrites(E,G), rewrites(curry_abs_1(F,G),K), decompose(I,J,[K]), rewrites(I,H), decompose(I,J,[K]).

sigdec(close_1,computes(D),[A,B]) :- sigdec(A,C,[B]), subsort_rt(C,computes(D)).

onestep(close_1(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(close_1(J,K),L).

onestep(close_1(A,B),C,M,run) :- rewrites(A,O), rewrites(B,I), rewrites(F,E), eq_label(C,[env=D|H]), rewrites(D,E), rewrites(F,G), runcheck(G,env), checktag(G,env,J), unobs(H), rewrites(I,K), rewrites(J,L), rewrites(closure(K,L),P), decompose(N,O,[P]), rewrites(N,M), decompose(N,O,[P]).

sigdec(occurs_within_1,boolean,[A,val]) :- sigdec(A,B,[_]), subsort_rt(B,val).

onestep(occurs_within_1(A,B),D,I,run) :- rewrites(A,E), rewrites(B,C), runstep(C,D,F) -> rewrites(E,G), rewrites(F,H), rewrites(occurs_within_1(G,H),I).

onestep(occurs_within_1(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(occurs_within_1(J,K),L).

sigdec(occurs_within_1,computes(boolean),[A,computes(val)]) :- sigdec(A,B,[_]), subsort_rt(B,val).

rewrite(occurs_within_1(A,B),E) :- rewrites(A,_), rewrites(B,C), rewrites(C,D), runcheck(D,constant), checktag(D,constant,_), rewrites(false,E).

rewrite(occurs_within_1(A,B),F) :- rewrites(A,D), decompose(C,D,[E]), rewrites(B,C), decompose(C,D,[E]), rewrites(E,_), rewrites(true,F).

rewrite(occurs_within_1(A,B),O) :- rewrites(A,K), decompose(C,H,[D]), rewrites(B,C), decompose(C,H,[D]), rewrites(D,L), decompose(E,H,[L]), rewrites(E,F), decompose(E,H,[L]), runcheck(F,val), checktag(F,val,_), decompose(G,H,[L]), decompose(I,K,[J]), \+rewrites(G,I), decompose(G,H,[L]), decompose(I,K,[J]), rewrites(K,M), rewrites(L,N), rewrites(occurs_within_1(M,N),O).

rewrite(occurs_within_1(A,B),R) :- rewrites(A,L), decompose(C,G,[D,E]), rewrites(B,C), decompose(C,G,[D,E]), rewrites(D,I), rewrites(E,M), decompose(F,G,[I,M]), rewrites(F,H), decompose(F,G,[I,M]), runcheck(H,val), checktag(H,val,_), rewrites(L,J), rewrites(I,K), rewrites(occurs_within_1(J,K),P), rewrites(L,N), rewrites(M,O), rewrites(occurs_within_1(N,O),Q), rewrites(or(P,Q),R).

rewrite(occurs_within_1(A,B),X) :- rewrites(A,R), decompose(C,H,[D,E,F]), rewrites(B,C), decompose(C,H,[D,E,F]), rewrites(D,J), rewrites(E,M), rewrites(F,S), decompose(G,H,[J,M,S]), rewrites(G,I), decompose(G,H,[J,M,S]), runcheck(I,val), checktag(I,val,_), rewrites(R,K), rewrites(J,L), rewrites(occurs_within_1(K,L),P), rewrites(R,N), rewrites(M,O), rewrites(occurs_within_1(N,O),Q), rewrites(or(P,Q),V), rewrites(R,T), rewrites(S,U), rewrites(occurs_within_1(T,U),W), rewrites(or(V,W),X).

sigdec(invert_1,patt,[A,patt,patt]) :- sigdec(A,B,[_,_]), subsort_rt(B,passable).

onestep(invert_1(A,B,C),K,R,resolve) :- rewrites(A,D), rewrites(B,E), rewrites(C,F), pre_comp(K,I), onestep(D,I,L,resolve), mid_comp(I,J), pre_comp(J,G), onestep(E,G,M,resolve), mid_comp(G,H), onestep(F,H,N,resolve), post_comp(G,H,J), post_comp(I,J,K), rewrites(L,O), rewrites(M,P), rewrites(N,Q), rewrites(invert_1(O,P,Q),R).

sigdec(invert_1,patt,[A,patt]) :- sigdec(A,B,[_]), subsort_rt(B,passable).

onestep(invert_1(A,B),G,L,resolve) :- rewrites(A,C), rewrites(B,D), pre_comp(G,E), onestep(C,E,H,resolve), mid_comp(E,F), onestep(D,F,I,resolve), post_comp(E,F,G), rewrites(H,J), rewrites(I,K), rewrites(invert_1(J,K),L).

sigdec(invert_1,patt,[A]) :- sigdec(A,B,[]), subsort_rt(B,value).

onestep(invert_1(A),C,F,resolve) :- rewrites(A,B), onestep(B,C,D,resolve), rewrites(D,E), rewrites(invert_1(E),F).

onestep(invert_1(A,B,C),F,T,run) :- rewrites(A,N), rewrites(B,L), rewrites(C,P), decompose(D,N,[I,E]), rewrites(D,H), decompose(D,N,[I,E]), eq_label(F,[given=G|K]), rewrites(G,H), rewrites(I,J), M=[given=J|K], runstep(L,M,O) -> rewrites(N,Q), rewrites(O,R), rewrites(P,S), rewrites(invert_1(Q,R,S),T).

onestep(invert_1(A,B,C),F,T,run) :- rewrites(A,N), rewrites(B,O), rewrites(C,L), decompose(D,N,[E,I]), rewrites(D,H), decompose(D,N,[E,I]), eq_label(F,[given=G|K]), rewrites(G,H), rewrites(I,J), M=[given=J|K], runstep(L,M,P) -> rewrites(N,Q), rewrites(O,R), rewrites(P,S), rewrites(invert_1(Q,R,S),T).

onestep(invert_1(A,B,C),H,T,run) :- rewrites(A,E), rewrites(B,K), rewrites(C,M), decompose(D,E,[F,G]), rewrites(D,J), decompose(D,E,[F,G]), eq_label(H,[given=I|O]), rewrites(I,J), rewrites(K,L), runcheck(L,env), checktag(L,env,P), rewrites(M,N), runcheck(N,env), checktag(N,env,Q), unobs(O), rewrites(P,R), rewrites(Q,S), rewrites(map_union(R,S),T).

onestep(invert_1(A,B,C),O,N,run) :- rewrites(A,H), rewrites(B,_), rewrites(C,_), rewrites(K,E), eq_label(O,[given=D|F]), rewrites(D,E), eq_label(F,[not_in_domain+=_|M]), decompose(G,H,[I,J]), \+rewrites(K,G), decompose(G,H,[I,J]), rewrites(K,L), runcheck(L,passable), checktag(L,passable,_), unobs(M), rewrites(stuck,N), rewrites(true,P), eq_label(O,[not_in_domain+=P|_]).

onestep(invert_1(A,B),D,P,run) :- rewrites(A,L), rewrites(B,J), decompose(C,L,[G]), rewrites(C,F), decompose(C,L,[G]), eq_label(D,[given=E|I]), rewrites(E,F), rewrites(G,H), K=[given=H|I], runstep(J,K,M) -> rewrites(L,N), rewrites(M,O), rewrites(invert_1(N,O),P).

onestep(invert_1(A,B),F,M,run) :- rewrites(A,D), rewrites(B,I), decompose(C,D,[E]), rewrites(C,H), decompose(C,D,[E]), eq_label(F,[given=G|K]), rewrites(G,H), rewrites(I,J), runcheck(J,env), checktag(J,env,L), unobs(K), rewrites(L,M).

onestep(invert_1(A,B),M,L,run) :- rewrites(A,G), rewrites(B,_), rewrites(I,D), eq_label(M,[given=C|E]), rewrites(C,D), eq_label(E,[not_in_domain+=_|K]), decompose(F,G,[H]), \+rewrites(I,F), decompose(F,G,[H]), rewrites(I,J), runcheck(J,passable), checktag(J,passable,_), unobs(K), rewrites(stuck,L), rewrites(true,N), eq_label(M,[not_in_domain+=N|_]).

onestep(invert_1(A),C,G,run) :- rewrites(A,B), rewrites(B,E), eq_label(C,[given=D|F]), rewrites(D,E), unobs(F), rewrites(map_empty,G).

onestep(invert_1(A),J,I,run) :- rewrites(A,E), rewrites(F,C), eq_label(J,[given=B|D]), rewrites(B,C), eq_label(D,[not_in_domain+=_|H]), \+rewrites(F,E), rewrites(F,G), runcheck(G,passable), checktag(G,passable,_), unobs(H), rewrites(stuck,I), rewrites(true,K), eq_label(J,[not_in_domain+=K|_]).

